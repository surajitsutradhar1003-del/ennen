// Muvio Cinematic Database - Firebase Cloud Messaging Service Worker
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging-compat.js');

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Fetch active config dynamically to remain synchronized with current project settings
fetch('/firebase-applet-config.json')
  .then(response => response.json())
  .then(firebaseConfig => {
    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();

    messaging.onBackgroundMessage((payload) => {
      console.log('[firebase-messaging-sw.js] Observed background message payload: ', payload);
      const notificationTitle = payload.notification?.title || 'Muvio Broadcast';
      const notificationOptions = {
        body: payload.notification?.body || 'New cinematics, comments or reviews are hot!',
        icon: payload.notification?.image || payload.notification?.icon || 'https://images.unsplash.com/photo-1542204172-e7052809a936?auto=format&fit=crop&q=80&w=1200',
        badge: '/assets/icon-badge.png',
        data: payload.data
      };

      self.registration.showNotification(notificationTitle, notificationOptions);
    });
  })
  .catch(err => {
    console.warn('Silent FCM Service Worker dynamic loader bypassed (custom sandbox or offline environment).', err);
  });
