/**
 * Muvio Push Messaging Portal - Cloudflare Worker
 * 
 * Secure gateway routing FCM HTTP v1 notifications.
 * Uses Web Crypto APIs natively to handle JSON Web Tokens (RS256)
 * exchanging the Firebase Service Account credentials for Google OAuth access tokens.
 * 
 * Environment Variables Required on Cloudflare:
 * - FIREBASE_PROJECT_ID: The id of your Firebase project.
 * - FIREBASE_SERVICE_ACCOUNT_JSON: The text of your service-account JSON key.
 */

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

export default {
  async fetch(request, env) {
    // Handle CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: CORS_HEADERS
      });
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Only POST requests are accepted." }), {
        status: 405,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    try {
      const payload = await request.json();
      const { tokens, notification, data } = payload;

      if (!tokens || !Array.isArray(tokens) || tokens.length === 0) {
        return new Response(JSON.stringify({ error: "recipient tokens must be a non-empty array." }), {
          status: 400,
          headers: { "Content-Type": "application/json", ...CORS_HEADERS }
        });
      }

      if (!notification || !notification.title || !notification.body) {
        return new Response(JSON.stringify({ error: "notification object with title and body is mandatory." }), {
          status: 400,
          headers: { "Content-Type": "application/json", ...CORS_HEADERS }
        });
      }

      const projectId = env.FIREBASE_PROJECT_ID;
      const saRaw = env.FIREBASE_SERVICE_ACCOUNT_JSON;

      if (!projectId || !saRaw) {
        return new Response(JSON.stringify({ error: "Gateway not configured. Ensure FIREBASE_PROJECT_ID and FIREBASE_SERVICE_ACCOUNT_JSON are bound on Cloudflare." }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...CORS_HEADERS }
        });
      }

      // Exchange service account credentials for Google OAuth access token
      const accessToken = await getGoogleAccessToken(saRaw);

      // Distribute payload to individual tokens via FCM HTTP v1
      const results = [];
      let successCount = 0;
      let failureCount = 0;

      for (const token of tokens) {
        const fcmUrl = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;
        const fcmPayload = {
          message: {
            token: token,
            notification: {
              title: notification.title,
              body: notification.body,
              ...(notification.image ? { image: notification.image } : {})
            },
            ...(data ? { data } : {})
          }
        };

        try {
          const fcmResponse = await fetch(fcmUrl, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${accessToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify(fcmPayload)
          });

          const fcmResult = await fcmResponse.json();
          if (fcmResponse.ok) {
            successCount++;
            results.push({ token, status: "success", name: fcmResult.name });
          } else {
            failureCount++;
            results.push({ token, status: "error", error: fcmResult.error?.message || "Rejected" });
          }
        } catch (err) {
          failureCount++;
          results.push({ token, status: "error", error: err.message });
        }
      }

      return new Response(JSON.stringify({
        success: true,
        successCount,
        failureCount,
        results
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: err.message || "Internal server exception." }), {
        status: 500,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }
  }
};

// Pure JavaScript OAuth accessor using Web Crypto standard
async function getGoogleAccessToken(serviceAccountJson) {
  const sa = typeof serviceAccountJson === 'string' ? JSON.parse(serviceAccountJson) : serviceAccountJson;
  const privateKeyPem = sa.private_key;
  const clientEmail = sa.client_email;

  const pemHeader = "-----BEGIN PRIVATE KEY-----";
  const pemFooter = "-----END PRIVATE KEY-----";
  const pemContents = privateKeyPem
    .replace(pemHeader, "")
    .replace(pemFooter, "")
    .replace(/\s+/g, "");
  
  const binaryDer = base64ToArrayBuffer(pemContents);

  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryDer,
    {
      name: "RSASSA-PKCS1-v1_5",
      hash: { name: "SHA-256" },
    },
    false,
    ["sign"]
  );

  const header = { alg: "RS256", typ: "JWT" };
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    iss: clientEmail,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const message = `${encodedHeader}.${encodedPayload}`;

  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    cryptoKey,
    new TextEncoder().encode(message)
  );

  const encodedSignature = base64UrlEncodeArrayBuffer(signature);
  const jwt = `${message}.${encodedSignature}`;

  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    }).toString()
  });

  const tokenData = await tokenResponse.json();
  if (!tokenResponse.ok) {
    throw new Error(`Google OAuth error: ${JSON.stringify(tokenData)}`);
  }
  return tokenData.access_token;
}

function base64ToArrayBuffer(base64) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

function base64UrlEncode(str) {
  const bytes = new TextEncoder().encode(str);
  return base64UrlEncodeArrayBuffer(bytes);
}

function base64UrlEncodeArrayBuffer(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary)
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}
