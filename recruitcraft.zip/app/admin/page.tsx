'use client';

import React, { useEffect, useState } from 'react';
import AdminPanelPage from '../../src/components/AdminPanelPage';
import { subscribeToAuth, UserProfile, updateSettingValue, getSettingValue } from '../../src/lib/firebase';

export default function AdminPage() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLandingPage, setShowLandingPage] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToAuth((state) => {
      setCurrentUser(state.user);
      setLoading(state.loading);
    });

    async function loadSetting() {
      try {
        const val = await getSettingValue('show_landing_page', true);
        setShowLandingPage(val);
      } catch (err) {
        console.warn('Failed to load global landing page setting:', err);
      }
    }
    loadSetting();

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!loading) {
      if (!currentUser || currentUser.role !== 'admin') {
        if (typeof window !== 'undefined') {
          // Fallback location change or direct state navigation if used in router
          window.location.href = '/explore';
        }
      }
    }
  }, [currentUser, loading]);

  const handleToggleSetting = async (newValue: boolean) => {
    setShowLandingPage(newValue);
    await updateSettingValue('show_landing_page', newValue);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#070707] text-white flex flex-col items-center justify-center p-6 select-none font-sans">
        <span className="font-display font-black text-xl text-[#E50914] crimson-glow tracking-widest animate-pulse">
          LOADING ADMIN CHANNEL...
        </span>
      </div>
    );
  }

  if (!currentUser || currentUser.role !== 'admin') {
    return null;
  }

  const handleNavigate = (route: string) => {
    if (typeof window !== 'undefined') {
      window.location.href = route;
    }
  };

  return (
    <div className="min-h-screen bg-[#070707] text-white">
      <AdminPanelPage
        onNavigate={handleNavigate}
        showLandingPage={showLandingPage}
        onToggleLandingPage={handleToggleSetting}
      />
    </div>
  );
}
