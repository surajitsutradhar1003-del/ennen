export async function onRequestPost(context: any) {
  const { request, env } = context;

  const colorMap: Record<string, string> = {
    "Thrill & Action (Adrenaline)": "#E50914",
    "Drama & Depth (Intellectual)": "#3B82F6",
    "Comedy & Leisure (Amusement)": "#10B981",
    "Romance & Warmth (Emotional)": "#F97316"
  };

  let title = '', genre = '', overview = '', model = 'gemini-3.5-flash';
  try {
    const body = await request.json();
    title = body.title || '';
    genre = body.genre || '';
    overview = body.overview || '';
    model = body.model || 'gemini-3.5-flash';
  } catch {
    console.log('[vibe-chart] Body parse failed');
  }

  console.log('[vibe-chart] title:', title, '| genre:', genre);

  function getGenreFallback(normGenre: string) {
    if (normGenre.includes('action') || normGenre.includes('thriller')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 50, color: "#E50914", desc: "High-octane sequences and intense stakes." },
          { label: "Drama & Depth (Intellectual)", value: 25, color: "#3B82F6", desc: "Complex character motivations." },
          { label: "Comedy & Leisure (Amusement)", value: 10, color: "#10B981", desc: "Light relief moments." },
          { label: "Romance & Warmth (Emotional)", value: 15, color: "#F97316", desc: "Character bonds and warmth." }
        ],
        profile: "THRILLING"
      };
    } else if (normGenre.includes('romance') || normGenre.includes('drama')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 10, color: "#E50914", desc: "Tension-filled turning points." },
          { label: "Drama & Depth (Intellectual)", value: 35, color: "#3B82F6", desc: "Rich emotional storytelling." },
          { label: "Comedy & Leisure (Amusement)", value: 15, color: "#10B981", desc: "Warm lighthearted moments." },
          { label: "Romance & Warmth (Emotional)", value: 40, color: "#F97316", desc: "Deep emotional connections." }
        ],
        profile: "EMOTIONAL"
      };
    } else if (normGenre.includes('horror') || normGenre.includes('mystery')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 45, color: "#E50914", desc: "Spine-chilling suspenseful sequences." },
          { label: "Drama & Depth (Intellectual)", value: 30, color: "#3B82F6", desc: "Psychological depth and mystery." },
          { label: "Comedy & Leisure (Amusement)", value: 5, color: "#10B981", desc: "Rare dark humor moments." },
          { label: "Romance & Warmth (Emotional)", value: 20, color: "#F97316", desc: "Character vulnerability and bonds." }
        ],
        profile: "DARK"
      };
    } else if (normGenre.includes('comedy')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 10, color: "#E50914", desc: "Energetic comedic sequences." },
          { label: "Drama & Depth (Intellectual)", value: 20, color: "#3B82F6", desc: "Underlying meaningful themes." },
          { label: "Comedy & Leisure (Amusement)", value: 55, color: "#10B981", desc: "Humor-driven entertainment." },
          { label: "Romance & Warmth (Emotional)", value: 15, color: "#F97316", desc: "Heartwarming character moments." }
        ],
        profile: "AMUSING"
      };
    } else if (normGenre.includes('sci-fi') || normGenre.includes('science fiction') || normGenre.includes('fantasy')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 35, color: "#E50914", desc: "Epic world-scale confrontations." },
          { label: "Drama & Depth (Intellectual)", value: 40, color: "#3B82F6", desc: "Mind-bending concepts and lore." },
          { label: "Comedy & Leisure (Amusement)", value: 10, color: "#10B981", desc: "Light moments of wonder." },
          { label: "Romance & Warmth (Emotional)", value: 15, color: "#F97316", desc: "Bonds forged across worlds." }
        ],
        profile: "ATMOSPHERIC"
      };
    } else if (normGenre.includes('animation') || normGenre.includes('anime')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 25, color: "#E50914", desc: "Vibrant stylized action sequences." },
          { label: "Drama & Depth (Intellectual)", value: 25, color: "#3B82F6", desc: "Layered character journeys." },
          { label: "Comedy & Leisure (Amusement)", value: 30, color: "#10B981", desc: "Playful and expressive humor." },
          { label: "Romance & Warmth (Emotional)", value: 20, color: "#F97316", desc: "Heartfelt emotional moments." }
        ],
        profile: "VIBRANT"
      };
    } else if (normGenre.includes('documentary')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 15, color: "#E50914", desc: "Real-world tension and stakes." },
          { label: "Drama & Depth (Intellectual)", value: 55, color: "#3B82F6", desc: "Deep factual and human insights." },
          { label: "Comedy & Leisure (Amusement)", value: 10, color: "#10B981", desc: "Moments of levity." },
          { label: "Romance & Warmth (Emotional)", value: 20, color: "#F97316", desc: "Human connection stories." }
        ],
        profile: "INSIGHTFUL"
      };
    } else if (normGenre.includes('war') || normGenre.includes('history')) {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 40, color: "#E50914", desc: "Intense battlefield sequences." },
          { label: "Drama & Depth (Intellectual)", value: 40, color: "#3B82F6", desc: "Heavy moral and human cost." },
          { label: "Comedy & Leisure (Amusement)", value: 5, color: "#10B981", desc: "Rare moments of soldier camaraderie." },
          { label: "Romance & Warmth (Emotional)", value: 15, color: "#F97316", desc: "Love tested by conflict." }
        ],
        profile: "INTENSE"
      };
    } else {
      return {
        vibes: [
          { label: "Thrill & Action (Adrenaline)", value: 30, color: "#E50914", desc: "Engaging high-stakes sequences." },
          { label: "Drama & Depth (Intellectual)", value: 35, color: "#3B82F6", desc: "Rich narrative and character depth." },
          { label: "Comedy & Leisure (Amusement)", value: 15, color: "#10B981", desc: "Lighthearted relief moments." },
          { label: "Romance & Warmth (Emotional)", value: 20, color: "#F97316", desc: "Emotional warmth and connection." }
        ],
        profile: "CINEMATIC"
      };
    }
  }

  if (!overview && !title) {
    return new Response(JSON.stringify(getGenreFallback(genre.toLowerCase())), {
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }

  const GEMINI_API_KEY = env.GEMINI_API_KEY || '';

  if (!GEMINI_API_KEY) {
    console.log('[vibe-chart] No API key, using fallback');
    return new Response(JSON.stringify(getGenreFallback(genre.toLowerCase())), {
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }

  try {
    console.log('[vibe-chart] Calling Gemini for:', title);

    const prompt = `You are a cinematic vibe analyzer. Analyze this movie/show and break down its emotional and tonal composition into exactly 4 vibe categories.

Title: "${title || 'Unknown'}"
Genre: "${genre || 'Unknown'}"
Synopsis: "${overview || 'No synopsis available'}"

Return ONLY a valid JSON object (no markdown, no explanation) with:
- "vibes": array of exactly 4 objects, each with:
  - "label": one of these exact labels: "Thrill & Action (Adrenaline)", "Drama & Depth (Intellectual)", "Comedy & Leisure (Amusement)", "Romance & Warmth (Emotional)"
  - "value": integer percentage (all 4 must add up to exactly 100)
  - "desc": 1 short sentence describing how this vibe appears in this specific content (max 8 words)
- "profile": 1 word that best describes the overall vibe (e.g. "INTENSE", "EMOTIONAL", "THRILLING", "ATMOSPHERIC", "HEARTWARMING", "DARK", "ADVENTUROUS")

Base the percentages on the actual content tone.`;

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.7
          }
        })
      }
    );

    console.log('[vibe-chart] Gemini status:', geminiRes.status);

    if (!geminiRes.ok) {
      console.log('[vibe-chart] Gemini failed, using fallback');
      return new Response(JSON.stringify(getGenreFallback(genre.toLowerCase())), {
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    const geminiData: any = await geminiRes.json();
    const rawText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    console.log('[vibe-chart] Gemini raw:', rawText.substring(0, 100));

    const parsed = JSON.parse(rawText.replace(/```json|```/g, '').trim());

    if (!parsed.vibes || !Array.isArray(parsed.vibes) || parsed.vibes.length !== 4) {
      console.log('[vibe-chart] Invalid vibes array, using fallback');
      return new Response(JSON.stringify(getGenreFallback(genre.toLowerCase())), {
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    parsed.vibes = parsed.vibes.map((v: any) => ({
      ...v,
      color: colorMap[v.label] || "#E50914"
    }));

    console.log('[vibe-chart] Success! Profile:', parsed.profile);

    return new Response(JSON.stringify(parsed), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });

  } catch (err: any) {
    console.log('[vibe-chart] Exception:', err?.message);
    return new Response(JSON.stringify(getGenreFallback(genre.toLowerCase())), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
  }
}

export async function onRequestOptions() {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}
