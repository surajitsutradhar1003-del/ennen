// Cloudflare Pages Function: /api/push/broadcast
// POST /api/push/broadcast
// env vars needed: FCM_SERVER_KEY (Firebase Cloud Messaging Server Key)

export async function onRequestPost(context: any) {
  const { request, env } = context;

  // CORS preflight
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  let title = '';
  let body = '';
  let iconUrl = '';

  try {
    const payload = await request.json();
    title = payload.title || '';
    body = payload.body || '';
    iconUrl = payload.iconUrl || '';
  } catch {
    return new Response(JSON.stringify({ success: false, error: 'Invalid JSON body' }), {
      status: 400,
      headers: corsHeaders,
    });
  }

  if (!title || !body) {
    return new Response(JSON.stringify({ success: false, error: 'title and body are required' }), {
      status: 400,
      headers: corsHeaders,
    });
  }

  const fcmServerKey = env.FCM_SERVER_KEY;
  if (!fcmServerKey) {
    return new Response(JSON.stringify({ success: false, error: 'FCM_SERVER_KEY not configured in environment' }), {
      status: 500,
      headers: corsHeaders,
    });
  }

  // Firebase Cloud Messaging Legacy HTTP API (send to topic "all" — all subscribed users)
  const fcmPayload = {
    to: '/topics/all',
    notification: {
      title,
      body,
      icon: iconUrl || '/assets/icon.png',
      click_action: env.APP_URL || '/',
    },
    data: {
      title,
      body,
      url: env.APP_URL || '/',
    },
  };

  try {
    const fcmResponse = await fetch('https://fcm.googleapis.com/fcm/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `key=${fcmServerKey}`,
      },
      body: JSON.stringify(fcmPayload),
    });

    const fcmResult = await fcmResponse.json() as any;

    if (fcmResult.failure && fcmResult.failure > 0 && !fcmResult.message_id) {
      return new Response(JSON.stringify({ success: false, error: 'FCM send failed', details: fcmResult }), {
        status: 500,
        headers: corsHeaders,
      });
    }

    return new Response(JSON.stringify({ success: true, result: fcmResult }), {
      status: 200,
      headers: corsHeaders,
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ success: false, error: err.message || 'FCM request failed' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

// Handle CORS preflight
export async function onRequestOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
