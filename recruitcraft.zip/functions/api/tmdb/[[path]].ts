export async function onRequest(context: any) {
  const { request, env, params } = context;
  const url = new URL(request.url);
  const path = params.path ? (Array.isArray(params.path) ? params.path.join('/') : params.path) : '';
  
  const tmdbKey = env.TMDB_API_KEY || '';
  const tmdbUrl = new URL(`https://api.themoviedb.org/3/${path}`);
  
  url.searchParams.forEach((val: string, key: string) => {
    tmdbUrl.searchParams.append(key, val);
  });
  tmdbUrl.searchParams.set('api_key', tmdbKey);

  const response = await fetch(tmdbUrl.toString(), {
    headers: { 'Accept': 'application/json' }
  });

  const data = await response.json();
  
  return new Response(JSON.stringify(data), {
    status: response.status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
  });
}
