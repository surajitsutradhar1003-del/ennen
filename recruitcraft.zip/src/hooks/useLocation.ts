import { useState, useEffect } from 'react';
import { AppRoute } from '../types';

export function useLocation() {
  const [path, setPath] = useState<AppRoute>(() => {
    const currentPath = window.location.pathname;
    const currentFull = (window.location.pathname + window.location.search) as AppRoute;
    const allowed = ['/', '/explore', '/schedule', '/spaces', '/collections', '/profile', '/login', '/register', '/admin', '/accounts/edit', '/news', '/rankings/monthly', '/rankings/top100'];
    if (allowed.includes(currentPath) || currentPath.startsWith('/content/') || currentPath.startsWith('/post/') || currentPath.startsWith('/spaces/post/') || currentPath.startsWith('/spaces/multi-') || currentPath.startsWith('/spaces/') || currentPath.startsWith('/collections/') || currentPath.startsWith('/u/') || currentPath.startsWith('/rankings/')) {
      return currentFull;
    }
    return '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      const currentPath = window.location.pathname;
      const currentFull = (window.location.pathname + window.location.search) as AppRoute;
      const allowed = ['/', '/explore', '/schedule', '/spaces', '/collections', '/profile', '/login', '/register', '/admin', '/accounts/edit', '/news', '/rankings/monthly', '/rankings/top100'];
      if (allowed.includes(currentPath) || currentPath.startsWith('/content/') || currentPath.startsWith('/post/') || currentPath.startsWith('/spaces/post/') || currentPath.startsWith('/spaces/multi-') || currentPath.startsWith('/spaces/') || currentPath.startsWith('/collections/') || currentPath.startsWith('/u/') || currentPath.startsWith('/rankings/')) {
        setPath(currentFull);
      } else {
        setPath('/');
      }
    };

    window.addEventListener('popstate', handlePopState);
    
    // Intercept clicks on links with data-nav attribute to enable SPA navigation
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      if (anchor && anchor.getAttribute('data-nav') === 'true') {
        e.preventDefault();
        const href = anchor.getAttribute('href') as AppRoute;
        if (href) {
          window.history.pushState(null, '', href);
          setPath(href);
        }
      }
    };

    document.addEventListener('click', handleGlobalClick);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('click', handleGlobalClick);
    };
  }, []);

  const navigate = (to: AppRoute) => {
    window.history.pushState(null, '', to);
    setPath(to);
  };

  return { path, navigate };
}
