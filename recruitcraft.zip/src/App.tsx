import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Sparkles, X } from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Header from './components/Header';
import BottomNavigation from './components/BottomNavigation';
import SideDrawer from './components/SideDrawer';
import LandingPage from './components/LandingPage';
import ExplorePageContent from './components/ExplorePageContent';
import PlaceholderPage from './components/PlaceholderPage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import AdminPanelPage from './components/AdminPanelPage';
import ContentDetailsPage from './components/ContentDetailsPage';
import SpacesPage from './components/SpacesPage';
import CollectionsPage from './components/CollectionsPage';
import SchedulePage from './components/SchedulePage';
import ProfilePage from './components/ProfilePage';
import AccountSettingsPage from './components/AccountSettingsPage';
import SearchOverlay from './components/SearchOverlay';
import AIChatModal from './components/AIChatModal';
import ScrollToTop from './components/ScrollToTop';
import { useLocation } from './hooks/useLocation';
import { 
  getSettingValue, 
  updateSettingValue, 
  subscribeToAuth, 
  initializeAuthMonitor, 
  registerToastCallback,
  UserProfile 
} from './lib/firebase';
import { AppRoute } from './types';
import { syncCatalogFromFirebase } from './lib/adminCatalog';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}

export function AppContent() {
  const { path, navigate } = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [showLandingPage, setShowLandingPage] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [showGlobalAuthModal, setShowGlobalAuthModal] = useState(false);

  // Listen to Auth State and Config settings
  useEffect(() => {
    // 0. Sync catalog from Firebase on startup
    syncCatalogFromFirebase();

    // 1. Subscribe to Toast Events from Service Actions
    registerToastCallback((msg, type) => {
      setToast({ message: msg, type });
      setTimeout(() => {
        setToast(null);
      }, 3500);
    });

    // 2. Initialize and monitor Authentication changes
    initializeAuthMonitor();

    const unsubscribe = subscribeToAuth((state) => {
      setCurrentUser(state.user);
      setAuthLoading(state.loading);

      if (state.user && typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'default') {
          setTimeout(() => {
            Notification.requestPermission().then(permission => {
              if (permission === 'granted') {
                console.log('Firebase Cloud Messaging notification capabilities granted by client user.');
              }
            }).catch(e => console.warn('Request permission exception: ', e));
          }, 3000);
        }
      }
    });

    // 3. Retrieve system settings once on startup
    async function loadSetting() {
      try {
        const val = await getSettingValue('show_landing_page', true);
        setShowLandingPage(val);
      } catch (err) {
        console.warn('Failed to load global landing page setting:', err);
      } finally {
        setIsLoading(false);
      }
    }
    
    loadSetting();

    return () => {
      unsubscribe();
    };
  }, []);

  // Real-time Gateway Authorization Guard (SPA Router Middleware)
  useEffect(() => {
    if (authLoading) return;

    const isPublicPath = 
      path === '/' ||
      path.startsWith('/explore') ||
      path.startsWith('/rankings/') ||
      path.startsWith('/content/') ||
      path.startsWith('/post/') ||
      path === '/schedule' ||
      path.startsWith('/spaces') ||
      path.startsWith('/collections') ||
      path === '/news' ||
      path.startsWith('/u/') ||
      path === '/login' ||
      path === '/register';

    if (!currentUser) {
      // Unauthenticated state: enforce login/register pathways for protected routes only
      if (!isPublicPath) {
        navigate('/login');
      }
    } else {
      // Authenticated state: bypass login/register, enforce admin permissions
      if (path === '/login' || path === '/register') {
        if (currentUser.role === 'admin') {
          navigate('/admin');
        } else {
          navigate('/explore');
        }
      } else if (path === '/admin') {
        if (currentUser.role !== 'admin') {
          setToast({ message: 'Access Denied. Admins role required.', type: 'error' });
          navigate('/explore');
        }
      }
    }
  }, [path, currentUser, authLoading]);

  // Update setting value function
  const handleToggleSetting = async (newValue: boolean) => {
    setShowLandingPage(newValue);
    await updateSettingValue('show_landing_page', newValue);
  };

  const handleOpenMenu = () => {
    setIsMenuOpen(true);
  };
  const handleCloseMenu = () => setIsMenuOpen(false);

  // Render the current view according to routes & landing configuration
  const renderCurrentView = () => {
    // Enforce full page loaders during verification checks
    if (authLoading || isLoading) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center py-40 select-none">
          <span className="font-display font-black text-2xl text-[#E50914] crimson-glow tracking-widest animate-pulse">
            LOADING MUVIO...
          </span>
          <div className="w-12 h-0.5 bg-[#E50914] mt-4 rounded-full animate-pulse"></div>
        </div>
      );
    }

    if (path.startsWith('/content/')) {
      const slug = path.replace('/content/', '');
      return <ContentDetailsPage slug={slug} onNavigate={navigate} />;
    }

    if (path.startsWith('/post/')) {
      const slug = path.replace('/post/', '');
      return <ContentDetailsPage slug={slug} onNavigate={navigate} />;
    }

    if (path.startsWith('/spaces')) {
      return <SpacesPage onNavigate={navigate} currentUser={currentUser} onTriggerLogin={() => setShowGlobalAuthModal(true)} />;
    }

    if (path.startsWith('/collections')) {
      return <CollectionsPage onNavigate={navigate} currentUser={currentUser} onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} />;
    }

    if (path.startsWith('/u/')) {
      const parts = path.split('/');
      const username = parts[2] || '';
      const autoSelectReviews = parts[3] === 'reviews' || path.endsWith('/reviews');
      return (
        <ProfilePage 
          targetUsername={username} 
          currentUser={currentUser} 
          onNavigate={navigate} 
          onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} 
          initialTab={autoSelectReviews ? 'REVIEWS' : undefined}
        />
      );
    }

    if (path.startsWith('/explore') || path.startsWith('/rankings/')) {
      return (
        <ExplorePageContent 
          onNavigate={navigate} 
          currentUser={currentUser} 
          onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} 
        />
      );
    }

    switch (path) {
      case '/accounts/edit':
        return <AccountSettingsPage currentUser={currentUser} onNavigate={navigate} />;
      case '/login':
        return <LoginPage onNavigate={navigate} />;
      case '/register':
        return <RegisterPage onNavigate={navigate} />;
      case '/admin':
        return (
          <AdminPanelPage 
            onNavigate={navigate} 
            showLandingPage={showLandingPage} 
            onToggleLandingPage={handleToggleSetting} 
          />
        );
      case '/':
        if (showLandingPage) {
          return (
            <LandingPage 
              onExplore={() => navigate('/explore')} 
              showLandingPageSetting={showLandingPage} 
            />
          );
        }
        return <ExplorePageContent onNavigate={navigate} currentUser={currentUser} onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} />;
      case '/explore':
        return <ExplorePageContent onNavigate={navigate} currentUser={currentUser} onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} />;
      case '/news':
        return <PlaceholderPage title="News Desk" description="The latest cinematic announcements, exclusive headlines, and production leaks." iconName="Tv" />;
      case '/schedule':
        return <SchedulePage onNavigate={navigate} currentUser={currentUser} onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} />;
      case '/profile':
        if (currentUser) {
          setTimeout(() => navigate(`/u/${currentUser.username}`), 0);
        } else {
          setTimeout(() => navigate('/login'), 0);
        }
        return (
          <div className="flex-1 flex items-center justify-center py-40">
            <span className="font-mono text-xs text-gray-500 animate-pulse">REDIRECTING OBSERVER NETWORK...</span>
          </div>
        );
      default:
        // Default safety gate
        return <ExplorePageContent onNavigate={navigate} currentUser={currentUser} onTriggerAuthPrompt={() => setShowGlobalAuthModal(true)} />;
    }
  };

  const isAuthPage = path === '/login' || path === '/register';
  const hideNav = ['/', '/login', '/register', '/forgot-password'].includes(path);

  return (
    <div className="min-h-screen bg-[#000000] text-white flex flex-col font-sans transition-colors duration-300 relative overflow-x-hidden">
      {/* Scroll restoration */}
      <ScrollToTop path={path} />

      {/* Immersive UI premium radial spotlight glow element */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(229,9,20,0.12)_0%,transparent_70%)] pointer-events-none z-0"></div>

      {/* Dynamic Toast Notifications */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className={`fixed top-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-2xl border text-xs font-bold shadow-[0_15px_40px_rgba(0,0,0,0.8)] flex items-center gap-2.5 whitespace-nowrap select-none ${
              toast.type === 'success' 
                ? 'bg-[#0a160d]/95 border-[#22C55E]/20 text-[#22C55E]' 
                : 'bg-[#15070a]/95 border-[#E50914]/20 text-[#FF4444]'
            }`}
            id="global-muvio-toast"
          >
            {toast.type === 'success' ? (
              <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E] animate-ping"></span>
            ) : (
              <span className="w-1.5 h-1.5 rounded-full bg-[#E50914] animate-pulse"></span>
            )}
            <span>{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top sticky header */}
      {!hideNav && (
        isAuthPage ? (
          <header className="sticky top-0 z-50 w-full h-20 px-6 md:px-10 flex items-center justify-between bg-[#0a0a0a]/60 backdrop-blur-xl border-b border-white/5">
            <div 
              onClick={() => {
                if (path === '/' || path === '/landing') {
                  // Do nothing
                } else {
                  navigate('/explore');
                }
              }}
              className="cursor-pointer flex items-center gap-2.5 group select-none"
            >
              <span className="font-display font-black tracking-tighter text-3xl text-[#E50914] italic transition-all group-hover:text-[#FF1A1A] drop-shadow-[0_0_15px_rgba(229,9,20,0.4)]">
                MUVIO
              </span>
              <span className="text-[8px] uppercase font-mono font-black tracking-widest px-1.5 py-0.5 bg-[#E50914]/12 text-[#E50914] border border-[#E50914]/20 rounded-md">
                PRE-BETA
              </span>
            </div>
          </header>
        ) : (
          <Header 
            onOpenMenu={handleOpenMenu} 
            onNavigate={navigate} 
            activePath={path} 
            currentUser={currentUser}
            onOpenSearch={() => setIsSearchOpen(true)}
            onOpenAIChat={() => setIsAIChatOpen(true)}
          />
        )
      )}

      {/* Global search overlay element */}
      <SearchOverlay 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
        onNavigate={navigate} 
        currentUser={currentUser} 
      />

      {/* Cinematic Oracle AI Chat Modal */}
      <AIChatModal
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        onNavigate={navigate}
        slugContext={path.startsWith('/content/') ? path.replace('/content/', '') : undefined}
      />

      {/* Main page content staging */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 md:px-8 py-8 relative z-10">
        {renderCurrentView()}
      </main>

      {/* Floating Bottom Navigator (hidden on login/register view gates) */}
      {!isAuthPage && !hideNav && (
        <BottomNavigation 
          currentPath={path} 
          onNavigate={navigate} 
        />
      )}

      {/* Side Slider Menu Drawer */}
      <SideDrawer 
        isOpen={isMenuOpen} 
        onClose={handleCloseMenu} 
        onNavigate={navigate} 
        currentUser={currentUser}
      />

      {/* GLOBAL AUTHENTICATION REQUIRED PROMPT OVERLAY */}
      <AnimatePresence>
        {showGlobalAuthModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-8 max-w-md w-full space-y-6 shadow-2xl relative text-center"
            >
              <button
                onClick={() => setShowGlobalAuthModal(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-[#E50914]/10 border border-[#E50914]/25 flex items-center justify-center mx-auto">
                  <Sparkles size={24} className="text-[#E50914] animate-pulse" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-black text-white uppercase tracking-tight">Authorization Required</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Authenticate your Muvio Critic credentials to claim tracking logs, custom vaults, and participate in active community debates.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => {
                    setShowGlobalAuthModal(false);
                    navigate('/login');
                  }}
                  className="bg-[#E50914] hover:bg-[#FF1A1A] text-[#ffffff] p-3.5 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    setShowGlobalAuthModal(false);
                    navigate('/register');
                  }}
                  className="bg-white/5 hover:bg-white/10 border border-white/10 text-[#ffffff] p-3.5 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Create Account
                </button>
              </div>

              <button
                onClick={() => setShowGlobalAuthModal(false)}
                className="w-full text-xs font-mono font-medium text-gray-500 hover:text-white transition-colors cursor-pointer"
              >
                Continue as Offline Guest
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
