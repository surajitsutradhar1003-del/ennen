import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, Compass, Award, Star, TrendingUp, Sparkles, LogOut, LogIn, Settings, UserCheck, Flame, Globe2, MessageSquare, Library } from 'lucide-react';
import { AppRoute } from '../types';
import { UserProfile } from '../lib/firebase';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: AppRoute) => void;
  currentUser?: UserProfile | null;
}

export default function SideDrawer({ isOpen, onClose, onNavigate, currentUser }: SideDrawerProps) {
  // Navigation elements with specific route mappings
  const browseBy = [
    { label: 'Following Activity', icon: UserCheck, route: '/explore?filter=following' },
    { label: 'Monthly Ranking', icon: Flame, route: '/rankings/monthly' },
    { label: 'Top 100', icon: TrendingUp, route: '/rankings/top100' },
    { label: 'Category', icon: Compass, route: '/explore?filter=category' },
    { label: 'Genre', icon: Play, route: '/explore?filter=genre' },
    { label: 'Country', icon: Globe2, route: '/explore?filter=country' },
    { label: 'Language', icon: Globe2, route: '/explore?filter=language' },
    { label: 'Family Friendly', icon: Star, route: '/explore?filter=family' },
    { label: 'Award Winners', icon: Award, route: '/explore?filter=awards' },
    { label: 'Muvio Select', icon: Sparkles, route: '/explore?filter=muvio-select' },
    { label: 'Anime', icon: Flame, route: '/explore?filter=anime' },
    { label: 'Franchise', icon: Library, route: '/explore?filter=franchise' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#000000]/75 backdrop-blur-sm z-50 cursor-pointer"
            id="drawer-backdrop"
          />

          {/* Drawer Body */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-sm bg-[#0a0a0a] border-l border-white/10 z-55 flex flex-col shadow-[0_0_50px_rgba(0,0,0,0.9)]"
            id="drawer-menu-container"
          >
            {/* Drawer Header */}
            <div className="p-5 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-display font-black tracking-widest text-lg text-[#E50914] crimson-glow">
                  MUVIO NAVIGATION
                </span>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg active:scale-95 transition-all outline-none"
                id="btn-close-drawer"
              >
                <X size={20} className="stroke-[2.5]" />
              </button>
            </div>

            {/* Scrollable List */}
            <div className="flex-1 overflow-y-auto px-5 py-6 space-y-8 select-none">
              {/* Browse By Section */}
              <div className="space-y-3">
                <h3 className="text-[10px] font-mono font-bold tracking-widest text-[#E50914] uppercase flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E50914] animate-pulse"></span>
                  Browse By
                </h3>
                <div className="grid grid-cols-1 gap-1.5">
                  {browseBy.map((item, index) => {
                    const IconComp = item.icon;
                    return (
                      <button
                        key={index}
                        onClick={() => {
                          onClose();
                          onNavigate(item.route);
                        }}
                        className="w-full flex items-center justify-between text-left text-sm font-medium text-gray-300 hover:text-white px-3 py-2.5 rounded-lg hover:bg-white/5 transition-all group outline-none"
                      >
                        <div className="flex items-center gap-3">
                          <IconComp size={16} className="text-gray-500 group-hover:text-[#E50914] transition-colors" />
                          <span>{item.label}</span>
                        </div>
                        <Play size={10} className="opacity-0 group-hover:opacity-100 fill-current text-[#E50914] transition-all -translate-x-2 group-hover:translate-x-0" />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Menu Options Section */}
              <div className="space-y-3">
                <h3 className="text-[10px] font-mono font-bold tracking-widest text-gray-500 uppercase flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-500"></span>
                  Menu & Actions
                </h3>
                <div className="space-y-1">
                  {currentUser ? (
                    <>
                      <button
                        onClick={() => {
                          onClose();
                          if (currentUser?.username) {
                            onNavigate(`/u/${currentUser.username}`);
                          } else {
                            onNavigate('/login');
                          }
                        }}
                        className="w-full flex items-center gap-3 text-left text-sm font-medium text-gray-300 hover:text-white px-3 py-2.5 rounded-lg hover:bg-white/5 transition-all group outline-none cursor-pointer"
                      >
                        <MessageSquare size={16} className="text-gray-500 group-hover:text-white" />
                        <span>My Reviews</span>
                      </button>

                      <button
                        onClick={() => {
                          onClose();
                          onNavigate('/accounts/edit');
                        }}
                        className="w-full flex items-center gap-3 text-left text-sm font-medium text-gray-300 hover:text-white px-3 py-2.5 rounded-lg hover:bg-white/5 transition-all group outline-none cursor-pointer"
                      >
                        <Settings size={16} className="text-gray-500 group-hover:text-white" />
                        <span>Settings</span>
                      </button>

                      <button
                        onClick={async () => {
                          onClose();
                          const { logoutUser } = await import('../lib/firebase');
                          await logoutUser();
                          onNavigate('/login');
                        }}
                        className="w-full flex items-center gap-3 text-left text-sm font-bold text-red-500 hover:text-red-400 px-3 py-2.5 rounded-lg hover:bg-red-500/10 transition-all outline-none cursor-pointer"
                        id="btn-drawer-logout"
                      >
                        <LogOut size={16} className="text-red-500" />
                        <span>Logout</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => {
                        onClose();
                        onNavigate('/login');
                      }}
                      className="w-full flex items-center gap-3 text-left text-sm font-medium text-gray-300 hover:text-white px-3 py-2.5 rounded-lg hover:bg-white/5 transition-all group outline-none cursor-pointer"
                      id="btn-drawer-login"
                    >
                      <LogIn size={16} className="text-gray-500 group-hover:text-white" />
                      <span>Login</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="p-5 border-t border-white/5 bg-[#111111]/30">
              <div className="text-center">
                <p className="text-[10px] font-mono font-bold text-gray-500">MUVIO CINEMATICS</p>
                <p className="text-[9px] font-mono text-gray-600 mt-1">© 2026 Phase 1 Initial Build</p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
