import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Calendar, 
  Award, 
  Heart, 
  MessageSquare, 
  Plus, 
  Search, 
  Grid, 
  List, 
  ChevronDown, 
  Users, 
  Globe, 
  FolderPlus, 
  ArrowRight, 
  MoreHorizontal, 
  X, 
  UserPlus, 
  UserMinus, 
  Filter,
  Camera,
  Edit3
} from 'lucide-react';
import { UserProfile, triggerToast } from '../lib/firebase';
import { 
  getUserProfileByUsername, 
  getReviewsForUser, 
  getUserCollections, 
  createCollection, 
  toggleFollowUser,
  getUserProfileByUserId,
  toggleLikeReview,
  updateUserProfile,
  getCommentsForReview
} from '../lib/userInteractions';
import { MuvioReview, UserCollection, UserWatched } from '../types';
import { getMediaDetails, getFallbackRichDetails, MuvioMedia } from '../lib/tmdb';
import { getUserWatchedItems } from '../lib/db-adapter';

const timeAgo = (dateInput: any) => {
  if (!dateInput) return '';
  try {
    let date: Date;
    if (dateInput && typeof dateInput === 'object') {
      if (typeof dateInput.toDate === 'function') {
        date = dateInput.toDate();
      } else if (typeof dateInput.seconds === 'number') {
        date = new Date(dateInput.seconds * 1000);
      } else {
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    if (isNaN(diffMs)) return '';
    const seconds = Math.floor(diffMs / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days}d ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo ago`;
    return `${Math.floor(months / 12)}y ago`;
  } catch (e) {
    return '';
  }
};

interface ProfilePageProps {
  targetUsername: string;
  currentUser: UserProfile | null;
  onNavigate: (to: string) => void;
  onTriggerAuthPrompt?: () => void;
  initialTab?: 'REVIEWS' | 'WATCHED' | 'COLLECTIONS';
}

export default function ProfilePage({ targetUsername, currentUser, onNavigate, onTriggerAuthPrompt, initialTab }: ProfilePageProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [reviews, setReviews] = useState<MuvioReview[]>([]);
  const [collections, setCollections] = useState<UserCollection[]>([]);
  const [watchedItems, setWatchedItems] = useState<UserWatched[]>([]);
  const [loadingMedia, setLoadingMedia] = useState(true);
  
  // Follow States
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [isFollowing, setIsFollowing] = useState(false);
  
  // Tabs & Filters
  const [activeTab, setActiveTab] = useState<'REVIEWS' | 'WATCHED' | 'COLLECTIONS'>(initialTab || 'REVIEWS');
  const [searchQuery, setSearchQuery] = useState('');
  const [ratingFilter, setRatingFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');

  // Redesign edits / inline updates
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [editedBio, setEditedBio] = useState('');
  const [savingInline, setSavingInline] = useState(false);

  // Expanded review text preview IDs
  const [expandedReviewIds, setExpandedReviewIds] = useState<Record<string, boolean>>({});

  const toggleReviewExpansion = (id: string) => {
    setExpandedReviewIds(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Media resolution maps
  const [mediaDetailsMap, setMediaDetailsMap] = useState<Record<string, MuvioMedia>>({});
  const [commentCountsMap, setCommentCountsMap] = useState<Record<string, number>>({});

  // Fast response to initialTab prop updates
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Synchronize inline display fields when profile loads
  useEffect(() => {
    if (profile) {
      setEditedName(profile.name || '');
      setEditedBio((profile as any).bio || '');
    }
  }, [profile]);
  
  // Modals
  const [activeFollowModal, setActiveFollowModal] = useState<'FOLLOWERS' | 'FOLLOWING' | null>(null);
  const [modalUsersList, setModalUsersList] = useState<UserProfile[]>([]);
  const [loadingModalUsers, setLoadingModalUsers] = useState(false);
  
  // Collection creation
  const [showCreateCollection, setShowCreateCollection] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [creating, setCreating] = useState(false);

  const isOwnProfile = currentUser && currentUser.username.toLowerCase() === targetUsername.toLowerCase();

  // Load target user profile
  useEffect(() => {
    async function loadProfile() {
      setLoading(true);
      try {
        const userProf = await getUserProfileByUsername(targetUsername);
        if (userProf) {
          setProfile(userProf);
          
          // Set counts
          const followers = (userProf as any).followers || [];
          const following = (userProf as any).following || [];
          setFollowersCount(followers.length);
          setFollowingCount(following.length);
          
          if (currentUser) {
            setIsFollowing(followers.includes(currentUser.uid));
          }
          
          // Load sub-content
          const [userReviews, userCollections, userWatched] = await Promise.all([
            getReviewsForUser(userProf.uid),
            getUserCollections(userProf.uid),
            getUserWatchedItems(userProf.uid)
          ]);
          setReviews(userReviews);
          setCollections(userCollections);
          setWatchedItems(userWatched);
        } else {
          setProfile(null);
        }
      } catch (err) {
        console.error('Failed to load observatory profile:', err);
        triggerToast('Error loading profile.', 'error');
      } finally {
        setLoading(false);
        setLoadingMedia(false);
      }
    }
    loadProfile();
  }, [targetUsername, currentUser?.uid]);

  // Image upload base64 converter and saver
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1500000) {
      triggerToast('Image size must be less than 1.5MB to save profile space.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        await updateUserProfile(profile!.uid, { avatarUrl: base64 } as any);
        setProfile(prev => prev ? { ...prev, avatarUrl: base64 } as any : null);
        if (currentUser && currentUser.uid === profile?.uid) {
          (currentUser as any).avatarUrl = base64;
        }
        triggerToast('Profile photograph changed successfully!', 'success');
      } catch (err) {
        triggerToast('Failed to modify profile image.', 'error');
      }
    };
    reader.readAsDataURL(file);
  };

  // Inline Profile metadata edit form action
  const handleSaveInlineProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setSavingInline(true);
    try {
      await updateUserProfile(profile.uid, {
        name: editedName.trim(),
        bio: editedBio.trim()
      } as any);

      setProfile(prev => prev ? {
        ...prev,
        name: editedName.trim(),
        bio: editedBio.trim()
      } as any : null);

      if (currentUser && currentUser.uid === profile.uid) {
        currentUser.name = editedName.trim();
        (currentUser as any).bio = editedBio.trim();
      }

      setIsEditingBio(false);
      triggerToast('Updated observed critic metadata success.', 'success');
    } catch (err) {
      triggerToast('Failed to update critic configurations.', 'error');
    } finally {
      setSavingInline(false);
    }
  };

  // Resolve media details for each review card and watched item
  useEffect(() => {
    async function resolveMedia() {
      const detailsMap = { ...mediaDetailsMap };
      const mediaIdsToResolve = new Set<string>();
      reviews.forEach(r => mediaIdsToResolve.add(r.mediaId));
      watchedItems.forEach(w => mediaIdsToResolve.add(w.id));

      let changed = false;
      for (const mId of mediaIdsToResolve) {
        if (detailsMap[mId]) continue;
        changed = true;
        const match = mId.match(/^(movie|tv|show|anime)-(\d+)$/i);
        if (match) {
          const typeStr = match[1].toLowerCase();
          const tmdbType = (typeStr === 'movie') ? 'movie' : 'tv';
          const tmdbId = parseInt(match[2], 10);
          try {
            const item = await getMediaDetails(tmdbType, tmdbId);
            if (item) {
              detailsMap[mId] = item;
            }
          } catch (err) {
            console.warn('Failed to fetch media details:', err);
          }
        }
        
        // Fallback checks
        if (!detailsMap[mId]) {
          try {
            const fallbackRich = getFallbackRichDetails(mId);
            if (fallbackRich && fallbackRich.media) {
              detailsMap[mId] = fallbackRich.media;
            }
          } catch (err) {
            detailsMap[mId] = {
              id: mId,
              tmdbId: 0,
              title: mId.split('-').slice(1).join(' ').toUpperCase() || 'CINEMATIC ITEM',
              type: mId.startsWith('tv') ? 'SHOW' : mId.startsWith('anime') ? 'ANIME' : 'MOVIE',
              year: 2025,
              description: '',
              backdropUrl: 'https://images.unsplash.com/photo-1542204172-e7052809a936?auto=format&fit=crop&q=80&w=1200',
              posterUrl: 'https://images.unsplash.com/photo-1542204172-e7052809a936?auto=format&fit=crop&q=80&w=400',
              ratingPercent: 82,
              voteCount: 50,
              releaseDate: '',
              statusBadge: undefined
            };
          }
        }
      }
      if (changed) {
        setMediaDetailsMap(detailsMap);
      }
    }
    if (reviews.length > 0 || watchedItems.length > 0) {
      resolveMedia();
    }
  }, [reviews, watchedItems]);

  // Resolve comment counts for each review card
  useEffect(() => {
    async function loadCommentCounts() {
      const countsMap: Record<string, number> = {};
      await Promise.all(reviews.map(async (rev) => {
        try {
          const comments = await getCommentsForReview(rev.id);
          countsMap[rev.id] = comments.length;
        } catch (err) {
          countsMap[rev.id] = 0;
        }
      }));
      setCommentCountsMap(countsMap);
    }
    if (reviews.length > 0) {
      loadCommentCounts();
    }
  }, [reviews]);

  // Handle Follow/Unfollow action (Optimistic UI update)
  const handleFollowToggle = async () => {
    if (!currentUser) {
      if (onTriggerAuthPrompt) {
        onTriggerAuthPrompt();
      } else {
        triggerToast('Please log in to follow critics.', 'error');
        onNavigate('/login');
      }
      return;
    }
    if (!profile) return;

    // Optimistic Update
    const previousState = isFollowing;
    const previousCount = followersCount;
    
    setIsFollowing(!isFollowing);
    setFollowersCount(isFollowing ? followersCount - 1 : followersCount + 1);
    
    try {
      const result = await toggleFollowUser(currentUser.uid, profile.uid);
      setIsFollowing(result);
      triggerToast(result ? `Following @${profile.username} successfully` : `Unfollowed @${profile.username}`, 'success');
    } catch (e) {
      // Rollback
      setIsFollowing(previousState);
      setFollowersCount(previousCount);
      triggerToast('Authentication or server update failed.', 'error');
    }
  };

  // Open follow/following modal lists
  const handleOpenFollowModal = async (type: 'FOLLOWERS' | 'FOLLOWING') => {
    if (!profile) return;
    setActiveFollowModal(type);
    setLoadingModalUsers(true);
    setModalUsersList([]);
    
    try {
      const uids = type === 'FOLLOWERS' ? ((profile as any).followers || []) : ((profile as any).following || []);
      const fetched: UserProfile[] = [];
      for (const uid of uids) {
        const u = await getUserProfileByUserId(uid);
        if (u) fetched.push(u);
      }
      setModalUsersList(fetched);
    } catch (e) {
      console.error(e);
      triggerToast('Failed to retrieve follow list.', 'error');
    } finally {
      setLoadingModalUsers(false);
    }
  };

  // Create Collection
  const handleCreateCollectionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !newCollectionName.trim()) return;
    setCreating(true);
    try {
      const newCol = await createCollection(currentUser.uid, newCollectionName);
      setCollections(prev => [...prev, newCol]);
      setNewCollectionName('');
      setShowCreateCollection(false);
      triggerToast(`Collection "${newCol.name}" created!`, 'success');
    } catch (err) {
      triggerToast('Could not register collection workspace.', 'error');
    } finally {
      setCreating(false);
    }
  };

  // Handle review liking (Optimistic update)
  const handleLikeReviewToggle = async (review: MuvioReview) => {
    if (!currentUser) {
      if (onTriggerAuthPrompt) {
        onTriggerAuthPrompt();
      } else {
        triggerToast('Log in to like review analyses.', 'error');
        onNavigate('/login');
      }
      return;
    }
    
    // Optimistic update
    const alreadyLiked = review.likedBy?.includes(currentUser.uid);
    const updatedLikedBy = alreadyLiked
      ? (review.likedBy || []).filter(id => id !== currentUser.uid)
      : [...(review.likedBy || []), currentUser.uid];
      
    setReviews(prev => prev.map(r => r.id === review.id ? { ...r, likedBy: updatedLikedBy } : r));
    
    try {
      await toggleLikeReview(currentUser.uid, review.id, review.userId, review.mediaId, currentUser.name || currentUser.username);
    } catch (err) {
      // Rollback
      setReviews(prev => prev.map(r => r.id === review.id ? { ...r, likedBy: review.likedBy } : r));
      triggerToast('Failed to save like review indicator.', 'error');
    }
  };

  // Filter reviews
  const filteredReviews = reviews.filter(rev => {
    const textMatch = rev.text.toLowerCase().includes(searchQuery.toLowerCase()) || 
                      rev.mediaId.toLowerCase().includes(searchQuery.toLowerCase());
    const ratingMatch = ratingFilter === 'ALL' || rev.rating === ratingFilter;
    return textMatch && ratingMatch;
  });

  // Render Skeleton Loader
  if (loading) {
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-pulse text-left py-10" id="profile-skeleton-loader">
        <div className="flex flex-col md:flex-row items-center gap-6 pb-8 border-b border-white/5">
          <div className="w-24 h-24 rounded-full bg-neutral-900 border border-white/5"></div>
          <div className="flex-1 space-y-3">
            <div className="h-6 w-48 bg-neutral-950 rounded"></div>
            <div className="h-4 w-32 bg-neutral-950 rounded"></div>
            <div className="h-4 w-60 bg-neutral-950 rounded"></div>
          </div>
        </div>
        <div className="h-10 bg-neutral-950 rounded-xl w-64"></div>
      </div>
    );
  }

  // Handle User Not Found state
  if (!profile) {
    return (
      <div className="max-w-md mx-auto text-center py-20 space-y-6" id="profile-not-found-gate">
        <div className="w-16 h-16 rounded-full bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center mx-auto text-[#E50914]">
          <User size={30} />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-black text-white uppercase tracking-tight font-display">Profile Not Found</h2>
          <p className="text-xs text-gray-400 font-sans leading-relaxed">
            The target cinematic profile "@" + <span className="text-[#E50914] font-bold">{targetUsername}</span> does not exist.
          </p>
        </div>
        <button
          onClick={() => onNavigate('/explore')}
          className="mt-4 px-6 py-3 bg-[#E50914] hover:bg-neutral-900 border border-transparent hover:border-white/10 text-[10px] font-mono tracking-widest font-black uppercase rounded-xl text-white transition-all cursor-pointer"
        >
          Go to Home
        </button>
      </div>
    );
  }

  // Rating badge designs
  const ratingBadgeConfigs: Record<string, { style: string; label: string }> = {
    'PERFECTION': { style: 'bg-purple-500/10 border-purple-500/40 text-purple-400', label: 'PERFECTION' },
    'GO FOR IT': { style: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400', label: 'GO FOR IT' },
    'TIMEPASS': { style: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400', label: 'TIMEPASS' },
    'SKIP': { style: 'bg-red-500/10 border-red-500/30 text-red-500', label: 'SKIP' }
  };

  // Initials for avatar fallback
  const nameInitials = profile.name ? profile.name.slice(0, 2).toUpperCase() : profile.username.slice(0, 2).toUpperCase();

  return (
    <div className="max-w-4xl mx-auto space-y-8" id="muvio-profile-master-canvas">
      
      {/* SOCIAL PROFILE HEADER CONTAINER */}
      <div className="bg-[#0c0c0c]/90 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl text-left relative flex flex-col">
        {/* Banner area with red abstract gradient */}
        <div className="h-32 sm:h-44 w-full bg-gradient-to-r from-[#E50914]/20 via-[#400000]/40 to-black relative border-b border-white/5">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(229,9,20,0.15),transparent)]"></div>
        </div>

        {/* Profile Details Area */}
        <div className="px-6 pb-6 md:px-8 relative">
          {/* Overlapping Avatar & Action button row */}
          <div className="flex justify-between items-end -mt-10 sm:-mt-14 mb-4">
            <div className="relative group/avatar">
              {profile.avatarUrl ? (
                <img 
                  src={profile.avatarUrl} 
                  alt={profile.name} 
                  className="w-20 h-20 sm:w-28 sm:h-28 rounded-full object-cover bg-neutral-950 border-4 border-black shadow-xl"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-full bg-neutral-950 border-4 border-black flex items-center justify-center font-display font-black text-xl sm:text-2xl text-[#E50914] shadow-xl">
                  {nameInitials}
                </div>
              )}
              
              {/* Image upload selector on hover when own profile */}
              {isOwnProfile && (
                <label className="absolute inset-0 bg-black/60 rounded-full flex flex-col items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity cursor-pointer text-white">
                  <Camera size={18} className="text-white/80" />
                  <span className="text-[8px] font-mono font-bold mt-1 uppercase tracking-wider">Upload</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageUpload} 
                    className="hidden" 
                  />
                </label>
              )}
            </div>

            {/* Desktop Action button */}
            <div className="hidden sm:block">
              {isOwnProfile ? (
                <button 
                  onClick={() => setIsEditingBio(!isEditingBio)}
                  className="px-5 py-2 sm:py-2.5 bg-[#111111] hover:bg-neutral-900 text-white border border-white/10 hover:border-white/25 text-[10px] font-mono tracking-wider font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Edit3 size={11} className="text-[#E50914]" />
                  {isEditingBio ? 'CLOSE EDITOR' : 'EDIT PROFILE'}
                </button>
              ) : (
                <button 
                  onClick={handleFollowToggle}
                  className={`px-6 py-2.5 text-[10px] font-mono tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                    isFollowing 
                      ? 'bg-[#111111] text-gray-300 border-white/5 hover:border-[#E50914]/50 hover:text-[#E50914]' 
                      : 'bg-[#E50914] text-white border-transparent hover:bg-[#FF1A1A] hover:shadow-[0_4px_20px_rgba(229,9,20,0.3)]'
                  }`}
                >
                  {isFollowing ? (
                    <>
                      <UserMinus size={11} /> UNFOLLOW
                    </>
                  ) : (
                    <>
                      <UserPlus size={11} /> FOLLOW
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Social info details with expandable inline form */}
          {isOwnProfile && isEditingBio ? (
            <form onSubmit={handleSaveInlineProfile} className="space-y-4 max-w-xl bg-neutral-950 p-4 rounded-2xl border border-white/5 mt-2">
              <div className="space-y-1">
                <label className="text-[8px] font-black uppercase font-mono text-gray-500 tracking-wider">Display Name</label>
                <input
                  type="text"
                  required
                  maxLength={40}
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className="w-full bg-[#111111] border border-white/5 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] font-black uppercase font-mono text-gray-500 tracking-wider">Biography / Bio Text</label>
                <textarea
                  maxLength={200}
                  rows={3}
                  value={editedBio}
                  onChange={(e) => setEditedBio(e.target.value)}
                  className="w-full bg-[#111111] border border-white/5 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#E50914] resize-none"
                  placeholder="Tell others what type of content you like..."
                />
              </div>
              <div className="flex gap-2 justify-end pt-1">
                <button
                  type="button"
                  onClick={() => setIsEditingBio(false)}
                  className="px-3 py-1.5 text-[9px] font-mono text-gray-400 hover:text-white uppercase font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingInline}
                  className="px-4 py-1.5 bg-[#E50914] hover:bg-neutral-900 text-[9px] font-mono text-white font-black uppercase rounded-lg transition-all"
                >
                  {savingInline ? 'Saving...' : 'Save Profile'}
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-1.5 mt-2">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h1 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">{profile.name || 'Anonymous Critic'}</h1>
                
                {/* Social blue verification badge checkmark */}
                {(profile.isVerified || (profile as any).verified) && (
                  <span className="inline-flex items-center justify-center bg-blue-500 text-white rounded-full w-4 h-4 shadow-sm shrink-0" title="Verified Movie Critic">
                    <svg className="w-2.5 h-2.5 fill-current text-white" viewBox="0 0 24 24">
                      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                    </svg>
                  </span>
                )}

                {profile.role === 'admin' && (
                  <span className="text-[8px] font-black uppercase text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/30 px-1.5 py-0.5 rounded-md flex items-center gap-0.5 font-mono">
                    <Award size={9} /> ARCHIVIST
                  </span>
                )}
              </div>

              {/* Username identifier below display name */}
              <p className="text-xs text-neutral-400 font-mono">@{profile.username}</p>

              {/* Bio space below username */}
              <p className="text-xs text-neutral-300 font-sans max-w-xl leading-relaxed pt-1.5">
                {profile.bio || "This cinematic critic operates behind sealed secure firewalls of silence. No custom intelligence bio provided."}
              </p>
            </div>
          )}

          {/* Followers / Following counts and Joined Date */}
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 items-center text-xs text-neutral-400">
            {/* Reviews Count */}
            <div className="flex items-center gap-1">
              <strong className="text-white font-mono font-bold">{reviews.length}</strong>
              <span className="text-neutral-500">Reviews</span>
            </div>

            <div className="w-1 h-1 bg-neutral-800 rounded-full"></div>

            {/* Watched Count */}
            <button 
              onClick={() => setActiveTab('WATCHED')}
              className="hover:underline flex items-center gap-1 cursor-pointer hover:text-white transition-colors text-left"
            >
              <strong className="text-white font-mono font-bold">{watchedItems.length}</strong>
              <span className="text-neutral-500">Watched</span>
            </button>

            <div className="w-1 h-1 bg-neutral-800 rounded-full"></div>

            {/* Collections Count */}
            <button 
              onClick={() => setActiveTab('COLLECTIONS')}
              className="hover:underline flex items-center gap-1 cursor-pointer hover:text-white transition-colors text-left"
            >
              <strong className="text-white font-mono font-bold">{collections.length}</strong>
              <span className="text-neutral-500">Collections</span>
            </button>

            <div className="w-1 h-1 bg-neutral-800 rounded-full"></div>

            {/* Followers count and Following count - both clickable */}
            <button 
              onClick={() => handleOpenFollowModal('FOLLOWERS')}
              className="hover:underline flex items-center gap-1 cursor-pointer hover:text-white transition-colors"
            >
              <strong className="text-white font-mono font-bold">{followersCount}</strong>
              <span className="text-neutral-500">Followers</span>
            </button>

            <div className="w-1 h-1 bg-neutral-800 rounded-full"></div>

            <button 
              onClick={() => handleOpenFollowModal('FOLLOWING')}
              className="hover:underline flex items-center gap-1 cursor-pointer hover:text-white transition-colors"
            >
              <strong className="text-white font-mono font-bold">{followingCount}</strong>
              <span className="text-neutral-500">Following</span>
            </button>

            {/* Joined Month + Year with calendar icon */}
            <div className="flex items-center gap-1.5 text-neutral-500 font-mono text-[11px] sm:ml-auto">
              <Calendar size={12} className="text-[#E50914]" />
              <span>Joined {new Date(profile.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long' })}</span>
            </div>
          </div>

          {/* Social Crimson Action Button - Fully responsive mobile view block */}
          <div className="w-full pt-4 block sm:hidden">
            {isOwnProfile ? (
              <button 
                onClick={() => setIsEditingBio(!isEditingBio)}
                className="w-full py-3 bg-[#111111] text-white border border-white/5 text-xs font-mono tracking-wider font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Edit3 size={12} className="text-[#E50914]" />
                {isEditingBio ? 'CLOSE EDITOR' : 'EDIT PROFILE'}
              </button>
            ) : (
              <button 
                onClick={handleFollowToggle}
                className={`w-full py-3 text-xs font-mono tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer border ${
                  isFollowing 
                    ? 'bg-[#111111] text-gray-300 border-white/5' 
                    : 'bg-[#E50914] text-white border-transparent'
                }`}
              >
                {isFollowing ? 'UNFOLLOW' : 'FOLLOW'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* REVIEWS AND COLLECTIONS TABS DISPLAY */}
      <div className="space-y-6 text-left">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-3">
          {/* Section Main Tab Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('REVIEWS')}
              className={`px-5 py-2.5 text-[10px] font-mono tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer ${
                activeTab === 'REVIEWS' 
                  ? 'bg-[#E50914] text-white shadow-[0_4px_20px_rgba(229,9,20,0.3)]' 
                  : 'bg-[#0f0f0f] border border-white/2 text-gray-400 hover:text-white'
              }`}
            >
              CRITIC REVIEWS ({reviews.length})
            </button>
            <button
              onClick={() => setActiveTab('WATCHED')}
              className={`px-5 py-2.5 text-[10px] font-mono tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer ${
                activeTab === 'WATCHED' 
                  ? 'bg-[#E50914] text-white shadow-[0_4px_20px_rgba(229,9,20,0.3)]' 
                  : 'bg-[#0f0f0f] border border-white/2 text-gray-400 hover:text-white'
              }`}
            >
              WATCHED ({watchedItems.length})
            </button>
            <button
              onClick={() => setActiveTab('COLLECTIONS')}
              className={`px-5 py-2.5 text-[10px] font-mono tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer ${
                activeTab === 'COLLECTIONS' 
                  ? 'bg-[#E50914] text-white shadow-[0_4px_20px_rgba(229,9,20,0.3)]' 
                  : 'bg-[#0f0f0f] border border-white/2 text-gray-400 hover:text-white'
              }`}
            >
              COLLECTION CABINETS ({collections.length})
            </button>
          </div>

          {activeTab === 'COLLECTIONS' && isOwnProfile && (
            <button
              onClick={() => setShowCreateCollection(true)}
              className="px-4 py-2 text-[10px] bg-[#E50914] hover:bg-neutral-800 text-white font-mono tracking-wider font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Plus size={11} /> NEW CABINET
            </button>
          )}
        </div>

        {/* Tab Content Rendering with AnimatePresence */}
        <AnimatePresence mode="wait">
          {activeTab === 'REVIEWS' ? (
            <motion.div
              key="reviews-canvas"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* FILTER TAB BAR: ALL | SKIP | TIMEPASS | GO FOR IT | PERFECTION */}
              <div className="flex flex-wrap items-center gap-2 border-b border-white/5 pb-2 overflow-x-auto whitespace-nowrap scrollbar-none">
                {['ALL', 'SKIP', 'TIMEPASS', 'GO FOR IT', 'PERFECTION'].map((tabVal) => {
                  const isActive = ratingFilter === tabVal;
                  let pillStyle = '';
                  
                  if (isActive) {
                    if (tabVal === 'SKIP') pillStyle = 'bg-red-950/40 text-red-500 border-red-500/50 shadow-[0_2px_10px_rgba(239,68,68,0.15)]';
                    else if (tabVal === 'TIMEPASS') pillStyle = 'bg-yellow-950/40 text-yellow-500 border-yellow-500/50 shadow-[0_2px_10px_rgba(234,179,8,0.15)]';
                    else if (tabVal === 'GO FOR IT') pillStyle = 'bg-emerald-950/40 text-emerald-500 border-emerald-500/50 shadow-[0_2px_10px_rgba(16,185,129,0.15)]';
                    else if (tabVal === 'PERFECTION') pillStyle = 'bg-purple-950/40 text-purple-500 border-purple-500/50 shadow-[0_2px_10px_rgba(168,85,247,0.15)]';
                    else pillStyle = 'bg-[#E50914] text-white border-transparent shadow-[0_4px_15px_rgba(229,9,20,0.25)]';
                  } else {
                    pillStyle = 'bg-[#111111] hover:bg-neutral-900 border-white/5 text-neutral-400 hover:text-white';
                  }

                  return (
                    <button
                      key={tabVal}
                      onClick={() => setRatingFilter(tabVal)}
                      className={`px-4 py-2 rounded-xl text-[10px] font-mono tracking-widest font-black uppercase transition-all cursor-pointer border ${pillStyle}`}
                    >
                      {tabVal}
                    </button>
                  );
                })}
              </div>

              {/* Search Bar + Grid/List Toggle Toggles */}
              <div className="flex flex-col sm:flex-row gap-3 items-center">
                <div className="relative flex-1 w-full">
                  <Search size={14} className="text-gray-500 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search reviews by movie code or text..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#111111] p-3.5 pl-11 rounded-2xl text-xs font-mono placeholder-gray-600 border border-white/5 focus:outline-none focus:border-[#E50914] text-white"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white">
                      <X size={14} />
                    </button>
                  )}
                </div>

                {/* Grid vs List togglers */}
                <div className="flex items-center gap-1 bg-[#111111] p-1 rounded-xl border border-white/5 shrink-0 self-end sm:self-center">
                  <button 
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded-lg transition-all cursor-pointer ${viewMode === 'list' ? 'bg-[#E50914]/10 text-[#E50914]' : 'text-gray-400 hover:text-white'}`}
                    title="List view"
                  >
                    <List size={14} />
                  </button>
                  <button 
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg transition-all cursor-pointer ${viewMode === 'grid' ? 'bg-[#E50914]/10 text-[#E50914]' : 'text-gray-400 hover:text-white'}`}
                    title="Grid view"
                  >
                    <Grid size={14} />
                  </button>
                </div>
              </div>

              {filteredReviews.length === 0 ? (
                <div className="p-12 text-center bg-[#0c0c0c]/40 border border-white/5 rounded-[2rem] space-y-3">
                  <div className="text-gray-600 text-base font-mono w-10 h-10 mx-auto rounded-full bg-white/2 flex items-center justify-center">?</div>
                  <h4 className="font-mono text-xs font-bold text-white uppercase tracking-wider">No reviews indexed</h4>
                  <p className="text-2xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                    No cinematic reviews matched your criteria or search text. Expand filters or submit critiques first.
                  </p>
                </div>
              ) : (
                <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-4'}>
                  {filteredReviews.map((rev) => {
                    const badge = ratingBadgeConfigs[rev.rating] || ratingBadgeConfigs['GO FOR IT'];
                    const hasLiked = currentUser && rev.likedBy?.includes(currentUser.uid);
                    
                    const isExpanded = !!expandedReviewIds[rev.id];
                    const charLimit = 160;
                    const needsTruncation = rev.text.length > charLimit;
                    const truncatedText = needsTruncation ? rev.text.slice(0, charLimit) + '...' : rev.text;
                    const media = mediaDetailsMap[rev.mediaId];

                    return (
                      <div 
                        key={rev.id}
                        className="bg-[#0c0c0c]/90 border border-white/5 p-4 rounded-2xl flex flex-row gap-4 shadow-lg relative group transition-all hover:bg-neutral-900/10 hover:border-white/10"
                      >
                        {/* Rating badge (absolute top right corner of card) */}
                        <span className={`absolute top-4 right-4 px-2 py-0.5 text-[8px] font-bold uppercase font-mono tracking-widest rounded border ${badge.style}`}>
                          {badge.label}
                        </span>

                        {/* Left Side: Movie Poster Thumbnail (fixed size, rounded corners) */}
                        <div 
                          onClick={() => onNavigate(`/content/${rev.mediaId}`)}
                          className="w-16 h-24 sm:w-20 sm:h-28 shrink-0 bg-neutral-950 rounded-xl overflow-hidden shadow-md border border-white/5 group-hover:border-[#E50914]/30 transition-all cursor-pointer relative"
                        >
                          <img 
                            src={media?.posterUrl || 'https://images.unsplash.com/photo-1542204172-e7052809a936?auto=format&fit=crop&q=80&w=400'} 
                            alt={media?.title || rev.mediaId} 
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                            referrerPolicy="no-referrer"
                            loading="lazy"
                          />
                        </div>

                        {/* Right Side: Details Area */}
                        <div className="flex-1 flex flex-col justify-between min-w-0 text-left">
                          <div className="space-y-1.5">
                            <div className="pr-16 sm:pr-20 space-y-0.5">
                              {/* Title click to navigate */}
                              <h4 
                                onClick={() => onNavigate(`/content/${rev.mediaId}`)}
                                className="font-display font-black text-sm sm:text-base text-white hover:text-[#E50914] cursor-pointer transition-colors uppercase tracking-tight line-clamp-1"
                              >
                                {media?.title || rev.mediaId.split('-').slice(1).join(' ').toUpperCase()}
                              </h4>
                              
                              {/* Metadata block: Year • Type • Time ago */}
                              <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono text-neutral-500 uppercase tracking-widest font-black">
                                <span>{media?.year || 2025}</span>
                                <span>•</span>
                                <span>{media?.type || 'MOVIE'}</span>
                                <span>•</span>
                                <span className="text-neutral-400 lowercase">{timeAgo(rev.createdAt)}</span>
                              </div>
                            </div>

                            {/* Review Text Preview with expand option (2-3 lines constraint) */}
                            <div className="text-xs text-neutral-300 font-sans leading-relaxed">
                              {rev.spoiler && (
                                <span className="bg-red-500/15 border border-red-500/30 text-[#E50914] text-[8px] font-mono font-bold tracking-widest rounded px-1.5 py-0.5 uppercase mr-1.5 inline-block">SPOILER</span>
                              )}
                              <span className={isExpanded ? "" : "line-clamp-2 sm:line-clamp-3 text-neutral-400"}>
                                {rev.text}
                              </span>
                              {needsTruncation && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleReviewExpansion(rev.id);
                                  }}
                                  className="text-[#E50914] hover:underline font-bold text-[10px] font-mono ml-2 uppercase cursor-pointer whitespace-nowrap"
                                >
                                  {isExpanded ? 'less' : 'more'}
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Footer Details: LIKES + COMMENTS and Explore Navigation Button */}
                          <div className="pt-2 sm:pt-3 border-t border-white/5 flex items-center justify-between text-neutral-500 text-[11px] mt-2">
                            <div className="flex items-center gap-4">
                              <button
                                onClick={() => handleLikeReviewToggle(rev)}
                                className={`flex items-center gap-1.5 cursor-pointer font-mono ${hasLiked ? 'text-[#E50914]' : 'hover:text-white'} transition-colors`}
                              >
                                <Heart size={12} className={hasLiked ? 'fill-[#E50914] text-[#E50914]' : ''} />
                                <span>{rev.likedBy?.length || 0} LIKES</span>
                              </button>

                              <button
                                onClick={() => onNavigate(`/content/${rev.mediaId}`)}
                                className="flex items-center gap-1.5 cursor-pointer font-mono hover:text-white transition-colors"
                              >
                                <MessageSquare size={12} />
                                <span>{commentCountsMap[rev.id] || 0} COMMENTS</span>
                              </button>
                            </div>
                            
                            <button 
                              onClick={() => onNavigate(`/content/${rev.mediaId}`)}
                              className="font-mono text-[#E50914] hover:text-[#ff3b46] flex items-center gap-1 transition-colors cursor-pointer font-bold"
                            >
                              <span>ENTER</span>
                              <ArrowRight size={10} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          ) : activeTab === 'WATCHED' ? (
            <motion.div
              key="watched-canvas"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {watchedItems.length === 0 ? (
                <div className="p-16 border border-dashed border-white/5 rounded-[2.5rem] bg-[#0b0b0b]/10 text-center space-y-3">
                  <span className="text-4xs font-black font-mono tracking-widest block uppercase text-red-500">SYSTEM EMPTY STATE</span>
                  <p className="text-xs text-gray-400 font-sans max-w-sm mx-auto">
                    Nothing watched yet
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                  {watchedItems.map((item) => {
                    const mediaDetails = mediaDetailsMap[item.id];
                    const poster = mediaDetails?.posterUrl || item.posterUrl;
                    const title = mediaDetails?.title || item.title;
                    const type = mediaDetails?.type || item.type;
                    const year = mediaDetails?.year || 'UNKNOWN';

                    return (
                      <div 
                        key={item.id}
                        onClick={() => onNavigate(`/content/${item.id}`)}
                        className="group bg-[#070707] border border-white/5 hover:border-white/10 rounded-[2rem] overflow-hidden transition-all duration-300 transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-[#E50914]/5 cursor-pointer flex flex-col h-full"
                      >
                        {/* Image / Poster Block */}
                        <div className="relative aspect-[2/3] w-full overflow-hidden bg-neutral-900 flex-shrink-0">
                          <img 
                            src={poster || 'https://images.unsplash.com/photo-1542204172-e7052809a936?auto=format&fit=crop&q=80&w=400'} 
                            alt={title} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          {/* Type Tag Overlay */}
                          <div className="absolute top-4 left-4 z-10">
                            <span className="px-2.5 py-1 bg-black/60 backdrop-blur-md border border-white/10 rounded-full text-[8px] font-black font-mono tracking-widest text-[#E50914] uppercase">
                              {type}
                            </span>
                          </div>
                        </div>

                        {/* Info Content Block */}
                        <div className="p-4 flex flex-col justify-between flex-1 text-left bg-black/30">
                          <div className="space-y-1">
                            <h4 className="text-xs font-bold text-white group-hover:text-[#E50914] transition-colors uppercase line-clamp-1">
                              {title}
                            </h4>
                            <p className="text-[10px] font-mono font-bold text-gray-500 uppercase">
                              {year}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="collections-canvas"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {collections.length === 0 ? (
                <div className="col-span-full p-12 text-center bg-[#0c0c0c]/40 border border-white/5 rounded-[2rem] space-y-3">
                  <div className="text-gray-600 text-base font-mono w-10 h-10 mx-auto rounded-full bg-white/2 flex items-center justify-center">+</div>
                  <h4 className="font-mono text-xs font-bold text-white uppercase tracking-wider">No Collection Cabinets found</h4>
                  <p className="text-2xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                    This user profile does not contain any catalogued folder collections or index cabinets yet.
                  </p>
                </div>
              ) : (
                collections.map((col) => (
                  <div
                    key={col.id}
                    onClick={() => onNavigate(`/collections/${col.id}`)}
                    className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2rem] p-5 space-y-4 flex flex-col justify-between transition-all group hover:shadow-xl cursor-pointer text-left"
                  >
                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <span className="bg-black/60 border border-white/10 px-2 py-0.5 rounded-full text-[8px] font-mono font-bold uppercase text-white flex items-center gap-1">
                          <Globe size={9} className="text-[#E50914]" /> Cabinet
                        </span>
                        <span className="text-3xs font-mono text-gray-500">
                          {new Date(col.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <h3 className="text-base font-black text-white group-hover:text-[#E50914] transition-colors uppercase tracking-tight font-display">
                        {col.name}
                      </h3>
                      
                      <p className="text-3xs font-mono text-gray-500">
                        FOLDER ID: #{col.id.toUpperCase()}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-white/5 flex items-center justify-between text-gray-400 font-mono text-3xs">
                      <span className="font-bold text-gray-300 uppercase">{col.mediaIds?.length || 0} ITEMS CATALOUGED</span>
                      <span className="text-[#E50914] flex items-center gap-0.5 hover:underline font-bold">VIEW CABINET <ArrowRight size={10} /></span>
                    </div>
                  </div>
                ))
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* --- BACKDROP MODALS ZONE --- */}

      {/* MODAL 1: FOLLOW LIST MODAL */}
      <AnimatePresence>
        {activeFollowModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#0d0d0d] border border-white/10 rounded-[2.5rem] p-6 space-y-5 text-left relative shadow-2xl"
              id="follow-modal-box"
            >
              <button 
                onClick={() => setActiveFollowModal(null)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-neutral-800 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer transition-colors"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">OBSERVER NETWORK</span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight font-display">
                  {activeFollowModal === 'FOLLOWERS' ? 'Critic Followers' : 'Observed Critics'}
                </h3>
              </div>

              {loadingModalUsers ? (
                <div className="py-12 text-center" id="modal-loading-indicator">
                  <div className="w-6 h-6 border-2 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                  <p className="text-4xs font-mono text-gray-500 tracking-wider">RETRIEVING NETWORK PROFILES...</p>
                </div>
              ) : modalUsersList.length === 0 ? (
                <div className="py-12 text-center text-gray-500 font-mono text-[10px]" id="modal-empty-state">
                  No explorer profiles documented in this log.
                </div>
              ) : (
                <div className="max-h-72 overflow-y-auto space-y-3 pr-1 scrollbar-thin">
                  {modalUsersList.map((u) => {
                    const initials = u.name ? u.name.slice(0, 2).toUpperCase() : u.username.slice(0, 2).toUpperCase();
                    return (
                      <div 
                        key={u.uid}
                        onClick={() => {
                          setActiveFollowModal(null);
                          onNavigate(`/u/${u.username}`);
                        }}
                        className="flex items-center justify-between p-3 rounded-2xl bg-neutral-950/40 hover:bg-neutral-950/80 border border-white/2 hover:border-white/5 transition-all cursor-pointer group"
                      >
                        <div className="flex items-center gap-3">
                          {(u as any).avatarUrl ? (
                            <img src={(u as any).avatarUrl} className="w-8 h-8 rounded-full object-cover" />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center text-[#E50914] text-xs font-black">
                              {initials}
                            </div>
                          )}
                          <div className="text-left leading-tight">
                            <h4 className="text-xs font-black text-white group-hover:text-[#E50914] transition-colors">{u.name}</h4>
                            <span className="text-3xs font-mono text-gray-500">@{u.username}</span>
                          </div>
                        </div>

                        <ArrowRight size={12} className="text-gray-500 group-hover:text-white transition-colors" />
                      </div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: CREATE CABINET */}
      <AnimatePresence>
        {showCreateCollection && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm bg-[#0d0d0d] border border-[#E50914]/20 rounded-[2.5rem] p-6 space-y-5 text-left relative shadow-2xl animate-fade"
              id="create-cabinet-modal"
            >
              <button 
                onClick={() => setShowCreateCollection(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-neutral-800 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer transition-colors"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">NEW CONTAINER</span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight">Create Collection Cabinet</h3>
                <p className="text-3xs text-gray-500 font-mono">Create a public folder to catalogue high-definition cinematic items.</p>
              </div>

              <form onSubmit={handleCreateCollectionSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Cabinet Title</label>
                  <input
                    type="text"
                    required
                    maxLength={30}
                    placeholder="E.G., CYBERPUNK CHRONICLES, CLASSIC SCI-FI (MAX 30 CHARS)"
                    value={newCollectionName}
                    onChange={(e) => setNewCollectionName(e.target.value)}
                    className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white uppercase"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setShowCreateCollection(false)}
                    className="flex-1 py-3 border border-white/5 text-[10px] font-mono font-bold hover:text-white rounded-xl text-gray-400 cursor-pointer"
                  >
                    CANCEL
                  </button>
                  <button 
                    type="submit" 
                    disabled={creating}
                    className="flex-1 py-3 bg-[#E50914] text-white text-[10px] font-mono font-black tracking-wider uppercase rounded-xl hover:bg-[#FF1A1A] cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {creating ? (
                      <span className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <>
                        <FolderPlus size={11} /> CREATE
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
