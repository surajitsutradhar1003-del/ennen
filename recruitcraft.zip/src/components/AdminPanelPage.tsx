import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, 
  Users, 
  Settings, 
  Radio, 
  Database,
  ArrowLeft,
  Power,
  RefreshCw,
  LogOut,
  ToggleLeft,
  ToggleRight,
  UserCheck,
  LayoutDashboard,
  Film,
  Clock,
  Compass,
  AlertTriangle,
  FileText,
  MessageSquare,
  AlertCircle,
  Newspaper,
  Heart,
  Import,
  Bell,
  Sparkles,
  Link2,
  Globe2,
  ListOrdered,
  Search,
  Filter,
  Trash2,
  Edit,
  Plus,
  X,
  Play,
  Check,
  Calendar,
  Layers,
  Menu,
  Download,
  Ticket,
  ChevronRight,
  Info,
  BadgeCheck
} from 'lucide-react';
import { 
  db, 
  auth, 
  logoutUser, 
  UserProfile, 
  getSettingValue, 
  updateSettingValue, 
  isFirebaseConfigured,
  triggerToast 
} from '../lib/firebase';
import { collection, getDocs, doc, deleteDoc } from 'firebase/firestore';
import { AppRoute, MuvioReview } from '../types';
import {
  getAdminCatalog,
  saveCatalogItem,
  deleteCatalogItem,
  bulkApproveItems,
  bulkRejectItems,
  getAutoFetchSettings,
  saveAutoFetchSettings,
  getFetchLogs,
  addFetchLog,
  MuvioCatalogItem,
  TMDBFetchLog
} from '../lib/adminCatalog';
import {
  searchCatalog,
  getRichMediaDetails,
  MuvioCompany,
  MuvioCastMember,
  MuvioCrewMember,
  mapTMDBToMuvio,
  MuvioMedia
} from '../lib/tmdb';
import { createNotification } from '../lib/userInteractions';

import AdminPushNotifications from './admin/AdminPushNotifications';
import AdminAds from './admin/AdminAds';
import AdminGeminiBuilder from './admin/AdminGeminiBuilder';
import AdminSeoSettings from './admin/AdminSeoSettings';
import AdminGeneralSettings from './admin/AdminGeneralSettings';
import AdminApiKeys from './admin/AdminApiKeys';
import AdminRankings from './admin/AdminRankings';

interface AdminPanelPageProps {
  onNavigate: (route: AppRoute) => void;
  showLandingPage: boolean;
  onToggleLandingPage: (v: boolean) => void;
}

export default function AdminPanelPage({ onNavigate, showLandingPage, onToggleLandingPage }: AdminPanelPageProps) {
  // Authentication & System Users
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [systemLogs, setSystemLogs] = useState<string[]>([]);
  const [reviewsList, setReviewsList] = useState<MuvioReview[]>([]);

  // Phase 9A Navigation Tabs state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Content Management & Editing States
  const [catalog, setCatalog] = useState<MuvioCatalogItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [mgmtTypeFilter, setMgmtTypeFilter] = useState<'ALL' | 'MOVIE' | 'SHOW' | 'ANIME'>('ALL');
  const [mgmtStatusFilter, setMgmtStatusFilter] = useState<'ALL' | 'Published' | 'Pending' | 'Draft'>('ALL');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [deleteConfirmationId, setDeleteConfirmationId] = useState<string | null>(null);

  // Content Editor Form Fields State
  const [editTitle, setEditTitle] = useState('');
  const [editOverview, setEditOverview] = useState('');
  const [editYear, setEditYear] = useState(2026);
  const [editDuration, setEditDuration] = useState('');
  const [editCountry, setEditCountry] = useState('United States');
  const [editLanguage, setEditLanguage] = useState('English');
  const [editAgeRating, setEditAgeRating] = useState('PG-13');
  const [editType, setEditType] = useState<'MOVIE' | 'SHOW' | 'ANIME'>('MOVIE');
  const [editRating, setEditRating] = useState(85);
  const [editVotes, setEditVotes] = useState(150);
  const [editReleased, setEditReleased] = useState('2026-01-01');
  const [editStatus, setEditStatus] = useState<'Published' | 'Pending' | 'Draft'>('Published');
  const [editPoster, setEditPoster] = useState('');
  const [editBackdrop, setEditBackdrop] = useState('');
  const [editCast, setEditCast] = useState<MuvioCastMember[]>([]);
  const [editCrew, setEditCrew] = useState<MuvioCrewMember[]>([]);
  const [editCompanies, setEditCompanies] = useState<MuvioCompany[]>([]);
  const [editGenres, setEditGenres] = useState<string[]>([]);
  const [editDownloads, setEditDownloads] = useState<{ quality: string; url: string; enabled: boolean; size?: string }[]>([]);
  const [editDownloadsEnabled, setEditDownloadsEnabled] = useState<boolean>(true);
  const [editTickets, setEditTickets] = useState<{ platform: string; url: string; type?: string; domain?: string }[]>([]);
  const [editIsFeatured, setEditIsFeatured] = useState(false);
  const [editIsMuvioSelect, setEditIsMuvioSelect] = useState(false);
  const [editDataSource, setEditDataSource] = useState<'DATABASE' | 'LIVE_TMDB'>('DATABASE');
  const [editStreamingEnabled, setEditStreamingEnabled] = useState<boolean>(false);
  const [editStreamingLinks, setEditStreamingLinks] = useState<{ platform: string; embedCode: string; enabled: boolean }[]>([]);
  const [editStreamingSeasons, setEditStreamingSeasons] = useState<{
    seasonNumber: number;
    episodes: {
      episodeNumber: number;
      title: string;
      platforms: { platform: string; embedCode: string; enabled: boolean }[];
    }[];
  }[]>([]);

  // Form helpers for adding casting and tickets
  const [newCastName, setNewCastName] = useState('');
  const [newCastChar, setNewCastChar] = useState('');
  const [newCastPhoto, setNewCastPhoto] = useState('');
  const [newCrewName, setNewCrewName] = useState('');
  const [newCrewRole, setNewCrewRole] = useState('');
  const [newGenreTag, setNewGenreTag] = useState('');
  const [newTicketPlatform, setNewTicketPlatform] = useState('');
  const [newTicketUrl, setNewTicketUrl] = useState('');
  const [newTicketType, setNewTicketType] = useState<string>('Subscription');
  const [newTicketDomain, setNewTicketDomain] = useState<string>('');
  const [newMovieStreamPlatform, setNewMovieStreamPlatform] = useState('');
  const [newMovieStreamCode, setNewMovieStreamCode] = useState('');
  const [newShowSeasonNum, setNewShowSeasonNum] = useState<number>(1);
  const [newShowEpisodeNum, setNewShowEpisodeNum] = useState<number>(1);
  const [newShowEpisodeTitle, setNewShowEpisodeTitle] = useState('');
  const [newShowStreamPlatform, setNewShowStreamPlatform] = useState('');
  const [newShowStreamCode, setNewShowStreamCode] = useState('');

  // Pending Approvals States
  const [selectedPendingIds, setSelectedPendingIds] = useState<string[]>([]);
  const [pendingTypeFilter, setPendingTypeFilter] = useState<'ALL' | 'MOVIE' | 'SHOW' | 'ANIME'>('ALL');

  // TMDB Import States
  const [tmdbQuery, setTmdbQuery] = useState('');
  const [tmdbResults, setTmdbResults] = useState<MuvioMedia[]>([]);
  const [loadingTmdb, setLoadingTmdb] = useState(false);
  const [selectedImportIds, setSelectedImportIds] = useState<number[]>([]);
  const [importingInProgress, setImportingInProgress] = useState(false);
  const [importConfirmItem, setImportConfirmItem] = useState<MuvioMedia | null>(null);
  const [isBulkImportConfirmOpen, setIsBulkImportConfirmOpen] = useState(false);
  const [importConfirmDataSource, setImportConfirmDataSource] = useState<'DATABASE' | 'LIVE_TMDB'>('DATABASE');

  // Auto-Fetch Config & Logs States
  const [autoSettings, setAutoSettings] = useState(getAutoFetchSettings());
  const [fetchLogs, setFetchLogs] = useState<TMDBFetchLog[]>(getFetchLogs());
  const [autoFetchLoading, setAutoFetchLoading] = useState(false);

  // PHASE 9B MODERATION STATES
  // 1. User Management
  const [usersSearchQuery, setUsersSearchQuery] = useState('');
  const [usersStatusFilter, setUsersStatusFilter] = useState<'ALL' | 'ACTIVE' | 'BANNED'>('ALL');
  const [isBanModalOpen, setIsBanModalOpen] = useState(false);
  const [userToBan, setUserToBan] = useState<any>(null);
  const [banReasonInput, setBanReasonInput] = useState('');
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [activityUser, setActivityUser] = useState<any>(null);

  // 1.5 Verification Requests States
  const [verificationRequests, setVerificationRequests] = useState<any[]>([]);
  const [loadingRequests, setLoadingRequests] = useState<boolean>(false);

  // 2. Reviews Moderation
  const [reviewsFilter, setReviewsFilter] = useState<'ALL' | 'REPORTED'>('ALL');
  const [selectedReviewForModal, setSelectedReviewForModal] = useState<MuvioReview | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isReviewDeleteConfirmOpen, setIsReviewDeleteConfirmOpen] = useState(false);
  const [reviewToDelete, setReviewToDelete] = useState<MuvioReview | null>(null);

  // 3. Comments Moderation
  const [commentsList, setCommentsList] = useState<any[]>([]);
  const [commentsFilter, setCommentsFilter] = useState<'ALL' | 'REPORTED'>('ALL');
  const [commentToDelete, setCommentToDelete] = useState<any | null>(null);
  const [isCommentDeleteConfirmOpen, setIsCommentDeleteConfirmOpen] = useState(false);

  // 4. Discussions Moderation
  const [discussionsList, setDiscussionsList] = useState<any[]>([]);
  const [discussionsReplies, setDiscussionsReplies] = useState<any[]>([]);
  const [activeDiscussionForRepliesModal, setActiveDiscussionForRepliesModal] = useState<any | null>(null);
  const [isDiscussionRepliesModalOpen, setIsDiscussionRepliesModalOpen] = useState(false);
  const [discussionToDelete, setDiscussionToDelete] = useState<any | null>(null);
  const [isDiscussionDeleteConfirmOpen, setIsDiscussionDeleteConfirmOpen] = useState(false);

  // 5. Reported Content
  const [reportsList, setReportsList] = useState<any[]>([]);
  const [reportsFilterTab, setReportsFilterTab] = useState<'REVIEWS' | 'COMMENTS' | 'DISCUSSIONS' | 'CONTENT'>('REVIEWS');
  const [viewedReportedItem, setViewedReportedItem] = useState<any | null>(null);

  // 6. News Management
  const [newsList, setNewsList] = useState<any[]>([]);
  const [isNewsFormOpen, setIsNewsFormOpen] = useState(false);
  const [editingNewsId, setEditingNewsId] = useState<string | null>(null);
  const [newsFormTitle, setNewsFormTitle] = useState('');
  const [newsFormCategory, setNewsFormCategory] = useState<'NEWS' | 'RUMOUR' | 'BOX OFFICE' | 'EXCLUSIVE'>('NEWS');
  const [newsFormAssociatedContentId, setNewsFormAssociatedContentId] = useState('');
  const [newsFormImageUrl, setNewsFormImageUrl] = useState('');
  const [newsFormBody, setNewsFormBody] = useState('');
  const [newsFormPrompt, setNewsFormPrompt] = useState('');
  const [isGeminiPromptOpen, setIsGeminiPromptOpen] = useState(false);
  const [isGeneratingNewsDraft, setIsGeneratingNewsDraft] = useState(false);
  const [deletingNewsIdState, setDeletingNewsIdState] = useState<string | null>(null);

  // 7. Collections Management
  const [collectionsList, setCollectionsList] = useState<any[]>([]);
  const [collectionToDelete, setCollectionToDelete] = useState<any | null>(null);
  const [isCollectionDeleteConfirmOpen, setIsCollectionDeleteConfirmOpen] = useState(false);

  // Push helper to admin terminal output logs
  const logMessage = (msg: string) => {
    setSystemLogs((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 25)]);
  };

  const handleUseNewsDraft = (draftText: string) => {
    setActiveTab('news');
    setEditingNewsId(null);
    setNewsFormTitle('AI Generated News Blueprint');
    setNewsFormCategory('NEWS');
    setNewsFormAssociatedContentId('');
    setNewsFormImageUrl('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600');
    setNewsFormBody(draftText);
    setNewsFormPrompt('');
    setIsNewsFormOpen(true);
  };

  // Auth subscriber wrapper
  useEffect(() => {
    const unsub = auth?.onAuthStateChanged((user) => {
      if (user) {
        setCurrentUser(user);
      }
    });
    return () => unsub?.();
  }, []);

  const loadRegisteredUsers = async () => {
    setLoadingUsers(true);
    logMessage('Querying system database users index...');
    
    if (isFirebaseConfigured && db) {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const list: UserProfile[] = [];
        usersSnap.forEach((doc) => {
          list.push(doc.data() as UserProfile);
        });
        setUsersList(list);
        logMessage(`Secure query returned ${list.length} critics profiles from the cloud.`);
      } catch (err: any) {
        logMessage(`Database query rejected: ${err.message || err}. Falling back to sandbox storage.`);
        loadLocalFallbacks();
      } finally {
        setLoadingUsers(false);
      }
    } else {
      loadLocalFallbacks();
      setLoadingUsers(false);
    }
  };

  const loadLocalFallbacks = () => {
    let rawMock = localStorage.getItem('muvio_mock_profiles');
    if (!rawMock) {
      const defaultMockObj = {
        "user_clark": { "uid": "user_clark", "name": "Clark Kent", "username": "gotham_observer", "email": "clark@dailyplanet.com", "role": "user", "createdAt": "2026-06-10T10:00:00.000Z", "status": "active", "isVerified": true },
        "user_valyria": { "uid": "user_valyria", "name": "Rhaenyra Targaryen", "username": "dragon_heart", "email": "rhaenyra@dragonstone.gov", "role": "user", "createdAt": "2026-06-12T19:45:00.000Z", "status": "active", "isVerified": false },
        "user_archive": { "uid": "user_archive", "name": "Gilles Deleuze", "username": "physical_media_guy", "email": "gilles@boutique.org", "role": "user", "createdAt": "2026-06-13T01:20:00.000Z", "status": "active", "isVerified": true },
        "user_toxic": { "uid": "user_toxic", "name": "Troll Master", "username": "hater_x", "email": "toxic@spambot.co", "role": "user", "createdAt": "2026-06-11T09:12:00.000Z", "status": "banned", "banReason": "Spamming offensive slurs in Spaces discussions", "isVerified": false }
      };
      localStorage.setItem('muvio_mock_profiles', JSON.stringify(defaultMockObj));
      rawMock = JSON.stringify(defaultMockObj);
    }
    const parsed = rawMock ? JSON.parse(rawMock) : {};
    const list = Object.values(parsed) as UserProfile[];
    setUsersList(list);
    logMessage(`Fetched ${list.length} sandboxed user accounts from localStorage.`);
  };

  const loadVerificationRequests = async () => {
    setLoadingRequests(true);
    logMessage('Querying verification requests queue...');
    if (isFirebaseConfigured && db) {
      try {
        const reqSnap = await getDocs(collection(db, 'verificationRequests'));
        const list: any[] = [];
        reqSnap.forEach((doc) => {
          list.push(doc.data());
        });
        setVerificationRequests(list);
        logMessage(`Secure query returned ${list.length} pending verification requests from the cloud.`);
      } catch (err: any) {
        logMessage(`Database query rejected: ${err.message || err}. Falling back to sandbox storage.`);
        loadLocalRequestsFallbacks();
      } finally {
        setLoadingRequests(false);
      }
    } else {
      loadLocalRequestsFallbacks();
      setLoadingRequests(false);
    }
  };

  const loadLocalRequestsFallbacks = () => {
    const rawRequests = localStorage.getItem('muvio_verification_requests') || '[]';
    try {
      setVerificationRequests(JSON.parse(rawRequests));
    } catch (e) {
      setVerificationRequests([]);
    }
  };

  const handleApproveVerification = async (req: any) => {
    logMessage(`Approving verification request for @${req.username}...`);
    
    // 1. Update User Profile
    if (isFirebaseConfigured && db) {
      try {
        const { doc, setDoc, deleteDoc } = await import('firebase/firestore');
        const userRef = doc(db, 'users', req.userId);
        await setDoc(userRef, { isVerified: true, verified: true }, { merge: true });
        
        // 2. Delete verification request
        const reqRef = doc(db, 'verificationRequests', req.id);
        await deleteDoc(reqRef);
        
        logMessage(`Critic @${req.username} of status verified successfully in cloud.`);
        triggerToast(`Verified @${req.username}`, 'success');
      } catch (err: any) {
        logMessage(`Failed to approve cloud verification request: ${err.message || err}`);
        triggerToast('Failed to approve request in database.', 'error');
        return;
      }
    } else {
      // Local Fallbacks
      // Update User profile list
      const updatedUsersList = usersList.map(u => {
        if (u.uid === req.userId) {
          return { ...u, isVerified: true, verified: true };
        }
        return u;
      });
      setUsersList(updatedUsersList);
      saveUsersToStorage(updatedUsersList);

      // Remove from verification requests list
      const existingReqs = localStorage.getItem('muvio_verification_requests') || '[]';
      try {
        const list = JSON.parse(existingReqs).filter((r: any) => r.id !== req.id);
        localStorage.setItem('muvio_verification_requests', JSON.stringify(list));
      } catch (e) {
        localStorage.setItem('muvio_verification_requests', '[]');
      }
      
      logMessage(`Critic @${req.username} verified successfully locally.`);
      triggerToast(`Verified @${req.username}`, 'success');
    }

    // Refresh UI
    loadRegisteredUsers();
    loadVerificationRequests();
  };

  const handleRejectVerification = async (req: any) => {
    logMessage(`Rejecting verification request for @${req.username}...`);
    
    if (isFirebaseConfigured && db) {
      try {
        const { doc, deleteDoc } = await import('firebase/firestore');
        const reqRef = doc(db, 'verificationRequests', req.id);
        await deleteDoc(reqRef);
        
        logMessage(`Verification request for @${req.username} removed from database.`);
        triggerToast(`Rejected request from @${req.username}`, 'success');
      } catch (err: any) {
        logMessage(`Failed to remove verification request: ${err.message || err}`);
        triggerToast('Failed to reject request in database.', 'error');
        return;
      }
    } else {
      // Local file fallback
      const existingReqs = localStorage.getItem('muvio_verification_requests') || '[]';
      try {
        const list = JSON.parse(existingReqs).filter((r: any) => r.id !== req.id);
        localStorage.setItem('muvio_verification_requests', JSON.stringify(list));
      } catch (e) {
        localStorage.setItem('muvio_verification_requests', '[]');
      }
      
      logMessage(`Verification request for @${req.username} rejected.`);
      triggerToast(`Rejected request from @${req.username}`, 'success');
    }

    // Refresh UI
    loadVerificationRequests();
  };

  // Sync / Real-time reviews fetching
  const loadSystemReviews = () => {
    logMessage('Syncing audience critic reviews catalog...');
    let rawReviews = localStorage.getItem('muvio_reviews');
    if (!rawReviews) {
      const defaultReviews = [
        { "id": "rev_1", "mediaId": "movie-823464", "userId": "user_clark", "username": "gotham_observer", "userAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=gotham_observer", "rating": "GO FOR IT", "text": "Paul Atreides dies in the first 20 minutes! Plot twist is insane! Godzilla saves the day! A visual tour de force.", "spoiler": true, "createdAt": "2026-06-13T10:00:00.000Z", "updatedAt": "2026-06-13T10:00:00.000Z", "likedBy": ["user_valyria"] },
        { "id": "rev_2", "mediaId": "movie-102", "userId": "user_archive", "username": "physical_media_guy", "userAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=physical_media_guy", "rating": "PERFECTION", "text": "This is an extraordinary cinematic masterpiece. Best sci-fi film of the decade with gorgeous score.", "spoiler": false, "createdAt": "2026-06-12T15:20:00.000Z", "updatedAt": "2026-06-12T15:20:00.000Z", "likedBy": [] }
      ];
      localStorage.setItem('muvio_reviews', JSON.stringify(defaultReviews));
      rawReviews = JSON.stringify(defaultReviews);
    }
    try {
      const parsed = JSON.parse(rawReviews) as MuvioReview[];
      setReviewsList(parsed);
      logMessage(`Loaded ${parsed.length} historic critic reviews into admin buffer.`);
    } catch (e) {
      logMessage('Formatting issue detected in reviews index.');
    }
  };

  // PHASE 9B DATA LIFECYCLE HANDLERS
  const loadPhase9BData = () => {
    // 1. Comments
    const rawComments = localStorage.getItem('muvio_comments');
    let loadedComments: any[] = [];
    if (!rawComments) {
      const defaultComments = [
        { "id": "comm_1", "reviewId": "rev_1", "userId": "user_toxic", "username": "hater_x", "userAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=hater_x", "text": "Your taste is garbage, crawl back to your cave.", "createdAt": "2026-06-13T10:15:00.000Z", "parentId": null, "replyToUsername": null, "likedBy": [] },
        { "id": "comm_2", "reviewId": "rev_1", "userId": "user_valyria", "username": "dragon_heart", "userAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=dragon_heart", "text": "I agree with your overview, although some pacing felt tight.", "createdAt": "2026-06-13T11:00:00.000Z", "parentId": null, "replyToUsername": null, "likedBy": [] }
      ];
      localStorage.setItem('muvio_comments', JSON.stringify(defaultComments));
      loadedComments = defaultComments;
    } else {
      loadedComments = JSON.parse(rawComments);
    }
    setCommentsList(loadedComments);

    // 2. Discussions, Posts, Replies
    const rawDisc = localStorage.getItem('muvio_spaces_discussions');
    let loadedDisc: any[] = [];
    if (!rawDisc) {
      const defaultDisc = [
        { "id": "disc_1", "title": "Will Dune Part Three cover the whole Messiah book?", "description": "Let's explore if Denis Villeneuve will compress the entire contents of Dune Messiah or if we will see a two-part resolution for Paul's tragic arc.", "authorName": "Astrophysicist Bob", "authorUsername": "bob_astrophysics", "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=bob", "createdAt": "2026-06-12T09:00:00.000Z", "isPinned": true, "replyCount": 2, "userId": "user_clark" },
        { "id": "disc_2", "title": "House of the Dragon: Did Pacing Kill Season 2?", "description": "Troll floor. Speak your mind regarding the pacing and structural issues of the second season.", "authorName": "Troll Master", "authorUsername": "hater_x", "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=hater_x", "createdAt": "2026-06-13T01:00:00.000Z", "isPinned": false, "replyCount": 1, "userId": "user_toxic" }
      ];
      localStorage.setItem('muvio_spaces_discussions', JSON.stringify(defaultDisc));
      loadedDisc = defaultDisc;
    } else {
      loadedDisc = JSON.parse(rawDisc);
    }
    setDiscussionsList(loadedDisc);

    // Spaces Posts (representing News & Rumours & Box Office)
    const loadNewsList = async () => {
      let loadedPosts: any[] = [];
      const rawPosts = localStorage.getItem('muvio_spaces_posts');
      if (rawPosts) {
        loadedPosts = JSON.parse(rawPosts);
      }

      if (isFirebaseConfigured && db) {
        try {
          const querySnapshot = await getDocs(collection(db, 'news'));
          if (!querySnapshot.empty) {
            const fsNews: any[] = [];
            querySnapshot.forEach((doc) => {
              fsNews.push({ id: doc.id, ...doc.data() });
            });
            fsNews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            loadedPosts = fsNews;
            localStorage.setItem('muvio_spaces_posts', JSON.stringify(fsNews));
          } else if (loadedPosts.length > 0) {
            try {
              const { doc, setDoc } = await import('firebase/firestore');
              for (const post of loadedPosts) {
                await setDoc(doc(db, 'news', post.id), post);
              }
            } catch (seedErr) {
              console.warn("Failed to seed items to Firestore news collection (expected if rules are restricted or pending):", seedErr);
            }
          }
        } catch (err: any) {
          console.warn("Failed to load news from Firestore, using local fallback:", err);
        }
      }

      if (loadedPosts.length === 0) {
        const defaultPosts = [
          {
            "id": "post_1",
            "category": "NEWS",
            "title": "Cillian Murphy Confirmed to Return for 28 Years Later",
            "text": "Director Danny Boyle and writer Alex Garland have officially secured Cillian Murphy's return to the legendary survival franchise. Murphy will reprise his role as Jim, serving as an executive producer.",
            "imageUrl": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=800",
            "authorName": "Muvio Admin",
            "authorUsername": "muvio_admin",
            "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=muvio_admin",
            "createdAt": "2026-06-11T12:00:00Z",
            "discussionsCount": 5,
            "userId": "admin"
          },
          {
            "id": "post_2",
            "category": "RUMOUR",
            "title": "Denis Villeneuve Eyed for Secret Cleopatra Film starring Zendaya",
            "text": "Industry insiders whisper that Sony Pictures is actively preparing a historical epic under Villeneuve's lens, with Zendaya attached to star. High-gravity drama ahead.",
            "imageUrl": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=800",
            "authorName": "Muvio Admin",
            "authorUsername": "muvio_admin",
            "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=muvio_admin",
            "createdAt": "2026-06-13T14:00:00Z",
            "discussionsCount": 3,
            "userId": "admin"
          },
          {
            "id": "post_3",
            "category": "BOX OFFICE",
            "title": "Inside Out 2 Shatters Global Records with $150M Second Weekend",
            "text": "The emotions are riding incredibly high. Pixar's latest triumph dominates global markets, showing spectacular hold with minimal decay in major regional indexes.",
            "imageUrl": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=800",
            "authorName": "Muvio Admin",
            "authorUsername": "muvio_admin",
            "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=muvio_admin",
            "createdAt": "2026-06-14T08:30:00Z",
            "discussionsCount": 0,
            "userId": "admin"
          }
        ];
        localStorage.setItem('muvio_spaces_posts', JSON.stringify(defaultPosts));
        loadedPosts = defaultPosts;
        if (isFirebaseConfigured && db) {
          try {
            const { doc, setDoc } = await import('firebase/firestore');
            for (const post of defaultPosts) {
              await setDoc(doc(db, 'news', post.id), post);
            }
          } catch (seedingErr) {
            console.error("Failed to seed default news into Firestore:", seedingErr);
          }
        }
      }
      setNewsList(loadedPosts);
    };

    loadNewsList();

    // Replies (for view replies in discussions moderation)
    const rawReplies = localStorage.getItem('muvio_spaces_replies');
    let loadedReplies: any[] = [];
    if (!rawReplies) {
      const defaultReplies = [
        { "id": "rep_reply_1", "parentId": null, "targetId": "disc_1", "targetType": "discussion", "authorUserId": "user_valyria", "authorUsername": "dragon_heart", "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=dragon_heart", "createdAt": "2026-06-12T10:00:00.000Z", "text": "I really hope they split it. Messiah is short but incredibly dense thematic density.", "likedBy": [] },
        { "id": "rep_reply_2", "parentId": null, "targetId": "disc_1", "targetType": "discussion", "authorUserId": "user_archive", "username": "physical_media_guy", "authorUsername": "physical_media_guy", "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=physical_media_guy", "createdAt": "2026-06-12T10:30:00.000Z", "text": "Denis said he only wants a trilogy, so splitting Messiah is unlikely.", "likedBy": [] },
        { "id": "rep_reply_3", "parentId": null, "targetId": "disc_2", "targetType": "discussion", "authorUserId": "user_toxic", "authorUsername": "hater_x", "authorAvatar": "https://api.dicebear.com/7.x/bottts/svg?seed=hater_x", "createdAt": "2026-06-13T01:30:00.000Z", "text": "Absolute trash pacing. Entire episodes where literally nothing happens.", "likedBy": [] }
      ];
      localStorage.setItem('muvio_spaces_replies', JSON.stringify(defaultReplies));
      loadedReplies = defaultReplies;
    } else {
      loadedReplies = JSON.parse(rawReplies);
    }
    setDiscussionsReplies(loadedReplies);

    // 3. Reports
    const rawReports = localStorage.getItem('muvio_reports');
    let loadedReports: any[] = [];
    if (!rawReports) {
      const defaultReports = [
        { "id": "rep_1", "type": "REVIEW", "reporter": "spoilers_hunter99", "reason": "Severe spoilers revealed without a warning tag.", "targetId": "rev_1", "reportedItemPreview": "Review: 'Paul Atreides dies in the first 20 minutes! Plot twist is insane!'", "date": "2026-06-13T10:00:00.000Z", "status": "PENDING" },
        { "id": "rep_2", "type": "COMMENT", "reporter": "be_kind_always", "reason": "Extremely toxic personal attack.", "targetId": "comm_1", "reportedItemPreview": "Comment: 'Your taste is garbage, crawl back to your cave.'", "date": "2026-06-12T18:30:00.000Z", "status": "PENDING" },
        { "id": "rep_3", "type": "DISCUSSION", "reporter": "valyria_fan", "reason": "Off-topic hate thread.", "targetId": "disc_2", "reportedItemPreview": "Discussion: 'House of the Dragon: Did Pacing Kill Season 2?'", "date": "2026-06-13T02:00:00.000Z", "status": "PENDING" },
        { "id": "rep_4", "type": "CONTENT", "reporter": "metadata_medic", "reason": "Incorrect release year and description.", "targetId": "movie-823464", "reportedItemPreview": "Content Catalog Item: 'GODZILLA X KONG: THE NEW EMPIRE'", "date": "2026-06-13T14:20:00.000Z", "status": "PENDING" }
      ];
      localStorage.setItem('muvio_reports', JSON.stringify(defaultReports));
      loadedReports = defaultReports;
    } else {
      loadedReports = JSON.parse(rawReports);
    }
    setReportsList(loadedReports);

    // 4. Collections
    const rawCol = localStorage.getItem('muvio_collections_list');
    let loadedCol: any[] = [];
    if (rawCol) {
      loadedCol = JSON.parse(rawCol);
    } else {
      const defaultCollections = [
        {
          "id": "col_cyberpunk",
          "name": "The Ultimate Cyberpunk & Sci-Fi Archives",
          "description": "Meticulously curated collection of the absolute finest neo-noir cyberpunk sagas, synthetic intelligence warnings, and expansive time-travelling space operas.",
          "createdAt": "2026-06-11T09:00:00.000Z",
          "mediaIds": ["movie-101", "show-102"],
          "ownerId": "gotham_observer_id",
          "ownerUsername": "gotham_observer",
          "isPublic": true,
          "likesCount": 142,
          "likedBy": [],
          "coverUrl": "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600",
          "isFeatured": true
        },
        {
          "id": "col_horror",
          "name": "Boutique Horror Masterpieces: Criterion Classics",
          "description": "Atmospheric, psychological, surreal gothic horrors that transcend conventional jump-scares. Rare physical transfers.",
          "createdAt": "2026-06-12T14:20:00.000Z",
          "mediaIds": ["show-104", "anime-201"],
          "ownerId": "dragon_heart_id",
          "ownerUsername": "dragon_heart",
          "isPublic": true,
          "likesCount": 89,
          "likedBy": [],
          "coverUrl": "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=600"
        }
      ];
      localStorage.setItem('muvio_collections_list', JSON.stringify(defaultCollections));
      loadedCol = defaultCollections;
    }
    setCollectionsList(loadedCol);
  };

  // Refresh catalogs
  const refreshLocalCatalog = () => {
    const current = getAdminCatalog();
    setCatalog(current);
  };

  useEffect(() => {
    loadRegisteredUsers();
    loadSystemReviews();
    refreshLocalCatalog();
    loadPhase9BData();
    loadVerificationRequests();
    logMessage('Administrator authentication established. Access terminal initialized.');
  }, []);

  // PHASE 9B ACTIONS & HANDLERS

  // 1. User Management
  const saveUsersToStorage = (users: any[]) => {
    const obj: Record<string, any> = {};
    users.forEach(u => {
      obj[u.uid] = u;
    });
    localStorage.setItem('muvio_mock_profiles', JSON.stringify(obj));
  };

  const handleToggleVerification = (user: any) => {
    const updated = usersList.map(u => {
      if (u.uid === user.uid) {
        const nextVerified = !(u as any).isVerified;
        logMessage(`Critic @${u.username} verification status updated to: ${nextVerified ? 'AUTHORIZED' : 'REVOKED'}.`);
        triggerToast(`Updated verification status for @${u.username}`, 'success');
        return { ...u, isVerified: nextVerified };
      }
      return u;
    });
    setUsersList(updated);
    saveUsersToStorage(updated);
  };

  const handleBanUnbanClick = (user: any) => {
    if (user.status === 'banned') {
      const updated = usersList.map(u => {
        if (u.uid === user.uid) {
          logMessage(`Critic @${u.username} unbanned from platform operations.`);
          triggerToast(`Unbanned @${u.username}`, 'success');
          return { ...u, status: 'active', banReason: '' };
        }
        return u;
      });
      setUsersList(updated);
      saveUsersToStorage(updated);
    } else {
      setUserToBan(user);
      setBanReasonInput('');
      setIsBanModalOpen(true);
    }
  };

  const handleConfirmBan = () => {
    if (!userToBan) return;
    const updated = usersList.map(u => {
      if (u.uid === userToBan.uid) {
        logMessage(`Critic @${u.username} BANNED. Reason logged: "${banReasonInput}".`);
        triggerToast(`Banned @${u.username}`, 'error');
        return { ...u, status: 'banned', banReason: banReasonInput };
      }
      return u;
    });
    setUsersList(updated);
    saveUsersToStorage(updated);
    setIsBanModalOpen(false);
    setUserToBan(null);
  };

  const handleDeleteUser = (uid: string) => {
    if (!window.confirm("Are you absolutely sure you want to permanently delete this user profile? This action cannot be undone.")) return;
    const updated = usersList.filter(u => u.uid !== uid);
    setUsersList(updated);
    saveUsersToStorage(updated);
    logMessage(`Permanent removal executed on user ID: ${uid}.`);
    triggerToast("User permanently removed.", "success");
  };

  const handleViewUserActivity = (user: any) => {
    setActivityUser(user);
    setIsActivityModalOpen(true);
  };

  // 2. Reviews Moderation
  const handleTriggerDeleteReview = async (review: MuvioReview) => {
    if (!window.confirm("Are you sure you want to delete this? This cannot be undone")) return;
    
    const originalList = [...reviewsList];
    const updated = reviewsList.filter(r => r.id !== review.id);
    setReviewsList(updated);
    localStorage.setItem('muvio_reviews', JSON.stringify(updated));
    
    try {
      if (isFirebaseConfigured && db) {
        await deleteDoc(doc(db, 'reviews', review.id));
      }
      logMessage(`Deleted review #${review.id} from consumer indexes.`);
      triggerToast("Review successfully deleted.", "success");
    } catch (err: any) {
      console.error("Failed to delete review:", err);
      setReviewsList(originalList);
      localStorage.setItem('muvio_reviews', JSON.stringify(originalList));
      triggerToast("Failed to delete review.", "error");
    }
  };

  // 3. Comments Moderation
  const handleTriggerDeleteComment = async (comment: any) => {
    if (!window.confirm("Are you sure you want to delete this? This cannot be undone")) return;
    
    const originalCommentsList = [...commentsList];
    const originalDiscussionsReplies = [...discussionsReplies];
    
    if (comment.type === 'COMMENT') {
      const currentRaw = localStorage.getItem('muvio_comments') || '[]';
      const parsed = JSON.parse(currentRaw) as any[];
      const updated = parsed.filter(c => c.id !== comment.id);
      localStorage.setItem('muvio_comments', JSON.stringify(updated));
      setCommentsList(updated);
    } else {
      const currentRaw = localStorage.getItem('muvio_spaces_replies') || '[]';
      const parsed = JSON.parse(currentRaw) as any[];
      const updated = parsed.filter(c => c.id !== comment.id);
      localStorage.setItem('muvio_spaces_replies', JSON.stringify(updated));
      setDiscussionsReplies(updated);
    }

    try {
      if (isFirebaseConfigured && db) {
        if (comment.type === 'COMMENT') {
          await deleteDoc(doc(db, 'comments', comment.id));
        } else {
          try {
            await deleteDoc(doc(db, 'replies', comment.id));
          } catch (dbErr) {
            console.warn("Firestore delete reply warn (this might be a local-only entity):", dbErr);
          }
        }
      }
      logMessage(`Comment node #${comment.id} deleted by administrator.`);
      triggerToast("Comment deleted successfully.", "success");
    } catch (err: any) {
      console.error("Failed to delete comment:", err);
      if (comment.type === 'COMMENT') {
        setCommentsList(originalCommentsList);
        localStorage.setItem('muvio_comments', JSON.stringify(originalCommentsList));
      } else {
        setDiscussionsReplies(originalDiscussionsReplies);
        localStorage.setItem('muvio_spaces_replies', JSON.stringify(originalDiscussionsReplies));
      }
      triggerToast("Failed to delete comment.", "error");
    }
  };

  const getUnifiedCommentsList = () => {
    const list: any[] = [];
    commentsList.forEach(c => {
      list.push({
        id: c.id,
        text: c.text,
        username: c.username,
        userAvatar: c.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${c.username}`,
        createdAt: c.createdAt,
        context: `Review #${c.reviewId || 'Catalog'}`,
        type: 'COMMENT',
        raw: c
      });
    });
    discussionsReplies.forEach(c => {
      if (list.some(x => x.id === c.id)) return;
      list.push({
        id: c.id,
        text: c.text,
        username: c.authorUsername,
        userAvatar: c.authorAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${c.authorUsername}`,
        createdAt: c.createdAt,
        context: `Space #${c.targetId}`,
        type: 'SPACE_REPLY',
        raw: c
      });
    });
    return list;
  };

  // 4. Discussions Moderation
  const handleTogglePinDiscussion = (id: string) => {
    const updated = discussionsList.map(d => {
      if (d.id === id) {
        const nextPinned = !d.isPinned;
        logMessage(`Space discussion #${id} pin status updated to: ${nextPinned}.`);
        triggerToast(nextPinned ? "Discussion pinned." : "Discussion unpinned.", "success");
        return { ...d, isPinned: nextPinned };
      }
      return d;
    });
    setDiscussionsList(updated);
    localStorage.setItem('muvio_spaces_discussions', JSON.stringify(updated));
  };

  const handleTriggerDeleteDiscussion = async (disc: any) => {
    if (!window.confirm("Are you sure you want to delete this? This cannot be undone")) return;
    
    const originalDiscussions = [...discussionsList];
    const originalReplies = [...discussionsReplies];
    
    const updated = discussionsList.filter(d => d.id !== disc.id);
    setDiscussionsList(updated);
    localStorage.setItem('muvio_spaces_discussions', JSON.stringify(updated));

    // Prune its replies
    const repliesRaw = localStorage.getItem('muvio_spaces_replies') || '[]';
    const parsedReplies = JSON.parse(repliesRaw) as any[];
    const filteredReplies = parsedReplies.filter(r => !(r.targetId === disc.id && r.targetType === 'discussion'));
    localStorage.setItem('muvio_spaces_replies', JSON.stringify(filteredReplies));
    setDiscussionsReplies(filteredReplies);

    try {
      if (isFirebaseConfigured && db) {
        try {
          await deleteDoc(doc(db, 'discussions', disc.id));
        } catch (dbErr) {
          console.warn("Firestore delete discussion warn (this might be a local-only entity):", dbErr);
        }
      }
      logMessage(`Discussion thread #${disc.id} and associated replies deleted.`);
      triggerToast("Discussion thread deleted.", "success");
    } catch (err: any) {
      console.error("Failed to delete discussion:", err);
      setDiscussionsList(originalDiscussions);
      localStorage.setItem('muvio_spaces_discussions', JSON.stringify(originalDiscussions));
      setDiscussionsReplies(originalReplies);
      localStorage.setItem('muvio_spaces_replies', JSON.stringify(originalReplies));
      triggerToast("Failed to delete discussion.", "error");
    }
  };

  const handleViewDiscussionReplies = (disc: any) => {
    setActiveDiscussionForRepliesModal(disc);
    setIsDiscussionRepliesModalOpen(true);
  };

  const handleDeleteRepliesModalReply = async (replyId: string) => {
    if (!window.confirm("Are you sure you want to delete this? This cannot be undone")) return;
    const originalReplies = [...discussionsReplies];
    
    const repliesRaw = localStorage.getItem('muvio_spaces_replies') || '[]';
    const parsedReplies = JSON.parse(repliesRaw) as any[];
    const updated = parsedReplies.filter(r => r.id !== replyId);
    localStorage.setItem('muvio_spaces_replies', JSON.stringify(updated));
    setDiscussionsReplies(updated);
    
    try {
      if (isFirebaseConfigured && db) {
        try {
          await deleteDoc(doc(db, 'replies', replyId));
        } catch (dbErr) {
          console.warn("Firestore delete reply warn:", dbErr);
        }
      }
      triggerToast("Reply successfully deleted.", "success");
    } catch (err: any) {
      console.error("Failed to delete reply:", err);
      setDiscussionsReplies(originalReplies);
      localStorage.setItem('muvio_spaces_replies', JSON.stringify(originalReplies));
      triggerToast("Failed to delete reply.", "error");
    }
  };

  // 5. Reports Handlers
  const handleDismissReport = (reportId: string) => {
    const updated = reportsList.map(r => {
      if (r.id === reportId) {
        logMessage(`Report #${reportId} dismissed by administrators.`);
        triggerToast("Report dismissed.", "success");
        return { ...r, status: 'RESOLVED_DISMISSED' };
      }
      return r;
    });
    setReportsList(updated);
    localStorage.setItem('muvio_reports', JSON.stringify(updated));
  };

  const handleResolveReport = (reportId: string, targetId: string, type: 'REVIEW' | 'COMMENT' | 'DISCUSSION' | 'CONTENT') => {
    // 1. Mark report as resolved
    const updatedReports = reportsList.map(r => {
      if (r.id === reportId) {
        return { ...r, status: 'RESOLVED_DELETED' };
      }
      return r;
    });
    setReportsList(updatedReports);
    localStorage.setItem('muvio_reports', JSON.stringify(updatedReports));

    // 2. Clear target item from its respective index
    if (type === 'REVIEW') {
      const updatedReviews = reviewsList.filter(r => r.id !== targetId);
      setReviewsList(updatedReviews);
      localStorage.setItem('muvio_reviews', JSON.stringify(updatedReviews));
    } else if (type === 'COMMENT') {
      const rawComm = localStorage.getItem('muvio_comments') || '[]';
      const parsedComm = JSON.parse(rawComm) as any[];
      const updatedComm = parsedComm.filter(c => c.id !== targetId);
      localStorage.setItem('muvio_comments', JSON.stringify(updatedComm));
      setCommentsList(updatedComm);

      const rawRep = localStorage.getItem('muvio_spaces_replies') || '[]';
      const parsedRep = JSON.parse(rawRep) as any[];
      const updatedRep = parsedRep.filter(r => r.id !== targetId);
      localStorage.setItem('muvio_spaces_replies', JSON.stringify(updatedRep));
      setDiscussionsReplies(updatedRep);
    } else if (type === 'DISCUSSION') {
      const updatedDisc = discussionsList.filter(d => d.id !== targetId);
      setDiscussionsList(updatedDisc);
      localStorage.setItem('muvio_spaces_discussions', JSON.stringify(updatedDisc));
    } else if (type === 'CONTENT') {
      const current = getAdminCatalog();
      const updatedCatalog = current.filter(item => item.id !== targetId);
      localStorage.setItem('muvio_admin_catalog', JSON.stringify(updatedCatalog));
      refreshLocalCatalog();
    }

    logMessage(`Resolved report #${reportId}. Deleted target ${type} item #${targetId}.`);
    triggerToast("Item deleted and report resolved.", "success");
  };

  const handleViewReportedItem = (report: any) => {
    setViewedReportedItem(report);
  };

  // 6. News Room / Editorial Handlers
  const handleOpenNewsForm = () => {
    setEditingNewsId(null);
    setNewsFormTitle('');
    setNewsFormCategory('NEWS');
    setNewsFormAssociatedContentId('');
    setNewsFormImageUrl('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600');
    setNewsFormBody('');
    setNewsFormPrompt('');
    setIsNewsFormOpen(true);
  };

  const handleEditNewsArticle = (post: any) => {
    setEditingNewsId(post.id);
    setNewsFormTitle(post.title || '');
    setNewsFormCategory(post.category || 'NEWS');
    setNewsFormAssociatedContentId(post.associatedContentId || '');
    setNewsFormImageUrl(post.imageUrl || '');
    setNewsFormBody(post.text || '');
    setNewsFormPrompt('');
    setIsNewsFormOpen(true);
  };

  const handleDeleteNewsArticle = async (id: string) => {
    const article = { id };
    console.log("DELETE BUTTON CLICKED", article.id);
    try {
      alert("Delete handler triggered");
    } catch (alertErr) {
      console.warn("alert was blocked by iframe browser environment sandbox restrictions:", alertErr);
    }

    if (!window.confirm("Are you sure you want to permanently delete this news article from Firestore? This cannot be undone.")) return;
    
    setDeletingNewsIdState(id);
    
    try {
      if (isFirebaseConfigured && db) {
        try {
          const { doc, deleteDoc } = await import('firebase/firestore');
          // Call deleteDoc directly on the 'news' collection using the document ID
          await deleteDoc(doc(db, 'news', id));
        } catch (dbErr: any) {
          console.error(`Failed to delete news article #${id} from Firestore:`, dbErr);
          // Propagate the real firebase error; do not fall back to fake local-only success
          throw new Error(`Firestore Error: ${dbErr.message || dbErr}`);
        }
      } else {
        throw new Error("Firestore database is not configured. Unable to perform permanent cloud deletion.");
      }
      
      // Confirm the delete operation succeeds in Firestore before removing the item from local state and localStorage
      const updated = newsList.filter(n => n.id !== id);
      setNewsList(updated);
      localStorage.setItem('muvio_spaces_posts', JSON.stringify(updated));
      logMessage(`Editorial News article #${id} deleted from Firestore permanently.`);
      triggerToast("Article successfully deleted from Firestore.", "success");
    } catch (err: any) {
      console.error(`Failed to delete news article #${id}:`, err);
      // Let the administrator know of the exact failure reason
      triggerToast(`Failed to delete news article: ${err.message || err}`, "error");
    } finally {
      setDeletingNewsIdState(null);
    }
  };

  const handleGenerateNewsDraft = async () => {
    if (!newsFormPrompt) {
      triggerToast("Please enter a short guidance prompt first.", "error");
      return;
    }
    setIsGeneratingNewsDraft(true);
    let assocTitle = '';
    if (newsFormAssociatedContentId) {
      const matched = catalog.find(x => x.id === newsFormAssociatedContentId);
      if (matched) assocTitle = matched.media.title;
    }
    
    try {
      const res = await fetch("/api/gemini/generate-news", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: newsFormPrompt,
          category: newsFormCategory,
          title: newsFormTitle,
          associatedContentTitle: assocTitle
        })
      });
      const data = await res.json();
      if (data.text) {
        setNewsFormBody(data.text);
        triggerToast("Editorial drafted by Gemini AI Director!", "success");
      } else {
        triggerToast("Generation failed. Double check prompt guidelines.", "error");
      }
    } catch (e: any) {
      console.error(e);
      triggerToast("AI integration offline. Falling back to local template.", "error");
      setNewsFormBody(`Fallback Draft: Investigation regarding "${newsFormTitle || 'the theatrical release'}". Fans globally are discussing potential releases and production beats.`);
    } finally {
      setIsGeneratingNewsDraft(false);
    }
  };

  const handleSaveNewsArticle = async () => {
    if (!newsFormTitle || !newsFormBody) {
      triggerToast("Title and Body content are mandatory.", "error");
      return;
    }

    let updatedList = [...newsList];
    let savedArticle: any = null;

    if (editingNewsId) {
      updatedList = updatedList.map(n => {
        if (n.id === editingNewsId) {
          const updated = {
            ...n,
            title: newsFormTitle,
            category: newsFormCategory,
            imageUrl: newsFormImageUrl,
            text: newsFormBody,
            associatedContentId: newsFormAssociatedContentId || undefined
          };
          savedArticle = updated;
          return updated;
        }
        return n;
      });
      logMessage(`Updated editorial content regarding draft #${editingNewsId}.`);
      triggerToast("Article successfully updated.", "success");
    } else {
      const newPostId = `post_${Date.now()}`;
      savedArticle = {
        id: newPostId,
        category: newsFormCategory,
        title: newsFormTitle,
        text: newsFormBody,
        imageUrl: newsFormImageUrl,
        authorName: "Muvio Admin",
        authorUsername: "muvio_admin",
        authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=muvio_admin`,
        createdAt: new Date().toISOString(),
        discussionsCount: 0,
        userId: "admin",
        associatedContentId: newsFormAssociatedContentId || undefined
      };
      updatedList = [savedArticle, ...updatedList];
      logMessage(`New active community article published. Category: ${newsFormCategory}.`);
      triggerToast("Editorial article published fully.", "success");
    }

    // Save to Firestore if configured
    if (isFirebaseConfigured && db && savedArticle) {
      try {
        const { doc, setDoc } = await import('firebase/firestore');
        await setDoc(doc(db, 'news', savedArticle.id), savedArticle);
      } catch (err: any) {
        console.warn("Failed to save news article to Firestore (using local fallback):", err);
        triggerToast(`Warning: News saved locally (cloud sync pending)`, "success");
      }
    }

    setNewsList(updatedList);
    localStorage.setItem('muvio_spaces_posts', JSON.stringify(updatedList));
    setIsNewsFormOpen(false);
  };

  // 7. Collections Management
  const handleToggleFeatureCollection = (id: string) => {
    const updated = collectionsList.map(c => {
      if (c.id === id) {
        const nextFeat = !c.isFeatured;
        logMessage(`Collection Portfolio #${id} featured-state set: ${nextFeat}.`);
        triggerToast(nextFeat ? "Collection set as Featured." : "Collection unfeatured.", "success");
        return { ...c, isFeatured: nextFeat };
      }
      return c;
    });
    setCollectionsList(updated);
    localStorage.setItem('muvio_collections_list', JSON.stringify(updated));
  };

  const handleTriggerDeleteCollection = async (col: any) => {
    if (!window.confirm("Are you sure you want to delete this? This cannot be undone")) return;
    const originalList = [...collectionsList];
    const updated = collectionsList.filter(c => c.id !== col.id);
    setCollectionsList(updated);
    localStorage.setItem('muvio_collections_list', JSON.stringify(updated));
    
    try {
      const ownerId = col.ownerId || col.userId;
      if (isFirebaseConfigured && db && ownerId) {
        await deleteDoc(doc(db, 'users', ownerId, 'collections', col.id));
      }
      logMessage(`Pruned collection portfolio #${col.id}.`);
      triggerToast("Collection successfully deleted.", "success");
    } catch (err: any) {
      console.error("Failed to delete collection:", err);
      setCollectionsList(originalList);
      localStorage.setItem('muvio_collections_list', JSON.stringify(originalList));
      triggerToast("Failed to delete collection.", "error");
    }
  };

  const handleToggleSetting = async () => {
    const nextVal = !showLandingPage;
    try {
      logMessage(`Initiating option payload modify: show_landing_page = ${nextVal}...`);
      await onToggleLandingPage(nextVal);
      logMessage(`Switched feature key write successful.`);
      triggerToast(`Spotlight screen state updated.`, 'success');
    } catch (err: any) {
      logMessage(`Mutation aborted: ${err.message || err}`);
    }
  };

  const handleForceLogoff = async () => {
    logMessage('De-authenticating terminal session key...');
    await logoutUser();
    onNavigate('/login');
  };

  // --- CONTENT CRUD HANDLERS ---

  const handleOpenEdit = (id: string) => {
    const item = catalog.find(c => c.id === id);
    if (!item) return;

    setEditingItemId(id);
    setIsCreatingNew(false);

    setEditTitle(item.media.title);
    setEditOverview(item.media.description);
    setEditYear(item.media.year);
    setEditDuration(item.duration);
    setEditCountry(item.country);
    setEditLanguage(item.language);
    setEditAgeRating(item.ageRating);
    setEditType(item.media.type);
    setEditRating(item.media.ratingPercent);
    setEditVotes(item.media.voteCount);
    setEditReleased(item.media.releaseDate);
    setEditStatus(item.status);
    setEditPoster(item.media.posterUrl);
    setEditBackdrop(item.media.backdropUrl);
    setEditCast(item.cast || []);
    setEditCrew(item.crew || []);
    setEditCompanies(item.productionCompanies || []);
    setEditGenres(item.genres || []);
    
    // Normalize and retrieve downloads
    if (item.downloads && item.downloads.length > 0) {
      setEditDownloads(
        item.downloads.map(dl => ({
          quality: dl.quality || '',
          url: dl.url || '',
          enabled: !!dl.enabled,
          size: dl.size || ''
        }))
      );
    } else {
      setEditDownloads([
        { quality: '480P', url: '', enabled: false, size: '' },
        { quality: '720P', url: '', enabled: false, size: '' },
        { quality: '1080P', url: '', enabled: false, size: '' },
        { quality: '4K HDR', url: '', enabled: false, size: '' }
      ]);
    }
    setEditDownloadsEnabled(item.downloadsEnabled !== false);

    setEditTickets(item.ticketLinks || []);
    setEditIsFeatured(item.isFeatured || false);
    setEditIsMuvioSelect(item.isMuvioSelect || false);
    setEditDataSource(item.dataSource || 'DATABASE');
    setEditStreamingEnabled(item.streamingEnabled || false);
    setEditStreamingLinks(item.streamingLinks || []);
    setEditStreamingSeasons(item.streamingSeasons || []);

    logMessage(`Instantiated edit terminal buffers for record "${item.media.title}" (${id}).`);
  };

  const handleOpenCreate = () => {
    setIsCreatingNew(true);
    setEditingItemId(null);

    setEditTitle('');
    setEditOverview('');
    setEditYear(2026);
    setEditDuration('2h 15m');
    setEditCountry('United States');
    setEditLanguage('English');
    setEditAgeRating('PG-13');
    setEditType('MOVIE');
    setEditRating(80);
    setEditVotes(120);
    setEditReleased('2026-06-13');
    setEditStatus('Published');
    setEditPoster('https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=400');
    setEditBackdrop('https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1200');
    setEditCast([]);
    setEditCrew([]);
    setEditCompanies([]);
    setEditGenres(['Action', 'Sci-Fi']);
    setEditDownloads([
      { quality: '480P', url: '', enabled: false, size: '' },
      { quality: '720P', url: '', enabled: false, size: '' },
      { quality: '1080P', url: '', enabled: false, size: '' },
      { quality: '4K HDR', url: '', enabled: false, size: '' }
    ]);
    setEditDownloadsEnabled(true);
    setEditTickets([]);
    setEditIsFeatured(false);
    setEditIsMuvioSelect(false);
    setEditDataSource('DATABASE');
    setEditStreamingEnabled(false);
    setEditStreamingLinks([]);
    setEditStreamingSeasons([]);

    logMessage('Created pristine buffer for custom database ingestion.');
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim()) {
      triggerToast('Title field is binary critical.', 'error');
      return;
    }

    const uniqueId = isCreatingNew 
      ? `${editType.toLowerCase()}-custom-${Math.random().toString(36).substring(2, 8)}`
      : editingItemId!;

    const payload: MuvioCatalogItem = {
      id: uniqueId,
      media: {
        id: uniqueId,
        tmdbId: isCreatingNew ? Math.floor(Math.random() * 900000) + 100000 : catalog.find(c => c.id === uniqueId)?.media.tmdbId || 99999,
        title: editTitle.toUpperCase(),
        type: editType,
        year: Number(editYear),
        description: editOverview,
        backdropUrl: editBackdrop || 'https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=1200',
        posterUrl: editPoster || 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&q=80&w=400',
        ratingPercent: Number(editRating),
        voteCount: Number(editVotes),
        releaseDate: editReleased,
        statusBadge: editStatus === 'Published' ? 'Published' : editStatus === 'Pending' ? 'Pending' : 'Draft'
      },
      genres: editGenres,
      duration: editDuration,
      directedBy: editCrew.find(c => c.role === 'Director')?.name || 'Unknown',
      country: editCountry,
      language: editLanguage,
      ageRating: editAgeRating,
      trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      productionCompanies: editCompanies,
      cast: editCast,
      crew: editCrew,
      status: editStatus,
      source: isCreatingNew ? 'Manual' : catalog.find(c => c.id === uniqueId)?.source || 'Manual',
      dateAdded: isCreatingNew ? new Date().toISOString() : catalog.find(c => c.id === uniqueId)?.dateAdded || new Date().toISOString(),
      downloads: editDownloads,
      downloadsEnabled: editDownloadsEnabled,
      ticketLinks: editTickets,
      isFeatured: editIsFeatured,
      isMuvioSelect: editIsMuvioSelect,
      dataSource: editDataSource,
      streamingEnabled: editStreamingEnabled,
      streamingLinks: editStreamingLinks,
      streamingSeasons: editStreamingSeasons
    };

    saveCatalogItem(payload);
    refreshLocalCatalog();
    setEditingItemId(null);
    setIsCreatingNew(false);
    triggerToast(`Cinema record "${payload.media.title}" captured in local system.`, 'success');
    logMessage(`Saved catalog item write transactions to disk: ${uniqueId}`);
  };

  const handleDeleteItem = (id: string) => {
    deleteCatalogItem(id);
    refreshLocalCatalog();
    setDeleteConfirmationId(null);
    triggerToast('Cinema entry discarded from central catalog.', 'success');
    logMessage(`Erased film record block from memory cache: ${id}`);
  };

  // --- STREAMING LINK MUTATORS ---
  const addMovieStreamLink = (platform: string, embedCode: string) => {
    if (!platform.trim() || !embedCode.trim()) {
      triggerToast('Platform name and embed/URL are required.', 'error');
      return;
    }
    const updated = [...editStreamingLinks, { platform, embedCode, enabled: true }];
    setEditStreamingLinks(updated);
    setNewMovieStreamPlatform('');
    setNewMovieStreamCode('');
    triggerToast(`Streaming platform "${platform}" added successfully.`, 'success');
  };

  const removeMovieStreamLink = (idx: number) => {
    const updated = editStreamingLinks.filter((_, i) => i !== idx);
    setEditStreamingLinks(updated);
    triggerToast('Streaming platform removed.', 'success');
  };

  const toggleMovieStreamLink = (idx: number) => {
    const updated = editStreamingLinks.map((item, i) => {
      if (i === idx) {
        return { ...item, enabled: !item.enabled };
      }
      return item;
    });
    setEditStreamingLinks(updated);
  };

  const addSeason = (num: number) => {
    if (!num || num <= 0) return;
    if (editStreamingSeasons.some(s => s.seasonNumber === num)) {
      triggerToast('Season already exists.', 'error');
      return;
    }
    const updated = [...editStreamingSeasons, { seasonNumber: num, episodes: [] }];
    updated.sort((a, b) => a.seasonNumber - b.seasonNumber);
    setEditStreamingSeasons(updated);
    triggerToast(`Season ${num} added successfully.`, 'success');
  };

  const removeSeason = (num: number) => {
    const updated = editStreamingSeasons.filter(s => s.seasonNumber !== num);
    setEditStreamingSeasons(updated);
    triggerToast(`Season ${num} removed.`, 'success');
  };

  const addEpisode = (seasonNum: number, epNum: number, title: string) => {
    if (!epNum || epNum <= 0) return;
    const seasonIdx = editStreamingSeasons.findIndex(s => s.seasonNumber === seasonNum);
    if (seasonIdx === -1) return;

    const season = editStreamingSeasons[seasonIdx];
    if (season.episodes.some(e => e.episodeNumber === epNum)) {
      triggerToast(`Episode ${epNum} already exists in Season ${seasonNum}.`, 'error');
      return;
    }

    const updatedEpisodes = [...season.episodes, { episodeNumber: epNum, title, platforms: [] }];
    updatedEpisodes.sort((a, b) => a.episodeNumber - b.episodeNumber);

    const updatedSeasons = [...editStreamingSeasons];
    updatedSeasons[seasonIdx] = { ...season, episodes: updatedEpisodes };
    setEditStreamingSeasons(updatedSeasons);
    triggerToast(`Episode ${epNum} added to Season ${seasonNum}.`, 'success');
  };

  const removeEpisode = (seasonNum: number, epNum: number) => {
    const seasonIdx = editStreamingSeasons.findIndex(s => s.seasonNumber === seasonNum);
    if (seasonIdx === -1) return;

    const season = editStreamingSeasons[seasonIdx];
    const updatedEpisodes = season.episodes.filter(e => e.episodeNumber !== epNum);

    const updatedSeasons = [...editStreamingSeasons];
    updatedSeasons[seasonIdx] = { ...season, episodes: updatedEpisodes };
    setEditStreamingSeasons(updatedSeasons);
    triggerToast(`Episode ${epNum} removed from Season ${seasonNum}.`, 'success');
  };

  const addPlatformToEpisode = (seasonNum: number, epNum: number, platform: string, embedCode: string) => {
    if (!platform.trim() || !embedCode.trim()) {
      triggerToast('Platform name and embed/URL keys are required.', 'error');
      return;
    }
    const seasonIdx = editStreamingSeasons.findIndex(s => s.seasonNumber === seasonNum);
    if (seasonIdx === -1) return;

    const season = editStreamingSeasons[seasonIdx];
    const epIdx = season.episodes.findIndex(e => e.episodeNumber === epNum);
    if (epIdx === -1) return;

    const episode = season.episodes[epIdx];
    const updatedPlatforms = [...episode.platforms, { platform, embedCode, enabled: true }];

    const updatedEpisodes = [...season.episodes];
    updatedEpisodes[epIdx] = { ...episode, platforms: updatedPlatforms };

    const updatedSeasons = [...editStreamingSeasons];
    updatedSeasons[seasonIdx] = { ...season, episodes: updatedEpisodes };
    
    setEditStreamingSeasons(updatedSeasons);
    triggerToast(`Server "${platform}" added to Episode ${epNum}.`, 'success');
  };

  const removePlatformFromEpisode = (seasonNum: number, epNum: number, platformIdx: number) => {
    const seasonIdx = editStreamingSeasons.findIndex(s => s.seasonNumber === seasonNum);
    if (seasonIdx === -1) return;

    const season = editStreamingSeasons[seasonIdx];
    const epIdx = season.episodes.findIndex(e => e.episodeNumber === epNum);
    if (epIdx === -1) return;

    const episode = season.episodes[epIdx];
    const updatedPlatforms = episode.platforms.filter((_, idx) => idx !== platformIdx);

    const updatedEpisodes = [...season.episodes];
    updatedEpisodes[epIdx] = { ...episode, platforms: updatedPlatforms };

    const updatedSeasons = [...editStreamingSeasons];
    updatedSeasons[seasonIdx] = { ...season, episodes: updatedEpisodes };

    setEditStreamingSeasons(updatedSeasons);
    triggerToast('Server host removed.', 'success');
  };

  const togglePlatformInEpisode = (seasonNum: number, epNum: number, platformIdx: number) => {
    const seasonIdx = editStreamingSeasons.findIndex(s => s.seasonNumber === seasonNum);
    if (seasonIdx === -1) return;

    const season = editStreamingSeasons[seasonIdx];
    const epIdx = season.episodes.findIndex(e => e.episodeNumber === epNum);
    if (epIdx === -1) return;

    const episode = season.episodes[epIdx];
    const updatedPlatforms = episode.platforms.map((p, idx) => {
      if (idx === platformIdx) {
        return { ...p, enabled: !p.enabled };
      }
      return p;
    });

    const updatedEpisodes = [...season.episodes];
    updatedEpisodes[epIdx] = { ...episode, platforms: updatedPlatforms };

    const updatedSeasons = [...editStreamingSeasons];
    updatedSeasons[seasonIdx] = { ...season, episodes: updatedEpisodes };

    setEditStreamingSeasons(updatedSeasons);
  };

  // --- CAST AND SUB-MEMBERS MUTATORS ---

  const addCastMember = () => {
    if (!newCastName.trim()) return;
    const item: MuvioCastMember = {
      id: Math.floor(Math.random() * 10000),
      name: newCastName,
      character: newCastChar || 'Supporting Lead',
      profileUrl: newCastPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120'
    };
    setEditCast([...editCast, item]);
    setNewCastName('');
    setNewCastChar('');
    setNewCastPhoto('');
  };

  const removeCastMember = (id: number) => {
    setEditCast(editCast.filter(c => c.id !== id));
  };

  const addCrewMember = () => {
    if (!newCrewName.trim() || !newCrewRole.trim()) return;
    const item: MuvioCrewMember = {
      id: Math.floor(Math.random() * 10000),
      name: newCrewName,
      role: newCrewRole,
      profileUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&q=80&w=120'
    };
    setEditCrew([...editCrew, item]);
    setNewCrewName('');
    setNewCrewRole('');
  };

  const addGenreTag = () => {
    if (!newGenreTag.trim()) return;
    if (!editGenres.includes(newGenreTag.trim())) {
      setEditGenres([...editGenres, newGenreTag.trim()]);
    }
    setNewGenreTag('');
  };

  const removeGenreTag = (tag: string) => {
    setEditGenres(editGenres.filter(g => g !== tag));
  };

  const addTicketPlatform = () => {
    if (!newTicketPlatform.trim() || !newTicketUrl.trim()) return;
    
    let domainToUse = newTicketDomain.trim();
    if (!domainToUse) {
      const norm = newTicketPlatform.trim().toLowerCase();
      if (norm.includes('netflix')) domainToUse = 'netflix.com';
      else if (norm.includes('amazon prime') || norm.includes('prime')) domainToUse = 'primevideo.com';
      else if (norm.includes('disney')) domainToUse = 'disneyplus.com';
      else if (norm.includes('hotstar')) domainToUse = 'hotstar.com';
      else if (norm.includes('jiocinema') || norm.includes('jio cinema')) domainToUse = 'jiocinema.com';
      else if (norm.includes('youtube')) domainToUse = 'youtube.com';
      else if (norm.includes('apple tv') || norm.includes('apple-tv')) domainToUse = 'apple.com';
      else if (norm.includes('hbo max') || norm.includes('max')) domainToUse = 'max.com';
      else if (norm.includes('hulu')) domainToUse = 'hulu.com';
      else if (norm.includes('sony liv') || norm.includes('sonyliv')) domainToUse = 'sonyliv.com';
      else if (norm.includes('zee5') || norm.includes('zee 5')) domainToUse = 'zee5.com';
      else if (norm.includes('voot')) domainToUse = 'voot.com';
      else if (norm.includes('mx player') || norm.includes('mxplayer')) domainToUse = 'mxplayer.in';
    }

    setEditTickets([...editTickets, { 
      platform: newTicketPlatform, 
      url: newTicketUrl, 
      type: newTicketType, 
      domain: domainToUse 
    }]);
    setNewTicketPlatform('');
    setNewTicketUrl('');
    setNewTicketDomain('');
    setNewTicketType('Subscription');
  };

  const removeTicketPlatform = (idx: number) => {
    setEditTickets(editTickets.filter((_, i) => i !== idx));
  };

  const handleDownloadChange = (idx: number, field: 'quality' | 'url' | 'enabled' | 'size', value: any) => {
    const updated = [...editDownloads];
    updated[idx] = { ...updated[idx], [field]: value };
    setEditDownloads(updated);
  };

  // --- BULK OPERATIONS FOR PENDING APPROVALS ---

  const handleTogglePendingSelect = (id: string) => {
    setSelectedPendingIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handlePendingBulkApprove = () => {
    if (selectedPendingIds.length === 0) return;
    bulkApproveItems(selectedPendingIds);
    logMessage(`Bulk approved ${selectedPendingIds.length} item(s) from pending queue.`);
    triggerToast(`Approved ${selectedPendingIds.length} movie entries.`, 'success');
    setSelectedPendingIds([]);
    refreshLocalCatalog();
  };

  const handlePendingBulkReject = () => {
    if (selectedPendingIds.length === 0) return;
    bulkRejectItems(selectedPendingIds);
    logMessage(`Bulk rejected ${selectedPendingIds.length} item(s) to drafts.`);
    triggerToast(`Rejected ${selectedPendingIds.length} movie entries to drafts.`, 'success');
    setSelectedPendingIds([]);
    refreshLocalCatalog();
  };

  const handlePendingSingleAction = (id: string, action: 'approve' | 'reject') => {
    if (action === 'approve') {
      bulkApproveItems([id]);
      triggerToast('Movie entry approved and published.', 'success');
      logMessage(`Approved single pending item: ${id}`);
    } else {
      bulkRejectItems([id]);
      triggerToast('Movie entry sent to raw drafts.', 'error');
      logMessage(`Rejected pending item: ${id}`);
    }
    refreshLocalCatalog();
  };

  // --- TMDB IMPORT OPERATIONS ---

  const handleTmdbSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tmdbQuery.trim()) return;

    setLoadingTmdb(true);
    logMessage(`Initiating TMDB query indexing: "${tmdbQuery}"...`);
    try {
      const results = await searchCatalog(tmdbQuery, 'ALL', true);
      setTmdbResults(results);
      logMessage(`Query index returned ${results.length} related match matrices from TMDB global node.`);
    } catch (err: any) {
      logMessage(`Catalog mapping failed: ${err.message || err}`);
      triggerToast('Failed to pull TMDB remote results.', 'error');
    } finally {
      setLoadingTmdb(false);
    }
  };

  const handleToggleImportSelect = (tmdbId: number) => {
    setSelectedImportIds(prev =>
      prev.includes(tmdbId) ? prev.filter(x => x !== tmdbId) : [...prev, tmdbId]
    );
  };

  const handleTriggerSingleImport = (item: MuvioMedia) => {
    setImportConfirmItem(item);
    setIsBulkImportConfirmOpen(false);
    setImportConfirmDataSource('DATABASE');
  };

  const handleTriggerBulkImport = () => {
    if (selectedImportIds.length === 0) return;
    setImportConfirmItem(null);
    setIsBulkImportConfirmOpen(true);
    setImportConfirmDataSource('DATABASE');
  };

  const handleSingleImport = async (item: MuvioMedia, dataSource: 'DATABASE' | 'LIVE_TMDB' = 'DATABASE') => {
    setImportingInProgress(true);
    logMessage(`Querying exact detail node mapping for TMDB ID ${item.tmdbId}...`);
    try {
      const typeStr = item.type === 'MOVIE' ? 'movie' : 'tv';
      const richDetails = await getRichMediaDetails(typeStr, item.tmdbId, true);

      const catalogItem: MuvioCatalogItem = {
        id: item.id,
        media: {
          ...item,
          statusBadge: 'Pending'
        },
        genres: richDetails.genres,
        duration: richDetails.duration,
        directedBy: richDetails.directedBy,
        country: richDetails.country,
        language: richDetails.language,
        ageRating: richDetails.ageRating,
        trailerUrl: richDetails.trailerUrl,
        productionCompanies: richDetails.productionCompanies,
        cast: richDetails.cast,
        crew: richDetails.crew,
        status: 'Pending',
        source: 'TMDB Import',
        dataSource: dataSource,
        dateAdded: new Date().toISOString(),
        downloads: [
          { quality: '480p', url: '', enabled: false },
          { quality: '720p', url: '', enabled: false },
          { quality: '1080p', url: '', enabled: false },
          { quality: '4K', url: '', enabled: false }
        ],
        ticketLinks: [],
        isFeatured: false,
        isMuvioSelect: false
      };

      saveCatalogItem(catalogItem);
      refreshLocalCatalog();
      triggerToast(`Successfully pulled "${item.title}" into Pending queue with source ${dataSource}.`, 'success');
      logMessage(`Import complete. Item payload placed in pending buffer: ${item.id} with source ${dataSource}`);

      // Push real system notifications
      if (currentUser?.uid) {
        await createNotification(
          currentUser.uid,
          'system',
          'SYSTEM',
          'TRENDING_CONTENT',
          'global',
          item.id,
          `"${item.title}" (${item.type}) has been imported from TMDB and awaits review.`
        ).catch(() => {});
      }
    } catch (err: any) {
      logMessage(`TMDB details compilation failed: ${err.message || err}`);
      triggerToast('Could not finalize detail matrices.', 'error');
    } finally {
      setImportingInProgress(false);
    }
  };

  const handleBulkImport = async (dataSource: 'DATABASE' | 'LIVE_TMDB' = 'DATABASE') => {
    if (selectedImportIds.length === 0) return;
    setImportingInProgress(true);
    logMessage(`Beginning batch ingestion of ${selectedImportIds.length} remote nodes with source ${dataSource}...`);
    
    let count = 0;
    for (const tmdbId of selectedImportIds) {
      const item = tmdbResults.find(r => r.tmdbId === tmdbId);
      if (!item) continue;

      try {
        const typeStr = item.type === 'MOVIE' ? 'movie' : 'tv';
        const richDetails = await getRichMediaDetails(typeStr, item.tmdbId, true);

        const catalogItem: MuvioCatalogItem = {
          id: item.id,
          media: {
            ...item,
            statusBadge: 'Pending'
          },
          genres: richDetails.genres,
          duration: richDetails.duration,
          directedBy: richDetails.directedBy,
          country: richDetails.country,
          language: richDetails.language,
          ageRating: richDetails.ageRating,
          trailerUrl: richDetails.trailerUrl,
          productionCompanies: richDetails.productionCompanies,
          cast: richDetails.cast,
          crew: richDetails.crew,
          status: 'Pending',
          source: 'TMDB Import',
          dataSource: dataSource,
          dateAdded: new Date().toISOString(),
          downloads: [
            { quality: '480p', url: '', enabled: false },
            { quality: '720p', url: '', enabled: false },
            { quality: '1080p', url: '', enabled: false },
            { quality: '4K', url: '', enabled: false }
          ],
          ticketLinks: [],
          isFeatured: false,
          isMuvioSelect: false
        };

        saveCatalogItem(catalogItem);
        count++;
      } catch (err) {
        logMessage(`Bulk import skip for ID ${tmdbId}: details retrieve failed.`);
      }
    }

    refreshLocalCatalog();
    setImportingInProgress(false);
    setSelectedImportIds([]);
    triggerToast(`Bulk imported ${count} entries into Pending queue with source ${dataSource}.`, 'success');
    logMessage(`Bulk sync complete. Added ${count} items with source ${dataSource}. Active pipeline closed.`);
  };

  // --- SYSTEM SCHEDULER & AUTO FETCH TRIGGER ---

  const handleManualFetchNow = async () => {
    setAutoFetchLoading(true);
    logMessage('Initiating dynamic auto-fetch trigger matrices...');
    
    // Simulate auto-fetch ingestion of highly popular blockbusters
    setTimeout(async () => {
      try {
        const popularItems = [
          {
            tmdbId: 823464,
            title: 'GODZILLA X KONG: THE NEW EMPIRE',
            type: 'MOVIE' as const,
            year: 2024,
            description: 'An all-new adventure that pits the almighty Kong and the fearsome Godzilla against a colossal undiscovered threat hidden within our world.',
            backdropUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&q=80&w=1200',
            posterUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&q=80&w=400',
            ratingPercent: 79,
            voteCount: 3410,
            releaseDate: '2024-03-27',
            statusBadge: 'Pending'
          },
          {
            tmdbId: 1022789,
            title: 'INSIDE OUT 2',
            type: 'MOVIE' as const,
            year: 2024,
            description: 'Teenager Riley\'s mind headquarters is undergoing a sudden demolition to make room for something entirely unexpected: new Emotions!',
            backdropUrl: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=1200',
            posterUrl: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=400',
            ratingPercent: 84,
            voteCount: 1205,
            releaseDate: '2024-06-12',
            statusBadge: 'Pending'
          }
        ];

        let count = 0;
        for (const raw of popularItems) {
          const id = `movie-${raw.tmdbId}`;
          // Ensure no duplicate insertion
          if (catalog.some(c => c.id === id)) continue;

          const newItem: MuvioCatalogItem = {
            id,
            media: {
              id,
              tmdbId: raw.tmdbId,
              title: raw.title,
              type: raw.type,
              year: raw.year,
              description: raw.description,
              backdropUrl: raw.backdropUrl,
              posterUrl: raw.posterUrl,
              ratingPercent: raw.ratingPercent,
              voteCount: raw.voteCount,
              releaseDate: raw.releaseDate,
              statusBadge: 'Pending'
            },
            genres: ['Action', 'Fantasy', 'Adventure'],
            duration: '1h 55m',
            directedBy: 'Adam Wingard',
            country: 'United States',
            language: 'English',
            ageRating: 'PG-13',
            trailerUrl: null,
            productionCompanies: [{ id: 88, name: 'Legendary Entertainment', logoUrl: null }],
            cast: [{ id: 99, name: 'Rebecca Hall', character: 'Dr. Ilene Andrews', profileUrl: '' }],
            crew: [{ id: 101, name: 'Adam Wingard', role: 'Director', profileUrl: '' }],
            status: 'Pending',
            source: 'Daily Auto-Fetch',
            dateAdded: new Date().toISOString(),
            downloads: [
              { quality: '480p', url: '', enabled: false },
              { quality: '720p', url: '', enabled: false },
              { quality: '1080p', url: '', enabled: false },
              { quality: '4K', url: '', enabled: false }
            ],
            ticketLinks: [],
            isFeatured: false,
            isMuvioSelect: false
          };

          saveCatalogItem(newItem);
          count++;
        }

        // Add log
        const log: TMDBFetchLog = {
          id: `log-${Date.now()}`,
          date: new Date().toISOString(),
          itemsFetched: count,
          status: 'SUCCESS',
          details: `Manual trigger of cinema engine acquired ${count} pending film(s) to verify queue list.`
        };
        addFetchLog(log);
        setFetchLogs(getFetchLogs());
        refreshLocalCatalog();

        // System notification
        if (currentUser?.uid) {
          await createNotification(
            currentUser.uid,
            'system',
            'SYSTEM',
            'TRENDING_CONTENT',
            'global',
            'daily-sync',
            `Daily Auto-Pipeline triggered: Ingested ${count} pending entries to approving state.`
          ).catch(() => {});
        }

        triggerToast(`Auto-Fetch execution complete. Placed ${count} items in Pending Approval.`, 'success');
        logMessage(`Synchronization complete: acquired ${count} film records.`);
      } catch (e: any) {
        logMessage(`Auto-Fetch failed: ${e.message || e}`);
      } finally {
        setAutoFetchLoading(false);
      }
    }, 1500);
  };

  const handleUpdateSettings = (enabled: boolean, frequency: 'Daily' | 'Weekly') => {
    const nextSettings = { enabled, frequency, lastRun: autoSettings.lastRun };
    setAutoSettings(nextSettings);
    saveAutoFetchSettings(nextSettings);
    triggerToast('Ingest scheduler rules registered.', 'success');
    logMessage(`Modified automatic ingest protocol settings: Active=${enabled}, Frequency=${frequency}`);
  };

  // Filter Catalog Items
  const filteredMgmtCatalog = catalog.filter(item => {
    const matchesSearch = item.media.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = mgmtTypeFilter === 'ALL' || item.media.type === mgmtTypeFilter;
    const matchesStatus = mgmtStatusFilter === 'ALL' || item.status === mgmtStatusFilter;
    return matchesSearch && matchesType && matchesStatus;
  }).sort((a, b) => {
    const dateA = a.dateAdded ? new Date(a.dateAdded).getTime() : 0;
    const dateB = b.dateAdded ? new Date(b.dateAdded).getTime() : 0;
    return dateB - dateA;
  });

  // Filter Pending Items
  const pendingItems = catalog.filter(item => {
    const matchesStatus = item.status === 'Pending';
    const matchesType = pendingTypeFilter === 'ALL' || item.media.type === pendingTypeFilter;
    return matchesStatus && matchesType;
  }).sort((a, b) => {
    const dateA = a.dateAdded ? new Date(a.dateAdded).getTime() : 0;
    const dateB = b.dateAdded ? new Date(b.dateAdded).getTime() : 0;
    return dateB - dateA;
  });

  // Derived metrics for Dashboard Tab
  const totalMovies = catalog.filter(c => c.media.type === 'MOVIE').length;
  const totalShows = catalog.filter(c => c.media.type === 'SHOW').length;
  const totalAnime = catalog.filter(c => c.media.type === 'ANIME').length;
  const totalPendingCount = catalog.filter(c => c.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-[#070707] text-white flex flex-col md:flex-row relative font-sans" id="muvio-admin-workspace">
      
      {/* Mobile Top Header Banner with collapsing drawer triggers */}
      <div className="md:hidden bg-[#0c0c0c] border-b border-white/5 p-4 flex items-center justify-between sticky top-0 z-40 w-full">
        <div className="flex items-center gap-2">
          <ShieldCheck className="text-[#E50914]" size={20} />
          <span className="font-display font-black text-sm tracking-tight text-white uppercase">MU-ADMIN PORTAL</span>
        </div>
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 bg-white/5 border border-white/5 rounded-xl text-gray-400 hover:text-white"
        >
          <Menu size={18} />
        </button>
      </div>

      {/* LEFT NAVIGATION SIDEBAR (Collapsible slide modal on mobile) */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-[#0a0a0a] border-r border-white/5 p-6 flex flex-col justify-between transition-transform duration-300 transform md:translate-x-0 md:static md:z-20
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/5">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-red-950/40 border border-[#E50914]/40 flex items-center justify-center">
                <ShieldCheck className="text-[#E50914] animate-pulse" size={18} />
              </div>
              <div className="text-left">
                <p className="font-display font-black text-xs uppercase tracking-wider text-[#E50914]">Muvio Core</p>
                <p className="text-[10px] text-gray-500 font-mono">SYS_AUTH: LEVEL_1</p>
              </div>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="md:hidden text-gray-500 hover:text-white"
            >
              <X size={16} />
            </button>
          </div>

          {/* Tab Options */}
          <nav className="space-y-1.5 max-h-[70vh] overflow-y-auto pr-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'content-mgmt', label: 'Content Management', icon: Film },
              { id: 'pending', label: 'Pending Approval', icon: AlertCircle, count: totalPendingCount },
              { id: 'tmdb-import', label: 'TMDB Import', icon: Import },
              { id: 'users-mgmt', label: 'User Management', icon: Users },
              { id: 'verification-requests', label: 'Verification Requests', icon: BadgeCheck, count: verificationRequests.length },
              { id: 'reviews-mod', label: 'Reviews Moderation', icon: MessageSquare },
              { id: 'comments-mod', label: 'Comments Moderation', icon: FileText },
              { id: 'discussions-mod', label: 'Discussions Moderation', icon: Layers },
              { id: 'reported', label: 'Reported Content', icon: AlertTriangle },
              { id: 'news', label: 'News Management', icon: Newspaper },
              { id: 'collections-mgmt', label: 'Collections Management', icon: Heart },
              { id: 'push', label: 'Push Notifications', icon: Bell },
              { id: 'ads', label: 'Ad Placements', icon: Globe2 },
              { id: 'ai-builder', label: 'Gemini AI Builder', icon: Sparkles },
              { id: 'seo', label: 'SEO Settings', icon: Info },
              { id: 'general', label: 'General Settings', icon: Settings },
              { id: 'api-keys', label: 'API Keys', icon: Database },
              { id: 'rankings', label: 'Rankings', icon: ListOrdered },
            ].map(tab => {
              const IconComp = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setIsSidebarOpen(false);
                    setEditingItemId(null);
                    setIsCreatingNew(false);
                  }}
                  className={`
                    w-full px-3.5 py-3 rounded-xl flex items-center justify-between text-left transition-all duration-200 cursor-pointer text-xs font-bold
                    ${isActive 
                      ? 'bg-[#E50914] text-white shadow-[0_4px_15px_rgba(229,9,20,0.25)]' 
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }
                  `}
                >
                  <div className="flex items-center gap-2.5">
                    <IconComp size={15} className={isActive ? 'text-white' : 'text-gray-400'} />
                    <span>{tab.label}</span>
                  </div>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className={`px-2 py-0.5 text-[8px] font-mono font-black rounded-full ${isActive ? 'bg-white text-[#E50914]' : 'bg-[#E50914] text-white animate-pulse'}`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer Details */}
        <div className="pt-6 border-t border-white/5 space-y-3">
          <div className="text-left">
            <p className="text-[10px] text-gray-400 font-bold uppercase truncate">{currentUser?.email || 'Admin Operator'}</p>
            <p className="text-[9px] font-mono text-neutral-600">WORKSPACE: CLOUD RUN</p>
          </div>
          <button
            onClick={handleForceLogoff}
            className="w-full py-2.5 rounded-xl border border-red-500/10 hover:border-red-500/30 bg-red-950/10 hover:bg-red-950/40 text-red-400 text-[10px] font-black tracking-widest uppercase transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Power size={11} />
            <span>TERMINATE PORTAL</span>
          </button>
        </div>
      </div>

      {/* RIGHT WORKSPACE PANELS */}
      <main className="flex-1 p-4 md:p-8 space-y-6 w-full max-w-7xl overflow-x-hidden">
        
        {/* Dynamic header row */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('/explore')}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all cursor-pointer"
              title="Return to explore page"
            >
              <ArrowLeft size={14} />
            </button>
            <div>
              <p className="text-[9px] font-mono font-black text-gray-500 uppercase tracking-widest">Workspace Dashboard</p>
              <h1 className="font-display font-black text-xl md:text-2xl tracking-tight uppercase mt-0.5">
                {editingItemId ? 'Edit Cinema Record' : isCreatingNew ? 'Create New Entry' : `${activeTab.replace('-', ' ')} Operational Center`}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono bg-white/5 border border-white/5 px-2.5 py-1 rounded-lg text-neutral-400">
              UTC_CLOCK: 2026_06_13
            </span>
          </div>
        </div>

        {/* RENDER ACTIVE TAB BODY CONTAINER */}
        <div className="space-y-6">

          {/* EDITING COMPONENT STAGE (OVERLAYS ALL OTHER TABS WHEN ACTIVATED) */}
          {(editingItemId || isCreatingNew) ? (
            <div className="bg-[#0a0a0a]/95 border border-white/5 rounded-3xl p-6 md:p-8 space-y-8 text-left">
              <div className="flex items-center justify-between pb-4 border-b border-white/5">
                <div>
                  <h2 className="text-lg font-black text-white uppercase">{isCreatingNew ? 'Ingest Custom Film Block' : `Modifying Entry Identifier: ${editingItemId}`}</h2>
                  <p className="text-[10px] text-gray-500 font-mono mt-0.5">Please make sure details are accurate for AI scrapers.</p>
                </div>
                <button
                  onClick={() => {
                    setEditingItemId(null);
                    setIsCreatingNew(false);
                  }}
                  className="p-2 rounded-[10px] bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                >
                  <X size={15} />
                </button>
              </div>

              <form onSubmit={handleSaveItem} className="space-y-6">
                
                {/* Visual Fields Category */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Cinema Record Title</label>
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      placeholder="e.g. DUNE: PART FOUR"
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] uppercase font-semibold"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Media Quality</label>
                      <select
                        value={editType}
                        onChange={(e) => setEditType(e.target.value as any)}
                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                      >
                        <option value="MOVIE">MOVIE</option>
                        <option value="SHOW">SHOW (TV SERIES)</option>
                        <option value="ANIME">ANIME</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Release Year</label>
                      <input
                        type="number"
                        value={editYear}
                        onChange={(e) => setEditYear(Number(e.target.value))}
                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Overview Synopsis</label>
                  <textarea
                    rows={4}
                    value={editOverview}
                    onChange={(e) => setEditOverview(e.target.value)}
                    placeholder="Enter short descriptive outline of the cinematic piece..."
                    className="w-full bg-[#111111] border border-white/5 rounded-xl p-4 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Duration Metric</label>
                    <input
                      type="text"
                      value={editDuration}
                      onChange={(e) => setEditDuration(e.target.value)}
                      placeholder="e.g. 2h 45m or 12 Episodes"
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Production Country</label>
                    <input
                      type="text"
                      value={editCountry}
                      onChange={(e) => setEditCountry(e.target.value)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Spoken Language</label>
                    <input
                      type="text"
                      value={editLanguage}
                      onChange={(e) => setEditLanguage(e.target.value)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Age Certification</label>
                    <select
                      value={editAgeRating}
                      onChange={(e) => setEditAgeRating(e.target.value)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                    >
                      <option value="G">G (All Audiences)</option>
                      <option value="PG">PG</option>
                      <option value="PG-13">PG-13</option>
                      <option value="R">R (Under 17 requires parent)</option>
                      <option value="NC-17">NC-17</option>
                      <option value="TV-MA">TV-MA (Mature Audiences)</option>
                      <option value="TV-14">TV-14</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Poster Resolution Image Url</label>
                    <input
                      type="text"
                      value={editPoster}
                      onChange={(e) => setEditPoster(e.target.value)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white font-mono"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Backdrop Panoramic Image Url</label>
                    <input
                      type="text"
                      value={editBackdrop}
                      onChange={(e) => setEditBackdrop(e.target.value)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                {/* Genre Tags Module */}
                <div className="p-5 bg-neutral-950 rounded-2xl border border-white/5 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">Genre & Mood Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {editGenres.map(gt => (
                      <span key={gt} className="px-3 py-1 bg-red-600/10 border border-red-600/20 rounded-full text-xxs font-mono font-bold text-red-400 flex items-center gap-1.5">
                        {gt}
                        <button type="button" onClick={() => removeGenreTag(gt)} className="text-red-400 hover:text-white">
                          <X size={10} />
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Add tag (e.g. Cyberpunk)"
                      value={newGenreTag}
                      onChange={(e) => setNewGenreTag(e.target.value)}
                      className="max-w-[200px] bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white"
                    />
                    <button type="button" onClick={addGenreTag} className="px-3 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xxs font-bold text-white flex items-center gap-1">
                      <Plus size={10} /> Add
                    </button>
                  </div>
                </div>

                {/* Ratings, Featured, and Sliders controls */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 p-5 bg-neutral-950 rounded-2xl border border-white/5">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Muvio Interest Score (0-100%)</label>
                    <input
                      type="number"
                      max={100}
                      min={10}
                      value={editRating}
                      onChange={(e) => setEditRating(Number(e.target.value))}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white"
                    />
                  </div>

                  <div className="space-y-3 pt-6 flex flex-col justify-start">
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={editIsFeatured}
                        onChange={(e) => setEditIsFeatured(e.target.checked)}
                        className="w-4 h-4 rounded bg-neutral-900 border-white/10 text-[#E50914] focus:ring-0"
                      />
                      <span className="text-xs font-bold text-gray-200">Featured Platform Carousel</span>
                    </label>
                    <p className="text-[10px] text-gray-500 font-mono">Shows in elite header spotlight scrolling slider.</p>
                  </div>

                  <div className="space-y-3 pt-6 flex flex-col justify-start">
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={editIsMuvioSelect}
                        onChange={(e) => setEditIsMuvioSelect(e.target.checked)}
                        className="w-4 h-4 rounded bg-neutral-900 border-white/10 text-[#E50914] focus:ring-0"
                      />
                      <span className="text-xs font-bold text-gray-200">Muvio Select Premium Badge</span>
                    </label>
                    <p className="text-[10px] text-gray-500 font-mono">Grants elite verified gold metadata status tag.</p>
                  </div>
                </div>

                 {/* Quality Digital Downloads */}
                 <div className="p-5 bg-neutral-950 rounded-2xl border border-white/5 space-y-5">
                   <div className="flex items-center justify-between">
                     <div>
                       <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">Download Links Settings</h3>
                       <p className="text-[10px] text-gray-500 font-mono">Regulate download vectors, set sizes, and toggle active qualities.</p>
                     </div>
                     <Download size={15} className="text-gray-500" />
                   </div>

                   {/* Master Toggle */}
                   <div className="px-4 py-3 bg-white/2 rounded-xl flex items-center justify-between border border-white/5">
                     <div className="space-y-0.5">
                       <span className="text-xxs font-black font-mono uppercase text-gray-200">Enable Downloads for this content</span>
                       <p className="text-[9px] text-gray-500">Universal master gateway switch representing download visibility.</p>
                     </div>
                     <button
                       type="button"
                       onClick={() => setEditDownloadsEnabled(!editDownloadsEnabled)}
                       className={`px-4 py-1.5 rounded-xl text-xxs font-mono font-bold uppercase transition-all ${
                         editDownloadsEnabled 
                           ? 'bg-[#E50914]/15 text-[#E50914] border border-[#E50914]/30 shadow-[0_0_15px_rgba(229,9,20,0.1)]' 
                           : 'bg-neutral-900 text-neutral-500 border border-white/5'
                       }`}
                     >
                       {editDownloadsEnabled ? 'ACTIVE (ON)' : 'DEACTIVATED (OFF)'}
                     </button>
                   </div>

                   <div className="space-y-4">
                     {editDownloads.map((dl, idx) => (
                       <div key={`dl-${idx}`} className="p-4 bg-white/2 rounded-xl border border-white/5 space-y-3">
                         <div className="flex items-center justify-between gap-4">
                           <input
                             type="text"
                             placeholder="Quality e.g. 1080P"
                             value={dl.quality || ''}
                             onChange={(e) => handleDownloadChange(idx, 'quality', e.target.value)}
                             className="bg-[#111111] border border-white/5 rounded-xl px-3 py-1.5 text-xxs font-mono font-bold text-white uppercase focus:border-red-650/40 w-32 sm:w-44"
                           />
                           
                           <div className="flex items-center gap-2">
                             <button
                               type="button"
                               onClick={() => handleDownloadChange(idx, 'enabled', !dl.enabled)}
                               className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold uppercase transition-all flex items-center gap-1.5 ${
                                 dl.enabled 
                                   ? 'bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30' 
                                   : 'bg-neutral-900 text-neutral-500 border border-white/5'
                               }`}
                             >
                               {dl.enabled ? <Check size={10} /> : <X size={10} />}
                               <span>{dl.enabled ? 'Enabled' : 'Disabled'}</span>
                             </button>

                             <button
                               type="button"
                               onClick={() => {
                                 setEditDownloads(editDownloads.filter((_, i) => i !== idx));
                                }}
                               className="text-red-500 hover:text-red-400 p-1.5 bg-red-950/15 border border-red-500/10 hover:border-red-500/35 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                               title="Remove Quality Section"
                             >
                               <Trash2 size={13} />
                             </button>
                           </div>
                         </div>

                         <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                           {/* URL Input */}
                           <div className="md:col-span-2 space-y-1">
                             <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Streaming/Download URL</span>
                             <input
                               type="text"
                               placeholder="e.g. https://server.muvio.com/streams/dune_4k.mp4"
                               value={dl.url || ''}
                               onChange={(e) => handleDownloadChange(idx, 'url', e.target.value)}
                               className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono placeholder-gray-750 focus:border-red-650/40"
                             />
                           </div>

                           {/* Size Input */}
                           <div className="space-y-1">
                             <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">File Size (Optional)</span>
                             <input
                               type="text"
                               placeholder="e.g. 1.45 GB"
                               value={dl.size || ''}
                               onChange={(e) => handleDownloadChange(idx, 'size', e.target.value)}
                               className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono placeholder-gray-750 focus:border-red-650/40"
                             />
                           </div>
                         </div>
                       </div>
                     ))}

                     {/* Add Section Button */}
                     <div className="flex justify-start">
                       <button
                         type="button"
                         onClick={() => {
                           setEditDownloads([
                             ...editDownloads,
                             { quality: '', url: '', enabled: false, size: '' }
                           ]);
                         }}
                         className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-gray-300 hover:text-white rounded-xl text-xxs font-mono font-bold uppercase transition-all flex items-center gap-2 border border-white/5 hover:border-white/12"
                       >
                         <Plus size={12} className="text-gray-400" />
                         <span>+ Add Section</span>
                       </button>
                     </div>
                   </div>
                 </div>

                  {/* Streaming Links Settings */}
                  <div className="p-5 bg-neutral-950 rounded-2xl border border-white/5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">Streaming Links Settings</h3>
                        <p className="text-[10px] text-gray-500 font-mono">Input on-demand stream sources, embeds, seasons and episodes.</p>
                      </div>
                      <Play size={15} className="text-gray-500" />
                    </div>

                    {/* Master Toggle */}
                    <div className="px-4 py-3 bg-white/2 rounded-xl flex items-center justify-between border border-white/5">
                      <div className="space-y-0.5">
                        <span className="text-xxs font-black font-mono uppercase text-gray-200">Enable Streaming for this content</span>
                        <p className="text-[9px] text-gray-500">Universal master gateway switch representing online player visibility.</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditStreamingEnabled(!editStreamingEnabled)}
                        className={editStreamingEnabled ? "px-4 py-1.5 rounded-xl text-xxs font-mono font-bold uppercase transition-all bg-[#0984E5]/15 text-[#0984E5] border border-[#0984E5]/30 shadow-[0_0_15px_rgba(9,132,229,0.1)]" : "px-4 py-1.5 rounded-xl text-xxs font-mono font-bold uppercase transition-all bg-neutral-900 text-neutral-500 border border-white/5"}
                      >
                        {editStreamingEnabled ? 'ACTIVE (ON)' : 'DEACTIVATED (OFF)'}
                      </button>
                    </div>

                    {editStreamingEnabled && editType === 'MOVIE' && (
                      <div className="space-y-4">
                        {/* Existing movie links */}
                        <div className="space-y-2">
                          {editStreamingLinks.map((sl, idx) => (
                            <div key={`stream-${idx}`} className="flex items-center justify-between p-3 bg-[#111111] rounded-xl border border-white/5 text-xs font-bold">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-blue-500 uppercase text-xxs tracking-wider font-extrabold px-2.5 py-0.5 bg-blue-950/20 border border-blue-500/10 rounded">
                                  {sl.platform}
                                </span>
                                <span className="text-gray-500 font-mono text-xxs max-w-md truncate">
                                  {sl.embedCode}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => toggleMovieStreamLink(idx)}
                                  className={sl.enabled ? "px-2 py-1 rounded bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30 text-xxs font-mono" : "px-2 py-1 rounded bg-neutral-900 text-neutral-500 border border-white/5 text-xxs font-mono"}
                                >
                                  {sl.enabled ? 'ACTIVE' : 'MUTED'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => removeMovieStreamLink(idx)}
                                  className="text-red-500 hover:text-red-400 p-1.5 bg-red-950/10 border border-red-500/10 hover:border-red-500/35 rounded-xl transition-all cursor-pointer"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Add stream form */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4 bg-white/2 rounded-xl border border-white/5">
                          <div className="space-y-1">
                            <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Platform Name</span>
                            <input
                              type="text"
                              placeholder="e.g. Server Hydrax"
                              value={newMovieStreamPlatform}
                              onChange={(e) => setNewMovieStreamPlatform(e.target.value)}
                              className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white"
                            />
                          </div>
                          <div className="space-y-1 md:col-span-2">
                            <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Embed Code / Watch URL</span>
                            <div className="flex gap-2">
                              <input
                                  type="text"
                                  placeholder="e.g. <iframe src='https://server.com/embed/123'></iframe> or https://vidsrc.xyz/123"
                                  value={newMovieStreamCode}
                                  onChange={(e) => setNewMovieStreamCode(e.target.value)}
                                  className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono"
                              />
                              <button
                                type="button"
                                onClick={() => addMovieStreamLink(newMovieStreamPlatform, newMovieStreamCode)}
                                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 flex-shrink-0"
                              >
                                <Plus size={12} />
                                <span>Add</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {editStreamingEnabled && (editType === 'SHOW' || editType === 'ANIME') && (
                      <div className="space-y-5">
                        {/* New Season Folder */}
                        <div className="p-4 bg-white/2 rounded-xl border border-white/5 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xxs font-black font-mono uppercase text-gray-400">Add New Season Folder</span>
                          </div>
                          <div className="flex gap-2 items-center">
                            <div className="w-32">
                              <input
                                type="number"
                                min="1"
                                placeholder="Season No."
                                value={newShowSeasonNum || ''}
                                onChange={(e) => setNewShowSeasonNum(Number(e.target.value))}
                                className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                addSeason(newShowSeasonNum);
                                setNewShowSeasonNum(newShowSeasonNum + 1);
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                            >
                              <Plus size={12} />
                              <span>Create Season</span>
                            </button>
                          </div>
                        </div>

                        {/* Seasons Panel Lists */}
                        {editStreamingSeasons.length === 0 ? (
                          <div className="text-center py-6 border border-dashed border-white/5 rounded-xl text-xxs text-gray-500 uppercase font-mono">
                            No seasons configured in streaming buffer.
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {editStreamingSeasons.map((season) => (
                              <div key={`season-box-${season.seasonNumber}`} className="p-4 bg-neutral-900/60 rounded-xl border border-white/5 space-y-4">
                                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                                  <div className="flex items-center gap-2">
                                    <Layers size={13} className="text-blue-500" />
                                    <span className="text-xs font-black text-white uppercase font-sans">Season {season.seasonNumber}</span>
                                    <span className="text-[10px] text-gray-500 font-mono">({season.episodes.length} Episodes)</span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => removeSeason(season.seasonNumber)}
                                    className="text-red-500 hover:text-red-400 text-xxs font-mono flex items-center gap-1 px-2 py-1 bg-red-950/15 border border-red-500/10 rounded-lg"
                                  >
                                    <Trash2 size={11} />
                                    <span>Delete Season</span>
                                  </button>
                                </div>

                                {/* Add Episode form */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 p-3 bg-black/30 rounded-lg border border-white/5">
                                  <div className="space-y-0.5">
                                    <span className="text-[9px] text-gray-500 font-mono uppercase">Episode No.</span>
                                    <input
                                      type="number"
                                      min="1"
                                      placeholder="e.g. 1"
                                      value={newShowEpisodeNum || ''}
                                      onChange={(e) => setNewShowEpisodeNum(Number(e.target.value))}
                                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-2 py-1.5 text-xxs text-white font-mono"
                                    />
                                  </div>
                                  <div className="space-y-0.5 md:col-span-2">
                                    <span className="text-[9px] text-gray-500 font-mono uppercase">Episode Title (Optional)</span>
                                    <div className="flex gap-2">
                                      <input
                                        type="text"
                                        placeholder="e.g. Episode Title"
                                        value={newShowEpisodeTitle}
                                        onChange={(e) => setNewShowEpisodeTitle(e.target.value)}
                                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-2 py-1.5 text-xxs text-white"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => {
                                          addEpisode(season.seasonNumber, newShowEpisodeNum, newShowEpisodeTitle || `Episode ${newShowEpisodeNum}`);
                                          setNewShowEpisodeNum(newShowEpisodeNum + 1);
                                          setNewShowEpisodeTitle('');
                                        }}
                                        className="px-3 py-1.5 bg-neutral-850 hover:bg-neutral-700 text-white rounded-lg text-xxs font-bold flex items-center gap-1 flex-shrink-0"
                                      >
                                        <Plus size={11} />
                                        <span>Add Episode</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>

                                {/* Episode List */}
                                {season.episodes.length === 0 ? (
                                  <div className="text-center py-4 text-xxs font-mono text-gray-500 uppercase">
                                    No episodes added to Season {season.seasonNumber}.
                                  </div>
                                ) : (
                                  <div className="space-y-3">
                                    {season.episodes.map((ep) => (
                                      <div key={`ep-card-${season.seasonNumber}-${ep.episodeNumber}`} className="p-3 bg-white/2 rounded-lg border border-white/5 space-y-3">
                                        <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
                                          <span className="text-xxs font-mono font-bold text-gray-200">
                                            Ep {ep.episodeNumber}: <span className="text-gray-400 font-sans">{ep.title}</span>
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => removeEpisode(season.seasonNumber, ep.episodeNumber)}
                                            className="text-red-500 hover:text-red-400"
                                          >
                                            <Trash2 size={12} />
                                          </button>
                                        </div>

                                        {/* Episode servers list */}
                                        <div className="space-y-2">
                                          {ep.platforms && ep.platforms.length > 0 && (
                                            <div className="space-y-1.5">
                                              {ep.platforms.map((plat, platIdx) => (
                                                <div key={`p-${platIdx}`} className="flex items-center justify-between p-2 bg-neutral-900 rounded border border-white/5 text-[10px]">
                                                  <div className="flex items-center gap-2 max-w-[70%]">
                                                    <span className="text-blue-500 uppercase font-black tracking-widest bg-blue-950/20 px-1.5 py-0.5 rounded border border-blue-500/10">
                                                      {plat.platform}
                                                    </span>
                                                    <span className="text-gray-500 truncate font-mono">{plat.embedCode}</span>
                                                  </div>
                                                  <div className="flex items-center gap-1.5">
                                                    <button
                                                      type="button"
                                                      onClick={() => togglePlatformInEpisode(season.seasonNumber, ep.episodeNumber, platIdx)}
                                                      className={plat.enabled ? "px-1.5 py-0.5 rounded bg-green-500/10 text-green-500 font-mono text-[9px] border border-green-500/20" : "px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-500 font-mono text-[9px] border border-white/5"}
                                                    >
                                                      {plat.enabled ? 'ON' : 'OFF'}
                                                    </button>
                                                    <button
                                                      type="button"
                                                      onClick={() => removePlatformFromEpisode(season.seasonNumber, ep.episodeNumber, platIdx)}
                                                      className="text-red-500 hover:text-red-400"
                                                    >
                                                      <X size={10} />
                                                    </button>
                                                  </div>
                                                </div>
                                              ))}
                                            </div>
                                          )}

                                          {/* Server inline form */}
                                          <div className="flex gap-2 pt-1 border-t border-white/5 mt-1">
                                            <div className="flex-1">
                                              <input
                                                type="text"
                                                placeholder="Server"
                                                id={`plat-input-${season.seasonNumber}-${ep.episodeNumber}`}
                                                className="w-full bg-[#111111] border border-white/5 rounded px-2 py-1 text-[10px] text-white"
                                              />
                                            </div>
                                            <div className="flex-[2]">
                                              <input
                                                type="text"
                                                placeholder="Embed code or URL"
                                                id={`code-input-${season.seasonNumber}-${ep.episodeNumber}`}
                                                className="w-full bg-[#111111] border border-white/5 rounded px-2 py-1 text-[10px] text-white font-mono"
                                              />
                                            </div>
                                            <button
                                              type="button"
                                              onClick={() => {
                                                const platEl = document.getElementById(`plat-input-${season.seasonNumber}-${ep.episodeNumber}`) as HTMLInputElement;
                                                const codeEl = document.getElementById(`code-input-${season.seasonNumber}-${ep.episodeNumber}`) as HTMLInputElement;
                                                if (platEl && codeEl) {
                                                  addPlatformToEpisode(season.seasonNumber, ep.episodeNumber, platEl.value, codeEl.value);
                                                  platEl.value = '';
                                                  codeEl.value = '';
                                                }
                                              }}
                                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold"
                                            >
                                              Add
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                {/* Ticket Platform Platform Links */}
                <div className="p-5 bg-neutral-950 rounded-2xl border border-white/5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">Available Digital Tickets</h3>
                      <p className="text-[10px] text-gray-500 font-mono">Input active digital ticket links, streams, watch URLs, and platforms.</p>
                    </div>
                    <Ticket size={15} className="text-gray-500" />
                  </div>

                  <div className="space-y-2">
                    {editTickets.map((tc, idx) => (
                      <div key={`ticket-${idx}`} className="flex items-center justify-between p-3 bg-[#111111] rounded-xl border border-white/5 text-xs font-bold">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[#E50914] uppercase text-xxs tracking-wider font-extrabold px-2.5 py-0.5 bg-red-950/20 border border-red-500/10 rounded">
                            {tc.platform}
                          </span>
                          {tc.domain && (
                            <span className="text-gray-300 font-mono text-xxs px-2 py-0.5 bg-[#1a1a1a] border border-white/5 rounded">
                              {tc.domain}
                            </span>
                          )}
                          <span className="text-gray-400 font-mono text-xxs px-2 py-0.5 bg-neutral-900 border border-white/5 rounded">
                            {tc.type || 'Subscription'}
                          </span>
                          <span className="text-gray-500 font-mono text-xxs max-w-md truncate">
                            {tc.url}
                          </span>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => removeTicketPlatform(idx)} 
                          className="text-red-500 hover:text-red-400 p-1.5 bg-red-950/10 border border-red-500/10 hover:border-red-500/35 rounded-xl transition-all cursor-pointer"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    <div className="space-y-1">
                      <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Platform Name</span>
                      <input
                        type="text"
                        placeholder="e.g. Netflix, Disney+"
                        value={newTicketPlatform}
                        onChange={(e) => setNewTicketPlatform(e.target.value)}
                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Platform Domain</span>
                      <input
                        type="text"
                        placeholder="e.g. netflix.com"
                        value={newTicketDomain || ''}
                        onChange={(e) => setNewTicketDomain(e.target.value)}
                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Platform Type</span>
                      <select
                        value={newTicketType}
                        onChange={(e) => setNewTicketType(e.target.value)}
                        className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white outline-none"
                      >
                        <option value="Subscription">Subscription</option>
                        <option value="Buy/Rent">Buy/Rent</option>
                        <option value="Stream Now">Stream Now</option>
                        <option value="Free">Free</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div className="md:col-span-2 space-y-1">
                      <span className="text-[9px] text-gray-500 font-mono uppercase text-left block">Ticket / Watch URL</span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="e.g. https://www.netflix.com/title/..."
                          value={newTicketUrl}
                          onChange={(e) => setNewTicketUrl(e.target.value)}
                          className="flex-1 bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono"
                        />
                        <button 
                          type="button" 
                          onClick={addTicketPlatform} 
                          className="px-4 py-2 bg-[#E50914] hover:bg-[#B80710] rounded-xl text-xxs font-bold text-white flex items-center justify-center gap-1 transition-all cursor-pointer shadow-[0_0_15px_rgba(229,9,20,0.15)] shrink-0"
                        >
                          <Plus size={12} /> Add Platform
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Casting Actors and Director Credits */}
                <div className="p-5 bg-neutral-950 rounded-2xl border border-white/5 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300">Film Cast Credits</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {editCast.map(member => (
                      <div key={member.id} className="flex items-center justify-between p-2 bg-[#111111] rounded-xl border border-white/5">
                        <div className="flex items-center gap-2.5">
                          <img src={member.profileUrl} className="w-8 h-8 rounded-lg object-cover" alt="" />
                          <div>
                            <p className="text-xs font-bold text-white">{member.name}</p>
                            <p className="text-[10px] text-gray-400 italic">as {member.character}</p>
                          </div>
                        </div>
                        <button type="button" onClick={() => removeCastMember(member.id)} className="text-gray-500 hover:text-red-400 p-1">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="text"
                      placeholder="Actor Legal Name"
                      value={newCastName}
                      onChange={(e) => setNewCastName(e.target.value)}
                      className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Character Name"
                      value={newCastChar}
                      onChange={(e) => setNewCastChar(e.target.value)}
                      className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Avatar Link (Unsplash/DiceBear)"
                      value={newCastPhoto}
                      onChange={(e) => setNewCastPhoto(e.target.value)}
                      className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white font-mono"
                    />
                    <button type="button" onClick={addCastMember} className="px-3 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xxs font-bold text-white flex items-center justify-center gap-1">
                      <Plus size={10} /> Add Actor
                    </button>
                  </div>
                </div>

                {/* status deployment */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-5 bg-neutral-950 rounded-2xl border border-white/5">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold">Metadata Distribution State</label>
                    <select
                      value={editStatus}
                      onChange={(e) => setEditStatus(e.target.value as any)}
                      className="w-full bg-[#111111] border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                    >
                      <option value="Published">PUBLISHED (Fully Active in Explore Catalogs)</option>
                      <option value="Pending">PENDING APPROVAL (Held in Stage queue)</option>
                      <option value="Draft">DRAFT / ARCHIVED (Invisible to Critics)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Data Source</label>
                    <div className="flex flex-col gap-2.5 pt-1.5">
                      <label className="flex items-start gap-2.5 cursor-pointer select-none">
                        <input
                          type="radio"
                          name="editDataSource"
                          value="DATABASE"
                          checked={editDataSource === 'DATABASE'}
                          onChange={() => setEditDataSource('DATABASE')}
                          className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                        />
                        <div>
                          <span className="text-xs font-bold text-gray-200">DATABASE</span>
                          <span className="text-[9px] text-gray-500 font-mono block">data copy karke mere database mein save karo</span>
                        </div>
                      </label>
                      
                      <label className="flex items-start gap-2.5 cursor-pointer select-none">
                        <input
                          type="radio"
                          name="editDataSource"
                          value="LIVE_TMDB"
                          checked={editDataSource === 'LIVE_TMDB'}
                          onChange={() => setEditDataSource('LIVE_TMDB')}
                          className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                        />
                        <div>
                          <span className="text-xs font-bold text-gray-200">LIVE_TMDB</span>
                          <span className="text-[9px] text-gray-500 font-mono block">sirf TMDB ID save karo, data live fetch hoga</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="flex items-end justify-end gap-3 pb-1">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingItemId(null);
                        setIsCreatingNew(false);
                      }}
                      className="px-6 py-3 rounded-xl hover:bg-white/5 border border-white/5 text-xs font-bold text-gray-400 hover:text-white transition-all cursor-pointer"
                    >
                      ABORT TRANS
                    </button>

                    <button
                      type="submit"
                      className="px-8 py-3 rounded-xl bg-[#E50914] hover:bg-[#b0070f] text-xs font-black uppercase tracking-wider text-white shadow-[0_4px_20px_rgba(229,9,20,0.3)] transition-all cursor-pointer"
                    >
                      COMMIT RECORD WRITE &rarr;
                    </button>
                  </div>
                </div>

              </form>
            </div>
          ) : (

            // NORMAL MENU TABS ROUTING STATE
            <div className="space-y-6">

              {/* TAB 1: DASHBOARD STATS PANEL */}
              {activeTab === 'dashboard' && (
                <div className="space-y-6">
                  
                  {/* Alert banner if pending items exist */}
                  {totalPendingCount > 0 && (
                    <div className="bg-red-500/10 border border-[#E50914]/20 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-left">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#E50914]/15 flex items-center justify-center text-[#E50914]">
                          <AlertTriangle size={15} className="animate-bounce" />
                        </div>
                        <div>
                          <p className="text-xs font-extrabold text-white">DECISION REQUIRED: Ingest Queue Blocked</p>
                          <p className="text-[10px] text-gray-400 mt-0.5 font-sans">There are currently <span className="text-[#E50914] font-bold font-mono">{totalPendingCount}</span> imported TMDB titles awaiting master approval.</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setActiveTab('pending')}
                        className="px-4 py-2 bg-[#E50914] hover:bg-[#b0070f] text-xxs font-black tracking-widest text-white rounded-xl uppercase transition-all self-start sm:self-auto cursor-pointer"
                      >
                        Launch Queue &rarr;
                      </button>
                    </div>
                  )}

                  {/* Stat cards bento grid */}
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {[
                      { label: 'Total Movies', count: totalMovies, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
                      { label: 'TV Shows', count: totalShows, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
                      { label: 'Anime Series', count: totalAnime, color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/20' },
                      { label: 'Elite Critics', count: usersList.length, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
                      { label: 'Posted Reviews', count: reviewsList.length, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
                      { label: 'Pending queue', count: totalPendingCount, color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/20', pulse: totalPendingCount > 0 },
                    ].map((st, idx) => (
                      <div key={idx} className="bg-[#0c0c0c]/85 border border-white/5 rounded-2xl p-4 flex flex-col justify-between h-32 relative text-left select-none">
                        <p className="text-[9px] font-mono text-gray-400 uppercase font-black">{st.label}</p>
                        <div className="flex items-baseline gap-2 mt-4">
                          <span className={`text-4xl font-black ${st.color} tracking-tight leading-none`}>{st.count}</span>
                          {st.pulse && (
                            <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
                          )}
                        </div>
                        <span className={`text-[8px] font-mono py-0.5 px-1 bg-white/5 border border-white/5 w-fit rounded uppercase mt-2 text-neutral-500`}>SYS_DAT</span>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* Left 2/3 - Recents & Tables */}
                    <div className="lg:col-span-2 space-y-6">

                      {/* Feature Switches */}
                      <div className="bg-[#0c0c0c]/85 border border-white/5 rounded-2xl p-5" id="admin-settings-container">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                          <Settings size={14} className="text-[#E50914]" />
                          <span>Spotlight Master Configuration</span>
                        </h3>

                        <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
                          <div className="space-y-1 pr-4 text-left">
                            <p className="text-xs font-bold text-gray-200">Enforce Cinema Landing Showcase</p>
                            <p className="text-[10px] text-gray-400 leading-relaxed font-sans">
                              Forces newcomers to experience the spotlight introductory splash page before Entering explore categories.
                            </p>
                          </div>
                          <button
                            onClick={handleToggleSetting}
                            className="cursor-pointer font-bold focus:outline-none transition-all active:scale-95 text-[#E50914]"
                          >
                            {showLandingPage ? (
                              <div className="flex items-center gap-1.5 font-bold text-xs bg-[#E50914]/15 border border-[#E50914]/30 text-[#E50914] px-3.5 py-1.5 rounded-full">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#E50914] animate-pulse"></span>
                                ACTIVE
                              </div>
                            ) : (
                              <div className="flex items-center gap-1.5 font-bold text-xs bg-gray-500/10 border border-white/5 text-gray-400 px-3.5 py-1.5 rounded-full">
                                INACTIVE
                              </div>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Users Registrations Log */}
                      <div className="bg-[#0c0c0c]/85 border border-white/5 rounded-2xl p-5 text-left">
                        <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
                          <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                            <Users size={14} className="text-[#E50914]" />
                            <span>Recent Critics Registered ({usersList.length})</span>
                          </h3>
                        </div>

                        {usersList.length === 0 ? (
                          <div className="py-6 text-center text-xs text-gray-500 font-mono">
                            Query Returned 0 Authenticated Accounts.
                          </div>
                        ) : (
                          <div className="overflow-x-auto">
                            <table className="w-full text-left text-[11px] text-gray-400">
                              <thead>
                                <tr className="border-b border-white/5 text-[9px] uppercase font-mono text-gray-500 text-left">
                                  <th className="py-2.5">Critic</th>
                                  <th className="py-2.5">Email Link</th>
                                  <th className="py-2.5">User Handle</th>
                                  <th className="py-2.5">Security Level</th>
                                </tr>
                              </thead>
                              <tbody>
                                {usersList.slice(0, 4).map((usr) => (
                                  <tr key={usr.uid} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                                    <td className="py-2.5 font-bold text-white">{usr.name}</td>
                                    <td className="py-2.5 font-mono text-neutral-400">{usr.email}</td>
                                    <td className="py-2.5 font-mono text-[#E50914]">@{usr.username}</td>
                                    <td className="py-2.5.5">
                                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${usr.role === 'admin' ? 'bg-[#E50914]/15 border border-[#E50914]/20 text-[#E50914]' : 'bg-green-500/10 text-green-400'}`}>
                                        {usr.role}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>

                      {/* Recent Reviews Audit Table */}
                      <div className="bg-[#0c0c0c]/85 border border-white/5 rounded-2xl p-5 text-left">
                        <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
                          <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                            <MessageSquare size={14} className="text-[#E50914]" />
                            <span>Audience Criticism Logs ({reviewsList.length})</span>
                          </h3>
                        </div>

                        {reviewsList.length === 0 ? (
                          <div className="py-8 text-center text-xs text-gray-500 font-mono">
                            No user reviews indexed in memory cache.
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {reviewsList.slice(0, 4).map((rev) => (
                              <div key={rev.id} className="p-3 bg-neutral-950 rounded-xl border border-white/5 flex gap-3 text-left">
                                <img src={rev.userAvatar} className="w-8 h-8 rounded-lg" alt="" />
                                <div className="flex-1 space-y-1">
                                  <div className="flex items-center justify-between">
                                    <p className="text-xs font-bold text-white">@{rev.username} <span className="text-xxs text-gray-500 italic font-mono font-normal">on {rev.mediaTitle}</span></p>
                                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-black tracking-tighter bg-yellow-500/10 text-yellow-500">★ {rev.rating}/10</span>
                                  </div>
                                  <p className="text-xxs text-gray-400 font-sans italic leading-relaxed line-clamp-2">"{rev.text}"</p>
                                  {rev.sentiment && (
                                    <span className={`inline-block px-1.5 py-0.5 rounded text-[8px] font-black font-mono mr-2 ${
                                      rev.sentiment === 'POSITIVE' ? 'bg-green-500/10 text-green-400' :
                                      rev.sentiment === 'NEGATIVE' ? 'bg-red-500/10 text-red-400' : 'bg-neutral-500/10 text-neutral-400'
                                    }`}>
                                      AI SENTIMENT: {rev.sentiment}
                                    </span>
                                  )}
                                  {rev.spoiler && (
                                    <span className="inline-block px-1.5 py-0.5 rounded text-[8px] font-mono font-black bg-[#E50914]/15 text-[#E50914]">SPOILER FLAGGED</span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                    </div>

                    {/* Right 1/3 - Server Logs Panel */}
                    <div className="space-y-6">
                      <div className="bg-[#0b0b0b] border border-[#E50914]/20 rounded-2xl p-5 flex flex-col h-[520px] overflow-hidden">
                        <div className="pb-3 border-b border-white/10 flex items-center justify-between text-left">
                          <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-[#E50914] animate-pulse"></span>
                            <span className="text-xs font-mono font-bold uppercase text-white tracking-wider">
                              TTY Master Terminal
                            </span>
                          </div>
                          <span className="text-[8px] font-mono text-[#E50914] bg-[#E50914]/10 px-1.5 py-0.5 rounded border border-[#E50914]/20 font-black">
                            SECURE_SHELL
                          </span>
                        </div>

                        <div className="flex-1 overflow-y-auto mt-4 font-mono text-[9px] text-[#A3A3A3] space-y-2.5 leading-relaxed text-left pr-1 select-text">
                          {systemLogs.map((log, i) => (
                            <div key={i} className="border-l-2 border-[#E50914]/30 pl-2 py-0.5">
                              <span className="text-neutral-700 select-none">muvio_root ~ </span>
                              <span>{log}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB 2: CONTENT MANAGEMENT */}
              {activeTab === 'content-mgmt' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  
                  {/* Action filter ribbon */}
                  <div className="flex flex-col md:flex-row gap-4 items-center justify-between pb-4 border-b border-white/5">
                    
                    {/* Left: searches and filter */}
                    <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                      <div className="relative">
                        <Search size={14} className="absolute left-3.5 top-3 text-neutral-500" />
                        <input
                          type="text"
                          placeholder="Search database movies/shows..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-9 pr-4 py-2 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] min-w-[240px] uppercase font-mono font-semibold"
                        />
                      </div>

                      <select
                        value={mgmtTypeFilter}
                        onChange={(e) => setMgmtTypeFilter(e.target.value as any)}
                        className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                      >
                        <option value="ALL">ALL MEDIA TYPES</option>
                        <option value="MOVIE">MOVIE</option>
                        <option value="SHOW">TV SHOW</option>
                        <option value="ANIME">ANIME</option>
                      </select>

                      <select
                        value={mgmtStatusFilter}
                        onChange={(e) => setMgmtStatusFilter(e.target.value as any)}
                        className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                      >
                        <option value="ALL">ALL INGEST STATUSES</option>
                        <option value="Published">PUBLISHED</option>
                        <option value="Pending">PENDING</option>
                        <option value="Draft">DRAFT</option>
                      </select>
                    </div>

                    {/* Right: Add new button */}
                    <button
                      onClick={handleOpenCreate}
                      className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-[#E50914] hover:bg-[#b0070f] text-xs font-black tracking-wider uppercase text-white flex items-center justify-center gap-2 shadow-[0_4px_15px_rgba(229,9,20,0.2)] cursor-pointer"
                    >
                      <Plus size={14} />
                      <span>Ingest Custom Content</span>
                    </button>
                  </div>

                  {/* Table displaying content items */}
                  {filteredMgmtCatalog.length === 0 ? (
                    <div className="py-16 text-center text-sm text-gray-500 font-mono uppercase">
                      No matching media units scanned in central registry.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left text-gray-300">
                        <thead>
                          <tr className="border-b border-white/5 text-[9px] font-mono text-neutral-500 uppercase">
                            <th className="py-3 px-4">Identifier</th>
                            <th className="py-3 px-4">Cinematic Poster / Title</th>
                            <th className="py-3 px-4">Properties</th>
                            <th className="py-3 px-4">Ingestion Badge</th>
                            <th className="py-3 px-4">Released Date</th>
                            <th className="py-3 px-4 text-right">Actions Panel</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredMgmtCatalog.map((item) => (
                            <tr key={item.id} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                              <td className="py-3 px-4 font-mono text-[10px] text-gray-500 truncate max-w-[120px]" title={item.id}>
                                {item.id}
                              </td>
                              <td className="py-3 px-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-14 rounded-lg overflow-hidden border border-white/10 flex-shrink-0 bg-neutral-900">
                                    <img src={item.media.posterUrl} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                                  </div>
                                  <div>
                                    <p className="font-bold text-white uppercase text-xs hover:text-[#E50914] transition-colors line-clamp-1">{item.media.title}</p>
                                    <p className="text-neutral-500 text-[10px] uppercase font-mono mt-0.5">{item.media.type}</p>
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-4">
                                <div className="space-y-1 text-neutral-400 text-[10px]">
                                  <p className="line-clamp-1">Genre: {item.genres.join(', ')}</p>
                                  <p className="font-mono">Time: {item.duration} / Rat: {item.media.ratingPercent}%</p>
                                </div>
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                                  item.status === 'Published' ? 'bg-green-500/10 text-green-400 border border-green-500/10' :
                                  item.status === 'Pending' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/10 animate-pulse' :
                                  'bg-gray-500/10 text-gray-400 border border-white/5'
                                }`}>
                                  {item.status}
                                </span>
                              </td>
                              <td className="py-3 px-4 font-mono text-neutral-500 text-[10px]">
                                {item.media.releaseDate}
                              </td>
                              <td className="py-3 px-4 text-right">
                                <div className="flex items-center justify-end gap-2">
                                  <button
                                    onClick={() => handleOpenEdit(item.id)}
                                    className="p-1.5 bg-white/5 border border-white/5 hover:border-white/10 rounded-lg text-gray-400 hover:text-white cursor-pointer"
                                    title="Edit Film Details"
                                  >
                                    <Edit size={12} />
                                  </button>
                                  <button
                                    onClick={() => setDeleteConfirmationId(item.id)}
                                    className="p-1.5 bg-red-950/20 border border-red-900/10 hover:bg-[#E50914] rounded-lg text-red-400 hover:text-white cursor-pointer"
                                    title="Delete Cinema Block"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* Confirmation Modal */}
                  {deleteConfirmationId && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-sm w-full space-y-4 text-center">
                        <AlertTriangle className="mx-auto text-[#E50914]" size={42} />
                        <div>
                          <h3 className="text-sm font-black uppercase text-white tracking-wide">CONFIRM ERASURE TRANSACTION</h3>
                          <p className="text-[10px] text-gray-400 mt-2 font-mono leading-relaxed">
                            You are deleting cinema index "{catalog.find(c => c.id === deleteConfirmationId)?.media.title}". This discard option is permanent.
                          </p>
                        </div>
                        <div className="flex gap-3">
                          <button
                            onClick={() => setDeleteConfirmationId(null)}
                            className="flex-1 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-400 hover:text-white"
                          >
                            ABORT
                          </button>
                          <button
                            onClick={() => handleDeleteItem(deleteConfirmationId)}
                            className="flex-1 py-2 rounded-xl bg-[#E50914] hover:bg-[#b0070f] text-xs font-black uppercase text-white"
                          >
                            DISCARD FOR EVER
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* TAB 3: PENDING APPROVAL LIST */}
              {activeTab === 'pending' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  
                  {/* Filter Header and Bulk Controls */}
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div className="flex items-center gap-3">
                      <select
                        value={pendingTypeFilter}
                        onChange={(e) => setPendingTypeFilter(e.target.value as any)}
                        className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                      >
                        <option value="ALL">ALL TYPE WORKLOADS</option>
                        <option value="MOVIE">MOVIES</option>
                        <option value="SHOW">TV SHOWS</option>
                        <option value="ANIME">ANIME</option>
                      </select>

                      {pendingItems.length > 0 && (
                        <p className="text-[10px] text-gray-500 font-mono font-bold uppercase">
                          {selectedPendingIds.length} select nodes
                        </p>
                      )}
                    </div>

                    {selectedPendingIds.length > 0 && (
                      <div className="flex gap-2 w-full sm:w-auto">
                        <button
                          onClick={handlePendingBulkReject}
                          className="flex-1 sm:flex-none px-4 py-2 border border-red-500/10 hover:border-red-500/20 bg-red-950/20 hover:bg-red-950/30 text-red-400 text-[10px] font-bold uppercase rounded-xl transition-all"
                        >
                          Send Selected to Drafts
                        </button>
                        <button
                          onClick={handlePendingBulkApprove}
                          className="flex-1 sm:flex-none px-4 py-2 bg-green-600 hover:bg-green-700 text-xs font-black uppercase text-white rounded-xl transition-all"
                        >
                          Approve Selected Ingests
                        </button>
                      </div>
                    )}
                  </div>

                  {pendingItems.length === 0 ? (
                    <div className="py-20 text-center space-y-3">
                      <Check className="mx-auto text-green-500" size={32} />
                      <p className="text-xs text-gray-500 font-mono uppercase tracking-widest">Master ingest pipeline is verified clear.</p>
                      <p className="text-[10px] text-gray-400">All harvested nodes have been authorized or filtered.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {pendingItems.map((item) => {
                        const isChecked = selectedPendingIds.includes(item.id);
                        return (
                          <div 
                            key={item.id} 
                            className={`p-4 rounded-2xl bg-[#0e0e0e] border transition-all duration-200 flex flex-col justify-between ${
                              isChecked ? 'border-[#E50914] bg-[#E50914]/5' : 'border-white/5 hover:border-white/10'
                            }`}
                          >
                            <div className="flex gap-3 text-left">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => handleTogglePendingSelect(item.id)}
                                className="mt-1 flex-shrink-0 cursor-pointer w-4 h-4 rounded text-[#E50914] focus:ring-0"
                              />

                              <div className="w-14 h-20 bg-neutral-900 border border-white/5 rounded-xl overflow-hidden flex-shrink-0">
                                <img src={item.media.posterUrl} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                              </div>

                              <div className="flex-1 min-w-0 space-y-1">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="px-1.5 py-0.5 bg-neutral-800 border border-white/5 text-[8px] font-mono font-bold text-gray-400 rounded uppercase">
                                    {item.media.type}
                                  </span>
                                  <span className="px-1.5 py-0.5 bg-red-950/20 border border-red-500/15 text-[8px] font-mono font-bold text-red-400 rounded uppercase">
                                    Source: {item.source}
                                  </span>
                                </div>
                                <h4 className="font-bold text-xs uppercase text-white truncate">{item.media.title}</h4>
                                <p className="text-xxs text-gray-500 font-sans line-clamp-2 italic">"{item.media.description}"</p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between border-t border-white/5 pt-3 mt-4">
                              <button
                                onClick={() => handleOpenEdit(item.id)}
                                className="text-gray-400 hover:text-white font-mono text-[9px] hover:underline uppercase"
                              >
                                Edit & Approve
                              </button>

                              <div className="flex gap-2">
                                <button
                                  onClick={() => handlePendingSingleAction(item.id, 'reject')}
                                  className="px-3 py-1.5 rounded-lg border border-red-900/10 hover:border-red-900/20 hover:bg-red-950/20 text-red-500 text-[10px] font-bold uppercase transition-all"
                                >
                                  Reject
                                </button>
                                <button
                                  onClick={() => handlePendingSingleAction(item.id, 'approve')}
                                  className="px-3 py-1.5 bg-[#22C55E]/15 border border-[#22C55E]/20 text-[#22C55E] hover:bg-[#22C55E] hover:text-white text-[10px] font-bold uppercase rounded-lg transition-all"
                                >
                                  Approve
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                </div>
              )}

              {/* TAB 4: TMDB IMPORT PANEL */}
              {activeTab === 'tmdb-import' && (
                <div className="space-y-6">
                  
                  {/* TMDB Auto-Fetch configuration switches */}
                  <div className="p-6 bg-[#0a0a0a] border border-white/5 rounded-3xl space-y-6 text-left">
                    <div className="flex items-center justify-between pb-3 border-b border-white/5">
                      <div>
                        <h3 className="text-sm font-black uppercase text-white">Automated Ingestion Protocol Settings</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5">Allow system cron tasks to pull popular blockbusters and release logs daily.</p>
                      </div>
                      <Compass className="text-neutral-500" size={16} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                      <div className="flex items-center justify-between p-3.5 bg-neutral-950 border border-white/5 rounded-2xl">
                        <span className="text-xs font-bold text-gray-200">Daily Harvesting Tasks</span>
                        <button
                          onClick={() => handleUpdateSettings(!autoSettings.enabled, autoSettings.frequency)}
                          className="hover:scale-95 transition-all text-xs focus:outline-none"
                        >
                          {autoSettings.enabled ? (
                            <span className="bg-green-500/10 border border-green-500/20 text-green-400 px-3 py-1.5 rounded-full font-bold uppercase">Active Ingress</span>
                          ) : (
                            <span className="bg-neutral-900 border border-white/5 text-neutral-500 px-3 py-1.5 rounded-full font-bold">Offline</span>
                          )}
                        </button>
                      </div>

                      <div className="flex items-center justify-between p-3.5 bg-neutral-950 border border-white/5 rounded-2xl">
                        <span className="text-xs font-bold text-gray-200">Execution Cadence</span>
                        <select
                          value={autoSettings.frequency}
                          onChange={(e) => handleUpdateSettings(autoSettings.enabled, e.target.value as any)}
                          className="bg-neutral-900 border border-white/5 rounded-xl px-2.5 py-1 text-xs text-white"
                        >
                          <option value="Daily">Daily Syncs</option>
                          <option value="Weekly">Weekly Syncs</option>
                        </select>
                      </div>

                      <button
                        onClick={handleManualFetchNow}
                        disabled={autoFetchLoading}
                        className="w-full py-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-xs font-black tracking-widest uppercase transition-all flex items-center justify-center gap-2 text-[#E50914] cursor-pointer"
                      >
                        <RefreshCw size={12} className={autoFetchLoading ? 'animate-spin' : ''} />
                        <span>{autoFetchLoading ? 'Harvesting Blockbusters...' : 'Fetch Now (Cron Trigger)'}</span>
                      </button>
                    </div>

                    {/* Auto Fetch logs */}
                    <div className="space-y-3 pt-3">
                      <h4 className="text-[10px] font-mono font-bold text-gray-400 uppercase">Secure Ingest Pipelines Logs</h4>
                      <div className="overflow-x-auto rounded-xl border border-white/5">
                        <table className="w-full text-[10px] text-gray-400 text-left bg-[#111111]/40">
                          <thead>
                            <tr className="border-b border-white/5 bg-neutral-950 font-mono text-[8px] text-neutral-500 uppercase">
                              <th className="py-2 px-3">Sync Date</th>
                              <th className="py-2 px-3">Workload Ingested</th>
                              <th className="py-2 px-3">State</th>
                              <th className="py-2 px-3">Execution details</th>
                            </tr>
                          </thead>
                          <tbody>
                            {fetchLogs.map(log => (
                              <tr key={log.id} className="border-b border-white/5 hover:bg-white/2">
                                <td className="py-2 px-3 font-mono text-neutral-500">{new Date(log.date).toLocaleString()}</td>
                                <td className="py-2 px-3 font-mono text-white">{log.itemsFetched} catalog items</td>
                                <td className="py-2 px-3">
                                  <span className="px-1.5 py-0.5 bg-green-500/10 text-green-400 rounded text-[8px] font-black">{log.status}</span>
                                </td>
                                <td className="py-2 px-3 text-neutral-400 leading-relaxed max-w-sm truncate">{log.details}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>

                  {/* TMDB Search Import Panel */}
                  <div className="p-6 bg-[#0a0a0a] border border-white/5 rounded-3xl space-y-6 text-left">
                    <div className="flex items-center justify-between pb-3 border-b border-white/5">
                      <div>
                        <h3 className="text-sm font-black uppercase text-white">TMDB On-Demand Content Import Portal</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5">Query over 1 million records over movie and TV credits instantly into internal queue.</p>
                      </div>
                      <Import className="text-[#E50914]" size={16} />
                    </div>

                    <form onSubmit={handleTmdbSearch} className="flex gap-3">
                      <div className="relative flex-1">
                        <Search size={14} className="absolute left-3.5 top-3.5 text-neutral-500" />
                        <input
                          type="text"
                          placeholder="Type titles name to lookup (e.g. Inception, Avatar, Cyberpunk)..."
                          value={tmdbQuery}
                          onChange={(e) => setTmdbQuery(e.target.value)}
                          className="pl-10 pr-4 py-3 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] w-full"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={loadingTmdb}
                        className="px-6 bg-[#E50914] hover:bg-[#b0070f] text-xs font-black uppercase text-white rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {loadingTmdb ? <RefreshCw className="animate-spin" size={13} /> : <Search size={13} />}
                        <span>Lookup Catalog</span>
                      </button>
                    </form>

                    {/* Results list */}
                    {tmdbResults.length > 0 && (
                      <div className="space-y-4 pt-4">
                        <div className="flex items-center justify-between pb-2 border-b border-white/5">
                          <p className="text-xs font-bold text-gray-400 font-mono uppercase">{tmdbResults.length} TMDB matches mapped</p>
                          {selectedImportIds.length > 0 && (
                            <button
                              onClick={handleTriggerBulkImport}
                              disabled={importingInProgress}
                              className="px-4 py-2 bg-green-600 hover:bg-green-700 text-xs font-black uppercase text-white rounded-xl transition-all cursor-pointer"
                            >
                              {importingInProgress ? 'Ingesting Bulk...' : `Bulk Ingest Selected (${selectedImportIds.length})`}
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {tmdbResults.map((item) => {
                            const isSelected = selectedImportIds.includes(item.tmdbId);
                            // Avoid duplicate display as importable if already inside catalog
                            const isAlreadyIngested = catalog.some(c => c.media.tmdbId === item.tmdbId);

                            return (
                              <div key={item.tmdbId} className="p-3 bg-[#111111]/40 border border-white/5 rounded-2xl flex items-center justify-between gap-3 text-left">
                                <div className="flex items-center gap-3 min-w-0">
                                  {!isAlreadyIngested && (
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={() => handleToggleImportSelect(item.tmdbId)}
                                      className="cursor-pointer"
                                    />
                                  )}
                                  <div className="w-10 h-14 bg-neutral-900 border border-white/5 rounded-lg overflow-hidden flex-shrink-0">
                                    <img src={item.posterUrl} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                                  </div>
                                  <div className="min-w-0 space-y-0.5">
                                    <h4 className="font-bold text-xs uppercase text-white truncate max-w-[200px]" title={item.title}>{item.title}</h4>
                                    <p className="text-neutral-500 text-[10px] uppercase font-mono">{item.type} • {item.year}</p>
                                  </div>
                                </div>

                                {isAlreadyIngested ? (
                                  <span className="text-[9px] font-mono text-green-500 bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded uppercase font-bold">Already Imported</span>
                                ) : (
                                  <button
                                    onClick={() => handleTriggerSingleImport(item)}
                                    disabled={importingInProgress}
                                    className="px-3 py-1.5 bg-[#E50914] hover:bg-[#b0070f] text-xxs font-black uppercase text-white rounded-lg transition-all cursor-pointer"
                                  >
                                    Import
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Single Item Import DataSource Confirmation Modal */}
                  {importConfirmItem && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <div className="bg-[#0e0e0e] border border-white/5 p-6 md:p-8 rounded-3xl max-w-md w-full space-y-6 text-left">
                        <div className="space-y-2">
                          <h3 className="text-sm font-black uppercase text-white tracking-widest text-[#E50914]">CONFIRM IMPORT SOURCE</h3>
                          <p className="text-[10px] text-gray-500 font-mono">CHOOSE THE TARGET RESIDENT PIPELINE DATA CONFIGURATION</p>
                        </div>

                        <div className="p-4 bg-white/2 rounded-2xl border border-white/5 flex gap-3 items-center">
                          <img src={importConfirmItem.posterUrl} className="w-10 h-14 object-cover rounded-lg flex-shrink-0" alt="" referrerPolicy="no-referrer" />
                          <div>
                            <p className="text-xs font-bold text-white uppercase">{importConfirmItem.title}</p>
                            <p className="text-[10px] text-gray-400 font-mono mt-0.5">{importConfirmItem.type} • {importConfirmItem.year}</p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Data Source Strategy</label>
                          <div className="flex flex-col gap-3">
                            <label className="flex items-start gap-3 p-3 bg-white/2 hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl cursor-pointer select-none transition-all">
                              <input
                                type="radio"
                                name="importConfirmDataSource"
                                value="DATABASE"
                                checked={importConfirmDataSource === 'DATABASE'}
                                onChange={() => setImportConfirmDataSource('DATABASE')}
                                className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                              />
                              <div>
                                <span className="text-xs font-bold text-gray-200 block">DATABASE</span>
                                <span className="text-[9px] text-gray-500 font-mono">data copy karke mere database mein save karo</span>
                              </div>
                            </label>

                            <label className="flex items-start gap-3 p-3 bg-white/2 hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl cursor-pointer select-none transition-all">
                              <input
                                type="radio"
                                name="importConfirmDataSource"
                                value="LIVE_TMDB"
                                checked={importConfirmDataSource === 'LIVE_TMDB'}
                                onChange={() => setImportConfirmDataSource('LIVE_TMDB')}
                                className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                              />
                              <div>
                                <span className="text-xs font-bold text-gray-200 block">LIVE_TMDB</span>
                                <span className="text-[9px] text-gray-500 font-mono">sirf TMDB ID save karo, data live fetch hoga</span>
                              </div>
                            </label>
                          </div>
                        </div>

                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={() => setImportConfirmItem(null)}
                            className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/15 text-xs font-bold text-gray-400 hover:text-white transition-all cursor-pointer text-center border border-white/5"
                          >
                            ABORT
                          </button>
                          <button
                            onClick={() => {
                              handleSingleImport(importConfirmItem, importConfirmDataSource);
                              setImportConfirmItem(null);
                            }}
                            className="flex-1 py-3 rounded-xl bg-[#E50914] hover:bg-[#b0070f] text-xs font-black uppercase text-white shadow-[0_4px_15px_rgba(229,9,20,0.3)] transition-all cursor-pointer text-center"
                          >
                            CONFIRM & IMPORT
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Bulk Ingest DataSource Confirmation Modal */}
                  {isBulkImportConfirmOpen && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <div className="bg-[#0e0e0e] border border-white/5 p-6 md:p-8 rounded-3xl max-w-md w-full space-y-6 text-left">
                        <div className="space-y-2">
                          <h3 className="text-sm font-black uppercase text-white tracking-widest text-[#E50914]">CONFIRM BULK IMPORT</h3>
                          <p className="text-[10px] text-gray-500 font-mono">CHOOSE THE TARGET RESIDENT PIPELINE DATA CONFIGURATION FOR {selectedImportIds.length} ITEMS</p>
                        </div>

                        <div className="space-y-3">
                          <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Bulk Data Source Strategy</label>
                          <div className="flex flex-col gap-3">
                            <label className="flex items-start gap-3 p-3 bg-white/2 hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl cursor-pointer select-none transition-all">
                              <input
                                type="radio"
                                name="bulkConfirmDataSource"
                                value="DATABASE"
                                checked={importConfirmDataSource === 'DATABASE'}
                                onChange={() => setImportConfirmDataSource('DATABASE')}
                                className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                              />
                              <div>
                                <span className="text-xs font-bold text-gray-200 block">DATABASE</span>
                                <span className="text-[9px] text-gray-500 font-mono">data copy karke mere database mein save karo</span>
                              </div>
                            </label>

                            <label className="flex items-start gap-3 p-3 bg-white/2 hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl cursor-pointer select-none transition-all">
                              <input
                                type="radio"
                                name="bulkConfirmDataSource"
                                value="LIVE_TMDB"
                                checked={importConfirmDataSource === 'LIVE_TMDB'}
                                onChange={() => setImportConfirmDataSource('LIVE_TMDB')}
                                className="mt-0.5 w-4 h-4 rounded-full border border-white/10 text-[#E50914] focus:ring-x focus:ring-0 cursor-pointer"
                              />
                              <div>
                                <span className="text-xs font-bold text-gray-200 block">LIVE_TMDB</span>
                                <span className="text-[9px] text-gray-500 font-mono">sirf TMDB ID save karo, data live fetch hoga</span>
                              </div>
                            </label>
                          </div>
                        </div>

                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={() => setIsBulkImportConfirmOpen(false)}
                            className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/15 text-xs font-bold text-gray-400 hover:text-white transition-all cursor-pointer text-center border border-white/5"
                          >
                            ABORT
                          </button>
                          <button
                            onClick={() => {
                              handleBulkImport(importConfirmDataSource);
                              setIsBulkImportConfirmOpen(false);
                            }}
                            className="flex-1 py-3 rounded-xl bg-green-600 hover:bg-green-700 text-xs font-black uppercase text-white shadow-[0_4px_15px_rgba(22,163,74,0.3)] transition-all cursor-pointer text-center"
                          >
                            CONFIRM BULK IMPORT
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* TAB: USER MANAGEMENT */}
              {activeTab === 'users-mgmt' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">System User Management</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Moderate critic and audience accounts, ban bad actors, and award verification badges.</p>
                    </div>
                  </div>

                  {/* PENDING VERIFICATION REQUESTS SUBSECTION */}
                  {verificationRequests.length > 0 && (
                    <div className="border border-red-500/10 bg-[#E50914]/2 rounded-2xl p-5 space-y-4 animate-fade-in" id="pending-verification-block-sub">
                      <div className="flex items-center gap-2">
                        <BadgeCheck className="text-[#E50914]" size={16} />
                        <h4 className="text-xs font-black uppercase text-white tracking-wider">Pending Critic Verification Requests ({verificationRequests.length})</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {verificationRequests.map((req) => (
                          <div key={req.id} className="bg-neutral-950 p-4 rounded-xl border border-white/5 space-y-3">
                            {/* User details */}
                            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/2 pb-2">
                              <div>
                                <span className="text-xs font-bold text-white block capitalize">{req.fullName}</span>
                                <span className="text-[10px] text-gray-400 font-mono">@{req.username}</span>
                              </div>
                              <div className="text-right">
                                <span className="text-[9px] text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/20 px-2 py-0.5 rounded font-mono font-bold uppercase block">{req.email}</span>
                                <span className="text-[8px] text-neutral-500 font-mono block mt-1">
                                  {req.createdAt ? new Date(req.createdAt).toLocaleDateString() : 'N/A'}
                                </span>
                              </div>
                            </div>

                            {/* Reason / Statement */}
                            <div className="text-left space-y-1">
                              <span className="text-[8px] text-neutral-500 uppercase font-mono tracking-wider block">Reason:</span>
                              <p className="text-xxs text-gray-300 leading-relaxed bg-black/40 p-2.5 rounded border border-white/2">{req.reason}</p>
                            </div>

                            {/* Proof Link */}
                            {req.proofUrl && (
                              <div className="flex items-center gap-1.5 pt-1">
                                <span className="text-[8px] text-neutral-500 font-mono uppercase tracking-wider">Portfolio:</span>
                                <a 
                                  href={req.proofUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer" 
                                  className="text-[9px] text-blue-400 font-mono hover:underline truncate max-w-[200px]"
                                >
                                  {req.proofUrl}
                                </a>
                              </div>
                            )}

                            {/* Action Row */}
                            <div className="flex gap-2 pt-1 border-t border-white/2">
                              <button
                                onClick={() => handleApproveVerification(req)}
                                className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[9px] font-mono font-black tracking-wider uppercase transition-colors text-center cursor-pointer font-bold"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleRejectVerification(req)}
                                className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-[9px] font-mono font-black tracking-wider uppercase transition-colors text-center cursor-pointer font-bold"
                              >
                                Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Search and Filters */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search size={14} className="absolute left-3.5 top-3.5 text-neutral-500" />
                      <input
                        type="text"
                        placeholder="Search users by name or email..."
                        value={usersSearchQuery}
                        onChange={(e) => setUsersSearchQuery(e.target.value)}
                        className="pl-10 pr-4 py-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] w-full"
                      />
                    </div>
                    <select
                      value={usersStatusFilter}
                      onChange={(e) => setUsersStatusFilter(e.target.value as any)}
                      className="bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    >
                      <option value="ALL">ALL ACCOUNT STATUSES</option>
                      <option value="ACTIVE">ACTIVE ONLY</option>
                      <option value="BANNED">BANNED ONLY</option>
                    </select>
                  </div>

                  {/* Users Table */}
                  <div className="overflow-x-auto rounded-xl border border-white/5 animate-fade-in">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-white/5 bg-neutral-950 font-mono text-[9px] text-neutral-500 uppercase">
                          <th className="py-3 px-4">User Identity</th>
                          <th className="py-3 px-4">Email</th>
                          <th className="py-3 px-4">Joined Date</th>
                          <th className="py-3 px-4 text-center">Status</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {usersList
                          .filter(u => {
                            const query = usersSearchQuery.toLowerCase();
                            const matchesSearch = u.name.toLowerCase().includes(query) || 
                                                 u.email.toLowerCase().includes(query) || 
                                                 u.username.toLowerCase().includes(query);
                            const matchesStatus = usersStatusFilter === 'ALL' || 
                                                  (usersStatusFilter === 'ACTIVE' && (u as any).status !== 'banned') || 
                                                  (usersStatusFilter === 'BANNED' && (u as any).status === 'banned');
                            return matchesSearch && matchesStatus;
                          })
                          .map((u: any) => {
                            const isBanned = u.status === 'banned';
                            const isVerified = u.isVerified || false;
                            return (
                              <tr key={u.uid} className="border-b border-white/5 hover:bg-white/2 text-xs text-gray-300">
                                <td className="py-3.5 px-4 flex items-center gap-3">
                                  <img 
                                    src={`https://api.dicebear.com/7.x/bottts/svg?seed=${u.username || u.name}`}
                                    className="w-8 h-8 rounded-full border border-white/10 bg-neutral-900"
                                    alt={u.username}
                                  />
                                  <div>
                                    <div className="flex items-center gap-1">
                                      <span className="font-bold text-white capitalize">{u.name}</span>
                                      {isVerified && (
                                        <ShieldCheck className="text-blue-500" size={12} title="Verified Critic" />
                                      )}
                                    </div>
                                    <span className="text-[10px] text-neutral-500 font-mono">@{u.username}</span>
                                  </div>
                                </td>
                                <td className="py-3.5 px-4 font-mono text-gray-400">{u.email}</td>
                                <td className="py-3.5 px-4 text-gray-400 text-xxs font-mono">
                                  {new Date(u.createdAt || Date.now()).toLocaleDateString()}
                                </td>
                                <td className="py-3.5 px-4 text-center">
                                  {isBanned ? (
                                    <span 
                                      className="px-2 py-0.5 bg-red-500/10 text-red-500 border border-red-500/20 rounded text-[9px] font-mono font-bold uppercase cursor-help"
                                      title={`Reason: ${u.banReason || 'No reason specified'}`}
                                    >
                                      Banned
                                    </span>
                                  ) : (
                                    <span className="px-2 py-0.5 bg-green-500/10 text-green-500 border border-green-500/20 rounded text-[9px] font-mono font-bold uppercase">
                                      Active
                                    </span>
                                  )}
                                </td>
                                <td className="py-3.5 px-4 text-right space-x-2">
                                  <button
                                    onClick={() => handleViewUserActivity(u)}
                                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-xxs uppercase tracking-wider font-bold rounded text-white"
                                  >
                                    Activity
                                  </button>
                                  <button
                                    onClick={() => handleToggleVerification(u)}
                                    className={`px-2.5 py-1 text-xxs uppercase tracking-wider font-bold rounded ${
                                      isVerified ? 'bg-blue-900/10 text-blue-400 border border-blue-500/20 hover:bg-blue-950/20' : 'bg-white/5 text-gray-300 hover:bg-white/10 text-white'
                                    }`}
                                  >
                                    {isVerified ? 'Unverify' : 'Verify'}
                                  </button>
                                  <button
                                    onClick={() => handleBanUnbanClick(u)}
                                    className={`px-2.5 py-1 text-xxs uppercase tracking-wider font-bold rounded ${
                                      isBanned ? 'bg-green-950/30 text-green-400 border border-green-500/20 hover:bg-green-900/30' : 'bg-red-950/30 text-red-400 border border-red-500/20 hover:bg-red-900/30'
                                    }`}
                                  >
                                    {isBanned ? 'Unban' : 'Ban'}
                                  </button>
                                  <button
                                    onClick={() => handleDeleteUser(u.uid)}
                                    className="p-1 text-neutral-500 hover:text-red-500 transition-colors inline-block align-middle"
                                    title="Delete Account"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: VERIFICATION REQUESTS */}
              {activeTab === 'verification-requests' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left" id="verification-requests-panel">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Verification Requests Queue</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Audit credentials, portfolio links, and submissions to grant official verified critic status.</p>
                    </div>
                  </div>

                  {loadingRequests ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-3 border border-dashed border-white/5 rounded-2xl bg-black/40">
                      <div className="w-8 h-8 border-2 border-[#E50914] border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-xs font-mono text-gray-500 uppercase tracking-widest">Accessing cloud requests queue...</span>
                    </div>
                  ) : verificationRequests.length === 0 ? (
                    <div className="text-center py-20 border border-dashed border-white/5 rounded-2xl bg-black/40 space-y-3">
                      <div className="w-12 h-12 rounded-full border border-white/5 flex items-center justify-center mx-auto text-gray-500 bg-neutral-950">
                        <BadgeCheck size={20} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-white uppercase font-mono">No Outbox Requests</h4>
                        <p className="text-[10px] text-gray-500 max-w-xs mx-auto">There are currently no outstanding critic or curator verification requests pending review.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {verificationRequests.map((req) => (
                        <div key={req.id} className="bg-neutral-950 p-5 rounded-2xl border border-white/5 flex flex-col md:flex-row justify-between gap-4">
                          <div className="space-y-3 flex-1">
                            {/* Header: User name, email, date */}
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xs font-black text-white">{req.fullName}</span>
                              <span className="text-[10px] text-gray-500 font-mono">@{req.username}</span>
                              <span className="text-[9px] text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/20 px-2 py-0.5 rounded font-mono font-bold uppercase">{req.email}</span>
                              <span className="text-gray-600 text-[10px]">&bull;</span>
                              <span className="text-[9px] text-gray-500 font-mono">
                                {req.createdAt ? new Date(req.createdAt).toLocaleDateString() : 'N/A'}
                              </span>
                            </div>

                            {/* Reason / Message block */}
                            <div className="bg-zinc-950 p-4 rounded-xl border border-white/2 text-left space-y-1.5">
                              <span className="text-[8px] text-gray-500 uppercase font-mono font-black block tracking-wider">Statement of Credentials:</span>
                              <p className="text-xs text-gray-300 font-sans leading-relaxed whitespace-pre-wrap">{req.reason}</p>
                            </div>

                            {/* Proof website/social portfolio link */}
                            {req.proofUrl && (
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="text-[8px] text-gray-500 font-mono uppercase tracking-wider whitespace-nowrap">Proof of authority:</span>
                                <a 
                                  href={req.proofUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer" 
                                  className="text-[10px] text-blue-400 font-mono hover:underline break-all"
                                >
                                  {req.proofUrl}
                                </a>
                              </div>
                            )}
                          </div>

                          {/* Action controls (Approve vs Reject) */}
                          <div className="flex flex-row md:flex-col justify-end gap-2.5 min-w-[120px] shrink-0 justify-items-stretch">
                            <button
                              onClick={() => handleApproveVerification(req)}
                              className="flex-1 md:flex-none py-2 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-3xs font-mono font-black tracking-widest uppercase transition-all cursor-pointer text-center font-bold"
                            >
                              APPROVE
                            </button>
                            <button
                              onClick={() => handleRejectVerification(req)}
                              className="flex-1 md:flex-none py-2 px-4 bg-red-600 hover:bg-red-500 text-white rounded-xl text-3xs font-mono font-black tracking-widest uppercase transition-all cursor-pointer text-center font-bold"
                            >
                              REJECT
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB: REVIEWS MODERATION */}
              {activeTab === 'reviews-mod' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Audience Reviews Moderation</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Audit, approve, or prune consumer review logs flagged by automated filters or community members.</p>
                    </div>
                  </div>

                  {/* Filter tabs */}
                  <div className="flex gap-2 border-b border-white/5 pb-1">
                    <button
                      onClick={() => setReviewsFilter('ALL')}
                      className={`px-4 py-2 text-xs font-bold uppercase transition-all border-b-2 ${
                        reviewsFilter === 'ALL' ? 'border-[#E50914] text-white font-black' : 'border-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      All Reviews ({reviewsList.length})
                    </button>
                    <button
                      onClick={() => setReviewsFilter('REPORTED')}
                      className={`px-4 py-2 text-xs font-bold uppercase transition-all border-b-2 ${
                        reviewsFilter === 'REPORTED' ? 'border-[#E50914] text-red-400 font-black' : 'border-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      Reported ({reportsList.filter(r => r.type === 'REVIEW' && r.status === 'PENDING').length})
                    </button>
                  </div>

                  {/* List */}
                  <div className="space-y-4">
                    {reviewsList
                      .filter(r => {
                        if (reviewsFilter === 'REPORTED') {
                          return reportsList.some(rep => rep.type === 'REVIEW' && rep.targetId === r.id && rep.status === 'PENDING');
                        }
                        return true;
                      })
                      .map((rev) => {
                        const associatedReport = reportsList.find(rep => rep.type === 'REVIEW' && rep.targetId === rev.id && rep.status === 'PENDING');
                        return (
                          <div key={rev.id} className="p-4 bg-[#111111]/40 border border-white/5 rounded-2xl space-y-3">
                            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 bg-[#E50914]/15 border border-[#E50914]/20 text-[#E50914] text-[9px] font-mono font-bold uppercase rounded">
                                  {rev.rating} ★
                                </span>
                                <span className="text-[10px] text-gray-500 font-mono">Posted by @{rev.username}</span>
                              </div>
                              <span className="text-[10px] text-gray-500 font-mono">
                                {new Date(rev.createdAt).toLocaleString()}
                              </span>
                            </div>

                            <p className="text-xs text-gray-300 line-clamp-2 italic font-sans">
                              "{rev.text}"
                            </p>

                            {associatedReport && (
                              <div className="p-2.5 bg-red-950/20 border border-red-500/10 rounded-xl text-xxs text-red-400 font-mono">
                                <span className="font-bold text-red-500 block text-[9px] uppercase tracking-wider mb-0.5">Reported by @{associatedReport.reporter}:</span>
                                <span>Reason: "{associatedReport.reason}"</span>
                              </div>
                            )}

                            <div className="flex gap-2 justify-end pt-2 border-t border-white/5">
                              <button
                                onClick={() => {
                                  setSelectedReviewForModal(rev);
                                  setIsReviewModalOpen(true);
                                }}
                                className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-neutral-300 text-xxs font-bold uppercase rounded"
                              >
                                View Details
                              </button>
                              
                              {associatedReport ? (
                                <>
                                  <button
                                    onClick={() => handleDismissReport(associatedReport.id)}
                                    className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-gray-300 text-xxs font-bold uppercase rounded"
                                  >
                                    Dismiss Report
                                  </button>
                                  <button
                                    onClick={() => handleResolveReport(associatedReport.id, rev.id, 'REVIEW')}
                                    className="px-2.5 py-1.5 bg-red-600/20 hover:bg-red-600/30 text-red-400 text-xxs font-bold uppercase rounded"
                                  >
                                    Delete & Resolve
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={() => handleTriggerDeleteReview(rev)}
                                  className="px-2.5 py-1.5 bg-red-650 hover:bg-red-750 text-white hover:bg-red-700 text-xxs font-bold uppercase rounded"
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* TAB: COMMENTS MODERATION */}
              {activeTab === 'comments-mod' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">System Comments & Replies</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Moderate comments posted across reviews as well as replies in spaces forums.</p>
                    </div>
                  </div>

                  {/* Filter tabs */}
                  <div className="flex gap-2 border-b border-white/5 pb-1">
                    <button
                      onClick={() => setCommentsFilter('ALL')}
                      className={`px-4 py-2 text-xs font-bold uppercase transition-all border-b-2 ${
                        commentsFilter === 'ALL' ? 'border-[#E50914] text-white font-black' : 'border-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      All Comments ({getUnifiedCommentsList().length})
                    </button>
                    <button
                      onClick={() => setCommentsFilter('REPORTED')}
                      className={`px-4 py-2 text-xs font-bold uppercase transition-all border-b-2 ${
                        commentsFilter === 'REPORTED' ? 'border-[#E50914] text-red-400 font-black' : 'border-transparent text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      Reported ({reportsList.filter(r => r.type === 'COMMENT' && r.status === 'PENDING').length})
                    </button>
                  </div>

                  {/* Comments list */}
                  <div className="space-y-4">
                    {getUnifiedCommentsList()
                      .filter(c => {
                        if (commentsFilter === 'REPORTED') {
                          return reportsList.some(rep => rep.type === 'COMMENT' && rep.targetId === c.id && rep.status === 'PENDING');
                        }
                        return true;
                      })
                      .map((comm) => {
                        const associatedReport = reportsList.find(rep => rep.type === 'COMMENT' && rep.targetId === comm.id && rep.status === 'PENDING');
                        return (
                          <div key={comm.id} className="p-4 bg-[#111111]/40 border border-white/5 rounded-2xl flex flex-col justify-between gap-3 text-left">
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                  <img src={comm.userAvatar} className="w-5 h-5 rounded-full bg-neutral-900 border border-white/10" alt="" />
                                  <span className="font-bold text-xs text-white">@{comm.username}</span>
                                  <span className="text-[9px] px-1.5 py-0.5 bg-neutral-800 text-neutral-400 rounded uppercase font-mono">{comm.context}</span>
                                </div>
                                <span className="text-[10px] text-gray-500 font-mono">{new Date(comm.createdAt).toLocaleString()}</span>
                              </div>
                              <p className="text-xs text-gray-300 italic">"{comm.text}"</p>

                              {associatedReport && (
                                <div className="p-2 bg-red-950/20 border border-red-500/10 rounded-xl text-xxs text-red-400 font-mono">
                                  <span className="font-bold text-red-500 block text-[9px] uppercase tracking-wider mb-0.5">Report Reason (@{associatedReport.reporter}):</span>
                                  <span>"{associatedReport.reason}"</span>
                                </div>
                              )}
                            </div>

                            <div className="flex justify-end gap-2 border-t border-white/5 pt-2">
                              {associatedReport ? (
                                <>
                                  <button
                                    onClick={() => handleDismissReport(associatedReport.id)}
                                    className="px-2.5 py-1 text-xxs font-bold uppercase rounded bg-neutral-800 hover:bg-neutral-700 text-gray-300"
                                  >
                                    Dismiss Report
                                  </button>
                                  <button
                                    onClick={() => handleResolveReport(associatedReport.id, comm.id, 'COMMENT')}
                                    className="px-2.5 py-1 text-xxs font-bold uppercase rounded bg-red-600/20 hover:bg-red-600/30 text-red-400 font-black"
                                  >
                                    Delete & Resolve
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={() => handleTriggerDeleteComment(comm)}
                                  className="px-2.5 py-1 text-xxs font-bold uppercase bg-red-600 hover:bg-red-700 text-white rounded"
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* TAB: DISCUSSIONS MODERATION */}
              {activeTab === 'discussions-mod' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Spaces Forums & Discussions</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Audit community-started Open Floor forums. Toggle sticky pins, read through/delete replies, and handle reported threads.</p>
                    </div>
                  </div>

                  {/* Discussions list */}
                  <div className="space-y-4 animate-fade-in">
                    {discussionsList.map((disc) => {
                      const associatedReport = reportsList.find(rep => rep.type === 'DISCUSSION' && rep.targetId === disc.id && rep.status === 'PENDING');
                      const discReplies = discussionsReplies.filter(r => r.targetId === disc.id && r.targetType === 'discussion');
                      return (
                        <div key={disc.id} className="p-5 bg-[#111111]/40 border border-white/5 rounded-2xl space-y-3">
                          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              {disc.isPinned && (
                                <span className="px-1.5 py-0.5 bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-[8px] font-mono font-bold uppercase rounded animate-pulse">
                                  Pinned
                                </span>
                              )}
                              <h4 className="font-bold text-sm text-white uppercase">{disc.title}</h4>
                            </div>
                            <span className="text-[10px] text-gray-500 font-mono">{new Date(disc.createdAt).toLocaleString()}</span>
                          </div>

                          <p className="text-xs text-gray-400 line-clamp-2 italic">
                            "{disc.description}"
                          </p>

                          <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono pt-2 border-t border-white/5 flex-wrap gap-2">
                            <span>Started by @{disc.authorUsername} • {discReplies.length} replies</span>
                            
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleTogglePinDiscussion(disc.id)}
                                className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-neutral-300 text-xxs font-bold uppercase tracking-wide rounded"
                              >
                                {disc.isPinned ? 'Unpin' : 'Pin Thread'}
                              </button>
                              <button
                                onClick={() => handleViewDiscussionReplies(disc)}
                                className="px-2.5 py-1 bg-white/5 hover:bg-[#E50914]/20 hover:text-white transition-all text-neutral-300 text-xxs font-bold uppercase tracking-wide rounded"
                              >
                                Replies ({discReplies.length})
                              </button>
                              {associatedReport ? (
                                <>
                                  <button
                                    onClick={() => handleDismissReport(associatedReport.id)}
                                    className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-gray-300 text-xxs font-bold tracking-wider rounded"
                                  >
                                    Dismiss
                                  </button>
                                  <button
                                    onClick={() => handleResolveReport(associatedReport.id, disc.id, 'DISCUSSION')}
                                    className="px-2.5 py-1 bg-red-650 hover:bg-red-700 text-white text-xxs font-bold tracking-wider rounded"
                                  >
                                    Resolve (Delete)
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={() => handleTriggerDeleteDiscussion(disc)}
                                  className="px-2.5 py-1 bg-[#E50914]/15 border border-[#E50914]/25 hover:bg-[#E50914] text-[#E50914] hover:text-white text-xxs font-bold uppercase rounded transition-colors"
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </div>

                          {associatedReport && (
                            <div className="p-2.5 bg-red-950/20 border border-red-500/10 rounded-xl text-xxs text-red-400 font-mono">
                              <span className="font-bold text-red-500 block text-[9px] uppercase tracking-wider mb-0.5">Reported Thread by @{associatedReport.reporter}:</span>
                              <span>"{associatedReport.reason}"</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB: REPORTED CONTENT */}
              {activeTab === 'reported' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Unified Reports Queue</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Central clearing house for active reports submitted by users or tagged by the AI agent.</p>
                    </div>
                  </div>

                  {/* Filter selectors */}
                  <div className="flex flex-wrap gap-2 border-b border-white/5 pb-1">
                    {(['REVIEWS', 'COMMENTS', 'DISCUSSIONS', 'CONTENT'] as const).map((tab) => {
                      const count = reportsList.filter(r => {
                        const matchesType = 
                          (tab === 'REVIEWS' && r.type === 'REVIEW') ||
                          (tab === 'COMMENTS' && r.type === 'COMMENT') ||
                          (tab === 'DISCUSSIONS' && r.type === 'DISCUSSION') ||
                          (tab === 'CONTENT' && r.type === 'CONTENT');
                        return matchesType && r.status === 'PENDING';
                      }).length;
                      return (
                        <button
                          key={tab}
                          onClick={() => setReportsFilterTab(tab)}
                          className={`px-4 py-2 text-xs font-bold uppercase transition-all border-b-2 ${
                            reportsFilterTab === tab ? 'border-[#E50914] text-white font-black' : 'border-transparent text-gray-500 hover:text-gray-300'
                          }`}
                        >
                          {tab} ({count})
                        </button>
                      );
                    })}
                  </div>

                  {/* Queue List */}
                  <div className="space-y-4">
                    {reportsList
                      .filter(r => {
                        const matchesType = 
                          (reportsFilterTab === 'REVIEWS' && r.type === 'REVIEW') ||
                          (reportsFilterTab === 'COMMENTS' && r.type === 'COMMENT') ||
                          (reportsFilterTab === 'DISCUSSIONS' && r.type === 'DISCUSSION') ||
                          (reportsFilterTab === 'CONTENT' && r.type === 'CONTENT');
                        return matchesType && r.status === 'PENDING';
                      })
                      .map((rep) => {
                        return (
                          <div key={rep.id} className="p-4 bg-red-950/5 border border-red-500/10 hover:border-red-500/20 rounded-2xl space-y-3 transition-colors duration-150">
                            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                              <div className="space-y-0.5">
                                <span className="text-[10px] text-red-400 font-mono font-bold block uppercase">
                                  Flagged reason: "{rep.reason}"
                                </span>
                                <span className="text-gray-500 text-xxs font-mono block">
                                  Flagged on {new Date(rep.date).toLocaleString()} • Submitted by @{rep.reporter}
                                </span>
                              </div>
                              <span className="px-2 py-0.5 bg-red-500/10 border border-red-500/20 text-red-400 text-[8px] font-mono font-bold uppercase rounded self-start sm:self-center">
                                Pending Audit
                              </span>
                            </div>

                            <div className="p-3 bg-neutral-950/80 border border-white/5 rounded-xl text-xs text-gray-300 italic font-mono space-y-1">
                              <span className="text-[9px] text-gray-500 block uppercase font-black tracking-wider">Flagged item preview:</span>
                              <p className="line-clamp-2">"{rep.reportedItemPreview}"</p>
                            </div>

                            <div className="flex gap-2 justify-end pt-2 border-t border-white/5">
                              <button
                                onClick={() => handleViewReportedItem(rep)}
                                className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-neutral-300 text-xxs font-bold uppercase rounded transition-all"
                              >
                                View Item
                              </button>
                              <button
                                onClick={() => handleDismissReport(rep.id)}
                                className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-gray-300 text-xxs font-bold uppercase rounded transition-all"
                              >
                                Dismiss Report
                              </button>
                              <button
                                onClick={() => handleResolveReport(rep.id, rep.targetId, rep.type)}
                                className="px-2.5 py-1.5 bg-red-650 hover:bg-red-700 text-white text-xxs font-bold uppercase rounded transition-all"
                              >
                                Delete Item & Resolve
                              </button>
                            </div>
                          </div>
                        );
                      })}

                    {reportsList.filter(r => {
                      const matchesType = 
                        (reportsFilterTab === 'REVIEWS' && r.type === 'REVIEW') ||
                        (reportsFilterTab === 'COMMENTS' && r.type === 'COMMENT') ||
                        (reportsFilterTab === 'DISCUSSIONS' && r.type === 'DISCUSSION') ||
                        (reportsFilterTab === 'CONTENT' && r.type === 'CONTENT');
                      return matchesType && r.status === 'PENDING';
                    }).length === 0 && (
                      <div className="py-12 bg-neutral-950/20 rounded-2xl border border-white/5 text-center text-gray-500 space-y-2">
                        <Check className="mx-auto text-green-500 font-bold" size={24} />
                        <p className="text-xxs font-mono uppercase tracking-widest">No pending reports in this sector.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB: NEWS MANAGEMENT */}
              {activeTab === 'news' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Editorial & News Room</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Publish community news, media leaks, box office announcements, and articles powered by Gemini.</p>
                    </div>
                    <button
                      onClick={() => handleOpenNewsForm()}
                      className="px-4 py-2 bg-[#E50914] hover:bg-[#b0070f] text-xs font-black uppercase text-white rounded-xl transition-all cursor-pointer"
                    >
                      Draft New Article
                    </button>
                  </div>

                  {/* Add / Edit Form overlay fallback or toggle */}
                  {isNewsFormOpen && (
                    <div className="p-6 bg-neutral-950 border border-white/10 rounded-2xl space-y-4 animate-fade-in">
                      <div className="flex justify-between items-center pb-2 border-b border-white/5">
                        <h4 className="font-bold text-xs uppercase text-white">
                          {editingNewsId ? 'Edit Article Draft' : 'Draft New Editorial Article'}
                        </h4>
                        <button onClick={() => setIsNewsFormOpen(false)} className="text-gray-400 hover:text-white text-xs uppercase font-bold">Cancel</button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-mono uppercase text-gray-400 block font-bold">Article Title</label>
                          <input
                            type="text"
                            placeholder="e.g. Zack Snyder Announces Sci-Fi Franchise Expansion"
                            value={newsFormTitle}
                            onChange={(e) => setNewsFormTitle(e.target.value)}
                            className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] w-full"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-mono uppercase text-gray-400 block font-bold">Category</label>
                          <select
                            value={newsFormCategory}
                            onChange={(e) => setNewsFormCategory(e.target.value as any)}
                            className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white focus:outline-none w-full"
                          >
                            <option value="NEWS">NEWS</option>
                            <option value="RUMOUR">RUMOUR</option>
                            <option value="BOX OFFICE">BOX OFFICE</option>
                            <option value="EXCLUSIVE">EXCLUSIVE</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-mono uppercase text-gray-400 block font-bold">Cover Image URL</label>
                          <input
                            type="text"
                            placeholder="e.g. https://images.unsplash.com/photo-..."
                            value={newsFormImageUrl}
                            onChange={(e) => setNewsFormImageUrl(e.target.value)}
                            className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none w-full"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-mono uppercase text-gray-400 block font-bold">Associated Content Item (Optional)</label>
                          <select
                            value={newsFormAssociatedContentId}
                            onChange={(e) => setNewsFormAssociatedContentId(e.target.value)}
                            className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white focus:outline-none w-full"
                          >
                            <option value="">-- No Associated Movie/Show --</option>
                            {catalog.map(c => (
                              <option key={c.id} value={c.id}>
                                {c.media.title} ({c.media.type} - {c.media.year})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Gemini Assistant Section */}
                      <div className="p-4 bg-[#E50914]/5 border border-[#E50914]/20 rounded-xl space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <Sparkles className="text-[#E50914]" size={14} />
                            <span className="text-xxs font-mono font-bold text-red-400 uppercase tracking-widest">Gemini AI Editorial Assistant (gemini-3.5-flash)</span>
                          </div>
                          <button
                            onClick={() => setIsGeminiPromptOpen(!isGeminiPromptOpen)}
                            className="text-[10px] font-mono uppercase font-bold text-gray-400 hover:text-white"
                          >
                            {isGeminiPromptOpen ? 'Fold Assistant' : 'Open Assistant'}
                          </button>
                        </div>

                        {isGeminiPromptOpen && (
                          <div className="space-y-2 pt-1 transition-all duration-200">
                            <p className="text-[10px] text-gray-400 leading-relaxed font-mono">Input guidance criteria (e.g., 'Draft leaks of a new Spider-Man movie where Zendaya directs') to let Gemini generate a high-quality rich editorial body draft instantly.</p>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="Describe draft prompt instructions..."
                                value={newsFormPrompt}
                                onChange={(e) => setNewsFormPrompt(e.target.value)}
                                className="flex-1 p-2 bg-[#111111] border border-white/5 rounded-lg text-xs text-white focus:outline-none"
                              />
                              <button
                                onClick={handleGenerateNewsDraft}
                                disabled={isGeneratingNewsDraft}
                                className="px-3.5 py-2 bg-[#E50914] text-white text-xs font-bold uppercase rounded-lg hover:bg-red-700 transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                              >
                                {isGeneratingNewsDraft ? <RefreshCw className="animate-spin" size={11} /> : <Sparkles size={11} />}
                                <span>Generate Body</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-mono uppercase text-gray-400 block font-bold">Article Body</label>
                        <textarea
                          placeholder="Compose news text or use the Gemini AI generated draft..."
                          rows={6}
                          value={newsFormBody}
                          onChange={(e) => setNewsFormBody(e.target.value)}
                          className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] w-full"
                        ></textarea>
                      </div>

                      <div className="flex gap-2 justify-end pt-2 border-t border-white/5">
                        <button
                          onClick={() => setIsNewsFormOpen(false)}
                          className="px-4 py-2 bg-neutral-800 text-gray-300 text-xs font-bold uppercase rounded-xl hover:bg-neutral-700 transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={handleSaveNewsArticle}
                          className="px-5 py-2 bg-green-600 text-white text-xs font-bold uppercase rounded-xl hover:bg-green-700 transition-colors"
                        >
                          {editingNewsId ? 'Update Editorial' : 'Publish Editorial'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* News list */}
                  <div className="space-y-4">
                    {newsList
                      .filter(post => ['NEWS', 'RUMOUR', 'BOX OFFICE', 'EXCLUSIVE'].includes(post.category))
                      .map((post) => {
                        const article = post;
                        return (
                          <div key={article.id} className="p-4 bg-[#111111]/40 border border-white/5 rounded-2xl flex flex-col md:flex-row gap-4 text-left">
                            <div className="w-full md:w-32 h-20 rounded-xl overflow-hidden bg-neutral-900 border border-white/5 flex-shrink-0">
                              <img src={article.imageUrl} className="w-full h-full object-cover animate-fade-in" alt="" />
                            </div>
                            <div className="flex-1 space-y-1.5 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="px-2 py-0.5 bg-neutral-800 border border-white/10 text-neutral-400 text-[8px] font-mono font-bold uppercase rounded">
                                  {article.category}
                                </span>
                                {article.associatedContentId && (
                                  <span className="px-1.5 py-0.5 bg-red-950 text-red-400 border border-red-500/10 text-[8px] font-mono font-bold rounded">
                                    Linked Thread
                                  </span>
                                )}
                                <span className="text-[10px] text-gray-500 font-mono">Posted {new Date(article.createdAt).toLocaleDateString()}</span>
                              </div>
                              <h4 className="font-bold text-xs uppercase text-white truncate max-w-sm">{article.title}</h4>
                              <p className="text-xxs text-gray-400 line-clamp-2">{article.text}</p>

                              <div className="flex justify-end gap-2 pt-2 border-t border-white/5">
                                <button
                                  onClick={() => handleEditNewsArticle(article)}
                                  className="px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded text-neutral-300 text-xxs font-bold uppercase"
                                >
                                  Edit Draft
                                </button>
                                <button
                                  onClick={() => handleDeleteNewsArticle(article.id)}
                                  disabled={deletingNewsIdState === article.id}
                                  className={`px-2.5 py-1 bg-red-900/10 border border-red-500/10 hover:bg-red-700 text-red-400 hover:text-white text-xxs font-bold uppercase rounded transition-colors flex items-center gap-1 ${deletingNewsIdState === article.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                                >
                                  {deletingNewsIdState === article.id ? (
                                    <>
                                      <RefreshCw className="animate-spin text-red-400" size={10} />
                                      Deleting...
                                    </>
                                  ) : (
                                    'Delete'
                                  )}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* TAB: COLLECTIONS MANAGEMENT */}
              {activeTab === 'collections-mgmt' && (
                <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-black uppercase text-white">Public Collections Catalog</h3>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">Administer community portfolios. Mark collections as Featured, or delete offending ones.</p>
                    </div>
                  </div>

                  {/* List of public collections */}
                  <div className="space-y-4 font-mono">
                    {collectionsList.map((col) => {
                      const isFeatured = col.isFeatured || false;
                      return (
                        <div key={col.id} className="p-4 bg-[#111111]/40 border border-white/5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-neutral-900 border border-white/5 rounded-xl overflow-hidden flex-shrink-0">
                              <img src={col.coverUrl} className="w-full h-full object-cover" alt="" />
                            </div>
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <h4 className="font-bold text-xs uppercase text-white truncate max-w-[250px] font-sans">{col.name}</h4>
                                {isFeatured && (
                                  <span className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-[8px] font-mono font-bold uppercase rounded px-1.5 py-0.5 animate-pulse">FEATURED</span>
                                )}
                              </div>
                              <p className="text-neutral-500 text-[10px] font-mono">Curated by @{col.ownerUsername} • {col.mediaIds?.length || 0} movies/shows • {col.likesCount || 0} likes</p>
                              <p className="text-xxs text-gray-400 italic line-clamp-1 font-sans">"{col.description}"</p>
                            </div>
                          </div>

                          <div className="flex gap-2 self-end sm:self-center">
                            <button
                              onClick={() => handleToggleFeatureCollection(col.id)}
                              className={`px-3 py-1.5 text-xxs font-bold uppercase rounded-lg border transition-all ${
                                isFeatured ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-500 hover:bg-yellow-500/20' : 'bg-white/5 border-white/5 text-gray-300 hover:bg-white/10 text-white'
                              }`}
                            >
                              {isFeatured ? 'Unfeature' : 'Feature'}
                            </button>
                            <button
                              onClick={() => handleTriggerDeleteCollection(col)}
                              className="px-3 py-1.5 bg-red-650/20 hover:bg-red-750/30 border border-red-500/20 hover:border-red-500/30 text-red-400 hover:text-white text-xxs font-black uppercase rounded-lg transition-all"
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ACTION MODAL DIALOGS OVERLAYS FOR PHASE 9B FEATURES */}

              {/* 1. Ban User Modal */}
              {isBanModalOpen && userToBan && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                  <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-sm w-full space-y-4 text-left font-mono">
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <h3 className="text-xs font-black uppercase text-red-500 tracking-wider flex items-center gap-1 font-sans">
                        <AlertTriangle size={14} /> Ban User Profile
                      </h3>
                      <button onClick={() => setIsBanModalOpen(false)} className="text-gray-400 hover:text-white text-xs">✕</button>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-white capitalize font-sans">User: {userToBan.name}</p>
                      <p className="text-[10px] text-gray-500 font-mono">ID: @{userToBan.username}</p>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-mono text-gray-400 uppercase font-bold">Ban Audit Reason</label>
                      <input
                        type="text"
                        value={banReasonInput}
                        onChange={(e) => setBanReasonInput(e.target.value)}
                        placeholder="e.g. Hate speech or policy violation"
                        className="p-2.5 bg-[#111111] border border-white/5 rounded-xl text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] w-full"
                      />
                    </div>
                    <div className="flex gap-2 font-sans">
                      <button
                        onClick={() => setIsBanModalOpen(false)}
                        className="flex-1 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-400 hover:text-white"
                      >
                        Abort
                      </button>
                      <button
                        onClick={handleConfirmBan}
                        className="flex-1 py-2 rounded-xl bg-red-650 hover:bg-red-700 text-xs font-black uppercase text-white"
                      >
                        Confirm Ban
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. User Activity Modal */}
              {isActivityModalOpen && activityUser && (
                <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                  <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-2xl w-full max-h-[80vh] overflow-y-auto space-y-5 text-left font-sans">
                    <div className="flex justify-between items-center pb-3 border-b border-white/5">
                      <div>
                        <h3 className="text-xs font-black uppercase text-white tracking-widest font-mono">User Activity Journal</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5">Auditing profile action loops for @{activityUser.username}</p>
                      </div>
                      <button onClick={() => setIsActivityModalOpen(false)} className="p-1 px-2.5 bg-white/5 rounded-lg text-xs text-gray-400 hover:text-white">Close</button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-neutral-950 border border-white/5 rounded-2xl space-y-2">
                        <h4 className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest">Reviews Contributed</h4>
                        <div className="space-y-2 max-h-48 overflow-y-auto divide-y divide-white/5 pr-1 text-xs">
                          {reviewsList.filter(r => r.userId === activityUser.uid || r.username === activityUser.username).map(r => (
                            <div key={r.id} className="pt-2">
                              <div className="flex justify-between items-center text-[10px] text-gray-400 font-mono">
                                <span>Rating: {r.rating} ★</span>
                                <span>{new Date(r.createdAt).toLocaleDateString()}</span>
                              </div>
                              <p className="text-gray-300 italic max-w-sm font-sans mt-0.5">"{r.text}"</p>
                            </div>
                          ))}
                          {reviewsList.filter(r => r.userId === activityUser.uid || r.username === activityUser.username).length === 0 && (
                            <p className="text-[10px] text-neutral-600 font-mono pt-4">No reviews logged under this identity.</p>
                          )}
                        </div>
                      </div>

                      <div className="p-4 bg-neutral-950 border border-white/5 rounded-2xl space-y-2">
                        <h4 className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest">Comments & Replies</h4>
                        <div className="space-y-2 max-h-48 overflow-y-auto divide-y divide-white/5 pr-1 text-xs">
                          {getUnifiedCommentsList().filter(c => c.username === activityUser.username).map(c => (
                            <div key={c.id} className="pt-2">
                              <div className="flex justify-between items-center text-[10px] text-gray-400 font-mono">
                                <span className="text-xxs px-1 bg-white/5 text-gray-400 font-bold uppercase rounded">{c.context}</span>
                                <span>{new Date(c.createdAt).toLocaleDateString()}</span>
                              </div>
                              <p className="text-gray-300 italic max-w-sm font-sans mt-0.5">"{c.text}"</p>
                            </div>
                          ))}
                          {getUnifiedCommentsList().filter(c => c.username === activityUser.username).length === 0 && (
                            <p className="text-[10px] text-neutral-600 font-mono pt-4">No comments or space posts logged under this identity.</p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-white/5 flex justify-end">
                      <button
                        onClick={() => setIsActivityModalOpen(false)}
                        className="px-4 py-2 bg-neutral-900 border border-white/5 hover:bg-neutral-850 text-xs text-white font-bold uppercase rounded-xl"
                      >
                        Done Auditing
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 3. View Full Review Modal */}
              {isReviewModalOpen && selectedReviewForModal && (
                <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                  <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-md w-full space-y-4 text-left font-sans">
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <h3 className="text-xs font-black uppercase text-white tracking-widest font-mono">Review Details</h3>
                      <button onClick={() => setIsReviewModalOpen(false)} className="text-gray-400 hover:text-white text-xs font-bold">✕</button>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-white text-sm">Rating: {selectedReviewForModal.rating} ★</span>
                        <span className="text-[10px] text-gray-500 font-mono">{new Date(selectedReviewForModal.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-[10px] font-mono text-gray-400 uppercase">Author: @{selectedReviewForModal.username}</p>
                    </div>
                    <div className="p-4 bg-neutral-950 border border-white/5 rounded-xl">
                      <p className="text-xs text-gray-200 whitespace-pre-line font-sans leading-relaxed italic">
                        "{selectedReviewForModal.text}"
                      </p>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => setIsReviewModalOpen(false)}
                        className="px-4 py-2 bg-neutral-900 border border-white/5 hover:border-white/10 text-xs font-bold text-gray-400 hover:text-white rounded-xl"
                      >
                        Close
                      </button>
                      <button
                        onClick={() => {
                          handleTriggerDeleteReview(selectedReviewForModal);
                          setIsReviewModalOpen(false);
                        }}
                        className="px-4 py-2 bg-[#E50914] text-white text-xs font-black uppercase rounded-xl hover:bg-red-700"
                      >
                        Delete Review
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. Discussion Replies Modal */}
              {isDiscussionRepliesModalOpen && activeDiscussionForRepliesModal && (
                <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                  <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-xl w-full max-h-[75vh] overflow-y-auto space-y-4 text-left">
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <div>
                        <h3 className="text-xs font-black uppercase text-white tracking-widest font-mono">Discussion Reply Moderation</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5">Thread: "{activeDiscussionForRepliesModal.title}"</p>
                      </div>
                      <button onClick={() => setIsDiscussionRepliesModalOpen(false)} className="text-gray-400 hover:text-white text-xs">✕</button>
                    </div>

                    <div className="space-y-3 max-h-80 overflow-y-auto divide-y divide-white/5">
                      {discussionsReplies
                        .filter(r => r.targetId === activeDiscussionForRepliesModal.id && r.targetType === 'discussion')
                        .map(repl => (
                          <div key={repl.id} className="pt-2 text-xs flex justify-between gap-3 font-sans">
                            <div className="space-y-1 my-1">
                              <p className="text-gray-300">"{repl.text}"</p>
                              <span className="text-[10px] text-gray-500 font-mono block">By @{repl.authorUsername} • {new Date(repl.createdAt).toLocaleString()}</span>
                            </div>
                            <button
                              onClick={() => handleDeleteRepliesModalReply(repl.id)}
                              className="px-2 py-1 bg-red-950/20 hover:bg-[#E50914] text-red-500 hover:text-white h-fit self-center border border-red-500/10 rounded font-bold uppercase text-[9px]"
                            >
                              Prune
                            </button>
                          </div>
                        ))}

                      {discussionsReplies.filter(r => r.targetId === activeDiscussionForRepliesModal.id && r.targetType === 'discussion').length === 0 && (
                        <p className="text-xs text-neutral-600 font-mono py-6 text-center">No replies logged under this thread.</p>
                      )}
                    </div>

                    <div className="flex justify-end pt-2 border-t border-white/5">
                      <button
                        onClick={() => setIsDiscussionRepliesModalOpen(false)}
                        className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-xs text-white font-bold uppercase rounded-xl"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 5. View Reported Item Modal */}
              {viewedReportedItem && (
                <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                  <div className="bg-[#0e0e0e] border border-white/5 p-6 rounded-3xl max-w-md w-full space-y-4 text-left">
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <h3 className="text-xs font-black uppercase text-red-400 tracking-widest font-mono flex items-center gap-1 font-sans">
                        <AlertTriangle size={14} /> Audit Inspected Node
                      </h3>
                      <button onClick={() => setViewedReportedItem(null)} className="text-gray-400 hover:text-white text-xs font-bold">✕</button>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-500 font-mono uppercase block">Logged Sector: {viewedReportedItem.type}</span>
                      <p className="text-xs font-bold text-white leading-relaxed font-sans">Reported Item Plaintext:</p>
                    </div>
                    <div className="p-4 bg-neutral-950 border border-white/5 rounded-xl font-mono text-xs text-gray-300 leading-relaxed max-h-48 overflow-y-auto">
                      "{viewedReportedItem.reportedItemPreview}"
                    </div>
                    <div className="flex gap-2 font-sans">
                      <button
                        onClick={() => setViewedReportedItem(null)}
                        className="flex-1 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs font-bold text-gray-400 hover:text-white border border-white/5"
                      >
                        Back
                      </button>
                      <button
                        onClick={() => {
                          handleResolveReport(viewedReportedItem.id, viewedReportedItem.targetId, viewedReportedItem.type);
                          setViewedReportedItem(null);
                        }}
                        className="flex-1 py-2 rounded-xl bg-red-650 hover:bg-red-700 text-xs font-black uppercase text-white"
                      >
                        Purge & Clear
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* PHASE 9C Live Views */}
              {activeTab === 'push' && (
                <AdminPushNotifications usersCount={usersList.length} logMessage={logMessage} />
              )}
              {activeTab === 'ads' && (
                <AdminAds logMessage={logMessage} />
              )}
              {activeTab === 'ai-builder' && (
                <AdminGeminiBuilder onUseDraft={handleUseNewsDraft} logMessage={logMessage} />
              )}
              {activeTab === 'seo' && (
                <AdminSeoSettings logMessage={logMessage} />
              )}
              {activeTab === 'general' && (
                <AdminGeneralSettings showLandingPage={showLandingPage} onToggleLandingPage={onToggleLandingPage} logMessage={logMessage} />
              )}
              {activeTab === 'api-keys' && (
                <AdminApiKeys logMessage={logMessage} />
              )}
              {activeTab === 'rankings' && (
                <AdminRankings catalog={catalog} logMessage={logMessage} />
              )}

              {/* FALLBACK/PLACEHOLDER VIEWS FOR OFFLINE MODULE TABS */}
              {![ 'dashboard', 'content-mgmt', 'pending', 'tmdb-import', 'users-mgmt', 'verification-requests', 'reviews-mod', 'comments-mod', 'discussions-mod', 'reported', 'news', 'collections-mgmt', 'push', 'ads', 'ai-builder', 'seo', 'general', 'api-keys', 'rankings' ].includes(activeTab) && (
                <div className="py-16 text-center space-y-4 max-w-md mx-auto bg-[#0a0a0a] border border-white/5 rounded-3xl p-8 animate-fade-in">
                  <AlertTriangle className="mx-auto text-yellow-500 animate-pulse" size={36} />
                  <div>
                    <h3 className="text-xs font-black uppercase text-white tracking-widest font-mono">Module Scheduled</h3>
                    <p className="text-[10px] text-gray-500 font-sans mt-2 leading-relaxed font-sans">
                      Security authorization is configured, but implementation for <span className="text-[#E50914] font-bold font-mono">"{activeTab.toUpperCase()}"</span> is designated for ingestion in the subsequent construction phase (Phase 9C). Standard operational sandbox parameters remain ready.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="px-4 py-2 border border-white/5 hover:border-white/10 rounded-xl text-xxs font-bold uppercase tracking-wider text-gray-300 cursor-pointer"
                  >
                    Return to Operational Center
                  </button>
                </div>
              )}

            </div>
          )}

        </div>
      </main>
    </div>
  );
}
