import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Sparkles, 
  Bell, 
  Menu, 
  Heart, 
  MessageSquare, 
  MessageCircle, 
  UserPlus, 
  Flame, 
  Calendar, 
  TrendingUp, 
  BadgeCheck, 
  CheckCheck,
  Zap,
  Info
} from 'lucide-react';
import { AppRoute, MuvioNotification } from '../types';
import { getNotifications, markAllNotificationsAsRead, markNotificationAsRead } from '../lib/userInteractions';
import { UserProfile } from '../lib/firebase';

interface HeaderProps {
  onOpenMenu: () => void;
  onNavigate: (route: AppRoute) => void;
  activePath: string;
  currentUser: UserProfile | null;
  onOpenSearch: () => void;
  onOpenAIChat: () => void;
}

export default function Header({ onOpenMenu, onNavigate, activePath, currentUser, onOpenSearch, onOpenAIChat }: HeaderProps) {
  const [notifsOpen, setNotifsOpen] = useState(false);
  const [notifications, setNotifications] = useState<MuvioNotification[]>([]);
  const notifDropdownRef = useRef<HTMLDivElement>(null);

  // Load and subscribe/poll notifications
  useEffect(() => {
    if (!currentUser) {
      setNotifications([]);
      return;
    }

    const load = async () => {
      try {
        const list = await getNotifications(currentUser.uid);
        
        // Seed default notification if list is empty to make it look glorious
        if (list.length === 0) {
          const defaultItems: MuvioNotification[] = [
            {
              id: 'seed-notif-1',
              recipientId: currentUser.uid,
              senderId: 'muvio_official',
              senderName: 'Muvio Official',
              type: 'TRENDING_CONTENT',
              targetId: 'movie-101',
              mediaId: 'movie-101',
              text: 'Welcome to Muvio! Dunes: Part Three is officially catalogued inside the Schedule Pipeline. Mark interest to keep tracking.',
              read: false,
              createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString() // 15 mins ago
            },
            {
              id: 'seed-notif-2',
              recipientId: currentUser.uid,
              senderId: 'lucas_fan',
              senderName: 'Lucas_Critic',
              type: 'NEW_FOLLOWER',
              targetId: 'lucas_fan',
              mediaId: '',
              text: 'is now participating in your cinema reviews timeline.',
              read: false,
              createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString() // 2 hours ago
            }
          ];
          setNotifications(defaultItems);
          
          // Write to local cache for consistency
          const key = `muvio_notifications_${currentUser.uid}`;
          localStorage.setItem(key, JSON.stringify(defaultItems));
        } else {
          setNotifications(list);
        }
      } catch (err) {
        console.warn('Notifications retrieval failed: ', err);
      }
    };

    load();

    // Poll every 12 seconds for real-time notification drops
    const pid = setInterval(load, 12000);
    return () => clearInterval(pid);
  }, [currentUser, notifsOpen]);

  // Click outside to dismiss notifications dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notifDropdownRef.current && !notifDropdownRef.current.contains(event.target as Node)) {
        setNotifsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAllRead = async () => {
    if (!currentUser) return;
    await markAllNotificationsAsRead(currentUser.uid);
    const updated = notifications.map(n => ({ ...n, read: true }));
    setNotifications(updated);
  };

  const handleNotifClick = async (notif: MuvioNotification) => {
    if (!currentUser) return;
    setNotifsOpen(false);
    
    // Mark as read
    await markNotificationAsRead(currentUser.uid, notif.id);
    setNotifications(notifications.map(n => n.id === notif.id ? { ...n, read: true } : n));

    // Handle navigation based on type
    if (notif.mediaId) {
      onNavigate(`/content/${notif.mediaId}`);
    } else if (notif.type === 'NEW_FOLLOWER') {
      onNavigate(`/profile`);
    } else if (notif.targetId && notif.targetId.startsWith('post_')) {
      onNavigate(`/spaces`); // maps to spaces
    } else {
      onNavigate(`/explore`);
    }
  };

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'LIKE_REVIEW':
        return <Heart size={14} className="text-red-500 fill-red-500" />;
      case 'COMMENT_REVIEW':
        return <MessageSquare size={14} className="text-emerald-400" />;
      case 'REPLY_COMMENT':
      case 'DISCUSSION_REPLY':
      case 'SPACES_REPLY':
        return <MessageCircle size={14} className="text-blue-400" />;
      case 'NEW_FOLLOWER':
        return <UserPlus size={14} className="text-pink-400" />;
      case 'CONTENT_RELEASE':
      case 'RELEASE_REMINDER':
        return <Flame size={14} className="text-orange-500 fill-orange-500 animate-pulse" />;
      case 'TRENDING_CONTENT':
        return <TrendingUp size={14} className="text-yellow-400" />;
      default:
        return <Zap size={14} className="text-red-500" />;
    }
  };

  const getRelativeTime = (isoString: string) => {
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24) return `${hrs}h ago`;
      const days = Math.floor(hrs / 24);
      return `${days}d ago`;
    } catch {
      return 'Recent';
    }
  };

  const usePathname = () => activePath;
  const pathname = usePathname();
  const hideNav = ['/', '/login', '/register', '/forgot-password'].includes(pathname);

  if (hideNav) return null;

  return (
    <header className="sticky top-0 z-50 w-full h-20 px-6 md:px-10 flex items-center justify-between bg-[#0a0a0a]/60 backdrop-blur-xl border-b border-white/5 transition-all select-none">
      {/* Left: Logo */}
      <div 
        onClick={() => {
          if (pathname === '/' || pathname === '/landing') {
            // Stay on the page (no navigation)
          } else {
            onNavigate('/explore');
          }
        }}
        className="cursor-pointer flex items-center gap-2.5 group select-none"
        id="muvio-logo-container"
      >
        <span className="font-display font-black tracking-tighter text-3xl text-[#E50914] italic transition-all group-hover:text-[#FF1A1A] drop-shadow-[0_0_15px_rgba(229,9,20,0.4)]">
          MUVIO
        </span>
        <span className="text-[8px] uppercase font-mono font-black tracking-widest px-1.5 py-0.5 bg-[#E50914]/12 text-[#E50914] border border-[#E50914]/20 rounded-md">
          PRE-BETA
        </span>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 sm:gap-4 relative" id="header-actions-group">
        {/* Search button */}
        <button 
          onClick={onOpenSearch}
          className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 active:scale-95 transition-all outline-none cursor-pointer"
          title="Search movies & TV series"
          id="btn-search-trigger"
        >
          <Search size={22} className="stroke-[2]" />
        </button>

        {/* AI Chat button with Pulse Glow */}
        <button 
          onClick={onOpenAIChat}
          className="p-2 bg-[#E50914]/10 hover:bg-[#E50914]/20 text-[#E50914] rounded-lg border border-[#E50914]/20 hover:border-[#E50914]/40 relative group active:scale-95 transition-all outline-none cursor-pointer"
          title="Ask Muvio AI Assistant"
          id="btn-ai-assistant-trigger"
        >
          <Sparkles size={20} className="stroke-[2] animate-glow-pulse" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#E50914] box-shadow"></span>
        </button>

        {/* Notification bell container */}
        <div className="relative" ref={notifDropdownRef}>
          <button 
            onClick={() => { if (currentUser) setNotifsOpen(!notifsOpen); }}
            className={`p-2 rounded-lg relative active:scale-95 transition-all outline-none cursor-pointer ${
              notifsOpen ? 'text-white bg-white/5' : 'text-gray-400 hover:text-white'
            }`}
            title="Notifications"
            id="btn-notifications-trigger"
          >
            <Bell size={22} className="stroke-[2]" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 rounded-full bg-[#E50914] border border-[#000000] text-[9px] font-mono font-black text-white flex items-center justify-center animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>

          {/* NOTIFICATION FLIP-DROP ELEMENT */}
          {notifsOpen && (
            <div 
              className="absolute right-0 mt-3 w-80 md:w-88 bg-[#0b0b0b] border border-white/5 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-left z-50 animate-slide-in-top"
              id="notifications-dropdown-panel"
            >
              {/* Drop Header */}
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                  <span className="text-2xs font-mono font-black uppercase text-white tracking-wider">
                    Inbox Notifications
                  </span>
                </div>
                {unreadCount > 0 && (
                  <button 
                    onClick={handleMarkAllRead}
                    className="text-[9px] font-mono font-black uppercase tracking-wider text-red-500 hover:text-white cursor-pointer select-none"
                  >
                    Mark All Read
                  </button>
                )}
              </div>

              {/* Items listing */}
              <div className="max-h-72 overflow-y-auto min-h-24">
                {notifications.length === 0 ? (
                  <div className="py-8 text-center text-gray-500 space-y-2">
                    <Info size={16} className="mx-auto text-gray-600 block" />
                    <span className="text-3xs uppercase font-mono font-black tracking-widest block">Clean Slate Inbox</span>
                  </div>
                ) : (
                  <div className="divide-y divide-white/2">
                    {notifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => handleNotifClick(notif)}
                        className={`p-3.5 flex gap-3 cursor-pointer hover:bg-white/2 transition-all relative ${
                          !notif.read ? 'bg-red-950/4' : 'opacity-80'
                        }`}
                      >
                        {/* Dot indicator */}
                        {!notif.read && (
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-red-600"></span>
                        )}

                        {/* Icon circle */}
                        <div className="w-7 h-7 rounded-lg bg-neutral-900 border border-white/5 flex items-center justify-center shrink-0">
                          {getNotifIcon(notif.type)}
                        </div>

                        {/* Message body */}
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <p className="text-xxs text-gray-400 font-sans leading-normal pr-1 line-clamp-3">
                            <span className="inline-flex items-center gap-0.5 mr-1">
                              <strong className="text-white font-mono font-black">{notif.senderName}</strong>
                              {notif.senderName === 'ADMIN' && (
                                <span className="inline-flex items-center justify-center bg-blue-500 text-white rounded-full w-3.5 h-3.5 shrink-0" title="Verified">
                                  <svg className="w-2 h-2 fill-current text-white" viewBox="0 0 24 24">
                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                                  </svg>
                                </span>
                              )}
                            </span>
                            {notif.text}
                          </p>
                          <span className="text-[8px] font-mono text-gray-600 block">
                            {getRelativeTime(notif.createdAt)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Drop Footer */}
              <div className="p-2.5 bg-neutral-950 border-t border-white/5 text-center">
                <span className="text-[8px] font-mono font-black text-gray-500 uppercase tracking-widest block">
                  Muvio Push Security Encrypted
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Vertical divider */}
        <div className="w-[1px] h-6 bg-white/10 hidden sm:block"></div>

        {/* Hamburger Menu trigger */}
        <button 
          onClick={onOpenMenu}
          className="p-2 text-gray-300 hover:text-white rounded-lg hover:bg-white/5 active:scale-95 transition-all bg-[#111111] border border-white/5 outline-none font-medium text-sm flex items-center gap-1.5 cursor-pointer"
          id="btn-drawer-hamburger"
        >
          <Menu size={20} className="stroke-[2.25]" />
          <span className="hidden sm:inline text-xs font-semibold tracking-wider uppercase text-gray-400">Menu</span>
        </button>
      </div>
    </header>
  );
}
