import React from 'react';
import { motion } from 'motion/react';
import { Film, Sparkles, Tv, Users, Heart } from 'lucide-react';
import { AppRoute } from '../types';

interface LandingPageProps {
  onExplore: () => void;
  showLandingPageSetting: boolean;
}

export default function LandingPage({ onExplore, showLandingPageSetting }: LandingPageProps) {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center relative px-4 py-8 md:py-16 text-center overflow-hidden-y" id="landing-page-container">
      {/* Immersive UI decorative background elements */}
      <div className="absolute -top-20 left-1/4 w-[400px] h-[400px] bg-[#E50914]/5 blur-[120px] rounded-full pointer-events-none"></div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="w-full max-w-4xl mx-auto relative z-10 select-none flex flex-col items-center px-4 sm:px-8 md:px-12 py-8 bg-[#0a0a0a]/40 border border-white/5 md:border-transparent rounded-3xl"
      >
        {/* 1. MUVIO logo + PRE-BETA badge (top of card, centered and fully responsive) */}
        <div className="flex items-center justify-center gap-2.5 mb-6 select-none animate-fade-in" id="landing-logo-container">
          <span className="font-display font-black tracking-tighter text-2xl md:text-3xl lg:text-4xl text-[#E50914] italic transition-all hover:text-[#FF1A1A] drop-shadow-[0_0_15px_rgba(229,9,20,0.4)]">
            MUVIO
          </span>
          <span className="text-[8px] uppercase font-mono font-black tracking-widest px-1.5 py-0.5 bg-[#E50914]/12 text-[#E50914] border border-[#E50914]/20 rounded-md">
            PRE-BETA
          </span>
        </div>

        {/* 2. Sparkle badge from Immersive UI / The Future of Streaming pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#E50914]/30 bg-[#E50914]/5 mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E50914] animate-pulse"></span>
          <span className="text-[10px] font-bold tracking-[0.2em] text-[#E50914] uppercase font-mono">
            The Future of Streaming
          </span>
        </div>

        {/* 3. Cinematic Header Text with White-to-Transparent Gradient */}
        <div className="space-y-4 w-full">
          <h1 className="font-display font-black text-3xl sm:text-5xl md:text-[84px] leading-[0.95] md:leading-[0.9] tracking-tight text-white mb-6">
            DISCOVER<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-white/30 drop-shadow-[0_0_30px_rgba(255,255,255,0.05)]">
              YOUR NEXT OBSESSION
            </span>
          </h1>
          <p className="text-white/40 text-xs sm:text-sm md:text-base lg:text-lg max-w-2xl mx-auto mb-8 md:mb-10 leading-relaxed font-sans">
            Access the world's most comprehensive movie & TV database. Real-time schedules, community spaces, and AI-powered recommendations in one cinematic dashboard.
          </p>
        </div>

        {/* 4. Feature Grid highlights (Single column on mobile, 2x2 grid on tablet & desktop) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2 w-full max-w-2xl mx-auto text-left mb-8 md:mb-10" id="landing-highlights-grid">
          <div className="p-4 bg-[#111111]/40 border border-white/5 rounded-xl flex items-center gap-3 hover:border-white/10 transition-colors">
            <div className="p-1 px-1.5 rounded bg-[#E50914]/10 border border-[#E50914]/20"><Film size={14} className="text-[#E50914]" /></div>
            <span className="text-xs font-bold text-gray-300">Infinite Database</span>
          </div>
          <div className="p-4 bg-[#111111]/40 border border-white/5 rounded-xl flex items-center gap-3 hover:border-white/10 transition-colors">
            <div className="p-1 px-1.5 rounded bg-[#E50914]/10 border border-[#E50914]/20"><Users size={14} className="text-[#E50914]" /></div>
            <span className="text-xs font-bold text-gray-300">Interactive Spaces</span>
          </div>
          <div className="p-4 bg-[#111111]/40 border border-white/5 rounded-xl flex items-center gap-3 hover:border-white/10 transition-colors">
            <div className="p-1 px-1.5 rounded bg-[#E50914]/10 border border-[#E50914]/20"><Heart size={14} className="text-[#E50914]" /></div>
            <span className="text-xs font-bold text-gray-300">Curated Folders</span>
          </div>
          <div className="p-4 bg-[#111111]/40 border border-white/5 rounded-xl flex items-center gap-3 hover:border-white/10 transition-colors">
            <div className="p-1 px-1.5 rounded bg-[#E50914]/10 border border-[#E50914]/20"><Sparkles size={14} className="text-[#E50914]" /></div>
            <span className="text-xs font-bold text-gray-300">Muvio AI Copilot</span>
          </div>
        </div>

        {/* 5. Begin Exploration Button */}
        <div className="pt-2 flex justify-center w-full">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onExplore}
            className="group cursor-pointer px-10 md:px-12 py-4 bg-[#E50914] hover:bg-[#FF1A1A] text-white font-bold rounded-full shadow-[0_0_30px_rgba(229,9,20,0.3)] transition-all flex items-center gap-3 outline-none"
            id="btn-begin-exploration"
          >
            <span>Begin Exploration</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:translate-x-1.5 transition-transform duration-300">
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
