import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Tv, FolderHeart, User, Eye, Sparkles } from 'lucide-react';

interface PlaceholderPageProps {
  title: string;
  description: string;
  iconName: 'Calendar' | 'Tv' | 'FolderHeart' | 'User';
}

export default function PlaceholderPage({ title, description, iconName }: PlaceholderPageProps) {
  const getIcon = () => {
    switch (iconName) {
      case 'Calendar':
        return <Calendar size={48} className="text-[#E50914] crimson-glow" />;
      case 'Tv':
        return <Tv size={48} className="text-[#E50914] crimson-glow" />;
      case 'FolderHeart':
        return <FolderHeart size={48} className="text-[#E50914] crimson-glow" />;
      case 'User':
        return <User size={48} className="text-[#E50914] crimson-glow" />;
    }
  };

  return (
    <div className="flex flex-col items-center justify-center py-20 px-4 text-center select-none" id={`placeholder-page-${title.toLowerCase()}`}>
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md bg-[#111111] p-8 md:p-10 rounded-2xl border border-white/5 shadow-2xl relative overflow-hidden box-glow"
      >
        {/* Background glow overlay */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#E50914] opacity-10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Cinematic ambient borders */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#E50914]/45 to-transparent"></div>

        {/* Icon wrapper */}
        <div className="w-20 h-20 mx-auto rounded-full bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center mb-6 relative">
          {getIcon()}
          
          {/* Subtle micro sparkling particles */}
          <div className="absolute -top-1 -right-1">
            <Sparkles size={14} className="text-[#E50914] animate-pulse" />
          </div>
        </div>

        {/* Heading */}
        <h1 className="font-display text-2xl font-black text-white tracking-tight uppercase" id={`placeholder-heading-${title.toLowerCase()}`}>
          {title}
        </h1>

        {/* Status indicator badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E50914]/10 border border-[#E50914]/15 mt-3 text-[10px] font-mono text-[#E50914] uppercase tracking-widest font-black">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E50914] animate-ping"></span>
          PHASE 1 FOUNDATION
        </div>

        {/* Description text */}
        <p className="text-gray-400 text-sm mt-5 leading-relaxed font-sans font-medium">
          {description}
        </p>

        {/* Horizontal separator */}
        <div className="w-12 h-[1.5px] bg-[#E50914]/40 mx-auto my-6"></div>

        {/* Call to action element */}
        <div className="flex items-center justify-center gap-2 text-xs font-mono font-bold text-gray-500 uppercase tracking-widest">
          <Eye size={12} className="text-[#E50914]" />
          <span>Layout Tested Successfully</span>
        </div>
      </motion.div>
    </div>
  );
}
