import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  User, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Loader2 
} from 'lucide-react';
import { 
  registerWithEmail, 
  checkUsernameAvailable, 
  triggerToast 
} from '../lib/firebase';
import { AppRoute } from '../types';

interface RegisterPageProps {
  onNavigate: (route: AppRoute) => void;
}

type PasswordStrength = 'empty' | 'weak' | 'medium' | 'strong' | 'crimson-elite';

export default function RegisterPage({ onNavigate }: RegisterPageProps) {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isRegistrationSealed, setIsRegistrationSealed] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  // Real-time username query states
  const [usernameLoading, setUsernameLoading] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const usernameDebounceRef = useRef<any>(null);

  // Load General Settings Config
  useEffect(() => {
    const raw = localStorage.getItem('muvio_general_settings');
    if (raw) {
      try {
        const config = JSON.parse(raw);
        if (config.authMethods && config.authMethods.registration_enabled === false) {
          setIsRegistrationSealed(true);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  // Real-time Username validator triggering
  useEffect(() => {
    // Reset state if too short
    const cleanUser = username.trim();
    if (cleanUser.length < 3) {
      setUsernameAvailable(null);
      return;
    }

    // Alphanumeric character validations
    if (!/^[a-zA-Z0-9_]+$/.test(cleanUser)) {
      setUsernameAvailable(false);
      return;
    }

    if (usernameDebounceRef.current) {
      clearTimeout(usernameDebounceRef.current);
    }

    setUsernameLoading(true);
    usernameDebounceRef.current = setTimeout(async () => {
      try {
        const available = await checkUsernameAvailable(cleanUser);
        setUsernameAvailable(available);
      } catch {
        setUsernameAvailable(true); // Fallback friendly sandbox assumption
      } finally {
        setUsernameLoading(false);
      }
    }, 450);

    return () => {
      if (usernameDebounceRef.current) clearTimeout(usernameDebounceRef.current);
    };
  }, [username]);

  // Decipher Password strength calculation
  const getPasswordStrength = (): PasswordStrength => {
    if (!password) return 'empty';
    const len = password.length;
    const hasNumbers = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    const hasUpper = /[A-Z]/.test(password);

    if (len >= 8 && hasNumbers && hasSpecial && hasUpper) {
      return 'crimson-elite';
    }
    if (len >= 6 && (hasNumbers || hasSpecial)) {
      return 'strong';
    }
    if (len >= 6) {
      return 'medium';
    }
    return 'weak';
  };

  const strength = getPasswordStrength();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!name || !username || !email || !password) {
      setErrorMessage('Please completely fill in all secret credential parameters.');
      return;
    }

    if (username.trim().length < 3) {
      setErrorMessage('Username must be at least 3 characters.');
      return;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username.trim())) {
      setErrorMessage('Username contains forbidden characters. Only letters, digits and underscores permitted.');
      return;
    }

    if (usernameAvailable === false) {
      setErrorMessage('The chosen cinematic handle is already reserved by another member.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Private password passcode must consist of at least 6 characters.');
      return;
    }

    if (!termsAccepted) {
      setErrorMessage('Review and endorse our Master Terms & Watch Protocols to join.');
      return;
    }

    setLoading(true);
    try {
      await registerWithEmail(name, username, email, password);
      onNavigate('/explore');
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred during registry processing.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#0c0c0c]/90 border border-white/5 rounded-3xl p-6 md:p-8 relative select-none shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden" id="register-container">
      {/* Red ambient banner overlay */}
      <div className="absolute top-0 inset-x-0 h-[3px] bg-gradient-to-r from-transparent via-[#E50914] to-transparent"></div>

      {/* Hero Header */}
      <div className="text-center mb-8 space-y-2">
        <h2 className="font-display font-black text-3xl tracking-tighter text-[#E50914] italic crimson-glow hover:scale-[1.01] transition-all">
          MUVIO
        </h2>
        <p className="text-[10px] font-black tracking-[0.25em] text-white/40 uppercase font-mono">
          JOIN PRE-BETA VAULTS
        </p>
      </div>

      {/* Error Displays */}
      {errorMessage && (
        <motion.div 
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 mb-6 bg-[#E50914]/10 border border-[#E50914]/20 rounded-xl flex items-start gap-2.5 text-xs text-[#FF3333] font-medium"
          id="register-error-banner"
        >
          <AlertCircle size={16} className="mt-0.5 shrink-0" />
          <span>{errorMessage}</span>
        </motion.div>
      )}

      {/* Submission Form */}
      {isRegistrationSealed ? (
        <div className="py-12 px-4 text-center space-y-6" id="registration-sealed-notice">
          <div className="w-16 h-16 bg-red-600/10 border border-red-600/20 text-[#E50914] rounded-full flex items-center justify-center mx-auto animate-pulse">
            <Lock size={26} />
          </div>
          <div className="space-y-2">
            <h3 className="font-mono text-xs font-black uppercase text-white tracking-widest">REGISTRATION PROTOCOL LOCKED</h3>
            <p className="text-2xs font-sans text-gray-400 leading-relaxed max-w-xs mx-auto">
              Master administration orders have sealed the registry vault gate. New cinematic memberships are currently restricted to private invitation credentials.
            </p>
          </div>
          <button
            onClick={() => onNavigate('/explore')}
            className="px-6 py-3 bg-neutral-900 border border-white/5 hover:border-white/10 text-[10px] font-mono tracking-wider font-bold rounded-xl text-white hover:text-red-500 transition-all cursor-pointer"
          >
            RETURN TO CATALOGUE
          </button>
        </div>
      ) : (
        <form onSubmit={handleRegister} className="space-y-4" id="register-email-form">
        <div className="space-y-1">
          <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Full Name</label>
          <div className="relative">
            <User size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
            <input
              type="text"
              required
              disabled={loading}
              placeholder="Sylvester Stallone"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
            />
          </div>
        </div>

        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Unique Username Handle</label>
            {username.trim().length >= 3 && (
              <div className="flex items-center gap-1">
                {usernameLoading ? (
                  <Loader2 size={10} className="animate-spin text-white/20" />
                ) : usernameAvailable === true ? (
                  <span className="text-[9px] font-bold text-[#22C55E] flex items-center gap-1 bg-[#22C55E]/10 px-1.5 py-0.5 rounded-full">
                    <CheckCircle2 size={10} /> Available
                  </span>
                ) : usernameAvailable === false ? (
                  <span className="text-[9px] font-bold text-[#EF4444] flex items-center gap-1 bg-[#EF4444]/10 px-1.5 py-0.5 rounded-full">
                    <XCircle size={10} /> Reserved
                  </span>
                ) : null}
              </div>
            )}
          </div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-white/20">@</span>
            <input
              type="text"
              required
              disabled={loading}
              placeholder="rocky_balboa"
              value={username}
              onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
              className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-8 pr-4 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors font-mono"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Master Email Address</label>
          <div className="relative">
            <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
            <input
              type="email"
              required
              disabled={loading}
              placeholder="rocky@muvio.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Private Password Passcode</label>
          <div className="relative">
            <Lock size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
            <input
              type={showPassword ? 'text' : 'password'}
              required
              disabled={loading}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-10 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/40 transition-colors cursor-pointer"
            >
              {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>

          {/* Password strength indicator bars */}
          {password && (
            <div className="pt-1.5 space-y-1">
              <div className="grid grid-cols-4 gap-1">
                <div className={`h-1 rounded-sm transition-all ${strength !== 'empty' ? 'bg-[#EF4444]' : 'bg-white/5'}`}></div>
                <div className={`h-1 rounded-sm transition-all ${strength === 'medium' || strength === 'strong' || strength === 'crimson-elite' ? 'bg-orange-500' : 'bg-white/5'}`}></div>
                <div className={`h-1 rounded-sm transition-all ${strength === 'strong' || strength === 'crimson-elite' ? 'bg-yellow-500' : 'bg-white/5'}`}></div>
                <div className={`h-1 rounded-sm transition-all ${strength === 'crimson-elite' ? 'bg-[#22C55E]' : 'bg-white/5'}`}></div>
              </div>
              <div className="flex justify-between items-center text-[8px] font-mono font-black uppercase text-white/30">
                <span>Passcode strength</span>
                <span className={`font-bold ${
                  strength === 'crimson-elite' ? 'text-[#22C55E]' :
                  strength === 'strong' ? 'text-yellow-500' :
                  strength === 'medium' ? 'text-orange-500' : 'text-[#EF4444]'
                }`}>
                  {strength === 'crimson-elite' ? 'Elite Secure' :
                   strength === 'strong' ? 'Satisfactory' :
                   strength === 'medium' ? 'Moderate' : 'Too weak'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Terms checkbox */}
        <div className="flex items-start gap-2.5 pt-2">
          <input
            id="terms-checkbox"
            type="checkbox"
            checked={termsAccepted}
            onChange={(e) => setTermsAccepted(e.target.checked)}
            className="w-4 h-4 rounded border-white/10 bg-[#111111] text-[#E50914] focus:ring-0 focus:ring-offset-0 mt-0.5 cursor-pointer accent-[#E50914]"
          />
          <label htmlFor="terms-checkbox" className="text-[10px] text-white/40 leading-relaxed cursor-pointer font-sans select-none">
            I certify that my profile inputs are correct. I agree to comply with the <span className="text-white/60 font-bold underline">Muvio Code Of Cinema</span> and protocol rules.
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading || (username.trim().length >= 3 && usernameAvailable === false)}
          className="w-full bg-[#E50914] hover:bg-[#FF1A1A] disabled:bg-[#4d0c10] text-white font-bold text-xs py-3.5 rounded-xl shadow-[0_4px_16px_rgba(229,9,20,0.25)] transition-all flex items-center justify-center gap-2 cursor-pointer mt-6"
          id="btn-register-submit"
        >
          {loading ? (
            <>
              <Loader2 size={14} className="animate-spin" />
              <span>Registering Cinema Seal...</span>
            </>
          ) : (
            <>
              <span>CREATE ACCOUNT</span>
              <ArrowRight size={14} />
            </>
          )}
        </button>
      </form>
      )}

      {/* Login Navigation Switcher */}
      <div className="text-center mt-8 pt-6 border-t border-white/5">
        <button
          onClick={() => onNavigate('/login')}
          className="text-xs text-white/40 hover:text-white transition-colors cursor-pointer inline-flex items-center gap-1.5 font-sans"
          id="link-nav-login"
        >
          <span>Retaining credentials?</span>
          <span className="font-bold text-[#E50914] hover:underline">Access Master Portal</span>
        </button>
      </div>
    </div>
  );
}
