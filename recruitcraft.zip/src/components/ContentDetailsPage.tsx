import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Play, 
  Check, 
  Plus, 
  Share2, 
  MessageSquare, 
  Sparkles, 
  Clock, 
  Calendar,
  ThumbsUp,
  Flame,
  Star,
  ChevronLeft,
  ChevronRight,
  Film,
  Globe,
  Languages,
  AlertTriangle,
  Eye,
  FolderPlus,
  X,
  FolderHeart,
  Lock
} from 'lucide-react';
import { getRichMediaDetails, RichMediaDetails, getFallbackRichDetails, searchCatalog, generateSlug } from '../lib/tmdb';
import { getAdminCatalog, getCustomDetailsBySlug } from '../lib/adminCatalog';
import { AppRoute } from '../types';
import AdSlot from './AdSlot';
import { subscribeToAuth, triggerToast, UserProfile, getSettingValue, isFirebaseConfigured, db } from '../lib/firebase';
import { 
  getWatchedStatus, 
  toggleWatchedStatus, 
  getUserCollections, 
  createCollection, 
  updateCollectionItems 
} from '../lib/userInteractions';
import MediaReviewsSection from './MediaReviewsSection';

const PlatformLogo = ({ platformName, domain }: { platformName: string; domain?: string }) => {
  const [sourceIndex, setSourceIndex] = useState(0);

  const cleanDomain = domain?.trim() || '';

  if (!cleanDomain || sourceIndex > 2) {
    return (
      <div className="w-8 h-8 rounded-full bg-[#E50914] flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(229,9,20,0.3)]">
        <span className="text-white font-black text-xs font-mono uppercase">{platformName.charAt(0)}</span>
      </div>
    );
  }

  const sources = [
    `https://logo.clearbit.com/${cleanDomain}`,
    `https://www.google.com/s2/favicons?domain=${cleanDomain}&sz=64`,
    `https://icons.duckduckgo.com/ip3/${cleanDomain}.ico`
  ];

  return (
    <img
      src={sources[sourceIndex]}
      alt={`${platformName} Logo`}
      onError={() => setSourceIndex((prev) => prev + 1)}
      referrerPolicy="no-referrer"
      className="w-8 h-8 rounded-lg object-contain bg-white/5 p-1 shrink-0"
    />
  );
};

interface ContentDetailsPageProps {
  slug: string;
  onNavigate: (route: AppRoute) => void;
}

export default function ContentDetailsPage({ slug, onNavigate }: ContentDetailsPageProps) {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [details, setDetails] = useState<RichMediaDetails | null>(null);

  // Gemini Phase 8 AI States
  const [aiTags, setAiTags] = useState<string[]>([]);
  const [aiRecommendations, setAiRecommendations] = useState<any[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(false);

  // Vibe Chart State
  const [vibeData, setVibeData] = useState<{
    vibes: { label: string; value: number; color: string; desc: string }[];
    profile: string;
  } | null>(null);
  const [vibeLoading, setVibeLoading] = useState(false);
  
  // Interactive Component States
  const [isWatched, setIsWatched] = useState(false);
  const [watchedLoading, setWatchedLoading] = useState(false);
  const [isInterested, setIsInterested] = useState(false);
  
  // Modal control triggers
  const [showTrailer, setShowTrailer] = useState(false);
  const [showCollectionModal, setShowCollectionModal] = useState(false);
  const [showBrokenLinkModal, setShowBrokenLinkModal] = useState(false);
  const [showIncorrectModal, setShowIncorrectModal] = useState(false);
  const [showAuthPromptModal, setShowAuthPromptModal] = useState(false);

  // Custom Collection Operations States
  const [collections, setCollections] = useState<any[]>([]);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [collectionSaving, setCollectionSaving] = useState(false);

  // Broken Link Feedback states
  const [selectedLinkPlatform, setSelectedLinkPlatform] = useState('Netflix');
  const [brokenLinkDetail, setBrokenLinkDetail] = useState('');
  
  // Incorrect Meta feedback states
  const [incorrectType, setIncorrectType] = useState('Metadata');
  const [incorrectDetail, setIncorrectDetail] = useState('');

  // Secure fan debates thread details
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<Array<{ id: string; user: string; text: string; date: string }>>([]);
  const [newsItems, setNewsItems] = useState<Array<{ id: string; title: string; source: string; date: string; snippet: string; content?: string }>>([]);
  const [selectedNews, setSelectedNews] = useState<{title: string; source: string; date: string; snippet: string; content?: string} | null>(null);

  // Similar items local interests state tracking map
  const [similarInterestsMap, setSimilarInterestsMap] = useState<Record<string, boolean>>({});

  // Download Section state variables & modal control
  const [selectedDownloadQuality, setSelectedDownloadQuality] = useState<string | null>(null);
  const [selectedDownloadSize, setSelectedDownloadSize] = useState<string | null>(null);
  const [downloadModalOpen, setDownloadModalOpen] = useState<boolean>(false);
  const [downloadCountdown, setDownloadCountdown] = useState<number>(5);
  const [isDownloadReady, setIsDownloadReady] = useState<boolean>(false);

  // Online Streaming states
  const [activeStreamUrlOrEmbed, setActiveStreamUrlOrEmbed] = useState<string | null>(null);
  const [activePlatformName, setActivePlatformName] = useState<string | null>(null);
  const [selectedSeasonNumber, setSelectedSeasonNumber] = useState<number | null>(null);
  const [selectedEpisodeNumber, setSelectedEpisodeNumber] = useState<number | null>(null);
  const [episodePlatformsPopup, setEpisodePlatformsPopup] = useState<any[] | null>(null);

  // Helper to fetch timer setting
  const getDownloadTimerDuration = (): number => {
    try {
      const raw = localStorage.getItem('muvio_general_settings');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (typeof parsed.downloadTimerDuration === 'number') {
          return parsed.downloadTimerDuration;
        }
      }
    } catch (e) {
      // safe fallback
    }
    return 5; // default 5 seconds
  };

  useEffect(() => {
    if (!downloadModalOpen) return;
    
    const initialDuration = getDownloadTimerDuration();
    setDownloadCountdown(initialDuration);
    setIsDownloadReady(false);

    const startTime = Date.now();
    const endTime = startTime + initialDuration * 1000;

    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.round((endTime - Date.now()) / 1000));
      setDownloadCountdown(remaining);
      if (remaining <= 0) {
        setIsDownloadReady(true);
        clearInterval(interval);
      }
    }, 200);

    return () => clearInterval(interval);
  }, [downloadModalOpen]);

  useEffect(() => {
    if (details?.ticketLinks && details.ticketLinks.length > 0) {
      setSelectedLinkPlatform(details.ticketLinks[0].platform);
    }
  }, [details]);

  const handleDownloadClick = (qualityLabel: string, size: string) => {
    if (!currentUser) {
      setShowAuthPromptModal(true);
      return;
    }
    setSelectedDownloadQuality(qualityLabel);
    setSelectedDownloadSize(size);
    setDownloadModalOpen(true);
  };

  const getSelectedDownloadUrl = (): string => {
    if (!details?.downloads || !selectedDownloadQuality) return '#';
    const found = details.downloads.find(d => d.quality.toUpperCase() === selectedDownloadQuality.toUpperCase());
    return found?.url || '#';
  };

  // Horizontal Scrollers Refs
  const productionRef = useRef<HTMLDivElement>(null);
  const castRef = useRef<HTMLDivElement>(null);
  const crewRef = useRef<HTMLDivElement>(null);

  // Subscribe to auth state updates
  useEffect(() => {
    const unsubscribe = subscribeToAuth((state) => {
      setCurrentUser(state.user);
    });
    return () => unsubscribe();
  }, []);

  // Sync TMDB rich content details on load
  useEffect(() => {
    const match = slug.match(/^(movie|tv|show|anime)-(\d+)$/i);
    let tmdbType: 'movie' | 'tv' = 'movie';
    let tmdbId = 0;

    if (match) {
      const typeStr = match[1].toLowerCase();
      tmdbType = (typeStr === 'movie') ? 'movie' : 'tv';
      tmdbId = parseInt(match[2], 10);
    }

    async function loadData() {
      setLoading(true);
      
      try {
        // Check the database for a setting called "live_tmdb_mode"
        const liveTmdbMode = await getSettingValue('live_tmdb_mode', false);
        
        if (liveTmdbMode) {
          // IF live_tmdb_mode = TRUE:
          // → Fetch live data directly from TMDB API
          // → Database is bypassed
          if (tmdbId) {
            try {
              const richData = await getRichMediaDetails(tmdbType, tmdbId, true);
              setDetails(richData);
              
              const savedStr = localStorage.getItem(`muvio_interest_${richData.media.id}`);
              if (savedStr) {
                setIsInterested(JSON.parse(savedStr));
              }
            } catch (err) {
              console.error('Error loading media details via TMDB:', err);
              setDetails(null);
            }
          } else {
            try {
              const queryText = slug.replace(/-/g, ' ');
              const results = await searchCatalog(queryText, 'ALL', true);
              const matchedItem = results.find(item => generateSlug(item.title) === slug) || results[0];
              if (matchedItem) {
                const tType = matchedItem.type === 'MOVIE' ? 'movie' : 'tv';
                const richData = await getRichMediaDetails(tType, matchedItem.tmdbId, true);
                setDetails(richData);
                
                const savedStr = localStorage.getItem(`muvio_interest_${richData.media.id}`);
                if (savedStr) {
                  setIsInterested(JSON.parse(savedStr));
                }
              } else {
                setDetails(null);
              }
            } catch (err) {
              console.error('Error doing dynamic TMDB lookup for slug:', err);
              setDetails(null);
            }
          }
        } else {
          // IF live_tmdb_mode = FALSE (default/off):
          // → Fetch content data from DATABASE only
          // → Do NOT call TMDB live API on frontend
          // → If not in database → show "Content not found"
          const dbDetails = getCustomDetailsBySlug(slug);
          if (dbDetails) {
            if (dbDetails.dataSource === 'LIVE_TMDB' && dbDetails.media.tmdbId) {
              try {
                const freshTmdbDetails = await getRichMediaDetails(
                  dbDetails.media.type === 'MOVIE' ? 'movie' : 'tv',
                  dbDetails.media.tmdbId,
                  true,
                  true // forceLiveTMDB = true
                );
                
                // Merge fresh TMDB info with local DB specific fields
                const mergedDetails: RichMediaDetails = {
                  ...freshTmdbDetails,
                  media: {
                    ...freshTmdbDetails.media,
                    // Keep the local DB id to preserve key association
                    id: dbDetails.media.id,
                  },
                  // Keep our local downloads and tickets
                  downloads: dbDetails.downloads,
                  downloadsEnabled: dbDetails.downloadsEnabled,
                  ticketLinks: dbDetails.ticketLinks,
                  streamingEnabled: dbDetails.streamingEnabled,
                  streamingLinks: dbDetails.streamingLinks,
                  streamingSeasons: dbDetails.streamingSeasons,
                  dataSource: 'LIVE_TMDB'
                };
                setDetails(mergedDetails);
              } catch (err) {
                console.error('Error fetching live TMDB fallback detail block:', err);
                setDetails(dbDetails);
              }
            } else {
              setDetails(dbDetails);
            }
            
            const savedStr = localStorage.getItem(`muvio_interest_${dbDetails.media.id}`);
            if (savedStr) {
              setIsInterested(JSON.parse(savedStr));
            }
          } else {
            setDetails(null);
          }
        }
      } catch (err) {
        console.error('Error loading data:', err);
        setDetails(null);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [slug]);

  // Gemini Phase 8 AI dynamic tags and recommendations loader
  useEffect(() => {
    if (!details) {
      setAiTags([]);
      setAiRecommendations([]);
      return;
    }

    async function fetchAiTags() {
      try {
        const res = await fetch('/api/gemini/tags', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: details.media.title,
            genre: details.genres.join(', '),
            overview: details.media.description
          })
        });
        const data = await res.json();
        if (data && Array.isArray(data.tags)) {
          setAiTags(data.tags);
        }
      } catch (err) {
        console.warn('AI Vibe Tags fetching failed:', err);
      }
    }

    async function fetchAiRecommendations() {
      setLoadingRecs(true);
      try {
        const res = await fetch('/api/gemini/recommend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: details.media.title,
            genre: details.genres.join(', '),
            synopsis: details.media.description
          })
        });
        const recList = await res.json();
        if (recList && Array.isArray(recList)) {
          // Cross-reference recommended titles with catalog entries
          const resolved = await Promise.all(recList.slice(0, 6).map(async (rec: any) => {
            try {
              const matches = await searchCatalog(rec.title);
              if (matches && matches.length > 0) {
                // Find a exact match or closest substring title match
                const match = matches.find((item: any) => 
                  item.title.toLowerCase().includes(rec.title.toLowerCase()) || 
                  rec.title.toLowerCase().includes(item.title.toLowerCase())
                ) || matches[0];
                return { ...rec, matchedMedia: match };
              }
            } catch (searchErr) {
              console.warn(`Catalog cross-reference failed for recommended title "${rec.title}":`, searchErr);
            }
            return rec;
          }));
          setAiRecommendations(resolved);
        }
      } catch (err) {
        console.warn('AI Recommendations fetching failed:', err);
      } finally {
        setLoadingRecs(false);
      }
    }

    async function fetchVibeChart() {
      setVibeLoading(true);
      try {
        const res = await fetch('/api/gemini/vibe-chart', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: details.media.title,
            genre: details.genres.join(', '),
            overview: details.media.description
          })
        });
        const data = await res.json();
        if (data?.vibes && Array.isArray(data.vibes) && data.vibes.length === 4) {
          setVibeData(data);
        }
      } catch (err) {
        console.warn('Vibe chart fetch failed:', err);
      } finally {
        setVibeLoading(false);
      }
    }

    fetchAiTags();
    fetchAiRecommendations();
    fetchVibeChart();
  }, [details]);

  // Load News & Discussions from localStorage (global — not media-specific)
  useEffect(() => {
    if (!details) {
      setNewsItems([]);
      setComments([]);
      return;
    }

    // --- NEWS: sabse latest 3 news (createdAt se sort) ---
    const loadNewsList = async () => {
      let allPosts = [];
      try {
        const rawPosts = localStorage.getItem('muvio_spaces_posts');
        if (rawPosts) {
          allPosts = JSON.parse(rawPosts);
        }
      } catch (e) {}

      if (isFirebaseConfigured && db) {
        try {
          const { collection, getDocs } = await import('firebase/firestore');
          const querySnapshot = await getDocs(collection(db, 'news'));
          if (!querySnapshot.empty) {
            const fsNews: any[] = [];
            querySnapshot.forEach((doc) => {
              fsNews.push({ id: doc.id, ...doc.data() });
            });
            fsNews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            allPosts = fsNews;
            localStorage.setItem('muvio_spaces_posts', JSON.stringify(fsNews));
          } else {
            allPosts = [];
            localStorage.setItem('muvio_spaces_posts', JSON.stringify([]));
          }
        } catch (err) {
          console.warn('Failed to load news from Firestore in ContentDetailsPage:', err);
        }
      }

      const sorted = [...allPosts].sort((a: any, b: any) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      setNewsItems(sorted.slice(0, 3).map((p: any) => ({
        id: p.id,
        title: p.title,
        source: p.authorName || 'Muvio Editorial',
        date: p.createdAt
          ? new Date(p.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
          : 'Recently',
        snippet: (p.text || '').slice(0, 130) + ((p.text || '').length > 130 ? '...' : ''),
        content: p.text
      })));
    };

    loadNewsList();

    // --- DISCUSSIONS: sabse zyada active 3 (replyCount se sort) ---
    try {
      const rawDisc = localStorage.getItem('muvio_spaces_discussions');
      if (rawDisc) {
        const allDisc = JSON.parse(rawDisc);
        const sorted = [...allDisc].sort((a: any, b: any) =>
          (b.replyCount || 0) - (a.replyCount || 0)
        );
        setComments(sorted.slice(0, 3).map((d: any) => ({
          id: d.id,
          user: d.authorUsername || d.authorName || 'User',
          text: d.description || d.title,
          date: d.createdAt
            ? new Date(d.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
            : 'Recently'
        })));
      }
    } catch (e) {
      console.warn('Discussions load failed:', e);
    }
  }, [details]);

  // Sync Logged-In User parameters (Watched status and saved collections)
  useEffect(() => {
    if (!currentUser || !details) return;

    async function syncUserData() {
      try {
        const watchedItem = await getWatchedStatus(currentUser!.uid, details!.media.id);
        setIsWatched(!!watchedItem?.watched);

        const list = await getUserCollections(currentUser!.uid);
        setCollections(list);
      } catch (err) {
        console.warn('Unable to synchronize user status logs:', err);
      }
    }

    syncUserData();
  }, [currentUser, details]);

  const similarItems = React.useMemo(() => {
    if (!details) return [];
    try {
      const media = details.media;
      const genres = details.genres || [];
      const catalog = getAdminCatalog() || [];
      const candidates = catalog.filter(item => 
        item.status === 'Published' && item.media?.id !== media.id
      );

      const scored = candidates.map(item => {
        let score = 0;
        const itemGenres = item.genres || [];
        const overlapCount = itemGenres.filter((g: string) => 
          genres.some((cg: string) => cg.toLowerCase() === g.toLowerCase())
        ).length;
        score += overlapCount * 5;

        if (item.media?.type === media.type) {
          score += 3;
        }

        score += (item.media?.ratingPercent || 0) / 100;

        return { item: item.media, score };
      });

      scored.sort((a, b) => b.score - a.score);
      return scored.map(s => s.item).slice(0, 6);
    } catch (err) {
      console.error('Error calculating similar posts:', err);
      return [];
    }
  }, [details]);

  // Sync similar products interest settings from localStorage
  useEffect(() => {
    if (similarItems && similarItems.length > 0) {
      const map: Record<string, boolean> = {};
      similarItems.forEach(item => {
        if (item) {
          const savedStr = localStorage.getItem(`muvio_interest_${item.id}`);
          map[item.id] = savedStr ? JSON.parse(savedStr) : false;
        }
      });
      setSimilarInterestsMap(map);
    }
  }, [similarItems]);

  const handleToggleSimilarInterest = (item: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const currentStatus = !similarInterestsMap[item.id];
    setSimilarInterestsMap(prev => ({
      ...prev,
      [item.id]: currentStatus
    }));
    localStorage.setItem(`muvio_interest_${item.id}`, JSON.stringify(currentStatus));
    triggerToast(currentStatus ? `Saved ${item.title} to interests! 🔥` : `Removed ${item.title} from interests.`, 'success');
  };

  // Mark as Watched action trigger
  const handleToggleWatched = async () => {
    if (!currentUser) {
      setShowAuthPromptModal(true);
      return;
    }
    if (!details) return;

    setWatchedLoading(true);
    try {
      const nextState = await toggleWatchedStatus(
        currentUser.uid,
        details.media.id,
        details.media.title,
        details.media.type,
        details.media.posterUrl
      );
      setIsWatched(nextState);
      triggerToast(nextState ? "Marked as Watched! Already Watched! ✓" : "Removed from Watched catalog.", "success");
    } catch (err) {
      triggerToast("Failed to update watched records.", "error");
    } finally {
      setWatchedLoading(false);
    }
  };

  // Add to collections modal loader
  const handleOpenCollectionModal = async () => {
    if (!currentUser) {
      setShowAuthPromptModal(true);
      return;
    }
    try {
      const list = await getUserCollections(currentUser.uid);
      setCollections(list);
      setShowCollectionModal(true);
    } catch (err) {
      triggerToast("Could not load tailored folders.", "error");
    }
  };

  // Create Collection Action inside modal
  const handleCreateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!newCollectionName.trim()) return;

    try {
      const created = await createCollection(currentUser.uid, newCollectionName);
      setCollections(prev => [...prev, created]);
      setNewCollectionName('');
      triggerToast(`Vault Folder '${created.name}' created!`, "success");
    } catch (err) {
      triggerToast("Error creating vault collection folder.", "error");
    }
  };

  // Toggle Media ID inclusion inside Collections array checklist
  const handleToggleCollectionCheck = async (collectionId: string, currentChecked: boolean) => {
    if (!currentUser || !details) return;

    const targetCol = collections.find(c => c.id === collectionId);
    if (!targetCol) return;

    let mediaIdsList = [...targetCol.mediaIds];
    if (currentChecked) {
      // Remove
      mediaIdsList = mediaIdsList.filter(id => id !== details.media.id);
    } else {
      // Add
      if (!mediaIdsList.includes(details.media.id)) {
        mediaIdsList.push(details.media.id);
      }
    }

    try {
      await updateCollectionItems(currentUser.uid, collectionId, mediaIdsList);
      setCollections(prev => prev.map(c => c.id === collectionId ? { ...c, mediaIds: mediaIdsList } : c));
      triggerToast("Vault selections modified successfully.", "success");
    } catch (err) {
      triggerToast("Failed to modify collection items.", "error");
    }
  };

  // Interest list fast click handler
  const handleToggleInterest = () => {
    if (!details) return;
    const nextVal = !isInterested;
    setIsInterested(nextVal);
    localStorage.setItem(`muvio_interest_${details.media.id}`, JSON.stringify(nextVal));
    triggerToast(nextVal ? `Saved in personal interests! 🔥` : `Removed from interests.`, 'success');
  };

  // Secure comment board submission
  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !details) return;

    const newDiscussion = {
      id: `disc_${Date.now()}`,
      title: commentText.trim().slice(0, 80),
      description: commentText.trim(),
      authorName: currentUser?.name || 'Guest Critic',
      authorUsername: currentUser?.username || 'guest',
      authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser?.username || 'guest'}`,
      createdAt: new Date().toISOString(),
      isPinned: false,
      replyCount: 0,
      userId: currentUser?.uid || 'guest',
      linkedMediaId: details.media.id,
      linkedMediaTitle: details.media.title
    };

    // Save to localStorage muvio_spaces_discussions
    try {
      const raw = localStorage.getItem('muvio_spaces_discussions');
      const existing = raw ? JSON.parse(raw) : [];
      existing.unshift(newDiscussion);
      localStorage.setItem('muvio_spaces_discussions', JSON.stringify(existing));
    } catch (e) {
      console.warn('Failed to save discussion:', e);
    }

    // Update local state
    setComments((prev) => [
      {
        id: newDiscussion.id,
        user: newDiscussion.authorUsername,
        text: newDiscussion.description,
        date: 'Just now'
      },
      ...prev
    ]);
    setCommentText('');
    triggerToast("Your discussion has been posted!", "success");
  };

  // Broken link ticket reporting submit
  const handleBrokenLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowBrokenLinkModal(false);
    setBrokenLinkDetail('');
    triggerToast("Link feedback dispatched. Curators are verified! ⚔️", "success");
  };

  // Incorrect meta information ticket reporting submit
  const handleIncorrectMetaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowIncorrectModal(false);
    setIncorrectDetail('');
    triggerToast("Metadata variance report logged. Index update active! 🛰️", "success");
  };

  // Link copy share action
  const handleShareMedia = () => {
    navigator.clipboard.writeText(window.location.href);
    triggerToast("Vault URL link successfully parsed to clipboard!", "success");
  };

  // Helper trigger for scrolling rows smoothly via arrow locks
  const scrollContainer = (ref: React.RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = ref.current.clientWidth * 0.75;
      ref.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (loading) {
    return (
      <div className="py-32 flex flex-col items-center justify-center space-y-4 text-center">
        <div className="w-16 h-16 rounded-full border-4 border-t-[#E50914] border-white/5 animate-spin"></div>
        <p className="font-mono text-xs text-[#E50914] tracking-widest uppercase animate-pulse">
          Decrypting high-fidelity cinema archival logs...
        </p>
      </div>
    );
  }

  if (!details) {
    return (
      <div className="py-24 text-center max-w-md mx-auto space-y-4">
        <AlertTriangle size={48} className="text-[#EAB308] mx-auto animate-bounce" />
        <h2 className="text-xl font-bold uppercase tracking-wide">Content not found</h2>
        <p className="text-xs text-gray-400">
          The requested cinema slug has failed decrypt matching entries. It might be archived or blocked by TMDB.
        </p>
        <button 
          onClick={() => onNavigate('/explore')}
          className="px-5 py-2.5 rounded-full bg-[#111111] border border-white/5 text-xs text-white"
        >
          Return to Hub
        </button>
      </div>
    );
  }

  const { media, genres, duration, directedBy, country, language, ageRating, trailerUrl, productionCompanies, cast, crew } = details;

  return (
    <div className="animate-fade-in relative text-left min-h-screen bg-black" id="muvio-content-details-page">
      {/* SECTION 0: EXIT LINK RAMP */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 pt-4 pb-2">
        <button
          onClick={() => onNavigate('/explore')}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#111111]/80 hover:bg-[#E50914] text-gray-300 hover:text-white text-xs font-bold transition-all border border-white/5 cursor-pointer"
          id="btn-back-details"
        >
          <span>&larr; Back</span>
        </button>
      </div>

      {/* SECTION 1: HERO CONTAINER (Backdrop image full width, no border radius) */}
      <div className="relative w-full h-[220px] sm:h-[320px] md:h-[450px] overflow-hidden bg-[#050505] shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
        <img 
          src={media.backdropUrl} 
          alt={media.title} 
          className="w-full h-full object-cover object-center brightness-50"
        />
        {/* Immersive overlay styling */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#000000] via-[#000000]/50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#000000]/80 via-transparent to-transparent"></div>

        {/* Pulse red play button overlapping */}
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={() => {
              if (trailerUrl) {
                setShowTrailer(true);
              } else {
                triggerToast("Official trailer index coordinates not found.", "error");
              }
            }}
            className="group flex items-center justify-center w-14 h-14 md:w-18 md:h-18 rounded-full bg-[#E50914] text-white hover:bg-[#FF1A1A] transition-all duration-300 transform hover:scale-110 shadow-[0_0_20px_rgba(229,9,20,0.6)] cursor-pointer relative"
            id="play-trailer-trigger"
          >
            <span className="absolute inset-x-0 inset-y-0 rounded-full bg-[#E50914]/40 animate-ping group-hover:block hidden"></span>
            <Play size={20} className="ml-1 fill-current group-hover:scale-95 transition-transform" />
          </button>
          <span className="absolute mt-16 md:mt-20 font-mono text-[9px] uppercase font-bold tracking-widest text-white/50">
            Play Trailer
          </span>
        </div>
      </div>

      {/* SECTION 1.5: POSTER + INFO SIDE BY SIDE */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-12 sm:-mt-16 md:-mt-24 relative z-10 flex gap-4 md:gap-6 items-end">
        {/* Poster - small, left */}
        <div className="w-20 sm:w-28 md:w-36 aspect-[2/3] rounded-xl overflow-hidden border border-white/10 shadow-2xl bg-[#111] shrink-0">
          <img src={media.posterUrl} alt={media.title} className="w-full h-full object-cover" />
        </div>
        
        {/* Title & Info - right */}
        <div className="space-y-1.5 pb-2 text-left">
          <div className="flex flex-wrap items-center gap-1">
            <span className="bg-[#E50914] text-white font-mono font-bold text-[8px] tracking-widest px-1.5 py-0.5 rounded uppercase">
              {media.type}
            </span>
            <span className="bg-white/10 px-1.5 py-0.5 rounded text-[8px] font-mono font-extrabold tracking-wider text-gray-300">
              {media.statusBadge}
            </span>
            <div className="flex items-center gap-0.5 bg-[#EAB308]/15 border border-[#EAB308]/20 px-1.5 py-0.5 text-[9px] text-[#EAB308] font-bold rounded-full">
              <Star size={9} className="fill-current text-[#EAB308]" />
              <span>{media.ratingPercent}%</span>
            </div>
          </div>
          
          <h1 className="font-sans font-black text-[20px] md:text-[28px] text-white leading-tight uppercase tracking-tight">
            {media.title}
          </h1>
          
          <div className="text-[12px] md:text-[13px] text-gray-400 font-mono flex flex-wrap items-center gap-x-2 gap-y-1">
            <span>{media.releaseDate ? media.releaseDate.split('-')[0] : ''}</span>
            <span className="text-gray-600">•</span>
            <span>{duration}</span>
            <span className="text-gray-600">•</span>
            <span>{country}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 space-y-4">
        {/* SECTION 3: ACTION BUTTONS CONTAINER (Redesigned open row with py-2.5 px-4, font 14px, full width on mobile) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-4 border-b border-white/5">
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          {/* Mark as Watched */}
          <button
            onClick={handleToggleWatched}
            disabled={watchedLoading}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-full text-[14px] font-black tracking-wider transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer border ${
              isWatched 
                ? 'bg-[#22C55E]/15 border-[#22C55E]/30 text-[#22C55E]' 
                : 'bg-[#E50914] border-[#E50914] text-white hover:bg-[#FF1A1A] hover:border-[#FF1A1A]'
            }`}
            id="mark-watched-button"
          >
            {isWatched ? (
              <>
                <Check size={14} />
                <span>ALREADY WATCHED!</span>
              </>
            ) : (
              <>
                <Eye size={14} />
                <span>MARK AS WATCHED</span>
              </>
            )}
          </button>

          {/* Add to collections */}
          <button
            onClick={handleOpenCollectionModal}
            className="w-full sm:w-auto px-4 py-2.5 rounded-full text-[14px] font-black tracking-wider bg-white/5 hover:bg-white/10 text-white transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/10"
            id="add-collection-button"
          >
            <FolderHeart size={14} />
            <span>ADD TO COLLECTION</span>
          </button>
        </div>

        {/* Share Button */}
        <div className="w-full sm:w-auto">
          <button
            onClick={handleShareMedia}
            className="w-full sm:w-auto px-4 py-2.5 rounded-full bg-[#111111] hover:bg-white/10 text-gray-300 hover:text-white transition-all text-[14px] font-bold border border-white/5 cursor-pointer flex items-center justify-center gap-2"
            id="share-icon-button"
          >
            <Share2 size={14} />
            <span>SHARE</span>
          </button>
        </div>
      </div>

      {/* SECTION 4: OVERVIEW (Redesigned heading Overview, no heavy card layout, text body 14px on mobile) */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h2 className="text-[18px] md:text-[24px] font-black uppercase text-white tracking-tight">Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-3">
            <p className="text-gray-300 text-[14px] md:text-[15px] leading-relaxed font-sans font-medium">
              {media.description}
            </p>
            <div className="flex flex-wrap gap-1.5 pt-2">
              {genres.map((genre, idx) => (
                <span 
                  key={idx} 
                  className="bg-white/5 border border-white/10 px-2.5 py-1 rounded-full text-[11px] md:text-[12px] font-mono font-bold tracking-wider text-gray-300 select-none hover:border-[#E50914] cursor-default transition-all"
                >
                  #{genre.toUpperCase()}
                </span>
              ))}
              <span className="bg-orange-500/10 border border-orange-500/20 px-2.5 py-1 rounded-full text-[11px] md:text-[12px] font-mono font-bold tracking-wider text-orange-400 select-none">
                #CINEMATIC_ATMOSPHERE
              </span>
              {aiTags.map((tag, idx) => (
                <span 
                  key={`ai-tag-${idx}`} 
                  className="bg-[#E50914]/5 border border-[#E50914]/20 px-2.5 py-1 rounded-full text-[11px] md:text-[12px] font-mono font-bold tracking-wider text-red-400 select-none flex items-center gap-1"
                >
                  <Sparkles size={8} className="text-[#E50914]" />
                  {tag.toUpperCase()}
                </span>
              ))}
            </div>
          </div>
          
          {/* Overview Metadata Parameters table - clean minimalist table row */}
          <div className="md:col-span-1 bg-white/2 border border-white/5 rounded-2xl p-4 grid grid-cols-2 gap-4 text-[12px] font-sans">
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Directed By</span>
              <span className="text-white font-bold block truncate">{directedBy}</span>
            </div>
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Duration</span>
              <span className="text-white font-bold block">{duration}</span>
            </div>
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Origin Country</span>
              <span className="text-white font-bold block">{country}</span>
            </div>
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Language</span>
              <span className="text-white font-bold block truncate">{language}</span>
            </div>
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Age Rating</span>
              <span className="text-white font-bold block">{ageRating}</span>
            </div>
            <div className="space-y-0.5">
              <span className="text-gray-500 font-mono text-[9px] uppercase tracking-wider block">Release Date</span>
              <span className="text-white font-bold block font-mono">{media.releaseDate}</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 5: STREAM COORDINATES (Redesigned open row with simple transparent grid) */}
      {(() => {
        const ticketLinks = details?.ticketLinks || [];
        // Only show if there are platforms added
        if (ticketLinks.length === 0) return null;

        return (
          <div className="py-6 border-b border-white/5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
              <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Available Digital Tickets</h3>
              <button
                onClick={() => setShowBrokenLinkModal(true)}
                className="text-[10px] font-mono font-bold text-gray-500 hover:text-[#E21010] cursor-pointer flex items-center gap-1.5 transition-colors self-start md:self-auto"
                id="report-broken-link-trigger"
              >
                <AlertTriangle size={12} />
                <span>Broken link? Inform operators</span>
              </button>
            </div>

            {/* Streaming sources grid cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {ticketLinks.map((platform, idx) => (
                <a
                  key={idx}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  referrerPolicy="no-referrer"
                  className="flex flex-col p-3.5 rounded-xl border border-white/5 bg-white/2 hover:bg-[#E50914]/10 hover:border-[#E50914]/30 transition-all duration-300 group justify-between h-28 card-digital-ticket"
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    <PlatformLogo platformName={platform.platform} domain={platform.domain} />
                    <div className="min-w-0 flex-1">
                      <span className="font-extrabold text-sm tracking-tight text-white block truncate transition-colors group-hover:text-[#E50914]">{platform.platform}</span>
                      <span className="text-[10px] font-mono text-gray-400 tracking-wider block mt-0.5 uppercase">{platform.type || 'Subscription'}</span>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono leading-none tracking-widest text-[#E50914] text-right font-black block uppercase group-hover:translate-x-1 transition-transform">
                    WATCH &rarr;
                  </span>
                </a>
              ))}
            </div>
          </div>
        );
      })()}

        {/* SECTION 6: DOWNLOAD SECTION */}
      {(() => {
        const downloads = details?.downloads || [];
        const downloadsEnabled = details?.downloadsEnabled !== false;
        const activeDownloads = downloads.filter(dl => dl && dl.url && dl.url.trim() !== '' && dl.enabled);
        const shouldShowSection = downloadsEnabled && activeDownloads.length > 0;

        if (!shouldShowSection) return null;

        return (
          <div id="section-download" className="py-6 border-b border-white/5 space-y-4">
            <div className="space-y-0.5">
              <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Offline Media Downloader</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {activeDownloads.map((quality, idx) => (
                <button 
                  key={idx}
                  onClick={() => handleDownloadClick(quality.quality, quality.size || '')}
                  className="w-full p-4 bg-white/2 hover:bg-[#E50914]/10 hover:border-[#E50914]/30 border border-white/5 rounded-xl transition-all cursor-pointer group flex flex-col justify-between text-left animate-fade-in"
                >
                  <div className="flex justify-between items-center w-full">
                    <span className="text-white font-bold text-sm">{quality.quality} - Download</span>
                    {quality.size && quality.size.trim() !== '' && (
                      <span className="text-gray-500 text-[11px] font-mono">{quality.size}</span>
                    )}
                  </div>
                  <span className="text-[10px] text-gray-400 group-hover:text-[#E21010] block mt-1.5 font-mono">
                    Get high-fidelity print &rarr;
                  </span>
                </button>
              ))}
            </div>
          </div>
        );
      })()}

      {/* SECTION 6.5: ONLINE STREAMING SECTION */}
      {(() => {
        const isStreaming = details?.streamingEnabled;
        if (!isStreaming) return null;

        const isMovie = details?.media?.type === 'MOVIE';
        const movieLinks = details?.streamingLinks?.filter(l => l.enabled) || [];
        const seasons = details?.streamingSeasons || [];
        const hasSeasonsWithEpisodes = seasons.some(s => s.episodes?.length > 0);

        if (isMovie && movieLinks.length === 0) return null;
        if (!isMovie && !hasSeasonsWithEpisodes) return null;

        const curSeasonNum = selectedSeasonNumber || (seasons[0]?.seasonNumber);
        const currentSeason = seasons.find(s => s.seasonNumber === curSeasonNum);
        const episodes = currentSeason?.episodes || [];

        return (
          <div id="section-online-streaming" className="py-6 border-b border-white/5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="space-y-0.5">
                <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Online Streaming</h3>
                <p className="text-xxs text-gray-500 font-mono">Stream this cinematic wonder directly inside your browser.</p>
              </div>
              {activeStreamUrlOrEmbed && (
                <button
                  onClick={() => {
                    setActiveStreamUrlOrEmbed(null);
                    setActivePlatformName(null);
                  }}
                  className="px-3 py-1 bg-red-600/10 border border-red-650/30 text-red-500 rounded-lg text-xxs font-mono hover:bg-red-600/20 uppercase transition-all flex items-center justify-center gap-1 self-start"
                >
                  <span>Close Player</span>
                </button>
              )}
            </div>

            {/* Embed/Iframe Inline Video Player */}
            {activeStreamUrlOrEmbed ? (
              <div className="space-y-2 animate-fade-in">
                <div className="w-full max-w-4xl mx-auto aspect-video bg-neutral-950 rounded-2xl border border-white/5 shadow-[0_0_50px_rgba(229,9,20,0.1)] relative overflow-hidden">
                  {(() => {
                    const code = activeStreamUrlOrEmbed.trim();
                    if (code.startsWith('<iframe') || code.includes('<')) {
                      return (
                        <div 
                          className="w-full h-full"
                          dangerouslySetInnerHTML={{ __html: code.replace(/width="[0-9%]+"/, 'width="100%"').replace(/height="[0-9%]+"/, 'height="100%"') }}
                        />
                      );
                    } else {
                      return (
                        <iframe
                          src={code}
                          className="w-full h-full border-0"
                          allowFullScreen
                          referrerPolicy="no-referrer"
                          id="active-iframe-player"
                        />
                      );
                    }
                  })()}
                </div>
                {activePlatformName && (
                  <p className="text-center text-xxs text-gray-400 font-mono">
                    Currently playing via <strong className="text-blue-500 uppercase">{activePlatformName}</strong> server
                  </p>
                )}
              </div>
            ) : (
              /* Play area placeholder preview card */
              <div className="w-full max-w-4xl mx-auto h-[240px] sm:h-[340px] bg-[#111111]/80 rounded-2xl border border-white/5 flex flex-col items-center justify-center space-y-4 relative overflow-hidden group">
                <div className="absolute inset-0 bg-cover bg-center opacity-10 filter blur-[2px] transition-all group-hover:scale-105" style={{ backgroundImage: `url(${details?.media?.backdropUrl})` }} />
                <div className="p-4 rounded-full bg-red-600 text-white shadow-lg cursor-pointer transform hover:scale-110 active:scale-95 transition-all relative z-10 flex items-center justify-center"
                     onClick={() => {
                       if (isMovie && movieLinks.length > 0) {
                         setActiveStreamUrlOrEmbed(movieLinks[0].embedCode);
                         setActivePlatformName(movieLinks[0].platform);
                       } else if (!isMovie && episodes.length > 0) {
                         const firstEp = episodes[0];
                         const plats = firstEp.platforms?.filter(p => p.enabled) || [];
                         if (plats.length > 0) {
                           setActiveStreamUrlOrEmbed(plats[0].embedCode);
                           setActivePlatformName(plats[0].platform);
                         } else {
                           const firstSeason = seasons[0];
                           if (firstSeason) {
                             setSelectedSeasonNumber(firstSeason.seasonNumber);
                           }
                         }
                       }
                     }}
                >
                  <svg className="w-10 h-10 ml-1 fill-current" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
                <div className="text-center relative z-10 space-y-1">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">Start Streaming Now</h4>
                  <p className="text-xxs text-gray-400 max-w-xs mx-auto">Select a preferred server player load gateway source below.</p>
                </div>
              </div>
            )}

            {/* Platform links and navigation controls section */}
            {isMovie ? (
              /* Movie layout: flat list of buttons */
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Available Channels / Mirror Servers</span>
                <div className="flex flex-wrap gap-2.5">
                  {movieLinks.map((sl, idx) => (
                    <button
                      key={`stream-movie-${idx}`}
                      onClick={() => {
                        setActiveStreamUrlOrEmbed(sl.embedCode);
                        setActivePlatformName(sl.platform);
                      }}
                      className={activePlatformName === sl.platform ? "px-4 py-2 bg-blue-600 text-white rounded-xl text-xxs font-mono font-bold uppercase transition-all shadow-[0_0_15px_rgba(9,132,229,0.3)] border border-blue-500" : "px-4 py-2 bg-white/2 hover:bg-white/5 border border-white/5 rounded-xl text-xxs font-mono font-bold text-gray-400 hover:text-white uppercase transition-all"}
                    >
                      {sl.platform}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              /* Show / Anime layout: Seasons tabs + Episode List */
              <div className="space-y-4">
                {/* Seasons Tab switcher */}
                <div className="flex flex-wrap gap-2 pb-1 border-b border-white/5">
                  {seasons.map((season) => (
                    <button
                      key={`season-tab-${season.seasonNumber}`}
                      onClick={() => {
                        setSelectedSeasonNumber(season.seasonNumber);
                        setSelectedEpisodeNumber(null);
                      }}
                      className={curSeasonNum === season.seasonNumber ? "px-4 py-1.5 border-b-2 border-red-500 text-white text-xxs font-black uppercase font-mono tracking-wider transition-all" : "px-4 py-1.5 text-gray-400 text-xxs font-black uppercase font-mono tracking-wider hover:text-white transition-all"}
                    >
                      Season {season.seasonNumber}
                    </button>
                  ))}
                </div>

                {/* Episodes grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {episodes.map((ep) => {
                    const activePlats = ep.platforms?.filter(p => p.enabled) || [];
                    const isDisabled = activePlats.length === 0;

                    return (
                      <button
                        key={`ep-${ep.episodeNumber}`}
                        disabled={isDisabled}
                        onClick={() => {
                          setEpisodePlatformsPopup(activePlats);
                          setSelectedEpisodeNumber(ep.episodeNumber);
                        }}
                        className={isDisabled ? "w-full p-3 bg-neutral-900/40 border border-white/2 rounded-xl text-left opacity-35 cursor-not-allowed flex flex-col space-y-1 align-baseline" : "w-full p-3 bg-white/2 hover:bg-neutral-900 border border-white/5 rounded-xl text-left transition-all cursor-pointer flex flex-col justify-between space-y-1 active:scale-[0.98] group"}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-white font-bold text-xs uppercase font-mono">Episode {ep.episodeNumber}</span>
                          <span className="text-xxs px-1.5 py-0.5 bg-blue-950/20 text-blue-400 border border-blue-500/10 rounded font-mono uppercase tracking-widest text-[8px]">
                            {activePlats.length} Mirrors
                          </span>
                        </div>
                        <p className="text-[10px] text-gray-400 line-clamp-1 group-hover:text-gray-200 transition-all font-sans">
                          {ep.title}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Platforms selector popup list modal */}
            {episodePlatformsPopup && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
                <div className="w-full max-w-md bg-neutral-950 border border-white/5 rounded-2xl p-5 space-y-4 shadow-[0_0_50px_rgba(0,0,0,0.8)] relative">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400 font-mono">Episode {selectedEpisodeNumber}</h4>
                      <h3 className="text-[16px] font-black text-white uppercase tracking-tight">Select Mirror Gateway</h3>
                    </div>
                    <button
                      onClick={() => {
                        setEpisodePlatformsPopup(null);
                        setSelectedEpisodeNumber(null);
                      }}
                      className="p-1.5 bg-white/2 hover:bg-white/5 rounded-full border border-white/5 text-gray-400 hover:text-white transition-all cursor-pointer"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>

                  <div className="space-y-2 mt-2">
                    {episodePlatformsPopup.map((plat, idx) => (
                      <button
                        key={`popup-plat-${idx}`}
                        onClick={() => {
                          setActiveStreamUrlOrEmbed(plat.embedCode);
                          setActivePlatformName(plat.platform);
                          setEpisodePlatformsPopup(null);
                        }}
                        className="w-full p-3.5 bg-white/2 hover:bg-[#E50914]/10 hover:border-[#E50914]/30 border border-white/5 rounded-xl transition-all flex items-center justify-between font-mono text-left active:scale-[0.98]"
                      >
                        <div className="space-y-0.5">
                          <span className="text-white text-xs font-black uppercase text-left">{plat.platform}</span>
                          <span className="text-[8px] text-gray-500 block uppercase">Stream Server Load balancer active</span>
                        </div>
                        <span className="text-[#E50914] text-[10px] uppercase font-bold tracking-wider">
                          Load Player &rarr;
                        </span>
                      </button>
                    ))}
                  </div>

                  <p className="text-[9px] text-gray-500 font-mono text-center">
                    All pipelines pass strict end-to-end sandbox privacy filters.
                  </p>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* SECTION 7: VIBE CHART */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Vibe Metric Chart</h3>

        {vibeLoading ? (
          <div className="flex items-center justify-center py-10">
            <div className="w-8 h-8 rounded-full border-2 border-t-[#E50914] border-white/10 animate-spin"></div>
            <span className="ml-3 text-xs font-mono text-gray-500 uppercase tracking-widest animate-pulse">Analyzing vibes...</span>
          </div>
        ) : (
        <div className="flex flex-col md:flex-row items-center justify-around gap-6">
          {/* Custom SVG Donut Component - dynamic segments */}
          <div className="relative w-40 h-40 select-none">
            <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
              {/* Secondary gray track */}
              <circle cx="50" cy="50" r="40" fill="transparent" stroke="#111" strokeWidth="12" />

              {/* Dynamic colored segments */}
              {(() => {
                const circumference = 2 * Math.PI * 40; // ~251.2
                const vibes = vibeData?.vibes || [
                  { label: 'Thrill & Action (Adrenaline)', value: 40, color: '#E50914', desc: '' },
                  { label: 'Drama & Depth (Intellectual)', value: 25, color: '#3B82F6', desc: '' },
                  { label: 'Comedy & Leisure (Amusement)', value: 20, color: '#10B981', desc: '' },
                  { label: 'Romance & Warmth (Emotional)', value: 15, color: '#F97316', desc: '' }
                ];
                let offset = 0;
                return vibes.map((vibe, idx) => {
                  const dash = (vibe.value / 100) * circumference;
                  const gap = circumference - dash;
                  const el = (
                    <circle
                      key={idx}
                      cx="50" cy="50" r="40"
                      fill="transparent"
                      stroke={vibe.color}
                      strokeWidth="12"
                      strokeDasharray={`${dash} ${gap}`}
                      strokeDashoffset={-offset}
                    />
                  );
                  offset += dash;
                  return el;
                });
              })()}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="font-sans font-black text-white text-md tracking-tight">
                {vibeData?.profile || 'ATMOSPHERE'}
              </span>
              <span className="font-mono text-[8px] text-[#E50914] tracking-widest uppercase">Vibe Profile</span>
            </div>
          </div>

          {/* Chart Legend */}
          <div className="space-y-3 max-w-xs w-full text-[13px]">
            {(vibeData?.vibes || [
              { label: 'Thrill & Action (Adrenaline)', value: 40, color: '#E50914', desc: 'High adrenaline fights and heavy stakes.' },
              { label: 'Drama & Depth (Intellectual)', value: 25, color: '#3B82F6', desc: 'Rich dialogue frameworks and heavy plotting.' },
              { label: 'Comedy & Leisure (Amusement)', value: 20, color: '#10B981', desc: 'Warm structural humor and dialogue relief.' },
              { label: 'Romance & Warmth (Emotional)', value: 15, color: '#F97316', desc: 'Character attachments and warm bonds.' }
            ]).map((vibe, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="flex items-center justify-between font-bold">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: vibe.color }} />
                    <span className="text-white font-medium">{vibe.label}</span>
                  </div>
                  <span className="text-gray-400 font-mono">{vibe.value}%</span>
                </div>
                <p className="text-[11px] text-gray-500 ml-3.5 leading-tight">{vibe.desc}</p>
              </div>
            ))}
          </div>
        </div>
        )}
      </div>

      {/* SECTION 8: PRODUCTION HOUSE */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Production House</h3>
        <div className="flex flex-wrap gap-2">
          {productionCompanies.map((company, idx) => (
            <span 
              key={idx} 
              className="bg-white/5 border border-white/10 px-3 py-1.5 rounded-full text-[11px] md:text-[12px] font-semibold text-gray-300 font-sans tracking-wide hover:border-[#E50914] transition-colors"
            >
              {company.name}
            </span>
          ))}
        </div>
      </div>

      {/* SECTION 9: CAST */}
      <div className="py-6 border-b border-white/5 space-y-4 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Cast</h3>
          <div className="flex items-center gap-1.5 font-sans">
            <button
              onClick={() => scrollContainer(castRef, 'left')}
              className="w-7 h-7 rounded-full bg-white/5 hover:bg-[#E50914] text-gray-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              onClick={() => scrollContainer(castRef, 'right')}
              className="w-7 h-7 rounded-full bg-white/5 hover:bg-[#E50914] text-gray-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Scroll row - circular photos smaller 56px/64px */}
        <div
          ref={castRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide py-2 pl-1 pr-6"
          style={{ scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch' }}
        >
          {cast.map((actor, idx) => (
            <div 
              key={idx} 
              className="min-w-[100px] md:min-w-[120px] shrink-0 flex flex-col items-center text-center space-y-1.5"
              style={{ scrollSnapAlign: 'start' }}
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-full overflow-hidden border border-white/10 shadow-sm bg-[#111]">
                <img src={actor.profileUrl} alt={actor.name} className="w-full h-full object-cover" />
              </div>
              <div className="space-y-0.5 max-w-full">
                <span className="text-[12px] font-bold text-white block truncate">{actor.name}</span>
                <span className="text-[11px] font-mono text-gray-500 block truncate">{actor.character}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 10: CREW */}
      <div className="py-6 border-b border-white/5 space-y-4 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Crew</h3>
          <div className="flex items-center gap-1.5 font-sans">
            <button
              onClick={() => scrollContainer(crewRef, 'left')}
              className="w-7 h-7 rounded-full bg-white/5 hover:bg-[#E50914] text-gray-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              onClick={() => scrollContainer(crewRef, 'right')}
              className="w-7 h-7 rounded-full bg-white/5 hover:bg-[#E50914] text-gray-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Scroll row - circular photos smaller 56px/64px */}
        <div
          ref={crewRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide py-2 pl-1 pr-6"
          style={{ scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch' }}
        >
          {crew.map((member, idx) => (
            <div 
              key={idx} 
              className="min-w-[100px] md:min-w-[120px] shrink-0 flex flex-col items-center text-center space-y-1.5"
              style={{ scrollSnapAlign: 'start' }}
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-full overflow-hidden border border-white/10 shadow-sm bg-[#111]">
                <img src={member.profileUrl} alt={member.name} className="w-full h-full object-cover" />
              </div>
              <div className="space-y-0.5 max-w-full">
                <span className="text-[12px] font-bold text-white block truncate">{member.name}</span>
                <span className="text-[11px] font-mono text-[#E50914] block truncate">{member.role}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 11: MUVIO METER & GAUGE CHART */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Muvio Meter</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-center md:text-left">
          {/* Custom SVG Gauge meter arc - normal size */}
          <div className="flex flex-col items-center justify-center space-y-2">
            <div className="relative w-40 h-24 overflow-hidden">
              <svg viewBox="0 0 100 50" className="w-full h-full">
                <defs>
                  <linearGradient id="gauge-grad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#444" />
                    <stop offset="50%" stopColor="#E50914" />
                    <stop offset="100%" stopColor="#FF1A1A" />
                  </linearGradient>
                </defs>
                <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="#222" strokeWidth="10" strokeLinecap="round" />
                <path 
                  d="M 10 50 A 40 40 0 0 1 90 50" 
                  fill="none" 
                  stroke="url(#gauge-grad)" 
                  strokeWidth="10" 
                  strokeLinecap="round" 
                  strokeDasharray="125.6"
                  strokeDashoffset={125.6 - (125.6 * media.ratingPercent) / 100}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="absolute inset-x-0 bottom-0 flex flex-col items-center">
                <span className="font-display font-black text-white text-[24px] leading-tight">{media.ratingPercent}%</span>
                <span className="font-mono text-[8px] text-gray-500 tracking-wider">Muvio Meter Score</span>
              </div>
            </div>

            <div className="text-center font-mono text-[10px] text-gray-400">
              <span className="block font-bold">Total Index: {media.voteCount + 54} Votes</span>
            </div>
          </div>

          {/* Meter Breakdown List - breakdown list 14px text */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-[14px] font-sans">
              <div className="border border-white/5 p-2 rounded-lg">
                <span className="text-[#22C55E] font-bold block text-[14px]">Perfection (9-10)</span>
                <span className="text-[11px] font-mono text-gray-400 block mt-0.5">42% of responses</span>
              </div>
              <div className="border border-white/5 p-2 rounded-lg">
                <span className="text-[#EAB308] font-bold block text-[14px]">Go for it (7-8)</span>
                <span className="text-[11px] font-mono text-gray-400 block mt-0.5">30% of responses</span>
              </div>
              <div className="border border-white/5 p-2 rounded-lg">
                <span className="text-orange-400 font-bold block text-[14px]">Timepass (5-6)</span>
                <span className="text-[11px] font-mono text-gray-400 block mt-0.5">20% of responses</span>
              </div>
              <div className="border border-white/5 p-2 rounded-lg">
                <span className="text-red-500 font-bold block text-[14px]">Skip (0-4)</span>
                <span className="text-[11px] font-mono text-gray-400 block mt-0.5">8% of responses</span>
              </div>
            </div>

            <button
              onClick={handleShareMedia}
              className="w-full sm:w-auto px-4 py-2 bg-white/5 hover:bg-white/10 text-white transition-all text-xs font-bold font-mono tracking-wider uppercase rounded-lg border border-white/10 cursor-pointer"
              id="gauge-share-button"
            >
              Share Score Index
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: REVIEWS (Clean open layout, no dark cards) */}
      <div id="section-reviews" className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Reviews</h3>
        <MediaReviewsSection
          mediaId={media.id}
          mediaTitle={media.title}
          currentUser={currentUser}
          onTriggerAuthPrompt={() => setShowAuthPromptModal(true)}
        />
      </div>

      {/* SECTION: YOU MIGHT ALSO LIKE */}
      {similarItems.length > 0 && (
        <div className="py-6 border-b border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">You Might Also Like</h3>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {similarItems.map((item) => {
              const isSaved = !!similarInterestsMap[item.id];
              const voteCountDisplay = item.voteCount + (isSaved ? 1 : 0);

              return (
                <div 
                  key={item.id} 
                  onClick={() => onNavigate(`/content/${generateSlug(item.title)}`)}
                  className="group bg-[#0c0c0c]/90 rounded-2xl border border-white/5 overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:border-[#E50914]/40 text-left h-80"
                >
                  {/* Poster image (full card top, rounded) */}
                  <div className="aspect-[3/4.2] relative bg-black overflow-hidden flex items-center justify-center">
                    <img 
                      referrerPolicy="no-referrer"
                      src={item.posterUrl} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    
                    {/* Type badge: MOVIE/SHOW/ANIME (top left overlay) */}
                    <div className="absolute top-2.5 left-2.5 bg-[#E50914] text-white font-mono font-bold text-[8px] tracking-widest px-1.5 py-0.5 rounded uppercase">
                      {item.type}
                    </div>

                    {/* 🔥 Fire icon + interest count top right (e.g. 🔥 4202) */}
                    <div className="absolute top-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/5 text-[9px] font-mono text-orange-400 font-bold flex items-center gap-1">
                      <Flame size={10} className="fill-current text-orange-500" />
                      <span>{voteCountDisplay}</span>
                    </div>
                  </div>

                  {/* Info block - Below Poster */}
                  <div className="p-3 flex-1 flex flex-col justify-between mb-1 pl-4 bg-[#0a0a0a]">
                    <div>
                      {/* Type (MOVIE/SHOW/ANIME) small text and Year (small gray) */}
                      <div className="flex items-center justify-between text-[8px] font-mono font-black text-neutral-500 uppercase">
                        <span>{item.type}</span>
                        <span>{item.year}</span>
                      </div>
                      
                      {/* Title (bold white, with mt-1) */}
                      <h4 className="font-sans font-bold text-xs sm:text-sm text-neutral-200 mt-1 line-clamp-1 group-hover:text-white transition-colors uppercase tracking-tight">
                        {item.title}
                      </h4>
                    </div>

                    {/* 🔥 Fire icon (small, below title) (on left) and "EXPLORE →" text button (crimson, right side) */}
                    <div className="pt-2 flex items-center justify-between">
                      <button
                        onClick={(e) => handleToggleSimilarInterest(item, e)}
                        className={`p-1.5 rounded-lg border cursor-pointer transition-colors ${
                          isSaved 
                            ? 'bg-orange-500/20 border-orange-500/30 text-orange-400' 
                            : 'bg-white/5 border-white/5 text-neutral-500 hover:text-white hover:bg-neutral-800'
                        }`}
                        title="Add to interests"
                      >
                        <Flame size={11} className={isSaved ? 'fill-current' : ''} />
                      </button>
                      
                      <span className="text-[9px] font-mono font-black text-[#E50914] tracking-wider uppercase group-hover:underline">
                        EXPLORE &rarr;
                      </span>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION: LATEST NEWS */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Latest News</h3>
        <div className="space-y-4">
          {newsItems.length === 0 ? (
            <p className="text-sm text-gray-600 font-mono py-2">No news published for this title yet.</p>
          ) : (
            newsItems.map((news, idx) => (
              <div
                key={news.id}
                onClick={() => setSelectedNews({ title: news.title, source: news.source, date: news.date, snippet: news.snippet, content: news.content })}
                className="p-4 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] transition-all cursor-pointer border border-white/5 text-left block w-full space-y-1 group"
                id={`news-card-${idx}`}
              >
                <div className="flex items-center gap-2 text-[11px] font-mono text-gray-400">
                  <span>{news.source}</span>
                  <span>•</span>
                  <span>{news.date}</span>
                </div>
                <h4 className="text-[14px] font-bold text-white group-hover:text-[#E50914] transition-colors">{news.title}</h4>
                <p className="text-[13px] text-gray-400 leading-relaxed max-w-3xl">{news.snippet}</p>
              </div>
            ))
          )}
        </div>
      </div>

      {/* SECTION: DISCUSSIONS */}
      <div className="py-6 border-b border-white/5 space-y-4">
        <h3 className="text-[18px] md:text-[24px] font-black text-white uppercase tracking-tight">Discussions</h3>

        <div className="space-y-3">
          {comments.length === 0 ? (
            <p className="text-sm text-gray-600 font-mono py-2">No discussions yet.</p>
          ) : (
            comments.map((comment) => (
              <div
                key={comment.id}
                onClick={() => onNavigate(`/spaces/discussion/${comment.id}`)}
                className="p-4 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] transition-all cursor-pointer border border-white/5 text-left block w-full space-y-1 group"
                id={`comment-card-${comment.id}`}
              >
                <div className="flex items-center justify-between text-[11px] font-mono text-gray-400">
                  <span className="font-bold text-gray-300 group-hover:text-[#E50914] transition-colors">@{comment.user}</span>
                  <span>{comment.date}</span>
                </div>
                <p className="text-[14px] text-gray-300 leading-relaxed font-sans">{comment.text}</p>
              </div>
            ))
          )}
        </div>

        {/* Go to Spaces button */}
        <button
          onClick={() => onNavigate('/spaces')}
          className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-bold text-gray-300 hover:text-white transition-all font-mono uppercase tracking-wider cursor-pointer"
        >
          Join the Discussion in Spaces →
        </button>
      </div>

      {/* SECTION 13: PLACEHOLDER NEWS ANCHOR */}
      <div id="section-news" className="hidden"></div>

      {/* SECTION 15: GENERAL METADATA REPORT TRIGGER BUTTON */}
      <div className="pt-6 text-center">
        <button
          onClick={() => setShowIncorrectModal(true)}
          className="px-6 py-2.5 rounded-full bg-white/2 hover:bg-red-500/10 text-gray-500 hover:text-[#E50914] transition-all text-xs border border-white/5 cursor-pointer"
          id="meta-incorrect-report-trigger"
        >
          Incorrect Content Specs? Request Database Refactor
        </button>
      </div>
    </div>

      {/* MODAL 1: TRAILER PLAYBACK OVERLAY */}
      <AnimatePresence>
        {showTrailer && (
          <div className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4">
            <div className="absolute top-6 right-6 z-[210]">
              <button
                onClick={() => setShowTrailer(false)}
                className="w-12 h-12 rounded-full bg-white/5 hover:bg-[#E50914] text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
              >
                <X size={20} />
              </button>
            </div>

            <div className="w-full max-w-4xl aspect-video rounded-3xl overflow-hidden border border-white/10 shadow-2xl bg-black">
              {trailerUrl ? (
                <iframe
                  src={trailerUrl}
                  title={`${media.title} Official Trailer`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                ></iframe>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-center space-y-2">
                  <Film size={40} className="text-[#EAB308]" />
                  <p className="text-xs font-mono">No Trailer video available for this TMDB node.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: ADD TO COLLECTION DRAWER */}
      <AnimatePresence>
        {showCollectionModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-6 max-w-md w-full space-y-6 shadow-2xl relative text-left"
            >
              <button
                onClick={() => setShowCollectionModal(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">VAULT FOLDERS</span>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Add to Collections</h3>
              </div>

              {/* Collections lists with checklist */}
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {collections.length === 0 ? (
                  <p className="text-[11px] text-gray-500 font-mono text-center">No catalog folders structured yet.</p>
                ) : (
                  collections.map((col) => {
                    const existsInCol = col.mediaIds && col.mediaIds.includes(media.id);
                    return (
                      <div 
                        key={col.id} 
                        onClick={() => handleToggleCollectionCheck(col.id, existsInCol)}
                        className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                          existsInCol 
                            ? 'bg-[#E50914]/10 border-[#E50914]/30 text-[#E50914]' 
                            : 'bg-[#111]/40 border-white/5 text-gray-400 hover:bg-[#111]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <FolderHeart size={14} />
                          <span className="text-xs font-bold text-white block">{col.name}</span>
                        </div>
                        <div className="w-5 h-5 rounded border border-white/10 flex items-center justify-center">
                          {existsInCol && <Check size={12} className="text-[#E21010]" />}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Create Custom Folder */}
              <form onSubmit={handleCreateCollection} className="pt-4 border-t border-white/5 flex gap-2">
                <input
                  type="text"
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                  placeholder="Create New Vault Folder..."
                  className="flex-1 bg-[#111] border border-white/5 rounded-xl px-3 py-2 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]/40"
                />
                <button
                  type="submit"
                  className="bg-[#E50914] hover:bg-[#FF1A1A] text-white p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                >
                  <Plus size={16} />
                </button>
              </form>

              <button
                onClick={() => setShowCollectionModal(false)}
                className="w-full bg-[#111] hover:bg-[#1a1a1a] border border-white/5 text-white text-xs font-bold py-3 rounded-xl transition-all uppercase font-mono tracking-wider cursor-pointer"
              >
                Close Vault Checklist
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 3: BROKEN LINK ACTIONABLE OVERLAY */}
      <AnimatePresence>
        {showBrokenLinkModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-6 max-w-md w-full space-y-5 shadow-2xl relative text-left"
            >
              <button
                onClick={() => setShowBrokenLinkModal(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">OPERATIONS FEEDBACK</span>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Broken Stream Report</h3>
              </div>

              <form onSubmit={handleBrokenLinkSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Platform Link</label>
                  <select 
                    value={selectedLinkPlatform} 
                    onChange={(e) => setSelectedLinkPlatform(e.target.value)}
                    className="w-full bg-[#111] border border-white/5 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                  >
                    {details?.ticketLinks && details.ticketLinks.length > 0 ? (
                      details.ticketLinks.map((tc, idx) => (
                        <option key={idx} value={tc.platform}>{tc.platform}</option>
                      ))
                    ) : (
                      <>
                        <option value="Netflix">Netflix</option>
                        <option value="Amazon Prime Video">Amazon Prime Video</option>
                        <option value="Apple TV">Apple TV</option>
                        <option value="Google Play Movies">Google Play Movies</option>
                      </>
                    )}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Report Details</label>
                  <textarea
                    value={brokenLinkDetail}
                    onChange={(e) => setBrokenLinkDetail(e.target.value)}
                    placeholder="Describe issue (e.g. 404 error, takes to incorrect landing page, price changed)..."
                    rows={3}
                    className="w-full bg-[#111] border border-white/5 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#E50914] text-white hover:bg-[#FF1A1A] py-3 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Submit Broken Link Report
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 4: METADATA INCORRECT TICKET OVERLAY */}
      <AnimatePresence>
        {showIncorrectModal && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-6 max-w-md w-full space-y-5 shadow-2xl relative text-left"
            >
              <button
                onClick={() => setShowIncorrectModal(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">METRICS DEVIATION</span>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Database Variance</h3>
              </div>

              <form onSubmit={handleIncorrectMetaSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Discrepancy Group</label>
                  <select 
                    value={incorrectType} 
                    onChange={(e) => setIncorrectType(e.target.value)}
                    className="w-full bg-[#111] border border-white/5 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#E50914]"
                  >
                    <option value="Metadata">Basic Information (Title, Year, Duration)</option>
                    <option value="Cast">Actor & Crew Credits</option>
                    <option value="Trailer">YouTube Video / Clip</option>
                    <option value="Poster">Poster / Backdrop Graphics</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Correct Credentials Specs</label>
                  <textarea
                    value={incorrectDetail}
                    onChange={(e) => setIncorrectDetail(e.target.value)}
                    placeholder="Provide official specifications to support database correction..."
                    rows={3}
                    className="w-full bg-[#111] border border-white/5 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#E50914] text-white hover:bg-[#FF1A1A] py-3 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Verify and Submit Verification Ticket
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 5: AUTHENTICATION REQUIRED REDIRECT OVERLAY */}
      <AnimatePresence>
        {showAuthPromptModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-8 max-w-md w-full space-y-6 shadow-2xl relative text-center"
            >
              <button
                onClick={() => setShowAuthPromptModal(false)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-2">
                <Sparkles size={36} className="text-[#E50914] mx-auto animate-pulse" />
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Authorization Required</h3>
                <p className="text-xs text-gray-400">
                  Authenticate your Muvio Critic credentials to claim tracking logs, custom vaults, and custom reviews.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => onNavigate('/login')}
                  className="bg-[#E50914] hover:bg-[#FF1A1A] text-white p-3.5 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  onClick={() => onNavigate('/register')}
                  className="bg-white/5 hover:bg-white/10 border border-white/10 text-white p-3.5 rounded-xl text-xs font-bold uppercase font-mono tracking-wider cursor-pointer"
                >
                  Create Account
                </button>
              </div>

              <button
                onClick={() => setShowAuthPromptModal(false)}
                className="w-full text-xs font-mono font-medium text-gray-500 hover:text-white transition-colors cursor-pointer"
              >
                Continue as Offline Guest
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 6: DOWNLOAD AD & PROGRESS OVERLAY */}
      <AnimatePresence>
        {downloadModalOpen && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-6 md:p-8 max-w-lg w-full space-y-6 shadow-2xl relative text-center"
            >
              {/* Close Button */}
              <button
                onClick={() => setDownloadModalOpen(false)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/10 cursor-pointer hover:bg-white/10 transition-colors"
                id="btn-close-download-modal"
              >
                <X size={14} />
              </button>

              {/* Top Text */}
              <div className="space-y-1">
                <p className="text-xxs font-mono text-[#E50914] uppercase tracking-widest font-black">Prepping Cinematic Structure</p>
                <h3 className="text-md font-bold text-neutral-200">
                  Your download is being prepared...
                </h3>
              </div>

              {/* AD AREA */}
              <div id="download-ad-slot" className="w-full bg-neutral-900 border border-white/5 rounded-xl h-44 flex flex-col items-center justify-center p-4 relative overflow-hidden group">
                <div className="absolute top-2 left-3 text-[9px] font-mono text-neutral-600 uppercase tracking-widest">
                  Sponsored Space
                </div>
                {/* Ad Content / Placeholder */}
                <span className="text-xxs font-mono text-neutral-500 uppercase tracking-widest bg-white/2 border border-white/5 px-3 py-1.5 rounded-full animate-pulse">
                  Advertisement
                </span>
                <p className="text-[11px] text-neutral-400 font-sans mt-3 max-w-xs text-center leading-relaxed">
                  Support Muvio Cinematic by viewing our curator listings or checking featured prints.
                </p>
              </div>

              {/* Lower Section (Timer or Download Button) */}
              <div className="flex flex-col items-center justify-center space-y-4">
                {!isDownloadReady ? (
                  <>
                    {/* Crimson circular progress indicator */}
                    <div className="relative w-20 h-20 flex items-center justify-center">
                      <svg className="absolute w-full h-full transform -rotate-90">
                        <circle cx="40" cy="40" r="32" className="stroke-white/5" strokeWidth="4" fill="transparent" />
                        <circle 
                          cx="40" 
                          cy="40" 
                          r="32" 
                          className="stroke-[#E50914] transition-all duration-300" 
                          strokeWidth="4" 
                          fill="transparent"
                          strokeDasharray={2 * Math.PI * 32}
                          strokeDashoffset={2 * Math.PI * 32 * (1 - downloadCountdown / Math.max(1, getDownloadTimerDuration()))} 
                        />
                      </svg>
                      <span className="text-2xl font-black font-mono text-white tracking-tighter">
                        {downloadCountdown}
                      </span>
                    </div>

                    <p className="text-xs font-mono text-gray-400">
                      Download link ready in <strong className="text-white text-sm font-sans">{downloadCountdown}</strong> seconds
                    </p>
                  </>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4 w-full"
                  >
                    <p className="text-sm font-bold text-green-400 flex items-center justify-center gap-1.5">
                      <span className="text-lg">✅</span> Your Download is Ready!
                    </p>
                    
                    <a 
                      href={getSelectedDownloadUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        triggerToast(`Downloading ${selectedDownloadQuality} print successfully!`, 'success');
                        setDownloadModalOpen(false);
                      }}
                      className="w-full py-4 bg-[#E50914] hover:bg-[#FF1A1A] text-white font-mono text-xs font-black uppercase tracking-widest rounded-xl transition-all text-center block cursor-pointer shadow-[0_4px_20px_rgba(229,9,20,0.3)] animate-pulse"
                      id="btn-download-now-link"
                    >
                      DOWNLOAD NOW &rarr;
                    </a>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 7: FULL NEWS ARTICLE DETAILS */}
      <AnimatePresence>
        {selectedNews && (
          <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#111111] border border-white/10 rounded-2xl p-6 md:p-8 max-w-2xl w-full space-y-6 shadow-2xl relative text-left overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedNews(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/10 cursor-pointer hover:bg-white/10 transition-colors"
                id="btn-close-news-modal"
              >
                <X size={14} />
              </button>

              {/* Source & Date Metadata */}
              <div className="flex items-center gap-2 text-[11px] font-mono text-[#E50914] uppercase tracking-wider font-bold">
                <span>{selectedNews.source}</span>
                <span>•</span>
                <span>{selectedNews.date}</span>
              </div>

              {/* Title */}
              <h3 className="text-xl md:text-2xl font-black text-white leading-tight uppercase tracking-tight">
                {selectedNews.title}
              </h3>

              {/* Content Body */}
              <div className="text-sm text-gray-300 font-sans leading-relaxed space-y-4 overflow-y-auto pr-2 custom-scrollbar flex-1">
                {selectedNews.content ? (
                  selectedNews.content.split('\n\n').map((para, i) => (
                    <p key={i}>{para}</p>
                  ))
                ) : (
                  <p>{selectedNews.snippet}</p>
                )}
              </div>

              {/* Action Button */}
              <div className="pt-2 flex justify-between items-center border-t border-white/5">
                <span className="text-[10px] font-mono text-gray-500">Muvio News Desks Authorized Archive</span>
                <button
                  onClick={() => setSelectedNews(null)}
                  className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-white font-mono text-xs font-bold uppercase rounded-full transition-all cursor-pointer border border-white/10"
                >
                  Close Article
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
