import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Heart, 
  Trash2, 
  Edit3, 
  FolderHeart, 
  ArrowLeft, 
  Eye, 
  EyeOff, 
  Sparkles, 
  Globe, 
  Lock, 
  Calendar,
  X,
  Play
} from 'lucide-react';
import { triggerToast, UserProfile } from '../lib/firebase';
import { getMediaDetails, MuvioMedia, generateSlug } from '../lib/tmdb';
import { getCustomPublishedMedia } from '../lib/adminCatalog';
import { getUserCollections, updateCollectionItems } from '../lib/userInteractions';

interface CollectionsPageProps {
  onNavigate: (to: string) => void;
  currentUser: UserProfile | null;
  onTriggerAuthPrompt?: () => void;
}

export interface CollectionsItem {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  mediaIds: string[];
  ownerId: string;
  ownerUsername: string;
  isPublic: boolean;
  likesCount: number;
  likedBy: string[]; // List of userIds who saved/liked it
  coverUrl: string;
}

const DEMO_COLLECTION_IDS = ['col_cyberpunk', 'col_horror', 'col_deepspace'];

const INITIAL_PUBLIC_COLLECTIONS: CollectionsItem[] = [];

export default function CollectionsPage({ onNavigate, currentUser, onTriggerAuthPrompt }: CollectionsPageProps) {
  const [activeTab, setActiveTab] = useState<'DISCOVER' | 'MY' | 'SAVED'>('DISCOVER');

  // Load collections
  const [collections, setCollections] = useState<CollectionsItem[]>([]);
  const [collectionsLoaded, setCollectionsLoaded] = useState(false);

  // Fetch and Sync user specific collections inside muvio_collections_list
  useEffect(() => {
    async function loadAndMerge() {
      // Clear old demo data from localStorage if present
      const stored = localStorage.getItem('muvio_collections_list');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          const hasDemoData = parsed.some((c: any) => DEMO_COLLECTION_IDS.includes(c.id));
          if (hasDemoData) {
            localStorage.removeItem('muvio_collections_list');
          }
        } catch (e) {}
      }

      let list: CollectionsItem[] = [];
      const freshData = localStorage.getItem('muvio_collections_list');
      if (freshData) {
        try {
          list = JSON.parse(freshData);
        } catch (e) {}
      }

      if (currentUser) {
        try {
          const userCols = await getUserCollections(currentUser.uid);
          userCols.forEach(uc => {
            const existingIdx = list.findIndex(c => c.id === uc.id);
            if (existingIdx !== -1) {
              list[existingIdx] = {
                ...list[existingIdx],
                mediaIds: uc.mediaIds || [],
                name: uc.name,
              };
            } else {
              const randomImages = [
                "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
                "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=600",
                "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=600",
              ];
              const chosenCover = randomImages[Math.floor(Math.random() * randomImages.length)];
              list.push({
                id: uc.id,
                name: uc.name,
                description: (uc as any).description || 'A curated user playlist.',
                createdAt: uc.createdAt || new Date().toISOString(),
                mediaIds: uc.mediaIds || [],
                ownerId: currentUser.uid,
                ownerUsername: currentUser.username || 'me',
                isPublic: (uc as any).isPublic !== undefined ? (uc as any).isPublic : false,
                likesCount: (uc as any).likesCount || 0,
                likedBy: (uc as any).likedBy || [],
                coverUrl: (uc as any).coverUrl || chosenCover
              });
            }
          });
        } catch (err) {
          console.warn('Error fetching and merging user collections:', err);
        }
      }
      setCollections(list);
      setCollectionsLoaded(true);
    }
    loadAndMerge();
  }, [currentUser]);

  // State for subview collections details — initialize directly from URL
  const [viewState, setViewState] = useState<{ id: string }>(() => {
    const path = window.location.pathname;
    if (path.startsWith('/collections/')) {
      const id = path.replace('/collections/', '');
      return { id };
    }
    return { id: '' };
  });

  // Floating modal setup
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newIsPublic, setNewIsPublic] = useState(true);

  // Sync state pops
  useEffect(() => {
    const checkPath = () => {
      const path = window.location.pathname;
      if (path.startsWith('/collections/')) {
        const id = path.replace('/collections/', '');
        setViewState({ id });
      } else {
        setViewState({ id: '' });
      }
    };

    checkPath();
    window.addEventListener('popstate', checkPath);
    return () => window.removeEventListener('popstate', checkPath);
  }, []);

  const handleOpenCollectionDetail = (id: string) => {
    window.history.pushState(null, '', `/collections/${id}`);
    setViewState({ id });
  };

  const handleBackToList = () => {
    window.history.pushState(null, '', '/collections');
    setViewState({ id: '' });
  };

  const saveCollections = (updated: CollectionsItem[]) => {
    const filtered = updated.filter(c => !DEMO_COLLECTION_IDS.includes(c.id));
    setCollections(filtered);
    localStorage.setItem('muvio_collections_list', JSON.stringify(filtered));
    if (currentUser) {
      updated.forEach(async col => {
        if (col.ownerId === currentUser.uid) {
          try {
            await updateCollectionItems(currentUser.uid, col.id, col.mediaIds);
          } catch (err) {
            console.error('Failed to sync collection item to user storage:', err);
          }
        }
      });
    }
  };

  // Toggle Save/Like (Heart trigger)
  const handleToggleLike = (colId: string) => {
    if (!currentUser) {
      if (onTriggerAuthPrompt) {
        onTriggerAuthPrompt();
      } else {
        triggerToast('Authorise account credentials to save collections.', 'error');
        onNavigate('/login');
      }
      return;
    }

    const updated = collections.map(col => {
      if (col.id === colId) {
        const likedBy = [...col.likedBy];
        const idx = likedBy.indexOf(currentUser.uid);
        let likesCount = col.likesCount;

        if (idx !== -1) {
          likedBy.splice(idx, 1);
          likesCount = Math.max(0, likesCount - 1);
          triggerToast('Removed from saved list.', 'success');
        } else {
          likedBy.push(currentUser.uid);
          likesCount = likesCount + 1;
          triggerToast('Saved to your vault! ❤️', 'success');
        }
        return { ...col, likedBy, likesCount };
      }
      return col;
    });

    saveCollections(updated);
  };

  // Create Collection Action
  const handleCreateCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast('Authentication needed.', 'error');
      return;
    }

    if (!newTitle.trim()) {
      triggerToast('Collection Title is empty.', 'error');
      return;
    }

    const randomImages = [
      "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
      "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=600",
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=600",
    ];
    const chosenCover = randomImages[Math.floor(Math.random() * randomImages.length)];

    const newCol: CollectionsItem = {
      id: 'col_' + Math.random().toString(36).substring(2, 11),
      name: newTitle.trim(),
      description: newDesc.trim() || 'A curated selection of cinematic archives waiting for deployment and analysis.',
      createdAt: new Date().toISOString(),
      mediaIds: [],
      ownerId: currentUser.uid,
      ownerUsername: currentUser.username,
      isPublic: newIsPublic,
      likesCount: 0,
      likedBy: [],
      coverUrl: chosenCover
    };

    saveCollections([...collections, newCol]);
    setNewTitle('');
    setNewDesc('');
    setNewIsPublic(true);
    setShowCreateModal(false);
    triggerToast('Collection Vault Created Successfully! 🎬', 'success');
  };

  // Extract public list
  const publicCols = collections.filter(c => c.isPublic);

  // Extract own list
  const myCols = currentUser ? collections.filter(c => c.ownerId === currentUser.uid) : [];

  // Extract saved list
  const savedCols = currentUser ? collections.filter(c => c.likedBy.includes(currentUser.uid)) : [];

  if (viewState.id) {
    const targetCol = collections.find(c => c.id === viewState.id);
    if (!targetCol) {
      if (!collectionsLoaded) {
        return (
          <div className="text-center py-20">
            <span className="text-2xs font-mono text-gray-500 animate-pulse">LOADING COLLECTION...</span>
          </div>
        );
      }
      return (
        <div className="text-center py-20">
          <h2 className="text-xl font-bold font-mono">COLLECTION INDEX ERROR</h2>
          <p className="text-xs text-gray-400 mt-1">We couldn&apos;t load the parameters for this vault index.</p>
          <button onClick={handleBackToList} className="mt-4 px-5 py-2 bg-[#E50914] text-xs font-bold font-mono rounded-lg uppercase">
            Back to Collections
          </button>
        </div>
      );
    }
    return (
      <CollectionDetailView 
        collection={targetCol}
        allCollections={collections}
        onSaveCollections={saveCollections}
        currentUser={currentUser}
        onBack={handleBackToList}
        onNavigate={onNavigate}
        onToggleLike={handleToggleLike}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 text-left">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">
            MUVIO CUSTOM PLAYBOOKS
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight">
            Curated Collections
          </h2>
          <p className="text-2xs text-gray-400 font-mono mt-0.5 max-w-sm">
            Discover hyper-focused public study folders, or design private checklists to manage your movie archives.
          </p>
        </div>

        {/* HIGH-END METRO TABS */}
        <div className="flex bg-[#111111]/90 p-1 border border-white/5 rounded-2xl self-start md:self-auto">
          <button
            onClick={() => setActiveTab('DISCOVER')}
            className={`px-4 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'DISCOVER'
                ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Discover
          </button>
          <button
            onClick={() => setActiveTab('MY')}
            className={`px-4 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'MY'
                ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            My Collections
          </button>
          <button
            onClick={() => setActiveTab('SAVED')}
            className={`px-4 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'SAVED'
                ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Saved
          </button>
        </div>
      </div>

      {/* RENDER PAGES */}
      <AnimatePresence mode="wait">
        {activeTab === 'DISCOVER' && (
          <motion.div
            key="discover"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {publicCols.map((col) => {
              const isLiked = currentUser && col.likedBy.includes(currentUser.uid);
              return (
                <div
                  key={col.id}
                  className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2.5rem] overflow-hidden flex flex-col justify-between transition-all group hover:shadow-xl cursor-pointer"
                  onClick={() => handleOpenCollectionDetail(col.id)}
                >
                  <div className="w-full h-40 bg-zinc-900 overflow-hidden relative">
                    <img src={col.coverUrl} alt={col.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-103" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                    <span className="absolute top-3 left-3 bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-[8px] font-mono font-bold uppercase text-white flex items-center gap-1">
                      <Globe size={10} className="text-red-500" /> Public Folder
                    </span>

                    {/* Likes/Save count selector */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleLike(col.id);
                      }}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white cursor-pointer hover:bg-neutral-900 transition-colors"
                    >
                      <Heart size={13} className={isLiked ? 'fill-red-500 text-red-500' : 'text-gray-300'} />
                    </button>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5">
                      <h3 className="text-base md:text-lg font-black text-white group-hover:text-[#E50914] transition-colors uppercase tracking-tight">
                        {col.name}
                      </h3>
                      <p className="text-2xs text-gray-400 line-clamp-2 leading-relaxed">
                        {col.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-white/5 text-[10px] font-mono text-gray-500">
                      <span>Owner: <strong className="text-gray-300">@{col.ownerUsername}</strong></span>
                      <div className="flex gap-3 text-white font-bold">
                        <span>{col.mediaIds.length} ITEMS</span>
                        <span>•</span>
                        <span>{col.likesCount} SAVES</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {activeTab === 'MY' && (
          <motion.div
            key="my_collections"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            {/* FLOATING FAB ACTION */}
            <div className="flex justify-between items-center pl-1">
              <h3 className="text-xs font-black text-gray-400 font-mono uppercase tracking-widest">
                My Custom Folders
              </h3>

              <button
                onClick={() => {
                  if (!currentUser) {
                    if (onTriggerAuthPrompt) {
                      onTriggerAuthPrompt();
                    } else {
                      triggerToast('Login credentials required.', 'error');
                      onNavigate('/login');
                    }
                  } else {
                    setShowCreateModal(true);
                  }
                }}
                className="px-5 py-2.5 rounded-xl bg-[#E50914] hover:bg-red-600 text-white font-mono text-3xs font-black uppercase tracking-widest cursor-pointer shadow-lg shadow-[#E50914]/20 flex items-center gap-1.5"
              >
                <Plus size={12} /> Create Folder
              </button>
            </div>

            {myCols.length === 0 ? (
              <div className="p-16 border-2 border-dashed border-white/5 rounded-[2.5rem] text-center space-y-3 bg-[#0a0a0a]/30">
                <FolderHeart size={44} className="mx-auto text-gray-600 stroke-1" />
                <div className="space-y-1 max-w-sm mx-auto">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider font-mono">No created collections in vault</h4>
                  <p className="text-2xs text-gray-400">Launch a new custom folder schema using the Floating Creator Button.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {myCols.map((col) => (
                  <div
                    key={col.id}
                    className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2.5rem] overflow-hidden flex flex-col justify-between transition-all group hover:shadow-xl cursor-pointer"
                    onClick={() => handleOpenCollectionDetail(col.id)}
                  >
                    <div className="w-full h-40 bg-zinc-900 overflow-hidden relative">
                      <img src={col.coverUrl} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-103" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                      
                      <span className="absolute top-3 left-3 bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-[8px] font-mono font-bold uppercase text-white flex items-center gap-1">
                        {col.isPublic ? (
                          <>
                            <Globe size={10} className="text-emerald-400" /> Public Folder
                          </>
                        ) : (
                          <>
                            <Lock size={10} className="text-amber-500" /> Private Vault
                          </>
                        )}
                      </span>
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-1.5">
                        <h3 className="text-base md:text-lg font-black text-white group-hover:text-[#E50914] transition-colors uppercase tracking-tight">
                          {col.name}
                        </h3>
                        <p className="text-2xs text-gray-400 font-sans leading-relaxed line-clamp-2">
                          {col.description}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-white/5 text-[10px] font-mono text-gray-500">
                        <span>Created {new Date(col.createdAt).toLocaleDateString()}</span>
                        <div className="flex gap-2 text-white font-bold text-[9px] uppercase">
                          <span>{col.mediaIds.length} ITEMS</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'SAVED' && (
          <motion.div
            key="saved"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4"
          >
            {savedCols.length === 0 ? (
              <div className="p-16 border-2 border-dashed border-white/5 rounded-[2.5rem] text-center space-y-3 bg-[#0a0a0a]/30">
                <Heart size={44} className="mx-auto text-gray-600 stroke-1" />
                <div className="space-y-1 max-w-sm mx-auto">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider font-mono">No Saved Collections Exist</h4>
                  <p className="text-2xs text-gray-400">Explore and Heart public playbooks in the Discover Tab directory.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {savedCols.map((col) => (
                  <div
                    key={col.id}
                    className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2.5rem] overflow-hidden flex flex-col justify-between transition-all group hover:shadow-xl cursor-pointer"
                    onClick={() => handleOpenCollectionDetail(col.id)}
                  >
                    <div className="w-full h-40 bg-zinc-900 overflow-hidden relative">
                      <img src={col.coverUrl} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-103" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                      
                      <span className="absolute top-3 left-3 bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-[8px] font-mono font-bold uppercase text-white flex items-center gap-1">
                        <Globe size={10} className="text-red-500" /> Public Folder
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleLike(col.id);
                        }}
                        className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-[#E50914] cursor-pointer"
                      >
                        <Heart size={13} className="fill-[#E50914]" />
                      </button>
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-1.5">
                        <h3 className="text-base md:text-lg font-black text-white group-hover:text-[#E50914] transition-colors uppercase tracking-tight">
                          {col.name}
                        </h3>
                        <p className="text-2xs text-gray-400 line-clamp-2">
                          {col.description}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-white/5 text-[10px] font-mono text-gray-500">
                        <span>Curated by: <strong className="text-gray-300">@{col.ownerUsername}</strong></span>
                        <div className="flex gap-2 text-white font-bold text-[9px] uppercase">
                          <span>{col.mediaIds.length} ITEMS</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* COMPONENT CREATION MODAL */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#0b0b0b] border border-white/10 w-full max-w-md rounded-[2rem] overflow-hidden shadow-2xl space-y-5 p-6 relative"
            >
              <button
                onClick={() => setShowCreateModal(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>

              <div className="space-y-1 text-left">
                <span className="text-[#E50914] text-[9px] font-mono font-black tracking-widest block uppercase">CREATOR DICTIONARY</span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight">Create Collection Folder</h3>
              </div>

              <form onSubmit={handleCreateCollection} className="space-y-4 text-left">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-400 uppercase font-black">Folder Title</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Masterpieces of Cyber Intel"
                    className="w-full bg-black border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]"
                    maxLength={50}
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-400 uppercase font-black">Description</label>
                  <textarea
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Detail the thematic focus or content metrics inside this compiled portfolio..."
                    rows={3}
                    className="w-full bg-black border border-white/10 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914] leading-relaxed"
                    maxLength={250}
                  />
                </div>

                {/* PUBLIC_PRIVATE SLIDER TOGGLE */}
                <div className="flex items-center justify-between p-3 bg-white/2 rounded-xl border border-white/5">
                  <div className="text-[11px] font-mono">
                    <span className="text-white font-bold block uppercase tracking-tight">Public Directory</span>
                    <span className="text-gray-500 text-[9px] block">Allow other cinephiles to save and search details.</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setNewIsPublic(!newIsPublic)}
                    className={`w-12 h-6.5 rounded-full p-0.5 transition-colors cursor-pointer flex ${newIsPublic ? 'bg-red-600 justify-end' : 'bg-neutral-800 justify-start'}`}
                  >
                    <motion.div layout className="w-5.5 h-5.5 rounded-full bg-white shadow" />
                  </button>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold text-3xs font-mono tracking-widest uppercase transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-[#E50914] hover:bg-red-600 text-white font-bold text-3xs font-mono tracking-widest uppercase transition-colors cursor-pointer shadow-lg shadow-[#E50914]/25"
                  >
                    Deploy Folder
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}


// =========================================
// COLLECTION DETAILED SUB VIEW
// =========================================
interface DetailViewProps {
  collection: CollectionsItem;
  allCollections: CollectionsItem[];
  onSaveCollections: (list: CollectionsItem[]) => void;
  currentUser: UserProfile | null;
  onBack: () => void;
  onNavigate: (to: string) => void;
  onToggleLike: (id: string) => void;
}

function CollectionDetailView({
  collection,
  allCollections,
  onSaveCollections,
  currentUser,
  onBack,
  onNavigate,
  onToggleLike
}: DetailViewProps) {
  const [resolvedItems, setResolvedItems] = useState<MuvioMedia[]>([]);
  const [loading, setLoading] = useState(true);

  // Edit states
  const [showEditModal, setShowEditModal] = useState(false);
  const [editTitle, setEditTitle] = useState(collection.name);
  const [editDesc, setEditDesc] = useState(collection.description);
  const [editIsPublic, setEditIsPublic] = useState(collection.isPublic);

  const isOwner = currentUser && collection.ownerId === currentUser.uid;
  const isSaved = currentUser && collection.likedBy.includes(currentUser.uid);

  // Add Content Modal States
  const [showAddContentModal, setShowAddContentModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MuvioMedia[]>([]);

  // Load matches from our local published database
  useEffect(() => {
    try {
      const allMedia = getCustomPublishedMedia();
      if (!searchQuery.trim()) {
        setSearchResults(allMedia);
      } else {
        const filtered = allMedia.filter(media => 
          media.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (media.description && media.description.toLowerCase().includes(searchQuery.toLowerCase()))
        );
        setSearchResults(filtered);
      }
    } catch (err) {
      console.warn('Failed to filter database catalog search:', err);
    }
  }, [searchQuery, showAddContentModal]);

  const handleAddMediaToCollection = (media: MuvioMedia) => {
    if (!isOwner) return;

    if (collection.mediaIds.includes(media.id)) {
      triggerToast('Item already present within this folder collection!', 'error');
      return;
    }

    const nextMediaIds = [...collection.mediaIds, media.id];
    const updated = allCollections.map(c => {
      if (c.id === collection.id) {
        return { ...c, mediaIds: nextMediaIds };
      }
      return c;
    });

    onSaveCollections(updated);
    triggerToast(`'${media.title}' successfully catalogued in this folder!`, 'success');
  };

  // Resolution loader
  useEffect(() => {
    async function loadMediaItems() {
      setLoading(true);
      const list: MuvioMedia[] = [];
      const mediaList = collection.mediaIds || [];

      for (const mediaId of mediaList) {
        const match = mediaId.match(/^(movie|tv|show|anime)-(\d+)$/i);
        if (match) {
          const typeStr = match[1].toLowerCase();
          const tmdbType = (typeStr === 'movie') ? 'movie' : 'tv';
          const tmdbId = parseInt(match[2], 10);
          try {
            const item = await getMediaDetails(tmdbType, tmdbId);
            if (item) {
              list.push(item);
            }
          } catch (err) {
            console.error('Failed to parse collect item:', err);
          }
        }
      }
      setResolvedItems(list);
      setLoading(false);
    }
    loadMediaItems();
  }, [collection.mediaIds]);

  // Edit submit
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim()) return;

    const updated = allCollections.map(c => {
      if (c.id === collection.id) {
        return {
          ...c,
          name: editTitle.trim(),
          description: editDesc.trim(),
          isPublic: editIsPublic
        };
      }
      return c;
    });

    onSaveCollections(updated);
    setShowEditModal(false);
    triggerToast('Collection metadata reconfigured!', 'success');
  };

  // Delete Action
  const handleDeleteCollection = () => {
    if (window.confirm('Write access security verification check: Are you absolutely certain you wish to delete this collection directory?')) {
      const updated = allCollections.filter(c => c.id !== collection.id);
      onSaveCollections(updated);
      triggerToast('Vault index purged.', 'success');
      onBack();
    }
  };

  // Unlink item from collection
  const handleRemoveItem = (mediaId: string) => {
    if (!isOwner) return;

    const nextMediaIds = collection.mediaIds.filter(id => id !== mediaId);
    const updated = allCollections.map(c => {
      if (c.id === collection.id) {
        return { ...c, mediaIds: nextMediaIds };
      }
      return c;
    });

    onSaveCollections(updated);
    triggerToast('Item removed from folder.', 'success');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 text-left">
      {/* NAVIGATION BAR */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-mono font-bold text-gray-400 hover:text-white transition-all cursor-pointer uppercase py-1 border-b border-transparent hover:border-white/10"
        >
          <ArrowLeft size={14} /> Back to Directory
        </button>

        {isOwner && (
          <div className="flex gap-2">
            <button
              onClick={() => setShowEditModal(true)}
              className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 rounded-lg text-3xs font-black font-mono tracking-widest text-[#E50914] border border-white/5 uppercase transition-all cursor-pointer flex items-center gap-1"
            >
              <Edit3 size={11} /> Edit metadata
            </button>
            <button
              onClick={handleDeleteCollection}
              className="px-3.5 py-2 bg-red-600/10 hover:bg-red-600/25 border border-red-500/20 rounded-lg text-3xs font-black font-mono tracking-widest text-red-400 uppercase transition-all cursor-pointer flex items-center gap-1"
            >
              <Trash2 size={11} /> Purge Vault
            </button>
          </div>
        )}
      </div>

      {/* HERO HERO DETAILS OF COLLECTION */}
      <div className="bg-[#0b0b0b] border border-white/5 rounded-[2.5rem] overflow-hidden">
        <div className="w-full h-56 md:h-72 bg-zinc-950/80 border-b border-white/5 relative">
          <img src={collection.coverUrl} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>

          <div className="absolute top-4 left-4 flex gap-1.5">
            <span className="bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-[8.5px] font-mono font-black uppercase text-white flex items-center gap-1">
              {collection.isPublic ? (
                <>
                  <Globe size={10} className="text-emerald-400" /> Public Folder
                </>
              ) : (
                <>
                  <Lock size={10} className="text-amber-500" /> Private Folder
                </>
              )}
            </span>
          </div>

          {!isOwner && (
            <button
              onClick={() => onToggleLike(collection.id)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white cursor-pointer hover:bg-neutral-950"
            >
              <Heart size={14} className={isSaved ? 'fill-[#E50914] text-[#E50914]' : 'text-gray-300'} />
            </button>
          )}

          <div className="absolute bottom-5 left-5 right-5 space-y-2">
            <h1 className="text-xl md:text-3xl font-black text-white uppercase tracking-tight leading-none">
              {collection.name}
            </h1>
            <p className="text-2xs md:text-sm text-gray-300 font-sans leading-relaxed max-w-xl line-clamp-2">
              {collection.description}
            </p>
          </div>
        </div>

        {/* METADATA STRIP */}
        <div className="px-5 md:px-8 py-4 bg-white/2 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-2.5 text-[10px] font-mono text-gray-500">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-[#E50914]/10 border border-[#E50914]/25 flex items-center justify-center text-[#E50914] font-black">
              C
            </div>
            <span>Curated by: <strong className="text-gray-300">@{collection.ownerUsername}</strong></span>
          </div>

          <div className="flex gap-4">
            <span className="flex items-center gap-1">
              <Calendar size={11} /> Imported {new Date(collection.createdAt).toLocaleDateString()}
            </span>
            <span className="font-bold text-white text-[9px] uppercase tracking-wider bg-white/5 px-2.5 py-1 rounded border border-white/5">
              {collection.mediaIds.length} FILES CATALOGUED
            </span>
          </div>
        </div>
      </div>

      {/* ITEMS ROW DISPLAY */}
      <div className="space-y-4 text-left">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-gray-400 font-mono uppercase tracking-widest pl-1">
            Catalogued Items inside folder
          </h3>
          {isOwner && (
            <button
              onClick={() => setShowAddContentModal(true)}
              className="px-4 py-2 bg-[#E50914] hover:bg-red-600 rounded-xl text-3xs font-black font-mono tracking-widest uppercase transition-all cursor-pointer flex items-center gap-1.5 shadow-lg shadow-[#E50914]/20"
            >
              <Plus size={12} /> Add Content
            </button>
          )}
        </div>

        {loading ? (
          <div className="text-center py-20 bg-[#0b0b0b]/20 border border-white/5 rounded-2xl">
            <span className="text-2xs font-mono text-gray-500 animate-pulse">RECONSTRUCTING MEDIA RECORDS FROM TMDB...</span>
          </div>
        ) : resolvedItems.length === 0 ? (
          <div className="p-16 border border-dashed border-white/5 rounded-[2.5rem] bg-[#0b0b0b]/10 text-center space-y-4">
            <span className="text-4xs font-black font-mono tracking-widest block uppercase text-red-500">SYSTEM EMPTY STATE</span>
            <p className="text-xs text-gray-400 font-sans max-w-sm mx-auto">
              This folder directory does not contain any cinematic files. Add items from our database.
            </p>
            <div className="flex gap-3 justify-center">
              {isOwner && (
                <button
                  onClick={() => setShowAddContentModal(true)}
                  className="px-5 py-2.5 bg-[#E50914] hover:bg-red-600 rounded-xl text-3xs font-black font-mono tracking-widest uppercase transition-all cursor-pointer"
                >
                  Add Content
                </button>
              )}
              <button
                onClick={() => onNavigate('/explore')}
                className="px-5 py-2.5 bg-neutral-900 border border-white/5 hover:bg-neutral-800 rounded-xl text-3xs font-black font-mono tracking-widest uppercase transition-all cursor-pointer text-gray-400 hover:text-white"
              >
                Explore Database Catalog
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {resolvedItems.map((media) => (
              <div
                key={media.id}
                onClick={() => onNavigate(`/content/${media.id}`)}
                className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2rem] overflow-hidden group hover:shadow-xl transition-all relative cursor-pointer flex flex-col justify-between"
              >
                <div className="w-full aspect-[2/3] bg-zinc-900 overflow-hidden relative">
                  <img src={media.posterUrl} className="w-full h-full object-cover group-hover:scale-104 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
                  
                  {isOwner && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveItem(media.id);
                      }}
                      className="absolute top-2.5 right-2.5 w-7.5 h-7.5 rounded-full bg-black/8 w-2/5 border border-white/10 hover:bg-red-600/90 text-gray-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                      title="Remove item"
                    >
                      <X size={11} />
                    </button>
                  )}

                  <span className="absolute bottom-2.5 left-2.5 bg-black/70 border border-white/10 px-2 py-0.5 rounded text-[8px] font-mono font-black text-white tracking-widest uppercase">
                    {media.type}
                  </span>
                </div>

                <div className="p-3 text-left space-y-1">
                  <h4 className="text-xs md:text-sm font-black text-white uppercase group-hover:text-[#E50914] transition-colors leading-tight truncate">
                    {media.title}
                  </h4>
                  <p className="text-[10px] font-mono text-gray-500 font-bold uppercase">
                    Released {media.year} • {media.ratingPercent}% rating
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* EDIT MODAL */}
      <AnimatePresence>
        {showEditModal && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#0b0b0b] border border-white/10 w-full max-w-sm rounded-[2rem] p-6 space-y-4 relative text-left"
            >
              <button
                onClick={() => setShowEditModal(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>

              <h3 className="text-lg font-black text-white uppercase tracking-tight">Edit Folder Settings</h3>

              <form onSubmit={handleEditSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-400 uppercase font-black">Title</label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E50914]"
                    maxLength={50}
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-400 uppercase font-black">Description</label>
                  <textarea
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    rows={3}
                    className="w-full bg-black border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#E50914] leading-relaxed"
                    maxLength={250}
                  />
                </div>

                <div className="flex items-center justify-between p-3 bg-white/2 rounded-xl border border-white/5">
                  <span className="text-xs font-mono text-gray-300 block uppercase font-bold tracking-tight">Public Directory</span>
                  <button
                    type="button"
                    onClick={() => setEditIsPublic(!editIsPublic)}
                    className={`w-12 h-6.5 rounded-full p-0.5 transition-colors cursor-pointer flex ${editIsPublic ? 'bg-red-600 justify-end' : 'bg-neutral-800 justify-start'}`}
                  >
                    <motion.div layout className="w-5.5 h-5.5 rounded-full bg-white shadow" />
                  </button>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold font-mono text-3xs uppercase tracking-widest cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-[#E50914] hover:bg-red-600 text-white font-bold font-mono text-3xs uppercase tracking-widest cursor-pointer shadow-lg shadow-[#E50914]/25"
                  >
                    Confirm Configuration
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ADD CONTENT SEARCH OVERLAY */}
      <AnimatePresence>
        {showAddContentModal && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#0b0b0b] border border-white/10 w-full max-w-lg rounded-[2.5rem] p-6 space-y-4 relative text-left flex flex-col max-h-[85vh]"
            >
              <button
                onClick={() => {
                  setShowAddContentModal(false);
                  setSearchQuery('');
                }}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
              >
                <X size={14} />
              </button>

              <div className="space-y-1 pr-10">
                <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">DATABASE CATALOG SYSTEM</span>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Index Files to Folder</h3>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search database movies, shows, anime..."
                  className="w-full bg-black border border-white/10 rounded-xl pl-4 pr-10 py-3 text-xs text-white focus:outline-none focus:border-[#E50914] transition-all"
                />
              </div>

              {/* Items Panel */}
              <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[45vh] pr-1.5 custom-scrollbar">
                {searchResults.length === 0 ? (
                  <div className="text-center py-10 opacity-40">
                    <p className="text-xs font-mono">No matching database archives located.</p>
                  </div>
                ) : (
                  searchResults.map(media => {
                    const alreadyPresent = collection.mediaIds && collection.mediaIds.includes(media.id);
                    return (
                      <div
                        key={media.id}
                        className={`p-3 rounded-2xl border flex items-center justify-between gap-4 transition-all ${
                          alreadyPresent
                            ? 'bg-[#E50914]/5 border-[#E50914]/20 opacity-60'
                            : 'bg-black/40 border-white/5 hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={media.posterUrl}
                            alt=""
                            className="w-10 h-14 rounded-lg object-cover bg-neutral-900 flex-shrink-0"
                          />
                          <div className="min-w-0">
                            <h4 className="text-xs font-bold text-white uppercase truncate">{media.title}</h4>
                            <p className="text-[10px] font-mono text-gray-500 font-bold uppercase mt-0.5">
                              {media.type} • {media.year} • {media.ratingPercent}% Rating
                            </p>
                          </div>
                        </div>

                        <button
                          disabled={alreadyPresent}
                          onClick={() => handleAddMediaToCollection(media)}
                          className={`px-3 py-1.5 rounded-lg text-[9px] font-bold font-mono tracking-widest uppercase transition-all whitespace-nowrap cursor-pointer ${
                            alreadyPresent
                              ? 'bg-neutral-800 text-gray-500 cursor-not-allowed'
                              : 'bg-[#E50914] hover:bg-red-600 text-white shadow-lg shadow-[#E50914]/15'
                          }`}
                        >
                          {alreadyPresent ? 'Indexed' : '+ Index File'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="pt-2 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddContentModal(false);
                    setSearchQuery('');
                  }}
                  className="w-full py-3 rounded-xl bg-[#111] hover:bg-[#1a1a1a] border border-white/5 text-xs text-white font-bold font-mono uppercase tracking-wider transition-all cursor-pointer"
                >
                  Close Catalog Directory
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
