import React from 'react';
import { Compass, Calendar, Tv, FolderHeart, User } from 'lucide-react';
import { AppRoute, NavItem } from '../types';

interface BottomNavigationProps {
  currentPath: string;
  onNavigate: (route: AppRoute) => void;
}

export default function BottomNavigation({ currentPath, onNavigate }: BottomNavigationProps) {
  const usePathname = () => currentPath;
  const pathname = usePathname();
  const hideNav = ['/', '/login', '/register', '/forgot-password'].includes(pathname);

  if (hideNav) return null;

  const items: NavItem[] = [
    { id: 'explore', name: 'Explore', label: 'Explore', href: '/explore', iconName: 'Compass' },
    { id: 'schedule', name: 'Schedule', label: 'Schedule', href: '/schedule', iconName: 'Calendar' },
    { id: 'spaces', name: 'Spaces', label: 'Spaces', href: '/spaces', iconName: 'Tv' },
    { id: 'collections', name: 'Collections', label: 'Collections', href: '/collections', iconName: 'FolderHeart' },
    { id: 'profile', name: 'Profile', label: 'Profile', href: '/profile', iconName: 'User' },
  ];

  const renderIcon = (name: string, isActive: boolean) => {
    const size = 20;
    const className = `transition-transform duration-300 ${isActive ? 'scale-110 text-white' : 'text-gray-400 group-hover:text-white'}`;
    
    switch (name) {
      case 'Compass':
        return <Compass size={size} className={className} />;
      case 'Calendar':
        return <Calendar size={size} className={className} />;
      case 'Tv':
        return <Tv size={size} className={className} />;
      case 'FolderHeart':
        return <FolderHeart size={size} className={className} />;
      case 'User':
        return <User size={size} className={className} />;
      default:
        return <Compass size={size} className={className} />;
    }
  };

  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 w-auto max-w-[95%] select-none px-4" id="bottom-nav-container">
      <nav 
        className="bg-[#111111]/80 border border-white/10 backdrop-blur-2xl rounded-[32px] p-1.5 flex items-center gap-1 shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
        id="bottom-floating-bar"
      >
        {items.map((item) => {
          const isActive = currentPath === item.href || (item.href === '/explore' && currentPath === '/');
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.href)}
              className={`transition-all duration-300 outline-none cursor-pointer ${
                isActive 
                  ? 'flex items-center gap-2.5 px-5 py-3 bg-[#E50914] rounded-full shadow-[0_0_20px_rgba(229,9,20,0.4)] text-white font-bold' 
                  : 'flex flex-col items-center justify-center w-16 sm:w-20 py-1.5 text-gray-400 hover:text-[#E50914] group'
              }`}
              id={`nav-item-${item.id}`}
            >
              <div className="flex items-center justify-center">
                {renderIcon(item.iconName, isActive)}
              </div>
              
              {isActive ? (
                <span className="text-xs font-bold font-display tracking-tight whitespace-nowrap">
                  {item.label}
                </span>
              ) : (
                <span className="text-[9px] font-black uppercase tracking-wider opacity-40 group-hover:opacity-100 transition-opacity mt-0.5 whitespace-nowrap hidden sm:block">
                  {item.label === 'Collections' ? 'Vaults' : item.label}
                </span>
              )}

              {/* Simple tooltip on hover for mobile screens in inactive state */}
              {!isActive && (
                <span 
                  className="absolute bottom-14 scale-0 group-hover:scale-100 transition-all duration-200 bg-[#0a0a0a]/95 text-white font-mono text-[9px] px-2 py-1 rounded-md border border-white/10 shadow-lg sm:hidden pointer-events-none select-none z-50 whitespace-nowrap"
                >
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
