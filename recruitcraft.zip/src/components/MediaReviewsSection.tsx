import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  MessageSquare, 
  MoreHorizontal, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  Eye, 
  EyeOff, 
  Flag, 
  UserPlus, 
  UserMinus,
  CornerDownRight,
  Send,
  Sparkles,
  Award,
  Plus
} from 'lucide-react';
import { MuvioReview, MuvioComment } from '../types';
import { triggerToast, UserProfile } from '../lib/firebase';
import {
  getReviewsForMedia,
  saveReview,
  deleteReview,
  toggleLikeReview,
  getCommentsForReview,
  saveComment,
  deleteComment,
  toggleLikeComment,
  getUserProfileByUserId
} from '../lib/userInteractions';

interface MediaReviewsSectionProps {
  mediaId: string;
  mediaTitle: string;
  currentUser: UserProfile | null;
  onTriggerAuthPrompt: () => void;
  onReviewsChange?: (reviews: MuvioReview[]) => void;
}

export default function MediaReviewsSection({
  mediaId,
  mediaTitle,
  currentUser,
  onTriggerAuthPrompt,
  onReviewsChange
}: MediaReviewsSectionProps) {
  // Reviews List and filter state
  const [reviews, setReviews] = useState<MuvioReview[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Reviewer Profiles Cache Map and Fetched ID set track
  const [reviewerProfiles, setReviewerProfiles] = useState<Record<string, any>>({});
  const fetchedUserIdsRef = useRef<Set<string>>(new Set());
  
  // Filters: 'liked' | 'spoilers' | 'following'
  // Selected filter shifts review list order or visibility
  const [selectedFilter, setSelectedFilter] = useState<'LIKES' | 'NEWEST' | 'FOLLOWING'>('NEWEST');
  const [showSpoilersByDefault, setShowSpoilersByDefault] = useState(false);

  // Followed UserIDs loaded from Local Storage fallback list
  const [followedUserIds, setFollowedUserIds] = useState<string[]>(() => {
    return JSON.parse(localStorage.getItem('muvio_followed_users') || '[]');
  });

  // State: Expanded "Read More" for long reviews
  const [expandedReviews, setExpandedReviews] = useState<Record<string, boolean>>({});
  
  // State: Revealed spoilers for specific review cards
  const [revealedSpoilers, setRevealedSpoilers] = useState<Record<string, boolean>>({});

  // Write review form block states
  const [rating, setRating] = useState<'SKIP' | 'TIMEPASS' | 'GO FOR IT' | 'PERFECTION'>('GO FOR IT');
  const [reviewText, setReviewText] = useState('');
  const [isSpoiler, setIsSpoiler] = useState(false);
  const [formPosting, setFormPosting] = useState(false);
  const [isEditingExisting, setIsEditingExisting] = useState(false);
  const [editingReviewId, setEditingReviewId] = useState<string | null>(null);

  // Active expanded comments block of general reviews
  // Map of reviewId -> boolean
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  // Comments database snapshot: reviewId -> list of MuvioComment objects
  const [commentsMap, setCommentsMap] = useState<Record<string, MuvioComment[]>>({});
  // Replying text form open state: maps to Level 1 commentId or null
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  // Individual comment draft texts for review level (top level comments): reviewId -> string
  const [topCommentDrafts, setTopCommentDrafts] = useState<Record<string, string>>({});

  // Max reviews visibility expansion count
  const [visibleCount, setVisibleCount] = useState(5);

  // General Card Dropdowns Menu States
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Refresh reviews from storage/Firestore
  const loadReviewsData = async () => {
    setLoading(true);
    try {
      const snap = await getReviewsForMedia(mediaId);
      setReviews(snap);
      onReviewsChange?.(snap);

      // Pre-discover if current logged-in user already left a review to initiate Edit Mode
      if (currentUser) {
        const userReview = snap.find((r) => r.userId === currentUser.uid);
        if (userReview) {
          setRating(userReview.rating);
          setReviewText(userReview.text);
          setIsSpoiler(userReview.spoiler);
          setIsEditingExisting(true);
          setEditingReviewId(userReview.id);
        } else {
          setIsEditingExisting(false);
          setEditingReviewId(null);
          setReviewText('');
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReviewsData();
  }, [mediaId, currentUser]);

  useEffect(() => {
    if (reviews.length === 0) return;
    const uniqueUserIds: string[] = Array.from(new Set<string>(reviews.map((r) => r.userId)));
    const missingUserIds: string[] = uniqueUserIds.filter((uid: string) => !fetchedUserIdsRef.current.has(uid));

    if (missingUserIds.length === 0) return;

    // Mark as fetching/fetched immediately to prevent duplicates
    missingUserIds.forEach((uid: string) => fetchedUserIdsRef.current.add(uid));

    let active = true;

    const fetchProfiles = async () => {
      const fetched: Record<string, any> = {};
      await Promise.all(
        missingUserIds.map(async (uid: string) => {
          try {
            const profile = await getUserProfileByUserId(uid);
            if (profile) {
              fetched[uid] = profile;
            }
          } catch (err) {
            console.warn(`Failed to fetch user profile for ${uid}:`, err);
          }
        })
      );

      if (active && Object.keys(fetched).length > 0) {
        setReviewerProfiles((prev) => ({
          ...prev,
          ...fetched
        }));
      }
    };

    fetchProfiles();

    return () => {
      active = false;
    };
  }, [reviews]);

  // Load comments for a specific review when comments block toggles
  const handleToggleComments = async (reviewId: string) => {
    if (expandedComments[reviewId]) {
      // Collapse
      setExpandedComments(prev => ({ ...prev, [reviewId]: false }));
      return;
    }

    try {
      const comments = await getCommentsForReview(reviewId);
      setCommentsMap(prev => ({ ...prev, [reviewId]: comments }));
      setExpandedComments(prev => ({ ...prev, [reviewId]: true }));
    } catch (error) {
      console.error('Failed to load review comments:', error);
    }
  };

  // Human date formatter
  const formatRelativeTime = (isoString: string): string => {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    if (isNaN(diffMs)) return 'recently';
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSecs < 60) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays}d ago`;
  };

  // Perform Like of review
  const handleLikeReview = async (e: React.MouseEvent, review: MuvioReview) => {
    e.stopPropagation();
    if (!currentUser) {
      onTriggerAuthPrompt();
      return;
    }

    try {
      const nextLikesList = await toggleLikeReview(
        currentUser.uid,
        review.id,
        review.userId,
        mediaId,
        currentUser.name || currentUser.username
      );

      // In place updating
      setReviews(prev =>
        prev.map(r => r.id === review.id ? { ...r, likedBy: nextLikesList } : r)
      );
    } catch (err) {
      triggerToast('Like Operation encountered failure', 'error');
    }
  };

  // Submit main review action
  const handlePostReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onTriggerAuthPrompt();
      return;
    }

    if (!reviewText.trim()) {
      triggerToast('Please write review analysis text', 'error');
      return;
    }

    setFormPosting(true);

    const textToAnalyze = reviewText.trim();

    // 1. Spoiler Check: Auto-detect spoilers in reviews using Gemini
    let currentIsSpoiler = isSpoiler;
    const overrideFlag = (window as any)._muvio_spoiler_checked_text === textToAnalyze;

    if (!isSpoiler && !overrideFlag) {
      try {
        const res = await fetch('/api/gemini/spoilers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textToAnalyze })
        });
        const report = await res.json();
        if (report.containsSpoilers && report.confidence > 0.6) {
          setIsSpoiler(true);
          (window as any)._muvio_spoiler_checked_text = textToAnalyze;
          triggerToast('Oracle flagged potential plot spoilers. Spoiler toggle auto-enabled.', 'error');
          setFormPosting(false);
          return;
        }
      } catch (err) {
        console.warn('Review spoiler auto-detection failed, proceeding:', err);
      }
    }

    const targetReviewId = editingReviewId || 'rev_' + Math.random().toString(36).substring(2, 11);
    const dateString = new Date().toISOString();

    const payload: MuvioReview = {
      id: targetReviewId,
      mediaId,
      userId: currentUser.uid,
      username: currentUser.username,
      userAvatar: (currentUser as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      rating,
      text: textToAnalyze,
      spoiler: isSpoiler,
      createdAt: dateString,
      updatedAt: dateString,
      likedBy: []
    };

    // 2. Sentiment analysis on reviews using Gemini
    try {
      const sentimentRes = await fetch('/api/gemini/sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToAnalyze })
      });
      const data = await sentimentRes.json();
      if (data && data.sentiment) {
        payload.sentiment = data.sentiment as any;
        payload.sentimentScore = data.score;
        console.log(`Review sentiment analyzed: sentiment=${data.sentiment}, score=${data.score}`);
      }
    } catch (err) {
      console.warn('AIS review sentiment tagging skipped or encountered error:', err);
    }

    try {
      await saveReview(payload);
      triggerToast(isEditingExisting ? 'Review index updated successfully!' : 'Review posted with success!', 'success');
      loadReviewsData();
    } catch (e) {
      triggerToast('Database write failed. Review skipped.', 'error');
    } finally {
      setFormPosting(false);
    }
  };

  // Delete own review
  const handleDeleteReview = async (reviewId: string) => {
    if (!currentUser) return;
    try {
      await deleteReview(reviewId);
      triggerToast('Review deleted successfully', 'success');
      // Reset Editor Form if deleted
      if (editingReviewId === reviewId) {
        setIsEditingExisting(false);
        setEditingReviewId(null);
        setReviewText('');
      }
      loadReviewsData();
    } catch (error) {
      triggerToast('Failed to delete review', 'error');
    }
  };

  // Create Parent-level or Child-level Comment
  const handleAddComment = async (e: React.FormEvent, review: MuvioReview, parentId: string | null = null, replyToUsername: string | null = null) => {
    e.preventDefault();
    if (!currentUser) {
      onTriggerAuthPrompt();
      return;
    }

    // Identify target text
    const textVal = parentId ? replyText : topCommentDrafts[review.id];
    if (!textVal || !textVal.trim()) {
      triggerToast('Comment is empty', 'error');
      return;
    }

    const commentId = 'com_' + Math.random().toString(36).substring(2, 11);
    const newComment: MuvioComment = {
      id: commentId,
      reviewId: review.id,
      userId: currentUser.uid,
      username: currentUser.username,
      userAvatar: (currentUser as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      text: textVal.trim(),
      createdAt: new Date().toISOString(),
      parentId,
      replyToUsername,
      likedBy: []
    };

    // Determine parentAuthorId for target notifications
    let parentAuthorId = review.userId;
    if (parentId && commentsMap[review.id]) {
      const parentCommentObj = commentsMap[review.id].find(c => c.id === parentId);
      if (parentCommentObj) {
        parentAuthorId = parentCommentObj.userId;
      }
    }

    try {
      await saveComment(newComment, mediaId, parentAuthorId);
      triggerToast('Comment added!', 'success');
      
      // Reset target draft inputs
      if (parentId) {
        setReplyText('');
        setActiveReplyId(null);
      } else {
        setTopCommentDrafts(prev => ({ ...prev, [review.id]: '' }));
      }

      // Re-load comments list
      const freshComments = await getCommentsForReview(review.id);
      setCommentsMap(prev => ({ ...prev, [review.id]: freshComments }));
    } catch (e) {
      triggerToast('Could not save comment draft', 'error');
    }
  };

  // Comment deletion
  const handleDeleteComment = async (reviewId: string, commentId: string) => {
    if (!currentUser) return;
    try {
      await deleteComment(commentId);
      triggerToast('Comment deleted', 'success');
      const freshComments = await getCommentsForReview(reviewId);
      setCommentsMap(prev => ({ ...prev, [reviewId]: freshComments }));
    } catch {
      triggerToast('Failed to delete comment', 'error');
    }
  };

  // Toggle Like on comment
  const handleLikeComment = async (reviewId: string, commentId: string) => {
    if (!currentUser) {
      onTriggerAuthPrompt();
      return;
    }
    try {
      const nextLikes = await toggleLikeComment(currentUser.uid, commentId);
      setCommentsMap(prev => {
        const currentList = prev[reviewId] || [];
        return {
          ...prev,
          [reviewId]: currentList.map(c => c.id === commentId ? { ...c, likedBy: nextLikes } : c)
        };
      });
    } catch {
      triggerToast('Failed to toggle comment like', 'error');
    }
  };

  // Follow/Unfollow action helper
  const handleToggleFollowUser = (userIdToToggle: string, username: string) => {
    let list = [...followedUserIds];
    const idx = list.indexOf(userIdToToggle);
    if (idx !== -1) {
      list.splice(idx, 1);
      triggerToast(`Unfollowed @${username}`, 'success');
    } else {
      list.push(userIdToToggle);
      triggerToast(`Following @${username}`, 'success');
    }
    setFollowedUserIds(list);
    localStorage.setItem('muvio_followed_users', JSON.stringify(list));
  };

  // Trigger content reporting simulation
  const handleReportContent = (type: 'review' | 'comment', id: string, author: string) => {
    triggerToast(`Reported ${type} by @${author} to Muvio moderators.`, 'success');
  };

  // Apply filters on retrieved reviews
  const getProcessedReviews = () => {
    let result = [...reviews];

    // Filter based on selected pills
    if (selectedFilter === 'FOLLOWING') {
      result = result.filter(r => followedUserIds.includes(r.userId));
    }

    // Apply Sorting order
    if (selectedFilter === 'LIKES') {
      result.sort((a, b) => b.likedBy.length - a.likedBy.length);
    } else {
      // Default: Latest First
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    // Spoiler filtering constraint (can toggle Default spoil rule)
    if (!showSpoilersByDefault) {
      // If client requests hide, we still display them, but they're blurred! So no need to filter out elements.
    }

    return result;
  };

  const processedReviews = getProcessedReviews();

  // Rating colors
  const ratingBadgeConfigs = {
    'PERFECTION': { style: 'bg-red-500/10 border-red-500/40 text-red-500', label: 'PERFECTION' },
    'GO FOR IT': { style: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400', label: 'GO FOR IT' },
    'TIMEPASS': { style: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400', label: 'TIMEPASS' },
    'SKIP': { style: 'bg-zinc-500/10 border-white/10 text-gray-400', label: 'SKIP' }
  };

  return (
    <div className="space-y-4 text-left">
      {/* HEADER ROW & FILTERS (Redesigned: Filter buttons in a single horizontal scrollable row, 12px, compact) */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-white/5">
        <div className="flex overflow-x-auto scrollbar-hide items-center gap-1.5 py-1 select-none font-mono text-[12px] w-full">
          {/* Most Liked Pill */}
          <button
            onClick={() => setSelectedFilter('LIKES')}
            className={`px-3 py-1.5 rounded-full text-[12px] font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'LIKES'
                ? 'bg-[#E50914] text-white'
                : 'bg-white/5 text-gray-400 border border-white/5'
            }`}
          >
            Most Liked
          </button>

          {/* Newest Pill */}
          <button
            onClick={() => setSelectedFilter('NEWEST')}
            className={`px-3 py-1.5 rounded-full text-[12px] font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              selectedFilter === 'NEWEST'
                ? 'bg-[#E50914] text-white'
                : 'bg-white/5 text-gray-400 border border-white/5'
            }`}
          >
            Newest First
          </button>

          {/* Following Only Pill */}
          <button
            onClick={() => setSelectedFilter('FOLLOWING')}
            className={`px-3 py-1.5 rounded-full text-[12px] font-bold uppercase transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
              selectedFilter === 'FOLLOWING'
                ? 'bg-[#E50914] text-white'
                : 'bg-white/5 text-gray-400 border border-white/5'
            }`}
          >
            Following ({followedUserIds.length})
          </button>

          {/* Spoilers Toggle Pill */}
          <button
            onClick={() => setShowSpoilersByDefault(!showSpoilersByDefault)}
            className={`px-3 py-1.5 rounded-full text-[12px] font-bold uppercase transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
              showSpoilersByDefault
                ? 'border border-[#E50914]/40 text-[#E50914] bg-[#E50914]/5'
                : 'bg-white/5 text-gray-400 border border-white/5'
            }`}
          >
            {showSpoilersByDefault ? 'Unblur Spoilers' : 'Blur Spoilers'}
          </button>
        </div>
      </div>

      {/* WRITE REVIEW BOX (Clean minimal card-free layout) */}
      {currentUser ? (
        <form onSubmit={handlePostReview} className="py-4 border-b border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-white text-xs font-black uppercase font-mono tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#E50914]" />
              {isEditingExisting ? 'Revise Your Verdict' : 'Record Your Verdict'}
            </span>
            {isEditingExisting && (
              <span className="text-[10px] font-mono text-gray-500">
                You are revising an existing review
              </span>
            )}
          </div>

          {/* Rating Tabs: Single horizontal line, no wrapping, 12-13px font, 6px 14px padding, compact rounded pills */}
          <div className="flex overflow-x-auto scrollbar-hide gap-1.5 pb-1">
            {(['SKIP', 'TIMEPASS', 'GO FOR IT', 'PERFECTION'] as const).map((r) => {
              const active = r === rating;
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRating(r)}
                  className={`px-3.5 py-1.5 rounded-full text-[12px] font-black uppercase tracking-wider cursor-pointer border transition-all whitespace-nowrap flex items-center justify-center ${
                    active 
                      ? r === 'PERFECTION' ? 'bg-red-650 border-red-500 text-white'
                        : r === 'GO FOR IT' ? 'bg-emerald-650 border-emerald-500 text-white'
                        : r === 'TIMEPASS' ? 'bg-yellow-500 border-[#EAB308] text-black'
                        : 'bg-zinc-650 border-zinc-500 text-white'
                      : 'bg-white/2 border-white/5 hover:border-white/10 text-gray-400'
                  }`}
                >
                  {r}
                </button>
              );
            })}
          </div>

          <div className="relative">
            <textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value.slice(0, 1000))}
              placeholder="Flesh out your review. Progress pacing, screenplay structure, actors analysis..."
              rows={3}
              maxLength={1000}
              className="w-full bg-white/2 border border-white/5 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]"
              required
            />
            {/* Live Character counter */}
            <div className="absolute bottom-2.5 right-3 text-[10px] font-mono text-gray-500">
              {reviewText.length}/1000
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-0.5">
            <label className="flex items-center gap-1.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isSpoiler}
                onChange={(e) => setIsSpoiler(e.target.checked)}
                className="accent-[#E50914] h-3.5 w-3.5 rounded bg-black border-white/10 cursor-pointer"
              />
              <span className="text-[11px] text-gray-400 uppercase tracking-widest font-mono font-bold">
                Spilers Included
              </span>
            </label>

            <button
              type="submit"
              disabled={formPosting}
              className="bg-[#E50914] text-white hover:bg-neutral-800 font-bold text-xs px-4 py-2 rounded-lg tracking-wider transition-all cursor-pointer uppercase font-mono disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              {formPosting ? 'Saving...' : isEditingExisting ? 'Update Verdict' : 'Publish Verdict'}
            </button>
          </div>
        </form>
      ) : (
        <div className="py-4 border-b border-white/5 text-center space-y-2.5">
          <p className="text-[12px] text-gray-400 font-sans leading-relaxed max-w-sm mx-auto">
            Authorize your Critic credentials to access review logs, submit custom ratings, and participate in comments.
          </p>
          <button
            onClick={onTriggerAuthPrompt}
            className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-[#E50914] border border-white/10 text-xs font-bold uppercase font-mono tracking-widest cursor-pointer"
          >
            Authenticate Critic ID
          </button>
        </div>
      )}

      {/* REVIEWS LIST */}
      <div className="space-y-1">
        {processedReviews.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-xs text-gray-500 font-mono">
              {selectedFilter === 'FOLLOWING'
                ? 'No reviews yet from people you follow.'
                : 'No reviews yet. Be the first to review!'}
            </p>
          </div>
        ) : (
          processedReviews.slice(0, visibleCount).map((review) => {
            const hasLiked = currentUser && review.likedBy && review.likedBy.includes(currentUser.uid);
            const isOwnReview = currentUser && review.userId === currentUser.uid;
            
            // Spoiler visibility
            const isSpoilerBlurred = review.spoiler && !showSpoilersByDefault && !revealedSpoilers[review.id];
            
            const badge = ratingBadgeConfigs[review.rating] || ratingBadgeConfigs['GO FOR IT'];
            const commentsList = commentsMap[review.id] || [];

            // Character limits for read more
            const isLongText = review.text.length > 250;
            const isTextExpanded = expandedReviews[review.id];
            const displayedText = (isLongText && !isTextExpanded) 
              ? `${review.text.slice(0, 250)}...` 
              : review.text;

            return (
              <div 
                key={review.id} 
                className="py-5 border-b border-white/5 space-y-3.5 text-left relative"
              >
                {/* Review Header Card */}
                <div className="flex justify-between items-start">
                  <div className="flex gap-2.5">
                    <img 
                      src={(reviewerProfiles[review.userId] as any)?.avatarUrl || review.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${review.username}`}
                      alt={review.username} 
                      className="w-8 h-8 rounded-full bg-white/5 border border-white/5 flex-shrink-0 object-cover"
                      onError={(e) => { (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${review.username}`; }}
                    />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[13px] font-black text-white hover:text-[#E50914] transition-colors flex items-center gap-1">
                          {reviewerProfiles[review.userId]?.name || review.username}
                          {reviewerProfiles[review.userId] && (reviewerProfiles[review.userId].isVerified === true || reviewerProfiles[review.userId].verified === true) && (
                            <svg className="w-3.5 h-3.5 text-blue-500 fill-current inline-block flex-shrink-0" viewBox="0 0 24 24" id="verified-tick-icon" title="Verified Critic">
                              <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                          )}
                        </span>
                        {/* Verified Admin badge */}
                        {review.userId === 'admin_uid_fallback' && (
                          <span className="flex items-center text-[8px] font-black uppercase text-[#E50914] bg-[#E50914]/10 px-1.5 py-0.5 rounded border border-[#E50914]/20 font-mono gap-0.5">
                            <Award size={8} /> Admin
                          </span>
                        )}
                        {followedUserIds.includes(review.userId) && (
                          <span className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-mono">
                            Following
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-mono text-gray-500 block">
                        {formatRelativeTime(review.createdAt)}
                      </span>
                    </div>
                  </div>

                  {/* Rating Label and Dropdown Action menu */}
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-[9px] font-black uppercase font-mono tracking-wider rounded border ${badge.style}`}>
                      {badge.label}
                    </span>

                    {/* Action dropdown button */}
                    <div className="relative">
                      <button
                        onClick={() => setActiveMenuId(activeMenuId === review.id ? null : review.id)}
                        className="w-7 h-7 rounded-full bg-white/5 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
                      >
                        <MoreHorizontal size={12} />
                      </button>

                      {activeMenuId === review.id && (
                        <div className="absolute right-0 mt-1 w-40 bg-[#111] border border-white/10 rounded-lg shadow-xl py-1 z-50 text-[10px] font-mono">
                          {isOwnReview ? (
                            <button
                              onClick={() => {
                                setActiveMenuId(null);
                                handleDeleteReview(review.id);
                              }}
                              className="w-full text-left px-3 py-2 text-red-500 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                            >
                              <Trash2 size={11} /> Delete Review
                            </button>
                          ) : (
                            <>
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleToggleFollowUser(review.userId, review.username);
                                }}
                                className="w-full text-left px-3 py-2 text-white hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                {followedUserIds.includes(review.userId) ? (
                                  <>
                                    <UserMinus size={11} /> Unfollow User
                                  </>
                                ) : (
                                  <>
                                    <UserPlus size={11} /> Follow User
                                  </>
                                )}
                              </button>
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleReportContent('review', review.id, review.username);
                                }}
                                className="w-full text-left px-3 py-2 text-gray-400 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                <Flag size={11} /> Report Violation
                              </button>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Review Text Body with Spoiler blur options - font 14px */}
                <div className="space-y-2">
                  {isSpoilerBlurred ? (
                    <div className="p-3 bg-zinc-950/40 border border-white/5 rounded-xl relative text-center">
                      <p className="text-2xs font-mono text-gray-400 select-none filter blur-[2px] line-clamp-1 mb-1.5">
                        {review.text}
                      </p>
                      <button
                        type="button"
                        onClick={() => setRevealedSpoilers(prev => ({ ...prev, [review.id]: true }))}
                        className="bg-[#E50914] hover:bg-neutral-800 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg transition-all font-mono tracking-wider cursor-pointer uppercase flex items-center gap-1 mx-auto"
                      >
                        <Eye size={10} /> Reveal Spoiler
                      </button>
                    </div>
                  ) : (
                    <div>
                      <p className="text-[14px] text-gray-300 font-sans leading-relaxed whitespace-pre-line select-text">
                        {displayedText}
                      </p>
                      {isLongText && (
                        <button
                          type="button"
                          onClick={() => setExpandedReviews(prev => ({ ...prev, [review.id]: !prev[review.id] }))}
                          className="text-[11px] text-[#E50914] font-mono mt-1 hover:underline cursor-pointer tracking-wider font-bold block"
                        >
                          {isTextExpanded ? 'Collapse Review' : 'Read Full Analysis'}
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Footer Action buttons: Liking and commenting */}
                <div className="flex items-center gap-4 text-[11px] font-mono text-gray-500">
                  <button
                    onClick={(e) => handleLikeReview(e, review)}
                    className={`flex items-center gap-1 cursor-pointer transition-colors ${
                      hasLiked ? 'text-red-500 font-bold' : 'text-gray-455 hover:text-white'
                    }`}
                  >
                    <Heart size={12} className={hasLiked ? 'fill-red-500' : ''} />
                    <span>{review.likedBy ? review.likedBy.length : 0}</span>
                  </button>

                  <button
                    onClick={() => handleToggleComments(review.id)}
                    className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                  >
                    <MessageSquare size={12} />
                    <span>{commentsMap[review.id] ? commentsMap[review.id].length : (review.commentCount || 0)}</span>
                  </button>
                </div>

                {/* COMMENTS BLOCK SECTION */}
                <AnimatePresence>
                  {expandedComments[review.id] && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="origin-top overflow-hidden space-y-4 pt-3 border-t border-white/5 text-left"
                    >
                      {/* Comments list map rendering */}
                      <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                        {commentsList.length === 0 ? (
                          <p className="text-[10px] font-mono text-gray-500 py-3 text-center">
                            No review conversations structured yet.
                          </p>
                        ) : (
                          commentsList
                            .filter(c => !c.parentId) // Top-level comments
                            .map((cmt) => {
                              const cmtLiked = currentUser && cmt.likedBy && cmt.likedBy.includes(currentUser.uid);
                              const isOwnComment = currentUser && cmt.userId === currentUser.uid;

                              // Replies nested under this comment ID (Level 2 replies max)
                              const repliesList = commentsList.filter(reply => reply.parentId === cmt.id);

                              return (
                                <div key={cmt.id} className="space-y-3.5">
                                  {/* LEVEL 1 COMMENT */}
                                  <div className="p-3 bg-white/2 rounded-xl border border-white/5 space-y-2">
                                    <div className="flex justify-between items-start">
                                      <div className="flex items-center gap-2">
                                        <img src={cmt.userAvatar} className="w-5.5 h-5.5 rounded-full bg-white/5 border border-white/5" />
                                        <div>
                                          <span className="text-[10px] font-bold text-white">@{cmt.username}</span>
                                          <span className="text-[8px] font-mono text-gray-500 block">{formatRelativeTime(cmt.createdAt)}</span>
                                        </div>
                                      </div>

                                      {/* Level 1 Comment controls drop */}
                                      <div className="flex items-center gap-1">
                                        {isOwnComment ? (
                                          <button 
                                            onClick={() => handleDeleteComment(review.id, cmt.id)}
                                            className="text-gray-500 hover:text-red-500 p-1 rounded transition-colors"
                                            title="Delete"
                                          >
                                            <Trash2 size={11} />
                                          </button>
                                        ) : (
                                          <button
                                            onClick={() => handleReportContent('comment', cmt.id, cmt.username)}
                                            className="text-gray-500 hover:text-yellow-500 p-1 rounded transition-colors"
                                            title="Report"
                                          >
                                            <Flag size={11} />
                                          </button>
                                        )}
                                      </div>
                                    </div>

                                    <p className="text-2xs text-gray-300 leading-relaxed pl-1">{cmt.text}</p>

                                    {/* Action row (Like / Reply) */}
                                    <div className="flex items-center gap-3 text-[9px] font-mono pt-1">
                                      <button
                                        onClick={() => handleLikeComment(review.id, cmt.id)}
                                        className={`flex items-center gap-1 transition-colors ${cmtLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                                      >
                                        <Heart size={10} className={cmtLiked ? 'fill-red-500' : ''} />
                                        <span>{cmt.likedBy ? cmt.likedBy.length : 0}</span>
                                      </button>

                                      <button
                                        onClick={() => {
                                          setActiveReplyId(cmt.id);
                                          setReplyText(`@${cmt.username} `);
                                        }}
                                        className="text-gray-500 hover:text-red-400 font-bold transition-colors"
                                      >
                                        Reply
                                      </button>
                                    </div>
                                  </div>

                                  {/* LEVEL 2 NESTED REPLIES */}
                                  {repliesList.map((reply) => {
                                    const replyLiked = currentUser && reply.likedBy && reply.likedBy.includes(currentUser.uid);
                                    const isOwnReply = currentUser && reply.userId === currentUser.uid;

                                    return (
                                      <div key={reply.id} className="flex gap-2 pl-6">
                                        <CornerDownRight className="w-3.5 h-3.5 text-gray-600 flex-shrink-0 mt-2" />
                                        
                                        <div className="flex-1 p-3 bg-zinc-950/60 rounded-xl border border-white/5 space-y-2">
                                          <div className="flex justify-between items-start">
                                            <div className="flex items-center gap-1.5">
                                              <img src={reply.userAvatar} className="w-5 h-5 rounded-full bg-white/5 border border-white/5" />
                                              <div>
                                                <span className="text-[10px] font-bold text-white">@{reply.username}</span>
                                                <span className="text-[8px] font-mono text-gray-500 block">{formatRelativeTime(reply.createdAt)}</span>
                                              </div>
                                            </div>

                                            <div className="flex items-center">
                                              {isOwnReply ? (
                                                <button 
                                                  onClick={() => handleDeleteComment(review.id, reply.id)}
                                                  className="text-gray-500 hover:text-red-500 p-1 rounded transition-colors"
                                                >
                                                  <Trash2 size={11} />
                                                </button>
                                              ) : (
                                                <button
                                                  onClick={() => handleReportContent('comment', reply.id, reply.username)}
                                                  className="text-gray-500 hover:text-yellow-500 p-1 rounded transition-colors"
                                                >
                                                  <Flag size={11} />
                                                </button>
                                              )}
                                            </div>
                                          </div>

                                          <p className="text-2xs text-gray-300 leading-relaxed block select-text">
                                            <span className="text-red-500/90 font-mono font-black mr-1">{reply.replyToUsername}</span>
                                            {reply.text.replace(reply.replyToUsername || '', '').trim()}
                                          </p>

                                          <div className="flex items-center gap-3 text-[9px] font-mono">
                                            <button
                                              onClick={() => handleLikeComment(review.id, reply.id)}
                                              className={`flex items-center gap-1 transition-colors ${replyLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                                            >
                                              <Heart size={10} className={replyLiked ? 'fill-red-500' : ''} />
                                              <span>{reply.likedBy ? reply.likedBy.length : 0}</span>
                                            </button>

                                            <button
                                              onClick={() => {
                                                setActiveReplyId(cmt.id); // Maintains Level 2 parent
                                                setReplyText(`@${reply.username} `);
                                              }}
                                              className="text-gray-500 hover:text-red-400 font-bold transition-colors"
                                            >
                                              Reply
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              );
                            })
                        )}
                      </div>

                      {/* REPLY SUBMIT INLINE FORM */}
                      {activeReplyId && (
                        <form
                          onSubmit={(e) => {
                            const parentCmt = commentsList.find(c => c.id === activeReplyId);
                            handleAddComment(e, review, activeReplyId, parentCmt ? `@${parentCmt.username}` : null);
                          }}
                          className="p-3 bg-zinc-950/60 rounded-xl border border-red-500/10 flex gap-2"
                        >
                          <input
                            type="text"
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            placeholder="Type secure reply trace..."
                            className="flex-1 bg-black/60 border border-white/5 rounded-lg px-3 py-2 text-2xs text-white placeholder-white/25 focus:outline-none focus:border-[#E50914]"
                            autoFocus
                            required
                          />
                          <button
                            type="submit"
                            className="bg-[#E50914] text-white hover:bg-red-600 px-3.5 rounded-lg transition-colors cursor-pointer text-2xs font-mono font-bold uppercase flex items-center justify-center gap-1"
                          >
                            <Send size={10} /> Reply
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setActiveReplyId(null);
                              setReplyText('');
                            }}
                            className="text-gray-500 hover:text-white p-2 text-xs font-mono font-bold"
                          >
                            Cancel
                          </button>
                        </form>
                      )}

                      {/* TOP LEVEL WRITE COMMENT BOX */}
                      <form 
                        onSubmit={(e) => handleAddComment(e, review, null, null)}
                        className="flex gap-2"
                      >
                        <input
                          type="text"
                          value={topCommentDrafts[review.id] || ''}
                          onChange={(e) => setTopCommentDrafts(prev => ({ ...prev, [review.id]: e.target.value }))}
                          placeholder="Flesh out discussion point thread..."
                          className="flex-1 bg-black/40 border border-white/5 rounded-xl px-3.5 py-2.5 text-2xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914]"
                          required
                        />
                        <button
                          type="submit"
                          className="bg-[#E50914] hover:bg-red-600 text-white p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-center"
                        >
                          <Plus size={14} />
                        </button>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })
        )}
      </div>

      {/* SHOW ALL REVIEWS BUTTON */}
      {processedReviews.length > visibleCount && (
        <div className="pt-2 text-center">
          <button
            onClick={() => setVisibleCount(processedReviews.length)}
            className="px-6 py-3 rounded-full bg-white/5 hover:bg-white/10 text-white transition-all text-xs border border-white/5 cursor-pointer font-mono uppercase tracking-wider block mx-auto font-black"
          >
            Show All Reviews ({processedReviews.length})
          </button>
        </div>
      )}
    </div>
  );
}
