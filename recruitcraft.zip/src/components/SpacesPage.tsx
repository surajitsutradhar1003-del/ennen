import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Heart, 
  MessageSquare, 
  MoreHorizontal, 
  Trash2, 
  Flag, 
  Send, 
  Sparkles, 
  Award, 
  Plus, 
  ChevronDown, 
  Megaphone,
  User,
  Eye,
  Clock,
  ThumbsUp,
  CornerDownRight
} from 'lucide-react';
import { triggerToast, UserProfile, isFirebaseConfigured, db } from '../lib/firebase';
import { createNotification } from '../lib/userInteractions';
import AdSlot from './AdSlot';

interface SpacesPageProps {
  onNavigate: (to: string) => void;
  currentUser: UserProfile | null;
  onTriggerLogin?: () => void;
}

export interface SpacesPost {
  id: string;
  category: 'RUMOUR' | 'NEWS' | 'DISCUSSION';
  title: string;
  text: string;
  imageUrl: string;
  authorName: string;
  authorUsername: string;
  authorAvatar: string;
  createdAt: string;
  discussionsCount: number;
  userId: string;
}

export interface SpacesDiscussion {
  id: string;
  title: string;
  description: string;
  authorName: string;
  authorUsername: string;
  authorAvatar: string;
  createdAt: string;
  isPinned: boolean;
  replyCount: number;
  userId: string;
  linkedMediaId?: string; // Optional: links discussion to a specific media item
  linkedMediaTitle?: string;
}

export interface SpaceReply {
  id: string;
  parentId: string | null; // null for top-level, parent reply ID for nested (level 2 max)
  targetId: string; // post ID or discussion ID
  targetType: 'post' | 'discussion';
  authorUserId: string;
  authorUsername: string;
  authorAvatar: string;
  createdAt: string;
  text: string;
  likedBy: string[]; // User IDs who liked
}

// Initial Mock Seed for Posts
const INITIAL_POSTS: SpacesPost[] = [
  {
    id: "post_1",
    category: "RUMOUR",
    title: "Dunes Messiah: Part Three Script Completed?",
    text: "Rumours from industry insiders suggest that Denis Villeneuve has finally locked the screenplay for Dune Messiah (Part 3) with Legendary Pictures. Multiple leaks indicate production is slated to start late 2026, focusing heavily on Paul Atreides' heartbreaking, tragic descent and the Fremen jihad revolt.",
    imageUrl: "https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=600",
    authorName: "Aria Sterling",
    authorUsername: "aria_cinema",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=aria_cinema",
    createdAt: "2026-06-11T12:00:00.000Z",
    discussionsCount: 14,
    userId: "admin_uid_fallback"
  },
  {
    id: "post_2",
    category: "NEWS",
    title: "Tom Holland's Spider-Man 4 Locks Summer 2026 Release Window",
    text: "Marvel Studios and Sony Pictures have set an official release date for the next Spider-Man chapter. Directed by Destin Daniel Cretton, the movie is set to launch into theaters in July 2026. Speculation links the storyline to the multiverse cleanup post-Secret Wars.",
    imageUrl: "https://images.unsplash.com/photo-1635805737707-575885ab0820?auto=format&fit=crop&q=80&w=600",
    authorName: "Marcus Thorne",
    authorUsername: "marcus_headlines",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=marcus_headlines",
    createdAt: "2026-06-12T15:30:00.000Z",
    discussionsCount: 8,
    userId: "user_marcus"
  },
  {
    id: "post_3",
    category: "DISCUSSION",
    title: "Why Modern Science Fiction is Dominating Global Box Office",
    text: "From interstellar black holes to dystopian desert worlds, science fiction movies are pulling record audiences into premium IMAX theaters. Is our obsession driven by incredible special effects, or are we seeking deep allegories to modern tech anxiety?",
    imageUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
    authorName: "Elena Rostova",
    authorUsername: "elena_scifi",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=elena_scifi",
    createdAt: "2026-06-13T08:15:00.000Z",
    discussionsCount: 5,
    userId: "user_elena"
  }
];

// Initial Mock Seed for Discussions
const INITIAL_DISCUSSIONS: SpacesDiscussion[] = [
  {
    id: "disc_1",
    title: "Batman vs Superman Ideology: Who Was Morally Right?",
    description: "Stripping away the theatrical action and Martha sequence memes, BvS represents a massive clash of philosophies. Bruce Wayne operates on preemptive preventative paranoia, while Clark Kent attempts infinite hope. Let's debate which world views withstand modern geopolitics.",
    authorName: "Clark Wayne",
    authorUsername: "gotham_observer",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=gotham_observer",
    createdAt: "2026-06-10T10:00:00.000Z",
    isPinned: true,
    replyCount: 22,
    userId: "user_clark"
  },
  {
    id: "disc_2",
    title: "House of the Dragon: Did Pacing Kill Season 2?",
    description: "Many audience reviews complained about slow loop structures and locked locations, while other hard-core critics praised the meticulous character expansion. Let's analyze whether the climax left too many loose ends or served as superb buildup.",
    authorName: "Valyria Lore",
    authorUsername: "dragon_heart",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=dragon_heart",
    createdAt: "2026-06-12T19:45:00.000Z",
    isPinned: false,
    replyCount: 16,
    userId: "user_valyria"
  },
  {
    id: "disc_3",
    title: "Metal Steelbooks & Boutique Labels: Physical Media Resurrection",
    description: "In an age of licensing revocations and poor streaming compression, digital ownership has become a farce. Criterion, Arrow Video, and Shout Factory are seeing explosive revenues. Let's exchange current collections and find premium catalog recommendations.",
    authorName: "Steelbook Archivist",
    authorUsername: "physical_media_guy",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=physical_media_guy",
    createdAt: "2026-06-13T01:20:00.000Z",
    isPinned: false,
    replyCount: 9,
    userId: "user_archive"
  }
];

const INITIAL_REPLIES: SpaceReply[] = [
  {
    id: "rep_1_1",
    parentId: null,
    targetId: "post_1",
    targetType: "post",
    authorUserId: "user_elena",
    authorUsername: "elena_scifi",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=elena_scifi",
    createdAt: "2026-06-11T14:10:00.000Z",
    text: "This is crucial! Dune Messiah is far more psychological and political than the first book. If Denis can adapt the ending faithfully, it will go down as one of the best trilogies in science fiction history.",
    likedBy: ["user_marcus", "user_clark"]
  },
  {
    id: "rep_1_2",
    parentId: "rep_1_1",
    targetId: "post_1",
    targetType: "post",
    authorUserId: "user_marcus",
    authorUsername: "marcus_headlines",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=marcus_headlines",
    createdAt: "2026-06-11T14:45:00.000Z",
    text: "Agreed. Messiah subverts the Savior trope completely. People expecting a hero story like Star Wars are going to be absolutely stunned and uncomfortable with Paul's choices.",
    likedBy: ["user_elena"]
  },
  {
    id: "rep_2_1",
    parentId: null,
    targetId: "disc_1",
    targetType: "discussion",
    authorUserId: "aria_cinema",
    authorUsername: "aria_cinema",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=aria_cinema",
    createdAt: "2026-06-10T12:30:00.000Z",
    text: "Incredible topic! Bruce Wayne's argument is basically 'If there is even a 1% chance he is our enemy we must take it as an absolute certainty.' That's standard realist preemptive defense policy. Extremely dark but logically coherent.",
    likedBy: ["user_clark"]
  },
  {
    id: "rep_2_2",
    parentId: "rep_2_1",
    targetId: "disc_1",
    targetType: "discussion",
    authorUserId: "user_valyria",
    authorUsername: "dragon_heart",
    authorAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=dragon_heart",
    createdAt: "2026-06-10T13:00:00.000Z",
    text: "Exactly. But Clark's response is that you cannot lead by fear. It destroys humanity in the process of saving it. Gotham Observer hit the nail on the head.",
    likedBy: []
  }
];

export default function SpacesPage({ onNavigate, currentUser, onTriggerLogin }: SpacesPageProps) {
  const [activeTab, setActiveTab] = useState<'FEED' | 'FLOOR'>('FEED');

  // Load state from localStorage — no demo seed data
  const [posts, setPosts] = useState<SpacesPost[]>(() => {
    try {
      const data = localStorage.getItem('muvio_spaces_posts');
      if (data) return JSON.parse(data);
    } catch (e) {}
    return [];
  });

  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const syncPostsFromFirestore = async () => {
        try {
          const { collection, getDocs } = await import('firebase/firestore');
          const querySnapshot = await getDocs(collection(db, 'news'));
          if (!querySnapshot.empty) {
            const fsNews: SpacesPost[] = [];
            querySnapshot.forEach((doc) => {
              fsNews.push({ id: doc.id, ...doc.data() } as any);
            });
            fsNews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setPosts(fsNews);
            localStorage.setItem('muvio_spaces_posts', JSON.stringify(fsNews));
          } else {
            setPosts([]);
            localStorage.setItem('muvio_spaces_posts', JSON.stringify([]));
          }
        } catch (err) {
          console.warn("Failed to synchronize Spaces news from Firestore:", err);
        }
      };
      syncPostsFromFirestore();
    }
  }, []);

  const [discussions, setDiscussions] = useState<SpacesDiscussion[]>(() => {
    try {
      const data = localStorage.getItem('muvio_spaces_discussions');
      if (data) return JSON.parse(data);
    } catch (e) {}
    return [];
  });

  const [replies, setReplies] = useState<SpaceReply[]>(() => {
    try {
      const data = localStorage.getItem('muvio_spaces_replies');
      if (data) return JSON.parse(data);
    } catch (e) {}
    return [];
  });

  // State for specific active details page matching slug triggers
  const [viewState, setViewState] = useState<{ type: 'list' | 'post' | 'discussion'; id: string }>({ type: 'list', id: '' });

  // Monitor path changes via window.location to enable direct/back navigation perfectly
  useEffect(() => {
    const updateFromPath = () => {
      const path = window.location.pathname;
      if (path.startsWith('/spaces/post/')) {
        const id = path.replace('/spaces/post/', '');
        setViewState({ type: 'post', id });
      } else if (path.startsWith('/spaces/discussion/')) {
        const id = path.replace('/spaces/discussion/', '');
        setViewState({ type: 'discussion', id });
      } else {
        setViewState({ type: 'list', id: '' });
      }
    };

    updateFromPath();
    window.addEventListener('popstate', updateFromPath);
    return () => window.removeEventListener('popstate', updateFromPath);
  }, []);

  const handleGotoDetail = (type: 'post' | 'discussion', id: string) => {
    const toPath = `/spaces/${type}/${id}`;
    window.history.pushState(null, '', toPath);
    setViewState({ type, id });
  };

  const handleBackToList = () => {
    window.history.pushState(null, '', '/spaces');
    setViewState({ type: 'list', id: '' });
  };

  // Helper sync back state to main local storage
  const savePostsToStore = (newPosts: SpacesPost[]) => {
    setPosts(newPosts);
    localStorage.setItem('muvio_spaces_posts', JSON.stringify(newPosts));
  };

  const saveRepliesToStore = (newReplies: SpaceReply[]) => {
    setReplies(newReplies);
    localStorage.setItem('muvio_spaces_replies', JSON.stringify(newReplies));
  };

  const saveDiscussionsToStore = (newDiscussions: SpacesDiscussion[]) => {
    setDiscussions(newDiscussions);
    localStorage.setItem('muvio_spaces_discussions', JSON.stringify(newDiscussions));
  };

  // Structured time parser
  const relativeTimeString = (isoString: string): string => {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    if (isNaN(diffMs)) return 'recently';
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSecs < 60) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  if (viewState.type === 'post') {
    const postObj = posts.find(p => p.id === viewState.id);
    if (!postObj) {
      return (
        <div className="text-center py-20">
          <h2 className="text-xl font-bold font-mono">POST INDEX ERROR</h2>
          <p className="text-xs text-gray-500 mt-2">The requested cinematic transmission is unreadable.</p>
          <button onClick={handleBackToList} className="mt-4 px-5 py-2 bg-[#E50914] text-xs font-bold font-mono rounded-lg uppercase">
            Back to Spaces
          </button>
        </div>
      );
    }
    return (
      <SpacePostDetailView 
        post={postObj} 
        allReplies={replies} 
        onSaveReplies={saveRepliesToStore}
        currentUser={currentUser}
        onBack={handleBackToList}
        onTriggerLogin={onTriggerLogin || (() => onNavigate('/login'))}
        relativeTimeString={relativeTimeString}
      />
    );
  }

  if (viewState.type === 'discussion') {
    const discObj = discussions.find(d => d.id === viewState.id);
    if (!discObj) {
      return (
        <div className="text-center py-20">
          <h2 className="text-xl font-bold font-mono">DISCUSSION INDEX ERROR</h2>
          <p className="text-xs text-gray-500 mt-1">The requested floor discourse is missing inside current node.</p>
          <button onClick={handleBackToList} className="mt-4 px-5 py-2 bg-[#E50914] text-xs font-bold font-mono rounded-lg uppercase">
            Back to Spaces
          </button>
        </div>
      );
    }
    return (
      <SpaceDiscussionDetailView 
        discussion={discObj} 
        allReplies={replies} 
        onSaveReplies={saveRepliesToStore}
        currentUser={currentUser}
        onBack={handleBackToList}
        onTriggerLogin={onTriggerLogin || (() => onNavigate('/login'))}
        relativeTimeString={relativeTimeString}
      />
    );
  }

  // --- RENDERING TABS & LIST VIEWS ---
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <AdSlot placementId="spaces_top_banner" />

      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">
            MUVIO SOCIAL HUB
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight">
            Cinematic Spaces
          </h2>
          <p className="text-2xs text-gray-400 font-mono mt-0.5 max-w-md">
            Sync details, analysis transcripts, industry leaks, and open battle-testing platforms for cinephiles.
          </p>
        </div>

        {/* HIGH-END NEON TABS CARD */}
        <div className="flex bg-[#111111]/90 p-1 border border-white/5 rounded-2xl">
          <button
            onClick={() => setActiveTab('FEED')}
            className={`px-5 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'FEED'
                ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Spaces Feed
          </button>
          <button
            onClick={() => setActiveTab('FLOOR')}
            className={`px-5 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
              activeTab === 'FLOOR'
                ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Open Floor Discussions
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-left">
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
        {activeTab === 'FEED' ? (
          <motion.div
            key="feed"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4"
          >
            {posts.map((post) => {
              // Get live replies count
              const pReplies = replies.filter(r => r.targetId === post.id && r.targetType === 'post');
              const repliesCount = pReplies.length;

              const categoryColors = {
                'RUMOUR': 'border-amber-500/35 bg-amber-500/10 text-amber-400',
                'NEWS': 'border-blue-500/35 bg-blue-500/10 text-blue-400',
                'DISCUSSION': 'border-purple-500/35 bg-purple-500/10 text-purple-400'
              };

              return (
                <div
                  key={post.id}
                  onClick={() => handleGotoDetail('post', post.id)}
                  className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2rem] overflow-hidden p-4 md:p-5 flex flex-col md:flex-row gap-5 transition-all cursor-pointer hover:shadow-xl hover:shadow-white/[0.02] group"
                >
                  <div className="w-full md:w-44 h-40 md:h-32 rounded-2xl overflow-hidden bg-zinc-900 border border-white/5 flex-shrink-0 relative">
                    <img
                      src={post.imageUrl}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <span className={`absolute top-2 left-2 px-2 py-0.5 rounded text-[8px] font-black border font-mono tracking-widest ${categoryColors[post.category]}`}>
                      {post.category}
                    </span>
                  </div>

                  <div className="flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-2 text-left">
                      <h3 className="text-base md:text-lg font-black text-white uppercase tracking-tight group-hover:text-[#E50914] transition-colors leading-snug">
                        {post.title}
                      </h3>
                      <p className="text-xs text-gray-400 line-clamp-2 md:line-clamp-3 font-normal leading-relaxed">
                        {post.text}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[10px] font-mono text-gray-500">
                      <div className="flex items-center gap-2">
                        <img
                          src={post.authorAvatar}
                          alt={post.authorUsername}
                          className="w-5.5 h-5.5 rounded-full bg-white/5 border border-white/5"
                        />
                        <span className="text-gray-300 font-bold hover:text-white">
                          @{post.authorUsername}
                        </span>
                        <span className="text-gray-500 font-mono">
                          • {relativeTimeString(post.createdAt)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-gray-400 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5">
                        <MessageSquare size={11} className="text-[#E50914]" />
                        <span className="font-bold text-white text-[9px]">{repliesCount} DISCUSSIONS RUNNING</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        ) : (
          <motion.div
            key="floor"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            {/* FEATURED PINNED TOP_LEVEL DISCUSSION */}
            {discussions.filter(d => d.isPinned).map((feat) => {
              const featReplies = replies.filter(r => r.targetId === feat.id && r.targetType === 'discussion').length;
              return (
                <div
                  key={feat.id}
                  className="bg-[radial-gradient(ellipse_at_top_right,rgba(229,9,20,0.12),rgba(12,12,12,1))] border-2 border-[#E50914]/20 rounded-[2.5rem] p-6 text-left space-y-4 shadow-2xl relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-48 h-48 bg-red-600/5 blur-3xl rounded-full pointer-events-none"></div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-[9px] font-black uppercase text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/30 px-3 py-1 rounded-full font-mono tracking-widest">
                      <Megaphone size={10} className="animate-bounce" /> HOT TOPIC DEBATE
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">
                      Pinned Board
                    </span>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">
                      {feat.title}
                    </h3>
                    <p className="text-xs md:text-sm text-gray-300 font-medium leading-relaxed max-w-2xl">
                      {feat.description}
                    </p>
                  </div>

                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-3 border-t border-white/5">
                    <div className="flex items-center gap-2">
                      <img
                        src={feat.authorAvatar}
                        alt={feat.authorUsername}
                        className="w-7 h-7 rounded-full bg-white/5 border border-white/10"
                      />
                      <div className="text-[11px] font-mono">
                        <span className="text-white font-bold block">@{feat.authorUsername}</span>
                        <span className="text-gray-500 block text-[9px]">{relativeTimeString(feat.createdAt)} • Pinned Moderator</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleGotoDetail('discussion', feat.id)}
                      className="px-6 py-3 rounded-xl bg-[#E50914] hover:bg-red-600 text-white font-bold text-2xs uppercase font-mono tracking-widest transition-all cursor-pointer shadow-lg shadow-[#E50914]/10 self-start md:self-auto flex items-center gap-2"
                    >
                      <MessageSquare size={12} /> Join Pinned Conversation ({featReplies})
                    </button>
                  </div>
                </div>
              );
            })}

            {/* NORMAL TOPICS LIST */}
            <div className="space-y-4 text-left">
              <h3 className="text-xs font-black text-gray-400 font-mono uppercase tracking-widest pl-1">
                Active Discussions Floor
              </h3>

              {discussions.filter(d => !d.isPinned).map((disc) => {
                const discReplies = replies.filter(r => r.targetId === disc.id && r.targetType === 'discussion').length;
                return (
                  <div
                    key={disc.id}
                    onClick={() => handleGotoDetail('discussion', disc.id)}
                    className="p-5 bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-[2rem] space-y-3 transition-all cursor-pointer hover:shadow-xl hover:shadow-white/[0.01] group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1.5 flex-1 pr-4">
                        <h4 className="text-base md:text-lg font-black text-white group-hover:text-[#E50914] transition-colors uppercase tracking-tight leading-snug">
                          {disc.title}
                        </h4>
                        <p className="text-2xs text-gray-400 line-clamp-2 leading-relaxed">
                          {disc.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-1 bg-white/3 border border-white/5 py-1 px-2.5 rounded-lg text-2xs font-mono text-gray-300">
                        <MessageSquare size={11} className="text-[#E50914]" />
                        <span className="font-bold">{discReplies} REPLIES</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2.5 border-t border-white/5 text-[10px] font-mono text-gray-500">
                      <div className="flex items-center gap-2">
                        <img
                          src={disc.authorAvatar}
                          alt={disc.authorUsername}
                          className="w-5.5 h-5.5 rounded-full bg-white/5 border border-white/5"
                        />
                        <span className="text-gray-300 font-black">
                          @{disc.authorUsername}
                        </span>
                        <span>• {relativeTimeString(disc.createdAt)}</span>
                      </div>

                      <span className="text-[10px] text-[#E50914] font-bold uppercase tracking-wider group-hover:translate-x-1 transition-transform inline-block">
                        Participate Dialogue &rarr;
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
        </div>

        {/* SPACES SIDEBAR ADS COLUMN */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#0c0c0c]/90 border border-white/5 rounded-[2.5rem] p-6 space-y-4">
            <h4 className="text-[10px] font-mono font-black tracking-[0.25em] text-[#E50914] uppercase">SPONSOR GATEWAY</h4>
            <AdSlot placementId="spaces_sidebar" />
          </div>

          <div className="bg-[#0c0c0c]/80 border border-white/5 rounded-[2.5rem] p-6 space-y-3 font-mono text-[10px] text-gray-500">
            <h5 className="font-bold text-white uppercase text-xxs tracking-wider">PORTAL SECURITY POLICY</h5>
            <p className="leading-relaxed font-sans">
              All intelligence records, rumours, and exclusive articles are subjected to automated sentiment validation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}


// =========================================
// SPA POST DETAIL SUB VIEW
// =========================================
interface PostDetailProps {
  post: SpacesPost;
  allReplies: SpaceReply[];
  onSaveReplies: (replies: SpaceReply[]) => void;
  currentUser: UserProfile | null;
  onBack: () => void;
  onTriggerLogin: () => void;
  relativeTimeString: (iso: string) => string;
}

function SpacePostDetailView({
  post,
  allReplies,
  onSaveReplies,
  currentUser,
  onBack,
  onTriggerLogin,
  relativeTimeString
}: PostDetailProps) {
  const [commentText, setCommentText] = useState('');
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sortOrder, setSortOrder] = useState<'LATEST' | 'LIKED'>('LATEST');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Filter replies specific to this post
  const postReplies = allReplies.filter(r => r.targetId === post.id && r.targetType === 'post');

  // Perform Like of replies
  const handleLikeReply = (replyId: string) => {
    if (!currentUser) {
      triggerToast('Authorisation needed to vote.', 'error');
      return;
    }

    const updated = allReplies.map(r => {
      if (r.id === replyId) {
        const likedBy = [...(r.likedBy || [])];
        const idx = likedBy.indexOf(currentUser.uid);
        if (idx !== -1) {
          likedBy.splice(idx, 1);
        } else {
          likedBy.push(currentUser.uid);
        }
        return { ...r, likedBy };
      }
      return r;
    });
    onSaveReplies(updated);
  };

  // Submit level 1 Post reply
  const handlePostTopLevelReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast('Authenticate Critic Credentials to reply.', 'error');
      onTriggerLogin();
      return;
    }

    if (!commentText.trim()) {
      triggerToast('Reply content is blank', 'error');
      return;
    }

    const replyId = 'sparp_' + Math.random().toString(36).substring(2, 11);
    const newReply: SpaceReply = {
      id: replyId,
      parentId: null,
      targetId: post.id,
      targetType: 'post',
      authorUserId: currentUser.uid,
      authorUsername: currentUser.username,
      authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      createdAt: new Date().toISOString(),
      text: commentText.trim(),
      likedBy: []
    };

    onSaveReplies([newReply, ...allReplies]);
    setCommentText('');
    triggerToast('Dialogue logged!', 'success');

    // Notify author of the post
    if (post.userId && post.userId !== currentUser.uid) {
      createNotification(
        post.userId,
        currentUser.uid,
        currentUser.username,
        'REPLY_COMMENT', // Mapping to standard type
        post.id,
        'spaces_slug_link',
        `replied to your space post "${post.title.slice(0, 20)}..."`
      );
    }
  };

  // Submit Level 2 Nest Reply
  const handlePostNestedReply = (e: React.FormEvent, parentReplyId: string, replyAuthorUser: string, parentAuthorUserId: string) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast('Requires Login credential path.', 'error');
      return;
    }

    if (!replyText.trim()) {
      triggerToast('Message text required', 'error');
      return;
    }

    const replyId = 'sparp_' + Math.random().toString(36).substring(2, 11);
    const newReply: SpaceReply = {
      id: replyId,
      parentId: parentReplyId,
      targetId: post.id,
      targetType: 'post',
      authorUserId: currentUser.uid,
      authorUsername: currentUser.username,
      authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      createdAt: new Date().toISOString(),
      text: replyText.trim(),
      likedBy: []
    };

    onSaveReplies([...allReplies, newReply]);
    setReplyText('');
    setActiveReplyId(null);
    triggerToast('Replied linked to node!', 'success');

    // Notify original reply author
    if (parentAuthorUserId && parentAuthorUserId !== currentUser.uid) {
      createNotification(
        parentAuthorUserId,
        currentUser.uid,
        currentUser.username,
        'REPLY_COMMENT',
        post.id,
        'spaces_slug_link',
        `replied to your comment thread: "${replyText.slice(0, 25)}..."`
      );
    }
  };

  // Delete own reply
  const handleDeleteReply = (replyId: string) => {
    // Exclude reply and any children matching parentId=replyId
    const updated = allReplies.filter(r => r.id !== replyId && r.parentId !== replyId);
    onSaveReplies(updated);
    triggerToast('Your comment was detached.', 'success');
  };

  // Reporting simulation
  const handleReportReply = (user: string) => {
    triggerToast(`Reported @${user} to space managers. Core security active.`, 'success');
  };

  // Sort and filter replies
  const getSortedReplies = () => {
    // Only level 1 first
    const topLevel = postReplies.filter(r => !r.parentId);
    if (sortOrder === 'LIKED') {
      topLevel.sort((a, b) => b.likedBy.length - a.likedBy.length);
    } else {
      topLevel.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return topLevel;
  };

  const sortedTopReplies = getSortedReplies();

  return (
    <div className="max-w-3xl mx-auto space-y-6 text-left">
      {/* BACK NAVIGATION ROW */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-mono font-bold text-gray-400 hover:text-white transition-all cursor-pointer uppercase py-1 border-b border-transparent hover:border-white/10"
      >
        <ArrowLeft size={14} /> Back to Spaces Feed
      </button>

      {/* ARTICLE FULL PAGE BLOCK */}
      <div className="bg-[#0b0b0b] border border-white/5 rounded-[2.5rem] overflow-hidden">
        <div className="w-full h-64 md:h-80 bg-zinc-950/80 border-b border-white/5 relative">
          <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
          
          <div className="absolute bottom-5 left-5 right-5 space-y-2">
            <span className="px-2.5 py-0.5 rounded text-[9px] font-black uppercase font-mono tracking-widest border border-[#E50914]/40 bg-[#E50914]/10 text-[#E50914]">
              {post.category}
            </span>
            <h1 className="text-xl md:text-3xl font-black text-white uppercase tracking-tight leading-tight select-text">
              {post.title}
            </h1>
          </div>
        </div>

        {/* AUTHOR BLOCK INFO */}
        <div className="px-5 md:px-8 py-4 bg-white/2 border-b border-white/5 flex items-center justify-between text-[11px] font-mono text-gray-500">
          <div className="flex items-center gap-2">
            <img src={post.authorAvatar} className="w-7 h-7 rounded-full bg-white/5 border border-white/5" />
            <div>
              <span className="text-white font-bold block">@{post.authorUsername}</span>
              <span className="text-gray-500 text-[9px] block">Space Publisher • {post.authorName}</span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <Clock size={11} />
            <span>Published {relativeTimeString(post.createdAt)}</span>
          </div>
        </div>

        {/* FULL TEXT CONTENT */}
        <div className="p-5 md:p-8 select-text">
          <p className="text-sm md:text-base text-gray-300 font-sans leading-relaxed whitespace-pre-line font-medium">
            {post.text}
          </p>
        </div>
      </div>

      {/* REPLY ENGINE BLOCK */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-2">
          <h3 className="text-sm font-black text-white uppercase tracking-tight font-mono flex items-center gap-1.5">
            <MessageSquare size={14} className="text-[#E50914]" /> {postReplies.length} DEBATER CONVERSATIONS
          </h3>

          {/* SORT SWITCH */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-gray-500 uppercase">Sort Replies:</span>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="bg-[#111] border border-white/5 py-1 px-2.5 rounded-lg text-[10px] font-mono font-bold text-gray-300 focus:outline-none"
            >
              <option value="LATEST">Latest First</option>
              <option value="LIKED">Most Liked</option>
            </select>
          </div>
        </div>

        {/* INPUT FORM BLOCK */}
        {currentUser ? (
          <form onSubmit={handlePostTopLevelReply} className="bg-[#111111]/40 border border-white/5 p-4 rounded-2xl flex gap-3">
            <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`} className="w-8 h-8 rounded-full bg-white/5 flex-shrink-0" />
            <div className="flex-1 space-y-3">
              <textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Submit your cinematic reply or critique of this post thread..."
                rows={3}
                className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914] focus:ring-0 leading-relaxed font-sans"
              />
              <button
                type="submit"
                className="bg-[#E50914] text-white hover:bg-red-600 font-bold font-mono text-[10px] tracking-widest uppercase px-5 py-2.5 rounded-lg transition-colors cursor-pointer float-right"
              >
                Post Reply
              </button>
            </div>
          </form>
        ) : (
          <div className="bg-[#111111]/10 border border-white/5 py-6 px-4 rounded-[2rem] text-center space-y-2">
            <p className="text-xs text-gray-400 font-sans max-w-sm mx-auto">
              You must activate your identity credentials to post replies inside our Spaces discussion board.
            </p>
            <button
              onClick={onTriggerLogin}
              className="px-5 py-2 bg-white/5 hover:bg-white/10 text-[#E50914] border border-white/10 rounded-xl text-3xs font-black font-mono tracking-widest uppercase cursor-pointer"
            >
              Authorize Login Credential
            </button>
          </div>
        )}

        {/* REPLIES CARDS LIST */}
        <div className="space-y-4">
          {sortedTopReplies.length === 0 ? (
            <div className="bg-[#0b0b0b]/30 border border-white/5 rounded-[2rem] py-12 text-center text-gray-500 font-mono text-[11px]">
              No replies yet. Be the first!
            </div>
          ) : (
            sortedTopReplies.map((reply) => {
              const hasLiked = currentUser && reply.likedBy?.includes(currentUser.uid);
              const isOwnReply = currentUser && reply.authorUserId === currentUser.uid;

              // Nested L2 replies
              const l2Replies = postReplies.filter(r => r.parentId === reply.id);

              return (
                <div key={reply.id} className="space-y-3 p-4 bg-[#0c0c0c] border border-white/5 rounded-[2rem]">
                  {/* LEVEL 1 CARD */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-2.5">
                        <img src={reply.authorAvatar} className="w-8 h-8 rounded-full bg-white/5" />
                        <div>
                          <div className="flex items-center gap-1.5 font-sans font-medium text-xs">
                            <span className="text-white font-black text-2xs">@{reply.authorUsername}</span>
                            {reply.authorUserId === 'admin_uid_fallback' && (
                              <span className="text-[8px] uppercase tracking-widest text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/20 px-1 py-0.2 rounded font-mono font-bold">Mod</span>
                            )}
                          </div>
                          <span className="text-[9px] font-mono text-gray-500 block">{relativeTimeString(reply.createdAt)}</span>
                        </div>
                      </div>

                      {/* Drop menu controls */}
                      <div className="relative">
                        <button
                          onClick={() => setActiveMenuId(activeMenuId === reply.id ? null : reply.id)}
                          className="w-7 h-7 rounded-full bg-white/3 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
                        >
                          <MoreHorizontal size={12} />
                        </button>
                        {activeMenuId === reply.id && (
                          <div className="absolute right-0 mt-1 w-36 bg-[#111] border border-white/10 rounded-xl z-50 py-1 text-4xs font-mono shadow-2xl">
                            {isOwnReply ? (
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleDeleteReply(reply.id);
                                }}
                                className="w-full text-left px-3 py-2 text-red-500 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                <Trash2 size={10} /> Delete Reply
                              </button>
                            ) : (
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleReportReply(reply.authorUsername);
                                }}
                                className="w-full text-left px-3 py-2 text-gray-400 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                <Flag size={10} /> Report Violation
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-gray-300 pl-1">{reply.text}</p>

                    {/* Actions buttons */}
                    <div className="flex items-center gap-3.5 text-[9px] font-mono pt-1">
                      <button
                        onClick={() => handleLikeReply(reply.id)}
                        className={`flex items-center gap-1 transition-colors ${hasLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                      >
                        <Heart size={11} className={hasLiked ? 'fill-red-500 text-red-500' : ''} />
                        <span>{reply.likedBy?.length || 0}</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveReplyId(reply.id);
                          setReplyText(`@${reply.authorUsername} `);
                        }}
                        className="text-gray-500 hover:text-red-400 font-bold transition-all"
                      >
                        Reply
                      </button>
                    </div>
                  </div>

                  {/* LEVEL 2 INDENTED CARDS */}
                  {l2Replies.map((nested) => {
                    const nestLiked = currentUser && nested.likedBy?.includes(currentUser.uid);
                    const nestOwn = currentUser && nested.authorUserId === currentUser.uid;

                    return (
                      <div key={nested.id} className="flex gap-2.5 pl-6 border-l border-white/5">
                        <CornerDownRight size={14} className="text-gray-600 mt-2 flex-shrink-0" />
                        <div className="flex-1 p-3 bg-white/2 border border-white/5 rounded-2xl space-y-2">
                          <div className="flex justify-between items-start">
                            <div className="flex gap-2">
                              <img src={nested.authorAvatar} className="w-6 h-6 rounded-full bg-white/5" />
                              <div>
                                <span className="text-white font-black text-2xs block">@{nested.authorUsername}</span>
                                <span className="text-[8px] font-mono text-gray-500 block">{relativeTimeString(nested.createdAt)}</span>
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                if (nestOwn) {
                                  handleDeleteReply(nested.id);
                                } else {
                                  handleReportReply(nested.authorUsername);
                                }
                              }}
                              className="text-gray-500 hover:text-white text-3xs font-mono font-bold uppercase transition-all"
                            >
                              {nestOwn ? 'Delete' : 'Report'}
                            </button>
                          </div>

                          <p className="text-xs text-gray-300 leading-relaxed font-sans select-text">
                            {nested.text}
                          </p>

                          <button
                            onClick={() => handleLikeReply(nested.id)}
                            className={`flex items-center gap-1 text-[9px] font-mono transition-colors ${nestLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                          >
                            <Heart size={10} className={nestLiked ? 'fill-red-500 text-red-500' : ''} />
                            <span>{nested.likedBy?.length || 0}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  {/* REPLY INLINE BOX */}
                  {activeReplyId === reply.id && (
                    <form
                      onSubmit={(e) => handlePostNestedReply(e, reply.id, reply.authorUsername, reply.authorUserId)}
                      className="p-3 bg-black/60 rounded-xl border border-[#E50914]/20 flex gap-2 pl-6"
                    >
                      <input
                        type="text"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Structure your secure reply..."
                        className="flex-1 bg-black/60 border border-white/5 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E50914]"
                        autoFocus
                        required
                      />
                      <button type="submit" className="bg-[#E50914] text-white hover:bg-red-600 px-4 rounded-lg text-2xs font-mono font-bold uppercase">
                        Reply
                      </button>
                      <button type="button" onClick={() => { setActiveReplyId(null); setReplyText(''); }} className="text-gray-500 hover:text-white px-1 text-2xs font-bold font-mono uppercase">
                        Cancel
                      </button>
                    </form>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}


// =========================================
// SPA DISCUSSION DETAIL SUB VIEW
// =========================================
interface DiscussionDetailProps {
  discussion: SpacesDiscussion;
  allReplies: SpaceReply[];
  onSaveReplies: (replies: SpaceReply[]) => void;
  currentUser: UserProfile | null;
  onBack: () => void;
  onTriggerLogin: () => void;
  relativeTimeString: (iso: string) => string;
}

function SpaceDiscussionDetailView({
  discussion,
  allReplies,
  onSaveReplies,
  currentUser,
  onBack,
  onTriggerLogin,
  relativeTimeString
}: DiscussionDetailProps) {
  const [commentText, setCommentText] = useState('');
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sortOrder, setSortOrder] = useState<'LATEST' | 'LIKED'>('LATEST');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const discReplies = allReplies.filter(r => r.targetId === discussion.id && r.targetType === 'discussion');

  // Submit level 1 Reply
  const handlePostTopReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast('Authenticate Critic Credentials to write.', 'error');
      onTriggerLogin();
      return;
    }

    if (!commentText.trim()) return;

    const replyId = 'sparp_' + Math.random().toString(36).substring(2, 11);
    const newReply: SpaceReply = {
      id: replyId,
      parentId: null,
      targetId: discussion.id,
      targetType: 'discussion',
      authorUserId: currentUser.uid,
      authorUsername: currentUser.username,
      authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      createdAt: new Date().toISOString(),
      text: commentText.trim(),
      likedBy: []
    };

    onSaveReplies([newReply, ...allReplies]);
    setCommentText('');
    triggerToast('Verdict pinned to debate floor!', 'success');

    // Notify author of original discussion
    if (discussion.userId && discussion.userId !== currentUser.uid) {
      createNotification(
        discussion.userId,
        currentUser.uid,
        currentUser.username,
        'REPLY_COMMENT',
        discussion.id,
        'spaces_slug_link',
        `replied to your discussion "${discussion.title.slice(0, 20)}..."`
      );
    }
  };

  // Submit Level 2 Reply
  const handlePostNestedReply = (e: React.FormEvent, parentReplyId: string, replyAuthorUser: string, parentAuthorUserId: string) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast('Authorize account first.', 'error');
      return;
    }

    if (!replyText.trim()) return;

    const replyId = 'sparp_' + Math.random().toString(36).substring(2, 11);
    const newReply: SpaceReply = {
      id: replyId,
      parentId: parentReplyId,
      targetId: discussion.id,
      targetType: 'discussion',
      authorUserId: currentUser.uid,
      authorUsername: currentUser.username,
      authorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
      createdAt: new Date().toISOString(),
      text: replyText.trim(),
      likedBy: []
    };

    onSaveReplies([...allReplies, newReply]);
    setReplyText('');
    setActiveReplyId(null);
    triggerToast('Secure nested reply added!', 'success');

    // Notify parent author
    if (parentAuthorUserId && parentAuthorUserId !== currentUser.uid) {
      createNotification(
        parentAuthorUserId,
        currentUser.uid,
        currentUser.username,
        'REPLY_COMMENT',
        discussion.id,
        'spaces_slug_link',
        `replied to your debate note: "${replyText.slice(0, 25)}..."`
      );
    }
  };

  const handleLikeReply = (replyId: string) => {
    if (!currentUser) return;
    const updated = allReplies.map(r => {
      if (r.id === replyId) {
        const likedBy = [...(r.likedBy || [])];
        const idx = likedBy.indexOf(currentUser.uid);
        if (idx !== -1) {
          likedBy.splice(idx, 1);
        } else {
          likedBy.push(currentUser.uid);
        }
        return { ...r, likedBy };
      }
      return r;
    });
    onSaveReplies(updated);
  };

  const handleDeleteReply = (replyId: string) => {
    const updated = allReplies.filter(r => r.id !== replyId && r.parentId !== replyId);
    onSaveReplies(updated);
    triggerToast('Verdict unlinked from debate floor.', 'success');
  };

  const handleReportReply = (user: string) => {
    triggerToast(`Analysis report logged against @${user}. Security review pending.`, 'success');
  };

  const sortedTopReplies = discReplies.filter(r => !r.parentId).sort((a, b) => {
    if (sortOrder === 'LIKED') {
      return b.likedBy.length - a.likedBy.length;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <div className="max-w-3xl mx-auto space-y-6 text-left">
      {/* NAVIGATION BAR */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-mono font-bold text-gray-400 hover:text-white transition-all cursor-pointer uppercase py-1 border-b border-transparent hover:border-white/10"
      >
        <ArrowLeft size={14} /> Back to Discussions Floor
      </button>

      {/* DISCUSSION BANNER CARD */}
      <div className="bg-[#0b0b0b] border border-white/5 rounded-[2.5rem] p-6 md:p-8 space-y-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/[0.03] blur-2xl rounded-full pointer-events-none"></div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-red-600/10 text-red-500 rounded-full text-[9px] font-black font-mono tracking-widest border border-red-500/20 uppercase">
            DISCUSSION BOARD
          </span>
          {discussion.isPinned && (
            <span className="px-3 py-1 bg-emerald-600/10 text-emerald-400 rounded-full text-[9px] font-black font-mono tracking-widest border border-emerald-500/20 uppercase">
              PINNED DIALOGUE
            </span>
          )}
        </div>

        <div className="space-y-3 select-text">
          <h1 className="text-xl md:text-3xl font-black text-white uppercase tracking-tight leading-tight">
            {discussion.title}
          </h1>
          <p className="text-xs md:text-sm text-gray-300 font-sans leading-relaxed max-w-2xl font-medium">
            {discussion.description}
          </p>
        </div>

        <div className="flex justify-between items-center pt-4 border-t border-white/5 text-[10px] font-mono text-gray-500">
          <div className="flex items-center gap-2">
            <img src={discussion.authorAvatar} className="w-6.5 h-6.5 rounded-full bg-white/5 border border-white/10" />
            <div>
              <span className="text-white font-bold block">@{discussion.authorUsername}</span>
              <span className="text-gray-500 text-[8px] block">Discussion Initiator</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-gray-400 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5">
            <Clock size={11} />
            <span>Opened {relativeTimeString(discussion.createdAt)}</span>
          </div>
        </div>
      </div>

      {/* REPLIES ENGINE SYSTEM */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-2">
          <h3 className="text-sm font-black text-white uppercase tracking-tight font-mono">
            {discReplies.length} Floor Comments Pinned
          </h3>

          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as any)}
            className="bg-[#111] border border-white/5 py-1 px-2.5 rounded-lg text-[10px] font-mono font-bold text-gray-300 focus:outline-none"
          >
            <option value="LATEST">Latest First</option>
            <option value="LIKED">Most Liked</option>
          </select>
        </div>

        {/* REPLIES FORM GATES */}
        {currentUser ? (
          <form onSubmit={handlePostTopReply} className="bg-[#111111]/40 border border-white/5 p-4 rounded-2xl flex gap-3">
            <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`} className="w-8 h-8 rounded-full bg-white/5 flex-shrink-0" />
            <div className="flex-1 space-y-3">
              <textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Flesh out your floor response or argument with cinematic context..."
                rows={3}
                className="w-full bg-black/40 border border-white/5 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none focus:border-[#E50914] focus:ring-0 leading-relaxed font-sans"
              />
              <button
                type="submit"
                className="bg-[#E50914] text-white hover:bg-red-600 font-bold font-mono text-[10px] tracking-widest uppercase px-5 py-2.5 rounded-lg transition-colors cursor-pointer float-right"
              >
                Post Reply
              </button>
            </div>
          </form>
        ) : (
          <div className="bg-[#111111]/10 border border-white/5 py-6 px-4 rounded-[2rem] text-center space-y-2">
            <p className="text-xs text-gray-400 font-sans max-w-sm mx-auto">
              You must activate your identity credentials to post dialogue inside the Active debate floor.
            </p>
            <button
              onClick={onTriggerLogin}
              className="px-5 py-2 bg-white/5 hover:bg-white/10 text-[#E50914] border border-white/10 rounded-xl text-3xs font-black font-mono tracking-widest uppercase cursor-pointer"
            >
              Authorize Login Credential
            </button>
          </div>
        )}

        {/* VERDICTS LIST OUT */}
        <div className="space-y-4">
          {sortedTopReplies.length === 0 ? (
            <div className="bg-[#0b0b0b]/30 border border-white/5 rounded-[2rem] py-12 text-center text-gray-500 font-mono text-[11px]">
              No comments posted yet. Pioneer the dialogue floor!
            </div>
          ) : (
            sortedTopReplies.map((reply) => {
              const hasLiked = currentUser && reply.likedBy?.includes(currentUser.uid);
              const isOwnReply = currentUser && reply.authorUserId === currentUser.uid;
              const subLevel = discReplies.filter(r => r.parentId === reply.id);

              return (
                <div key={reply.id} className="space-y-3 p-4 bg-[#0c0c0c] border border-white/5 rounded-[2rem]">
                  {/* LEVEL 1 */}
                  <div className="space-y-2 animate-fadeIn">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-2.5">
                        <img src={reply.authorAvatar} className="w-8 h-8 rounded-full bg-white/5" />
                        <div>
                          <div className="flex items-center gap-1.5 font-sans font-medium text-xs">
                            <span className="text-white font-black text-2xs">@{reply.authorUsername}</span>
                          </div>
                          <span className="text-[9px] font-mono text-gray-500 block">{relativeTimeString(reply.createdAt)}</span>
                        </div>
                      </div>

                      {/* Menu */}
                      <div className="relative">
                        <button
                          onClick={() => setActiveMenuId(activeMenuId === reply.id ? null : reply.id)}
                          className="w-7 h-7 rounded-full bg-white/3 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer"
                        >
                          <MoreHorizontal size={12} />
                        </button>
                        {activeMenuId === reply.id && (
                          <div className="absolute right-0 mt-1 w-36 bg-[#111] border border-white/10 rounded-xl z-50 py-1 text-4xs font-mono shadow-2xl">
                            {isOwnReply ? (
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleDeleteReply(reply.id);
                                }}
                                className="w-full text-left px-3 py-2 text-red-500 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                <Trash2 size={10} /> Delete Reply
                              </button>
                            ) : (
                              <button
                                onClick={() => {
                                  setActiveMenuId(null);
                                  handleReportReply(reply.authorUsername);
                                }}
                                className="w-full text-left px-3 py-2 text-gray-400 hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                              >
                                <Flag size={10} /> Report Violation
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-gray-300 pl-1 leading-relaxed whitespace-pre-line select-text">
                      {reply.text}
                    </p>

                    <div className="flex items-center gap-3 text-[9px] font-mono pt-1">
                      <button
                        onClick={() => handleLikeReply(reply.id)}
                        className={`flex items-center gap-1 transition-colors ${hasLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                      >
                        <Heart size={11} className={hasLiked ? 'fill-red-500 text-red-500' : ''} />
                        <span>{reply.likedBy?.length || 0}</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveReplyId(reply.id);
                          setReplyText(`@${reply.authorUsername} `);
                        }}
                        className="text-gray-500 hover:text-red-400 font-bold transition-all"
                      >
                        Reply
                      </button>
                    </div>
                  </div>

                  {/* LEVEL 2 */}
                  {subLevel.map((nested) => {
                    const nestLiked = currentUser && nested.likedBy?.includes(currentUser.uid);
                    const nestOwn = currentUser && nested.authorUserId === currentUser.uid;

                    return (
                      <div key={nested.id} className="flex gap-2.5 pl-6 border-l border-white/5">
                        <CornerDownRight size={14} className="text-gray-600 mt-2 flex-shrink-0" />
                        <div className="flex-1 p-3 bg-white/2 border border-white/5 rounded-2xl space-y-2">
                          <div className="flex justify-between items-start">
                            <div className="flex gap-2">
                              <img src={nested.authorAvatar} className="w-6 h-6 rounded-full bg-white/5" />
                              <div>
                                <span className="text-white font-black text-2xs block">@{nested.authorUsername}</span>
                                <span className="text-[8px] font-mono text-gray-500 block">{relativeTimeString(nested.createdAt)}</span>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                if (nestOwn) {
                                  handleDeleteReply(nested.id);
                                } else {
                                  handleReportReply(nested.authorUsername);
                                }
                              }}
                              className="text-gray-500 hover:text-white text-3xs font-mono font-bold uppercase transition-all"
                            >
                              {nestOwn ? 'Delete' : 'Report'}
                            </button>
                          </div>

                          <p className="text-xs text-gray-300 leading-relaxed font-sans select-text">
                            {nested.text}
                          </p>

                          <button
                            onClick={() => handleLikeReply(nested.id)}
                            className={`flex items-center gap-1 text-[9px] font-mono transition-colors ${nestLiked ? 'text-red-500 font-bold' : 'text-gray-500 hover:text-white'}`}
                          >
                            <Heart size={10} className={nestLiked ? 'fill-red-500 text-red-500' : ''} />
                            <span>{nested.likedBy?.length || 0}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  {/* INLINE REPLY */}
                  {activeReplyId === reply.id && (
                    <form
                      onSubmit={(e) => handlePostNestedReply(e, reply.id, reply.authorUsername, reply.authorUserId)}
                      className="p-3 bg-black/60 rounded-xl border border-[#E50914]/20 flex gap-2 pl-6"
                    >
                      <input
                        type="text"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Structure your secure reply..."
                        className="flex-1 bg-black/60 border border-white/5 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E50914]"
                        autoFocus
                        required
                      />
                      <button type="submit" className="bg-[#E50914] text-white hover:bg-red-600 px-4 rounded-lg text-2xs font-mono font-bold uppercase">
                        Reply
                      </button>
                      <button type="button" onClick={() => { setActiveReplyId(null); setReplyText(''); }} className="text-gray-500 hover:text-white px-1 text-2xs font-bold font-mono uppercase">
                        Cancel
                      </button>
                    </form>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
