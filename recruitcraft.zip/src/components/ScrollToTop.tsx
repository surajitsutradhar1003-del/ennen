import { useEffect } from 'react';

interface ScrollToTopProps {
  path: string;
}

export default function ScrollToTop({ path }: ScrollToTopProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [path]);

  return null;
}
