import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Chrome, 
  Smartphone, 
  KeyRound, 
  ArrowRight, 
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { 
  loginWithEmail, 
  loginWithGoogle, 
  requestPhoneOTP, 
  verifyPhoneOTP, 
  checkLockoutStatus,
  triggerToast 
} from '../lib/firebase';
import { AppRoute } from '../types';

interface LoginPageProps {
  onNavigate: (route: AppRoute) => void;
}

type AuthTab = 'email' | 'google' | 'phone';

export default function LoginPage({ onNavigate }: LoginPageProps) {
  const [activeTab, setActiveTab] = useState<AuthTab>('email');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [authMethods, setAuthMethods] = useState({
    email_password: true,
    google_oauth: true,
    phone_otp: true
  });

  // Email form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Phone states
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [timer, setTimer] = useState(0);

  // 15-minute Lockout checker runtime
  const [lockoutTimer, setLockoutTimer] = useState<{ locked: boolean; remainingMinutes: number }>({
    locked: false,
    remainingMinutes: 0
  });

  useEffect(() => {
    // Load config settings dynamically
    const raw = localStorage.getItem('muvio_general_settings');
    if (raw) {
      try {
        const config = JSON.parse(raw);
        if (config.authMethods) {
          const methods = {
            email_password: config.authMethods.email_password !== false,
            google_oauth: config.authMethods.google_oauth !== false,
            phone_otp: config.authMethods.phone_otp !== false
          };
          setAuthMethods(methods);

          // Select first available tab
          if (methods.email_password) {
            setActiveTab('email');
          } else if (methods.google_oauth) {
            setActiveTab('google');
          } else if (methods.phone_otp) {
            setActiveTab('phone');
          }
        }
      } catch (e) {
        console.error(e);
      }
    }

    // Check lockout on render
    const status = checkLockoutStatus();
    setLockoutTimer(status);

    // Set interval to decrement or unlock
    const interval = setInterval(() => {
      const currentStatus = checkLockoutStatus();
      setLockoutTimer(currentStatus);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  // OTP resend timer countdown
  useEffect(() => {
    if (timer > 0) {
      const timerInterval = setInterval(() => {
        setTimer((v) => v - 1);
      }, 1000);
      return () => clearInterval(timerInterval);
    }
  }, [timer]);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Safeguard lockout
    if (lockoutTimer.locked) {
      setErrorMessage(`Master Portal Lockout. Please wait ${lockoutTimer.remainingMinutes} more minutes.`);
      return;
    }

    if (!email || !password) {
      setErrorMessage('Please enter both your master email address and private code.');
      return;
    }

    setLoading(true);
    try {
      const userProf = await loginWithEmail(email, password);
      if (userProf?.role === 'admin') {
        onNavigate('/admin');
      } else {
        onNavigate('/explore');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred during verification.');
      // Refresh lockout state
      setLockoutTimer(checkLockoutStatus());
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMessage(null);
    setLoading(true);
    try {
      const userProf = await loginWithGoogle();
      if (userProf?.role === 'admin') {
        onNavigate('/admin');
      } else {
        onNavigate('/explore');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Google authorization rejected.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!phoneNumber) {
      setErrorMessage('Please supply a valid phone signature.');
      return;
    }

    setLoading(true);
    try {
      // In Web iframe environment, we specify null verifier and fallback beautifully to code dispatch simulator
      const result = await requestPhoneOTP(phoneNumber, null);
      setConfirmationResult(result);
      setOtpSent(true);
      setTimer(60); // 60 seconds delay for resend option
      triggerToast('6-digit security token dispatched.', 'success');
    } catch (err: any) {
      setErrorMessage(err.message || 'Could not send OTP to the specified line.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!otpCode || otpCode.length !== 6) {
      setErrorMessage('Please enter the active 6-digit verification code.');
      return;
    }

    setLoading(true);
    try {
      const userProf = await verifyPhoneOTP(otpCode, confirmationResult);
      if (userProf?.role === 'admin') {
        onNavigate('/admin');
      } else {
        onNavigate('/explore');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid or expired OTP signature.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    if (!email) {
      triggerToast('Please type your registered email address first.', 'error');
      return;
    }
    triggerToast(`Password decryption/reset transmission sent successfully to ${email}.`, 'success');
  };

  return (
    <div className="w-full max-w-md mx-auto mt-6 md:mt-12 bg-[#0c0c0c]/90 border border-white/5 rounded-3xl p-6 md:p-8 relative select-none shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden" id="login-container">
      {/* Decorative gradient overlay */}
      <div className="absolute top-0 inset-x-0 h-[3px] bg-gradient-to-r from-transparent via-[#E50914] to-transparent"></div>

      {/* Hero header */}
      <div className="text-center mb-8 space-y-2">
        <h2 className="font-display font-black text-3xl tracking-tighter text-[#E50914] italic crimson-glow hover:scale-[1.01] transition-all">
          MUVIO
        </h2>
        <p className="text-[10px] font-black tracking-[0.25em] text-white/40 uppercase font-mono">
          MASTER CINEMA PORTAL
        </p>
      </div>

      {/* Tabs list */}
      {(!authMethods.email_password && !authMethods.google_oauth && !authMethods.phone_otp) ? (
        <div className="p-4 mb-6 bg-red-600/10 border border-red-600/20 rounded-xl text-center space-y-2">
          <div className="text-red-500 font-bold uppercase text-[10px] tracking-widest font-mono">⚠️ FULL SIGN-IN LOCKDOWN</div>
          <p className="text-[10px] text-gray-400 font-sans leading-relaxed">
            All dynamic authentication pipelines are currently locked by standard operator directives.
          </p>
        </div>
      ) : (
        <div className={`grid gap-1 bg-[#141414]/90 border border-white/5 p-1 rounded-2xl mb-6 ${
          (authMethods.email_password ? 1 : 0) + (authMethods.google_oauth ? 1 : 0) + (authMethods.phone_otp ? 1 : 0) === 3 ? 'grid-cols-3' :
          (authMethods.email_password ? 1 : 0) + (authMethods.google_oauth ? 1 : 0) + (authMethods.phone_otp ? 1 : 0) === 2 ? 'grid-cols-2' : 'grid-cols-1'
        }`}>
          {authMethods.email_password && (
            <button
              onClick={() => { setActiveTab('email'); setErrorMessage(null); }}
              className={`py-2 text-[10px] font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                activeTab === 'email' 
                  ? 'bg-[#E50914] text-white shadow-[0_2px_10px_rgba(229,9,20,0.2)]' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              id="tab-btn-email"
            >
              Email
            </button>
          )}
          {authMethods.google_oauth && (
            <button
              onClick={() => { setActiveTab('google'); setErrorMessage(null); }}
              className={`py-2 text-[10px] font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                activeTab === 'google' 
                  ? 'bg-[#E50914] text-white shadow-[0_2px_10px_rgba(229,9,20,0.2)]' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              id="tab-btn-google"
            >
              Google
            </button>
          )}
          {authMethods.phone_otp && (
            <button
              onClick={() => { setActiveTab('phone'); setErrorMessage(null); }}
              className={`py-2 text-[10px] font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                activeTab === 'phone' 
                  ? 'bg-[#E50914] text-white shadow-[0_2px_10px_rgba(229,9,20,0.2)]' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              id="tab-btn-phone"
            >
              OTP Link
            </button>
          )}
        </div>
      )}

      {/* Security alert notification banner */}
      {errorMessage && (
        <motion.div 
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 mb-6 bg-[#E50914]/10 border border-[#E50914]/20 rounded-xl flex items-start gap-2.5 text-xs text-[#FF3333] font-medium"
          id="auth-error-banner"
        >
          <ShieldAlert size={16} className="mt-0.5 shrink-0" />
          <span>{errorMessage}</span>
        </motion.div>
      )}

      {/* Active screen rendering */}
      {activeTab === 'email' && (
        <form onSubmit={handleEmailLogin} className="space-y-4" id="email-login-form">
          <div className="space-y-1">
            <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Secure Email</label>
            <div className="relative">
              <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
              <input
                type="email"
                required
                disabled={loading || lockoutTimer.locked}
                placeholder="signature@muvio.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Private Passcode</label>
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-[9px] font-bold text-gray-500 hover:text-[#E50914] transition-colors cursor-pointer"
              >
                Forgot Key Code?
              </button>
            </div>
            <div className="relative">
              <Lock size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                disabled={loading || lockoutTimer.locked}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-10 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/40 transition-colors cursor-pointer"
              >
                {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || lockoutTimer.locked}
            className="w-full bg-[#E50914] hover:bg-[#FF1A1A] disabled:bg-[#4d0c10] text-white font-bold text-xs py-3.5 rounded-xl shadow-[0_4px_16px_rgba(229,9,20,0.25)] transition-all flex items-center justify-center gap-2 cursor-pointer mt-6"
            id="btn-login-email-submit"
          >
            {loading ? (
              <>
                <Loader2 size={14} className="animate-spin" />
                <span>Authorizing Portal Access...</span>
              </>
            ) : (
              <>
                <span>AUTHORIZE ACCESS</span>
                <ArrowRight size={14} />
              </>
            )}
          </button>
        </form>
      )}

      {activeTab === 'google' && (
        <div className="space-y-5 py-2 text-center" id="google-login-view">
          <p className="text-xs text-white/40 max-w-xs mx-auto leading-relaxed font-sans">
            Instantly sync your reviews, schedules, and custom vaults using your Google core key credential.
          </p>

          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full bg-white hover:bg-neutral-100 text-black font-extrabold text-xs py-3.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer"
            id="btn-login-google-submit"
          >
            {loading ? (
              <Loader2 size={14} className="animate-spin text-[#E50914]" />
            ) : (
              <Chrome size={14} className="text-[#EA4335]" />
            )}
            <span>CONTINUE WITH GOOGLE</span>
          </button>
        </div>
      )}

      {activeTab === 'phone' && (
        <div className="space-y-4" id="phone-login-view">
          {!otpSent ? (
            <form onSubmit={handleSendOTP} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-wider text-white/40">Phone Number Signature</label>
                <div className="relative">
                  <Smartphone size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
                  <input
                    type="tel"
                    required
                    disabled={loading}
                    placeholder="+1 (555) 000-0000"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs text-white placeholder-white/20 focus:border-[#E50914]/40 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#E50914] hover:bg-[#FF1A1A] text-white font-bold text-xs py-3.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mt-6"
                id="btn-send-otp"
              >
                {loading ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    <span>Sending SMS token...</span>
                  </>
                ) : (
                  <>
                    <span>SEND VERIFICATION OTP</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOTP} className="space-y-4" id="otp-verify-form">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-wider text-white/40">6-Digit SMS Security Code</label>
                <div className="relative">
                  <KeyRound size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/20" />
                  <input
                    type="text"
                    required
                    disabled={loading}
                    maxLength={6}
                    placeholder="000000"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    className="w-full bg-[#111111]/80 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-xs text-white tracking-[0.6em] text-center placeholder-white/10 focus:border-[#E50914]/40 focus:outline-none transition-colors font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#E50914] hover:bg-[#FF1A1A] text-white font-bold text-xs py-3.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mt-6"
                id="btn-verify-otp"
              >
                {loading ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    <span>Verifying Code Signature...</span>
                  </>
                ) : (
                  <>
                    <span>SIGN IN SECURELY</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>

              <div className="flex justify-between items-center text-[10px] pt-1">
                <span className="text-white/30">Did not receive SMS code?</span>
                <button
                  type="button"
                  disabled={timer > 0 || loading}
                  onClick={handleSendOTP}
                  className="text-[#E50914] font-bold disabled:text-neutral-600 transition-colors cursor-pointer"
                >
                  {timer > 0 ? `Resend key in ${timer}s` : 'Resend OTP Link'}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Account creation link route switcher */}
      <div className="text-center mt-8 pt-6 border-t border-white/5">
        <button
          onClick={() => onNavigate('/register')}
          className="text-xs text-white/40 hover:text-white transition-colors cursor-pointer inline-flex items-center gap-1.5 font-sans"
          id="link-nav-register"
        >
          <span>Cinema Newcomer?</span>
          <span className="font-bold text-[#E50914] hover:underline">Register Account</span>
        </button>
      </div>
    </div>
  );
}
