import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useQuery } from '@tanstack/react-query';
import { 
  Flame, 
  Megaphone, 
  ChevronRight, 
  ChevronLeft, 
  Play, 
  Sparkles, 
  Star, 
  RefreshCw,
  FolderHeart,
  ExternalLink,
  Compass,
  Tv,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { 
  getFeaturedSliderContent, 
  getTalkOfTheTown, 
  getContentByCategory,
  getMostInterested,
  isLiveTmdbFeedOn,
  MuvioMedia,
  generateSlug
} from '../lib/tmdb';
import { getCustomPublishedMedia } from '../lib/adminCatalog';
import { toggleInterest, getUserInterests, getMostInterestedFromFirebase } from '../lib/userInteractions';
import { AppRoute } from '../types';
import AdSlot from './AdSlot';
import { UserProfile } from '../lib/firebase';
import AdvancedFilterAndRankingsView from './AdvancedFilterAndRankingsView';

interface ExplorePageContentProps {
  onNavigate?: (route: AppRoute) => void;
  currentUser?: UserProfile | null;
  onTriggerAuthPrompt?: () => void;
}

export default function ExplorePageContent({ 
  onNavigate,
  currentUser,
  onTriggerAuthPrompt
}: ExplorePageContentProps) {
  // 1. Resolve Active Global/Local Filter (Real-Time Synchronizer)
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  useEffect(() => {
    const handleUrlChange = () => {
      const searchParams = new URLSearchParams(window.location.search);
      let filterVal = searchParams.get('filter');
      const pathname = window.location.pathname;
      if (pathname === '/rankings/monthly') {
        filterVal = 'monthly';
      } else if (pathname === '/rankings/top100') {
        filterVal = 'top100';
      }
      setActiveFilter(filterVal);
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    const interval = setInterval(handleUrlChange, 250);

    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      clearInterval(interval);
    };
  }, []);

  // 1. Interactive States
  const [activeSlide, setActiveSlide] = useState(0);
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'MOVIE' | 'SHOW' | 'ANIME'>('ALL');
  const [interestedFilter, setInterestedFilter] = useState<'week' | 'month' | 'all'>('week');
  const [interestsMap, setInterestsMap] = useState<Record<string, boolean>>({});

  // 2. Pagination State for Latest Content Grid
  const [catalogPage, setCatalogPage] = useState(1);
  const [completeCatalog, setCompleteCatalog] = useState<MuvioMedia[]>([]);
  const [loadingCatalog, setLoadingCatalog] = useState(false);
  const [latestCountLimit, setLatestCountLimit] = useState<number>(10);

  // Load latest catalog limit dynamically and listen for sync events
  useEffect(() => {
    const updateLimit = () => {
      const savedCount = localStorage.getItem('muvio_latest_catalog_count');
      if (savedCount) {
        const val = parseInt(savedCount, 10);
        if (!isNaN(val) && val >= 4 && val <= 50) {
          setLatestCountLimit(val);
        }
      } else {
        setLatestCountLimit(10);
      }
      setCatalogPage(1);
    };
    updateLimit();
    window.addEventListener('muvio_latest_catalog_count_changed', updateLimit);
    return () => {
      window.removeEventListener('muvio_latest_catalog_count_changed', updateLimit);
    };
  }, []);

  // Calculated variables and helpers for pagination
  const totalItemsCount = completeCatalog.length;
  const totalPages = Math.max(1, Math.ceil(totalItemsCount / latestCountLimit));
  const activePage = Math.min(catalogPage, totalPages);
  
  const currentStart = totalItemsCount === 0 ? 0 : (activePage - 1) * latestCountLimit + 1;
  const currentEnd = Math.min(activePage * latestCountLimit, totalItemsCount);
  const paginatedItems = completeCatalog.slice((activePage - 1) * latestCountLimit, activePage * latestCountLimit);

  const getPaginationRange = (curr: number, total: number) => {
    const range: (number | string)[] = [];
    const delta = 1; // display delta around current page

    for (let i = 1; i <= total; i++) {
      if (
        i === 1 ||
        i === total ||
        (i >= curr - delta && i <= curr + delta)
      ) {
        range.push(i);
      } else if (range[range.length - 1] !== '...') {
        range.push('...');
      }
    }
    return range;
  };

  const handlePageChange = (p: number) => {
    setCatalogPage(p);
    const element = document.getElementById('latest-content-directory');
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  // Load user interests from Firebase
  useEffect(() => {
    if (!currentUser?.uid) return;
    getUserInterests(currentUser.uid).then(map => {
      setInterestsMap(map);
    }).catch(e => console.warn('getUserInterests failed:', e));
  }, [currentUser?.uid]);

  // --- REACT QUERY FETCHERS ---
  
  // A. Featured Cinematic Slider Query
  const { 
    data: featuredItems = [], 
    isLoading: featuredLoading, 
    isError: featuredError,
    refetch: refetchFeatured
  } = useQuery<MuvioMedia[]>({
    queryKey: ['featuredSliderData'],
    queryFn: getFeaturedSliderContent,
    staleTime: 1000 * 60 * 10, // 10 mins cache
  });

  // B. Most Interested Ranked query — Hybrid (Firebase primary + TMDB fallback)
  const HYBRID_MIN_THRESHOLD = 5; // Jab tak Firebase mein 5 se kam items hoon, TMDB se fill karo

  const { 
    data: interestedRaw = { firebaseData: [], tmdbFallback: [] }, 
    isLoading: interestedLoading,
    refetch: refetchInterested
  } = useQuery({
    queryKey: ['rankedInterestedData', interestedFilter],
    queryFn: async () => {
      // Step 1: Firebase se real user interest data lo
      const firebaseData = await getMostInterestedFromFirebase(interestedFilter);

      // Step 2: Agar Firebase mein enough data hai toh seedha return karo
      if (firebaseData.length >= HYBRID_MIN_THRESHOLD) {
        return { firebaseData, tmdbFallback: [] as MuvioMedia[] };
      }

      // Step 3: TMDB se fallback data lo
      let tmdbItems: MuvioMedia[] = [];
      try {
        tmdbItems = await getMostInterested(interestedFilter);
      } catch (e) {
        console.warn('TMDB fallback for Most Interested failed:', e);
      }

      // Step 4: Firebase IDs set banao taaki duplicates na aayein
      const firebaseIds = new Set(firebaseData.map(r => r.id));

      // Step 5: TMDB se sirf woh items lo jo Firebase mein already nahi hain
      const filteredTmdb = tmdbItems.filter(t => !firebaseIds.has(t.id));

      // Step 6: Kitne TMDB items chahiye fill karne ke liye
      const needed = HYBRID_MIN_THRESHOLD - firebaseData.length;
      const tmdbFallback = filteredTmdb.slice(0, needed + 5); // thoda extra

      return { firebaseData, tmdbFallback };
    },
    staleTime: 1000 * 60 * 2,
  });

  // Map Firebase + TMDB hybrid results to MuvioMedia shape
  const firebaseItems: MuvioMedia[] = (interestedRaw?.firebaseData || []).map((r: any) => ({
    id: r.id,
    title: r.data.title,
    type: r.data.type as any,
    year: r.data.year,
    posterUrl: r.data.posterUrl,
    backdropUrl: r.data.backdropUrl || '',
    voteCount: r.count,
    ratingPercent: 0,
    description: '',
    releaseDate: '',
    statusBadge: '🔥 Trending',
    tmdbId: 0,
  }));

  // TMDB fallback items — Firebase items ke baad aayenge
  const tmdbFallbackItems: MuvioMedia[] = (interestedRaw?.tmdbFallback || []).map((t: any) => ({
    ...t,
    voteCount: t.voteCount || 0,
  }));

  // Final merged list: Firebase (real) pehle, TMDB (fallback) baad mein
  const interestedItems: MuvioMedia[] = [...firebaseItems, ...tmdbFallbackItems];

  // C. Talk of the Town Megaphone list
  const { 
    data: talkItems = [], 
    isLoading: talkLoading 
  } = useQuery<MuvioMedia[]>({
    queryKey: ['talkTownData'],
    queryFn: getTalkOfTheTown,
    staleTime: 1000 * 60 * 5,
  });

  // --- PAGINATION LOADER FOR THE LATEST GRID ---
  useEffect(() => {
    let isCurrent = true;
    async function loadCategoryPool() {
      setLoadingCatalog(true);
      setCatalogPage(1);
      try {
        // Fetch multiple pages in parallel to build a rich items pool if TMDB is on
        const pagesToFetch = isLiveTmdbFeedOn() ? [1, 2, 3, 4, 5] : [1];
        const results = await Promise.all(
          pagesToFetch.map(p => getContentByCategory(activeCategory, p))
        );
        
        if (!isCurrent) return;

        // Flatten and deduplicate by item.id
        const combined = results.flat();
        const seenIds = new Set<string>();
        const unique = combined.filter(item => {
          if (!item || !item.id) return false;
          if (seenIds.has(item.id)) return false;
          seenIds.add(item.id);
          return true;
        });

        // Filter by elements' type (just in case, or double guarantee)
        const filtered = unique.filter(item => 
          activeCategory === 'ALL' || item.type === activeCategory
        );

        // Sort by newest first
        filtered.sort((a, b) => {
          const dateA = a.releaseDate || `${a.year}-01-01`;
          const dateB = b.releaseDate || `${b.year}-01-01`;
          return dateB.localeCompare(dateA);
        });

        setCompleteCatalog(filtered);
      } catch (err) {
        console.error('Failed to load category catalog pool:', err);
      } finally {
        if (isCurrent) setLoadingCatalog(false);
      }
    }
    loadCategoryPool();
    return () => {
      isCurrent = false;
    };
  }, [activeCategory]);

  // --- AUTOMATED FEATURED SLIDER INTERACTION TIMEOUT ---
  useEffect(() => {
    if (featuredItems.length === 0) return;
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % featuredItems.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [featuredItems.length]);

  // --- INTERACTIVITY HANDLERS ---
  const handleToggleInterest = async (item: MuvioMedia, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    if (!currentUser?.uid) {
      if (onTriggerAuthPrompt) onTriggerAuthPrompt();
      return;
    }

    const currentStatus = !!interestsMap[item.id];
    const newStatus = !currentStatus;

    // Optimistic UI update
    setInterestsMap(prev => ({ ...prev, [item.id]: newStatus }));

    try {
      await toggleInterest(currentUser.uid, {
        id: item.id,
        title: item.title,
        type: item.type,
        year: item.year,
        posterUrl: item.posterUrl,
        backdropUrl: item.backdropUrl,
      });
      // Refresh ranking list
      refetchInterested();
    } catch (err) {
      // Revert on error
      setInterestsMap(prev => ({ ...prev, [item.id]: currentStatus }));
      console.warn('toggleInterest failed:', err);
    }

    const customToastEvent = new CustomEvent('muvio_toast', {
      detail: {
        message: newStatus ? `Saved interest for "${item.title}" 🔥` : `Removed interest state.`,
        type: 'success'
      }
    });
    window.dispatchEvent(customToastEvent);
  };

  const handleProgrammaticNavigation = (route: AppRoute, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (onNavigate) {
      onNavigate(route);
    } else {
      window.history.pushState(null, '', route);
      const popEvent = new PopStateEvent('popstate');
      window.dispatchEvent(popEvent);
    }
  };

  // --- UI PARTIAL RENDERING (SKELETON LOADERS) ---
  const renderRowSkeleton = (count = 4) => (
    <div className="flex gap-6 overflow-x-hidden py-2">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="min-w-[150px] md:min-w-[180px] aspect-[2/3] bg-neutral-900 border border-white/5 rounded-2xl animate-pulse space-y-3 p-4 flex flex-col justify-end">
          <div className="h-4 bg-white/10 rounded w-3/4"></div>
          <div className="h-3 bg-white/5 rounded w-1/2"></div>
        </div>
      ))}
    </div>
  );

  if (activeFilter) {
    return (
      <AdvancedFilterAndRankingsView 
        filter={activeFilter}
        onNavigate={onNavigate}
        currentUser={currentUser}
        onTriggerAuthPrompt={onTriggerAuthPrompt}
      />
    );
  }

  return (
    <div className="space-y-12 pb-24" id="explore-homepage-container">
      <AdSlot placementId="explore_top_banner" />

      {(!isLiveTmdbFeedOn() && getCustomPublishedMedia().length === 0) ? (
        <div className="flex-1 flex flex-col items-center justify-center py-40 select-none text-center px-4" id="explore-empty-container">
          <Layers size={48} className="text-gray-600 animate-pulse mb-4 mx-auto" />
          <span className="font-sans text-md font-bold text-neutral-400 tracking-wide uppercase block">
            No content available yet
          </span>
          <p className="text-2xs text-gray-500 mt-2 max-w-sm mx-auto">
            The database is empty and live feed is deactivated. Check back later once curators approve content.
          </p>
        </div>
      ) : (
        <>
          {/* ERROR SECURE GATES */}
          {featuredError && (
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-2xl flex flex-col items-center space-y-3 text-center">
              <span className="text-sm font-bold text-red-400">Could not initialize connection to TMDB vaults.</span>
              <p className="text-xs text-neutral-500 max-w-md">Please verify your internet connection or reload catalog coordinates manually.</p>
              <button 
                onClick={() => { refetchFeatured(); refetchInterested(); }}
                className="px-4 py-1.5 bg-[#E50914] text-white text-xs font-bold rounded-full flex items-center gap-1.5 hover:bg-[#FF1A1A] transition-colors"
              >
                <RefreshCw size={12} /> Retry Coordinate Fetch
              </button>
            </div>
          )}

          {/* 1. CINEMATIC FEATURED SLIDER */}
      <section className="relative rounded-[32px] h-[400px] md:h-[480px] w-full overflow-hidden border border-white/5 shadow-[0_20px_50px_rgba(0,0,0,0.8)] group" id="featured-vault-slider">
        {featuredLoading ? (
          <div className="absolute inset-0 bg-[#060606] flex flex-col items-center justify-center space-y-4">
            <span className="w-10 h-10 border-4 border-[#E50914] border-t-transparent rounded-full animate-spin"></span>
            <span className="text-[10px] font-mono tracking-widest text-[#E50914] uppercase animate-pulse">Establishing Cinematic Links...</span>
          </div>
        ) : featuredItems.length === 0 ? (
          <div className="absolute inset-0 bg-[#060606] flex flex-col items-center justify-center space-y-4 p-8 text-center border border-dashed border-white/5 rounded-[32px]">
            <Layers size={32} className="text-neutral-600 animate-pulse" />
            <h3 className="text-sm font-bold text-neutral-400 uppercase tracking-widest">No Spotlights Curated</h3>
            <p className="text-[10px] text-neutral-500 max-w-sm font-sans">The cinematic catalog is currently offline or empty. Curators have not registered featured assets yet.</p>
          </div>
        ) : (
          <>
            <AnimatePresence mode="wait">
              {featuredItems.map((item, index) => {
                const isActive = index === activeSlide;
                if (!isActive) return null;
                const isSaved = !!interestsMap[item.id];
                const finalVoteValue = item.voteCount + (isSaved ? 1 : 0);

                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.8 }}
                    className="absolute inset-0"
                  >
                    {/* Background Backdrop Image */}
                    <div className="absolute inset-0">
                      <img 
                        src={item.backdropUrl} 
                        alt={item.title} 
                        className="w-full h-full object-cover object-center brightness-75 scale-100 group-hover:scale-102 transition-transform duration-[4000ms] ease-out"
                        referrerPolicy="no-referrer"
                      />
                      {/* Rich artistic radial and linear gradients for extreme legibility */}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#000000] via-[#000000]/50 to-transparent"></div>
                      <div className="absolute inset-0 bg-gradient-to-r from-[#000000]/95 via-[#000000]/40 to-transparent"></div>
                    </div>

                    {/* Left & Right custom chevron controllers */}
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveSlide((v) => (v - 1 + featuredItems.length) % featuredItems.length);
                      }}
                      className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/60 hover:bg-[#E50914] border border-white/10 text-white cursor-pointer z-20 opacity-0 group-hover:opacity-100 transition-all duration-300 transform -translate-x-3 group-hover:translate-x-0"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveSlide((v) => (v + 1) % featuredItems.length);
                      }}
                      className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/60 hover:bg-[#E50914] border border-white/10 text-white cursor-pointer z-20 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-3 group-hover:translate-x-0"
                    >
                      <ChevronRight size={16} />
                    </button>

                    {/* Content overlays */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 flex flex-col justify-end max-w-3xl h-full space-y-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-[#E50914] text-[9px] font-mono font-bold tracking-widest text-white uppercase shadow-md">
                          {item.type} SPOTLIGHT
                        </span>
                        <div className="inline-flex items-center gap-1.5 text-xs text-[#EAB308] bg-[#EAB308]/10 border border-[#EAB308]/20 px-2.5 py-0.5 rounded-full font-bold">
                          <Star size={11} className="fill-current" />
                          <span>{item.ratingPercent}% Approval</span>
                        </div>
                      </div>

                      <h2 className="font-display font-black text-3xl md:text-5xl text-white tracking-tighter uppercase leading-none">
                        {item.title}
                      </h2>

                      <p className="text-gray-300 text-xs md:text-sm font-medium line-clamp-3 leading-relaxed max-w-xl">
                        {item.description}
                      </p>

                      <div className="flex items-center gap-3 pt-2 text-xs font-mono text-neutral-400">
                        <span>{item.year}</span>
                        <span>•</span>
                        <span>TMDB Source</span>
                        <span>•</span>
                        <span className="text-orange-400 font-bold flex items-center gap-1">
                          <Flame size={12} className="fill-current text-orange-500" />
                          {finalVoteValue} interested
                        </span>
                      </div>

                      {/* Action buttons with details route redirect integration */}
                      <div className="flex flex-wrap items-center gap-3 pt-3">
                        <button
                          onClick={(e) => handleProgrammaticNavigation(`/content/${generateSlug(item.title)}`, e)}
                          className="px-6 py-3.5 bg-white hover:bg-neutral-100 text-black font-extrabold text-xs tracking-wider rounded-xl transition-all shadow-[0_10px_20px_rgba(255,255,255,0.1)] flex items-center gap-2 cursor-pointer active:scale-95"
                        >
                          <Play size={13} className="fill-current text-black" />
                          <span>VIEW DETAILS</span>
                        </button>

                        <button
                          onClick={(e) => handleToggleInterest(item, e)}
                          className={`px-5 py-3.5 rounded-xl text-xs font-extrabold tracking-wider transition-all flex items-center gap-2 cursor-pointer border border-white/5 ${
                            isSaved 
                              ? 'bg-orange-500/20 border-orange-500/40 text-orange-400 shadow-md' 
                              : 'bg-black/50 hover:bg-[#E50914] text-white'
                          }`}
                        >
                          <Flame size={13} className={isSaved ? 'animate-pulse text-orange-400' : 'text-neutral-400'} />
                          <span>{isSaved ? 'INTEREST ACCOUNTED' : 'MARK INTEREST'}</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {/* Slider bottom dots indicators */}
            <div className="absolute bottom-5 right-6 md:right-12 flex items-center gap-2 z-10">
              {featuredItems.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveSlide(idx)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 cursor-pointer ${
                    idx === activeSlide ? 'bg-[#E50914] w-6' : 'bg-white/20 hover:bg-white/40'
                  }`}
                  aria-label={`Slide index indicator ${idx + 1}`}
                />
              ))}
            </div>
          </>
        )}
      </section>

      <AdSlot placementId="explore_middle" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left column + Center columns (2/3): Ranked and town sections */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* 3. MOST INTERESTED SECTION */}
          <section className="space-y-6" id="most-interested-panel">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded-xl">
                  <Flame size={16} className="fill-current" />
                </div>
                <div>
                  <h3 className="font-display font-black text-lg text-white uppercase tracking-tight">
                    MOST INTERESTED
                  </h3>
                  <p className="text-[10px] text-neutral-500 font-mono tracking-wider">CRITICS EXTREME METERS</p>
                </div>
              </div>

              {/* Weekly/Monthly/All Filtering pills */}
              <div className="flex gap-1.5 bg-white/2 border border-white/5 p-1 rounded-xl self-start sm:self-auto">
                {(['week', 'month', 'all'] as const).map((filterVal) => {
                  const check = interestedFilter === filterVal;
                  return (
                    <button
                      key={filterVal}
                      onClick={() => setInterestedFilter(filterVal)}
                      className={`px-3 py-1 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                        check 
                          ? 'bg-neutral-800 text-white' 
                          : 'text-neutral-500 hover:text-neutral-300'
                      }`}
                    >
                      {filterVal === 'week' ? 'This Week' : filterVal === 'month' ? 'This Month' : 'All Time'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Horizontal Ranked shelf scroll list */}
            {interestedLoading ? (
              renderRowSkeleton(5)
            ) : interestedItems.length === 0 ? (
              <div className="py-12 text-center text-xs text-neutral-500 border border-dashed border-white/5 rounded-2xl">
                No active records match selected metrics.
              </div>
            ) : (
              <div className="flex gap-6 overflow-x-auto pb-4 select-none justify-start no-scrollbar scroll-smooth snap-x">
                {interestedItems.map((item, index) => {
                  const isSaved = !!interestsMap[item.id];
                  const rank = index + 1;
                  const voteCountDisplay = item.voteCount + (isSaved ? 1 : 0);

                  return (
                    <div
                      key={item.id}
                      onClick={(e) => handleProgrammaticNavigation(`/content/${generateSlug(item.title)}`, e)}
                      className="min-w-[150px] md:min-w-[170px] bg-[#0c0c0c]/90 rounded-2xl border border-white/5 overflow-hidden flex flex-col group hover:border-[#E50914]/40 cursor-pointer transition-all duration-300 text-left snap-start h-80"
                    >
                      {/* Cover Poster with Rank layout overlay */}
                      <div className="aspect-[3/4.2] relative bg-black overflow-hidden flex items-center justify-center">
                        <img 
                          src={item.posterUrl} 
                          alt={item.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          loading="lazy"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>

                        {/* Rank Badge Indicator */}
                        <div className="absolute -left-1 -bottom-3 text-[70px] font-display font-black tracking-tighter text-white stroke-text select-none leading-none opacity-90 group-hover:scale-110 transition-transform origin-bottom-left">
                          {rank}
                        </div>

                        {/* Active flame count — Firebase real data ya TMDB fallback badge */}
                        <div className="absolute top-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/5 text-[9px] font-mono text-orange-400 font-bold flex items-center gap-1">
                          <Flame size={10} className="fill-current text-orange-500" />
                          <span>
                            {/* Firebase real users ka count dikhao, TMDB fallback pe "Trending" */}
                            {index < firebaseItems.length
                              ? `${voteCountDisplay} interested`
                              : 'Trending'}
                          </span>
                        </div>
                      </div>

                      {/* Content details */}
                      <div className="p-3 flex-1 flex flex-col justify-between mb-1 pl-4">
                        <div>
                          <div className="flex items-center justify-between text-[8px] font-mono font-black text-neutral-500 uppercase">
                            <span>{item.type}</span>
                            <span>{item.year}</span>
                          </div>
                          <h4 className="font-display font-bold text-xs text-neutral-200 mt-1 line-clamp-1 group-hover:text-white transition-colors uppercase tracking-tight">
                            {item.title}
                          </h4>
                        </div>

                        <div className="pt-2 flex items-center justify-between">
                          <button
                            onClick={(e) => handleToggleInterest(item, e)}
                            className={`p-1.5 rounded-lg border cursor-pointer transition-colors ${
                              isSaved 
                                ? 'bg-orange-500/20 border-orange-500/30 text-orange-400' 
                                : 'bg-white/5 border-white/5 text-neutral-500 hover:text-white hover:bg-neutral-800'
                            }`}
                            title="Add to interests"
                          >
                            <Flame size={11} className={isSaved ? 'fill-current' : ''} />
                          </button>
                          
                          <span className="text-[9px] font-mono font-black text-[#E50914] tracking-wider uppercase group-hover:underline">
                            EXPLORE
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* 2. CATEGORY FILTER TABS SELECTOR */}
          <section className="bg-[#0b0b0b]/90 border border-white/5 rounded-3xl p-2 max-w-md mx-auto" id="genre-filter-tabs">
            <div className="grid grid-cols-4 gap-1">
              {(['ALL', 'MOVIE', 'SHOW', 'ANIME'] as const).map((cat) => {
                const isSel = activeCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => { setActiveCategory(cat); }}
                    className={`py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all duration-300 ${
                      isSel
                        ? 'bg-[#E50914] text-white shadow-[0_5px_15px_rgba(229,9,20,0.35)]'
                        : 'text-neutral-400 hover:text-white hover:bg-white/5'
                    }`}
                    id={`tab-explore-${cat}`}
                  >
                    {cat === 'ALL' ? 'ALL CATALOG' : `${cat}S`}
                  </button>
                );
              })}
            </div>
          </section>

          {/* 5. LATEST CONTENT GRID */}
          <section className="space-y-6" id="latest-content-directory">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div className="flex items-center gap-2">
                <Layers size={18} className="text-[#E50914]" />
                <div>
                  <h3 className="font-display font-black text-lg text-white uppercase tracking-tight">
                    LATEST {activeCategory === 'ALL' ? 'CATALOG' : `${activeCategory}S`}
                  </h3>
                </div>
              </div>
            </div>

            {/* Grid structure */}
            {loadingCatalog ? (
              <div className="grid grid-cols-2 shadow-sm gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-[2/3] bg-[#0c0c0c] border border-white/5 rounded-2xl animate-pulse flex flex-col justify-end p-4 space-y-2">
                    <div className="h-4 bg-white/10 rounded w-2/3"></div>
                    <div className="h-3 bg-white/5 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : totalItemsCount === 0 ? (
              <div className="py-16 text-center text-xs text-neutral-500 font-mono">
                No catalogs catalogued in this vault yet. Check back momentarily.
              </div>
            ) : (
              <div className="space-y-8">
                <div className="grid grid-cols-2 gap-4 md:gap-6" id="latest-items-grid">
                  {paginatedItems.map((item) => {
                    const isSaved = !!interestsMap[item.id];
                    const showBadge = item.statusBadge && (
                      item.statusBadge.toUpperCase() === 'BLOCKBUSTER' || 
                      item.statusBadge.toUpperCase() === 'MUST WATCH'
                    );
                    return (
                      <motion.div
                        layout
                        key={item.id}
                        onClick={(e) => handleProgrammaticNavigation(`/content/${generateSlug(item.title)}`, e)}
                        className="bg-[#080808]/90 border border-white/5 rounded-2xl overflow-hidden flex flex-col group hover:border-neutral-800 cursor-pointer h-full transition-all"
                      >
                        <div className="aspect-[2/3] relative overflow-hidden bg-black flex items-center justify-center border-b border-white/5">
                          <img 
                            src={item.posterUrl} 
                            alt={item.title} 
                            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500 brightness-95"
                            loading="lazy"
                            referrerPolicy="no-referrer"
                          />
                          {/* Rating overlay badge */}
                          <div className="absolute top-2.5 right-2.5 bg-black/85 backdrop-blur-md px-2 py-0.5 rounded-lg border border-white/5 text-[9px] font-mono text-[#EAB308] font-bold flex items-center gap-1 shadow-md">
                            <Star size={10} className="fill-current text-[#EAB308]" />
                            <span>{item.ratingPercent}%</span>
                          </div>

                          {/* Content Type overlay badge */}
                          <div className="absolute bottom-2.5 left-2.5 bg-black/85 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/5 text-[8px] font-mono text-neutral-300 font-extrabold tracking-widest uppercase whitespace-nowrap">
                            {item.type}
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                          <div className="space-y-1 text-left">
                            <div className="flex items-center justify-between text-[8px] font-mono font-black text-neutral-500 uppercase tracking-widest">
                              <span>{item.year}</span>
                              {showBadge && (
                                <span className="text-[#E50914] bg-[#E50914]/10 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider">{item.statusBadge}</span>
                              )}
                            </div>
                            <h4 className="font-display font-black text-sm text-neutral-200 group-hover:text-white transition-colors uppercase tracking-tight line-clamp-1 mt-1">
                              {item.title}
                            </h4>
                          </div>

                          <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                            <button
                              onClick={(e) => handleToggleInterest(item, e)}
                              className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors border cursor-pointer ${
                                isSaved 
                                  ? 'bg-orange-500/20 border-orange-500/30 text-orange-400' 
                                  : 'bg-[#111111] hover:bg-[#E50914] text-neutral-300 border-[#111111]/10 hover:text-white'
                              }`}
                            >
                              <Flame size={10} className={isSaved ? 'fill-current text-orange-400' : ''} />
                              <span>{isSaved ? 'MARK INTERESTED' : 'MARK INTEREST'}</span>
                            </button>

                            <span className="text-[10px] font-mono font-black text-neutral-500 group-hover:text-[#E50914] flex items-center gap-0.5 uppercase transition-colors">
                              ENTER
                              <ArrowRight size={10} className="group-hover:translate-x-1.5 transition-transform" />
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Pagination Controls Bar */}
                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between pt-6 border-t border-white/5 gap-4">
                    {/* Display range text */}
                    <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase">
                      PAGE <span className="text-[#E50914]">{activePage}</span> OF <span className="text-white">{totalPages}</span>
                    </span>

                    {/* Button Group layout */}
                    <div className="flex items-center gap-1 flex-wrap justify-center">
                      {/* Previous button */}
                      <button
                        type="button"
                        disabled={activePage === 1}
                        onClick={() => handlePageChange(activePage - 1)}
                        className="px-3.5 py-2 rounded-xl border border-white/5 bg-[#080808]/95 text-neutral-400 hover:text-white hover:border-neutral-800 disabled:opacity-20 disabled:hover:text-neutral-400 disabled:cursor-not-allowed transition-all cursor-pointer text-[10px] font-mono font-black uppercase tracking-wider flex items-center gap-1"
                      >
                        ← PREVIOUS
                      </button>

                      {/* Sliding pages block */}
                      {getPaginationRange(activePage, totalPages).map((p, idx) => {
                        if (p === '...') {
                          return (
                            <span key={`ell-${idx}`} className="text-[10px] font-mono text-neutral-600 px-1.5 select-none font-bold">
                              ...
                            </span>
                          );
                        }

                        const isCurrent = p === activePage;
                        return (
                          <button
                            key={`page-btn-${p}`}
                            type="button"
                            onClick={() => handlePageChange(p as number)}
                            className={`text-[10px] font-mono font-bold rounded-xl w-8 h-8 transition-all cursor-pointer flex items-center justify-center ${
                              isCurrent
                                ? 'bg-[#E50914] text-white font-black shadow-md border border-[#E50914]/20'
                                : 'bg-[#111111]/80 hover:bg-neutral-850 border border-white/5 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {p}
                          </button>
                        );
                      })}

                      {/* Next button */}
                      <button
                        type="button"
                        disabled={activePage === totalPages}
                        onClick={() => handlePageChange(activePage + 1)}
                        className="px-3.5 py-2 rounded-xl border border-white/5 bg-[#080808]/95 text-neutral-400 hover:text-white hover:border-neutral-800 disabled:opacity-20 disabled:hover:text-[#E50914] disabled:cursor-not-allowed transition-all cursor-pointer text-[10px] font-mono font-black uppercase tracking-wider flex items-center gap-1"
                      >
                        NEXT →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}


          </section>

        </div>

        {/* Right column (1/3): Talk of the town high density lists */}
        <div className="space-y-8">
          
          {/* 4. TALK OF THE TOWN SECTION */}
          <section className="bg-[#070707]/90 border border-white/5 rounded-[32px] p-6 space-y-6" id="talk-town-panel">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl">
                  <Megaphone size={16} />
                </div>
                <div>
                  <h3 className="font-display font-black text-sm text-white uppercase tracking-wider">
                    TALK OF THE TOWN
                  </h3>
                  <p className="text-[8px] font-mono text-neutral-500 tracking-wider">BUZZING COMMUNITY TOPICS</p>
                </div>
              </div>
            </div>

            {talkLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="flex gap-3 animate-pulse">
                    <div className="w-12 h-16 bg-neutral-950 rounded-lg"></div>
                    <div className="flex-1 space-y-2 py-1">
                      <div className="h-3 bg-white/10 rounded w-3/4"></div>
                      <div className="h-2.5 bg-white/5 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : talkItems.length === 0 ? (
              <p className="text-[10px] text-neutral-500 text-center py-6 font-mono font-bold uppercase">No ongoing debates archived.</p>
            ) : (
              <div className="space-y-4 text-left">
                {talkItems.map((item) => (
                  <div
                    key={item.id}
                    onClick={(e) => handleProgrammaticNavigation(`/content/${generateSlug(item.title)}`, e)}
                    className="flex gap-4 p-2 rounded-2xl hover:bg-white/2 cursor-pointer transition-colors group border border-transparent hover:border-white/5"
                  >
                    {/* Small thumbnail poster */}
                    <div className="w-14 h-20 overflow-hidden rounded-xl bg-black shrink-0 border border-white/5">
                      <img 
                        src={item.posterUrl} 
                        alt={item.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Content text metadata */}
                    <div className="flex-1 flex flex-col justify-between py-1">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 text-[8px] font-mono font-black text-neutral-500 tracking-wider uppercase">
                          <span>{item.type}</span>
                          <span>•</span>
                          <span>{item.year}</span>
                        </div>
                        <h4 className="font-sans font-bold text-xs text-neutral-200 group-hover:text-white transition-colors line-clamp-1">
                          {item.title}
                        </h4>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-extrabold text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/20 px-2 py-0.5 rounded-md">
                          Muvio {item.ratingPercent}%
                        </span>
                        <span className="text-[8px] font-mono font-black text-neutral-500 group-hover:text-white flex items-center gap-0.5 tracking-wider uppercase">
                          DEBATE <ChevronRight size={8} />
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>



          <AdSlot placementId="explore_bottom" />

        </div>

      </div>
      </>
      )}
    </div>
  );
}
