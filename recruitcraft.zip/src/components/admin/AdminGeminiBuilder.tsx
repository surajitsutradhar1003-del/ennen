import React, { useState } from 'react';
import { Sparkles, Save, Copy, FileText, Check, Compass, AlertCircle, RefreshCw } from 'lucide-react';
import { triggerToast } from '../../lib/firebase';

interface AdminGeminiBuilderProps {
  onUseDraft: (draftText: string) => void;
  logMessage: (msg: string) => void;
}

export default function AdminGeminiBuilder({ onUseDraft, logMessage }: AdminGeminiBuilderProps) {
  const [prompt, setPrompt] = useState('');
  const [category, setCategory] = useState<'NEWS' | 'RUMOUR' | 'BOX OFFICE' | 'EXCLUSIVE'>('NEWS');
  const [newsTitle, setNewsTitle] = useState('');
  const [associatedTitle, setAssociatedTitle] = useState('');
  
  const [isSparking, setIsSparking] = useState(false);
  const [draftResult, setDraftResult] = useState('');
  const [copied, setCopied] = useState(false);

  const handleSparkDraft = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      triggerToast("Please specify an input prompt first.", "error");
      return;
    }

    setIsSparking(true);
    setDraftResult('');
    logMessage(`Dispatching prompt token packets to Gemini AI Engine...`);

    try {
      // Same as AIChatModal - localStorage se config lo
      const savedConfig = localStorage.getItem('muvio_api_keys_v1');
      const config = savedConfig ? JSON.parse(savedConfig) : {};
      const GEMINI_API_KEY = config.geminiApiKey || import.meta.env.VITE_GEMINI_API_KEY || '';
      const GEMINI_MODEL = config.geminiModel || 'gemini-2.0-flash';

      if (!GEMINI_API_KEY) {
        triggerToast("Gemini API Key not set. Go to Admin → API Keys.", "error");
        logMessage("ERROR: Gemini API Key missing. Set it in Admin → API Keys.");
        setIsSparking(false);
        return;
      }

      const systemPrompt = `You are a professional film & entertainment journalist for Muvio.
Write a ${category} article.
Title: "${newsTitle || 'Untitled'}"
Associated Movie/Show: "${associatedTitle || 'N/A'}"
Guidelines: ${prompt}
Write 3-4 paragraphs in professional journalism tone. No markdown headings, just clean paragraphs.`;

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: systemPrompt }] }],
            generationConfig: { temperature: 0.8 }
          })
        }
      );

      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;

      if (text) {
        setDraftResult(text);
        logMessage(`Gemini AI Builder output received: drafted article of ${text.length} characters.`);
        triggerToast("Editorial drafted by Gemini AI successfully!", "success");
      } else {
        throw new Error(data?.error?.message || "Gemini returned no content.");
      }

    } catch (err: any) {
      triggerToast("Gemini call failed: " + err.message, "error");
      logMessage(`Gemini error: ${err.message}`);
    } finally {
      setIsSparking(false);
    }
  };

  const handleCopyToClipboard = () => {
    if (!draftResult) return;
    navigator.clipboard.writeText(draftResult);
    setCopied(true);
    triggerToast("Draft copied to clipboard!", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApplyDraft = () => {
    if (!draftResult) return;
    onUseDraft(draftResult);
    triggerToast("Draft dispatched. Opening News management room...", "success");
  };

  const handleTemplateSelect = (p: string, c: 'NEWS' | 'RUMOUR' | 'BOX OFFICE' | 'EXCLUSIVE', title: string, contentTitle: string) => {
    setPrompt(p);
    setCategory(c);
    setNewsTitle(title);
    setAssociatedTitle(contentTitle);
    triggerToast("Thematic prompt template applied!", "success");
  };

  return (
    <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left font-sans">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
        <div>
          <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
            <Sparkles size={16} className="text-[#E50914] animate-pulse" /> Gemini AI Builder & Editorial Assistant
          </h3>
          <p className="text-[10px] text-gray-500 font-mono mt-0.5">Harness server-side gemini-3.5-flash AI co-pilots to forge elite cinematic reporting articles, rumours, or box-office trends.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left column (5 cols): AI Formulation Controls */}
        <div className="lg:col-span-5 space-y-5">
          <form onSubmit={handleSparkDraft} className="bg-neutral-950/40 p-5 rounded-2xl border border-white/5 space-y-4">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
              Draft Generation Parameters
            </h4>

            {/* Title / Topic */}
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Target Article Title</label>
              <input 
                type="text" 
                value={newsTitle}
                onChange={e => setNewsTitle(e.target.value)}
                placeholder="e.g. Denis Villeneuve Cleared for Cleopatra"
                className="w-full bg-[#111111] border border-white/5 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-700 focus:outline-none focus:border-[#E50914] transition-all"
              />
            </div>

            {/* Category / Tone representation */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Tone Category</label>
                <select 
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full bg-[#111111] border border-white/5 rounded-xl px-2 py-2 text-xxs text-white focus:outline-none focus:border-[#E50914] font-bold"
                >
                  <option value="NEWS">NEWS REPORT</option>
                  <option value="RUMOUR">RUMOUR DISPATCH</option>
                  <option value="BOX OFFICE">BOX OFFICE STATS</option>
                  <option value="EXCLUSIVE">EXCLUSIVE STORY</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Associated Movie</label>
                <input 
                  type="text" 
                  value={associatedTitle}
                  onChange={e => setAssociatedTitle(e.target.value)}
                  placeholder="e.g. Interstellar"
                  className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2 text-xxs text-white placeholder-neutral-700 focus:outline-none focus:border-[#E50914] transition-all font-bold"
                />
              </div>
            </div>

            {/* Prompts Input */}
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Generative Editorial Guidelines</label>
              <textarea 
                value={prompt} 
                onChange={e => setPrompt(e.target.value)}
                placeholder="Explain the plot development, rumored directors, exclusive cast signings, or interesting box office thresholds you want to write about..."
                rows={4}
                className="w-full bg-[#111111] border border-white/5 rounded-xl p-3 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] transition-all"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSparking}
              className="w-full py-3 bg-[#E50914] hover:bg-[#FF1A1A] disabled:bg-[#E50914]/40 text-white font-black text-xs uppercase rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-[0_5px_15px_rgba(229,9,20,0.2)]"
            >
              {isSparking ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Sparking AI Model Neurons...</span>
                </>
              ) : (
                <>
                  <Sparkles size={13} className="animate-pulse" /> SPARK PROFESSIONAL DRAFT NOW
                </>
              )}
            </button>
          </form>

          {/* Quick templates */}
          <div className="space-y-3 bg-neutral-950/20 p-4 rounded-2xl border border-white/5 text-left">
            <h5 className="text-[8px] font-mono font-black text-gray-500 uppercase tracking-widest">Thematic Prompt Presets</h5>
            <div className="space-y-2">
              <button
                onClick={() => handleTemplateSelect(
                  "Discuss how Denis Villeneuve is planning to adapt Cleopatra starring Zendaya. Highlight the grand production scale and historical accuracy expectations.",
                  "EXCLUSIVE",
                  "Denis Villeneuve Eyed for Cleopatra Epic",
                  "Cleopatra"
                )}
                className="w-full p-2.5 bg-[#111111]/60 hover:bg-neutral-900 border border-white/5 rounded-xl text-xxs text-gray-300 font-sans transition-all text-left block truncate"
              >
                🎥 <span className="font-bold text-white">Zendaya Cleopatra</span> Historical Epic Production Leak
              </button>
              <button
                onClick={() => handleTemplateSelect(
                  "Explain how Inside Out 2 shatters all global animation records in its second weekend, hitting over $150M. Touch upon how families are driving extreme occupancy levels.",
                  "BOX OFFICE",
                  "Inside Out 2 Breaks Animation Second Weekend Record",
                  "Inside Out 2"
                )}
                className="w-full p-2.5 bg-[#111111]/60 hover:bg-neutral-900 border border-white/5 rounded-xl text-xxs text-gray-300 font-sans transition-all text-left block truncate"
              >
                📊 <span className="font-bold text-white">Inside Out 2</span> Global $150M Record Breakstats
              </button>
            </div>
          </div>
        </div>

        {/* Right column (7 cols): Generative Draft Canvas Result */}
        <div className="lg:col-span-7 flex flex-col h-full min-h-[400px]">
          <div className="bg-neutral-950/60 rounded-2xl border border-white/5 flex-1 flex flex-col overflow-hidden">
            {/* Header */}
            <div className="px-4 py-3 bg-[#111111]/40 border-b border-white/5 flex justify-between items-center flex-shrink-0">
              <span className="text-[9px] font-mono font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1">
                <FileText size={11} className="text-[#E50914]" /> Generative Editorial Canvas Output
              </span>
              
              {draftResult && (
                <div className="flex gap-2">
                  <button
                    onClick={handleCopyToClipboard}
                    className="p-1 px-2.5 bg-neutral-900 border border-white/10 text-xxs font-bold uppercase text-gray-300 hover:text-white rounded flex items-center gap-1 transition-all"
                  >
                    {copied ? <Check size={10} className="text-green-500" /> : <Copy size={10} />}
                    {copied ? 'COPIED' : 'COPY'}
                  </button>
                  <button
                    onClick={handleApplyDraft}
                    className="p-1 px-2.5 bg-[#E50914]/20 border border-[#E50914]/30 text-xxs font-black uppercase text-[#FF4444] hover:text-white hover:bg-[#E50914] rounded flex items-center gap-1 transition-all"
                  >
                    🚀 Use This Draft
                  </button>
                </div>
              )}
            </div>

            {/* Body */}
            <div className="p-5 flex-1 overflow-y-auto scrollbar-thin text-left font-mono">
              {!draftResult ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-3 py-20">
                  <div className="w-10 h-10 rounded-full bg-neutral-900/60 border border-white/5 flex items-center justify-center text-[#E50914] animate-pulse">
                    <Sparkles size={16} />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono uppercase text-gray-400 tracking-wider font-bold">Editorial Draft Canvas Empty</span>
                    <p className="text-neutral-600 text-xxs max-w-sm font-sans leading-relaxed">Formulate guidelines, seed targets, and tap the spark generator button. The server-side Gemini Model co-pilot will output the draft text here.</p>
                  </div>
                </div>
              ) : (
                <textarea
                  value={draftResult}
                  onChange={e => setDraftResult(e.target.value)}
                  rows={15}
                  className="w-full h-full bg-transparent border-none text-xs text-gray-200 focus:outline-none resize-none leading-relaxed font-sans"
                />
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
