import React, { useState, useEffect } from 'react';
import { Settings, Save, RefreshCw, Layers, ShieldCheck, ToggleLeft, ToggleRight, FileText, Download, ShieldAlert } from 'lucide-react';
import { triggerToast, getSettingValue, updateSettingValue } from '../../lib/firebase';

interface GeneralSettingsProps {
  showLandingPage: boolean;
  onToggleLandingPage: (v: boolean) => void;
  logMessage: (msg: string) => void;
}

export default function AdminGeneralSettings({ showLandingPage, onToggleLandingPage, logMessage }: GeneralSettingsProps) {
  // Input fields
  const [siteName, setSiteName] = useState('Muvio Cinematic');
  const [logoUrl, setLogoUrl] = useState('https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=150');
  const [faviconUrl, setFaviconUrl] = useState('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=32');
  
  // Toggles
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [globalDownload, setGlobalDownload] = useState(true);
  const [downloadTimerDuration, setDownloadTimerDuration] = useState(5);
  
  // Login toggles
  const [authMethods, setAuthMethods] = useState({
    email_password: true,
    google_oauth: true,
    phone_otp: true,
    registration_enabled: true
  });

  // Social Links
  const [discordLink, setDiscordLink] = useState('https://discord.gg/muvio');
  const [whatsappLink, setWhatsappLink] = useState('https://chat.whatsapp.com/muvio');
  const [instagramLink, setInstagramLink] = useState('https://instagram.com/muvio');

  // Policy text areas
  const [privacyPolicy, setPrivacyPolicy] = useState('Muvio values critic confidentiality. All account identifiers are locked under cryptographic standards.');
  const [termsOfUse, setTermsOfUse] = useState('By accessing Muvio ratings indexes, members agree to submit mature objective evaluations free of toxic keywords.');

  // Auto fetch settings (complements adminCatalog)
  const [autoFetchEnabled, setAutoFetchEnabled] = useState(false);
  const [autoFetchFrequency, setAutoFetchFrequency] = useState('DAILY'); // DAILY, WEEKLY
  const [liveTmdbFeed, setLiveTmdbFeed] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [latestCatalogCount, setLatestCatalogCount] = useState<number>(10);
  const [isSavingLatestCount, setIsSavingLatestCount] = useState<boolean>(false);

  useEffect(() => {
    const fetchDbSettings = async () => {
      try {
        const dbLiveMode = await getSettingValue('live_tmdb_mode', false);
        setLiveTmdbFeed(dbLiveMode);
      } catch (e) {
        console.warn('Failed to load live_tmdb_mode from db', e);
      }
    };
    fetchDbSettings();

    const savedSettings = localStorage.getItem('muvio_general_settings');
    if (savedSettings) {
      try {
        const config = JSON.parse(savedSettings);
        setSiteName(config.siteName || 'Muvio Cinematic');
        setLogoUrl(config.logoUrl || '');
        setFaviconUrl(config.faviconUrl || '');
        setMaintenanceMode(!!config.maintenanceMode);
        setGlobalDownload(config.globalDownload ?? true);
        setDownloadTimerDuration(config.downloadTimerDuration ?? 5);
        const defaultAuth = { email_password: true, google_oauth: true, phone_otp: true, registration_enabled: true };
        setAuthMethods(config.authMethods ? { ...defaultAuth, ...config.authMethods } : defaultAuth);
        setDiscordLink(config.discordLink || '');
        setWhatsappLink(config.whatsappLink || '');
        setInstagramLink(config.instagramLink || '');
        setPrivacyPolicy(config.privacyPolicy || '');
        setTermsOfUse(config.termsOfUse || '');
        setAutoFetchEnabled(config.autoFetchEnabled ?? false);
        setAutoFetchFrequency(config.autoFetchFrequency || 'DAILY');
        setLiveTmdbFeed(config.liveTmdbFeed ?? false);
      } catch (e) {
        console.error(e);
      }
    } else {
      setAutoFetchEnabled(false);
      setLiveTmdbFeed(false);
    }

    const savedCount = localStorage.getItem('muvio_latest_catalog_count');
    if (savedCount) {
      const val = parseInt(savedCount, 10);
      if (!isNaN(val) && val >= 4 && val <= 50) {
        setLatestCatalogCount(val);
      }
    }
  }, []);

  const handleSaveLatestCount = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsSavingLatestCount(true);
    logMessage(`Packaging Latest Catalog limit parameter...`);
    
    let val = latestCatalogCount;
    if (val < 4) val = 4;
    if (val > 50) val = 50;
    setLatestCatalogCount(val);

    localStorage.setItem('muvio_latest_catalog_count', String(val));
    logMessage(`Latest Catalog Settings updated: Number of posts to show set to ${val}.`);
    
    setTimeout(() => {
      setIsSavingLatestCount(false);
      triggerToast("Latest Catalog Settings updated successfully!", "success");
      window.dispatchEvent(new CustomEvent('muvio_latest_catalog_count_changed'));
    }, 600);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    logMessage(`Packaging site general option changes...`);

    const payload = {
      siteName: siteName.trim(),
      logoUrl: logoUrl.trim(),
      faviconUrl: faviconUrl.trim(),
      maintenanceMode,
      globalDownload,
      downloadTimerDuration,
      authMethods,
      discordLink: discordLink.trim(),
      whatsappLink: whatsappLink.trim(),
      instagramLink: instagramLink.trim(),
      privacyPolicy: privacyPolicy.trim(),
      termsOfUse: termsOfUse.trim(),
      autoFetchEnabled,
      autoFetchFrequency,
      liveTmdbFeed
    };

    localStorage.setItem('muvio_general_settings', JSON.stringify(payload));
    
    // Save live_tmdb_mode to Firestore db!
    try {
      await updateSettingValue('live_tmdb_mode', liveTmdbFeed);
    } catch (e) {
      console.warn('Failed to save live_tmdb_mode to db', e);
    }
    
    // Set auto fetch settings if available
    try {
      localStorage.setItem('muvio_auto_fetch_settings_v1', JSON.stringify({
        enabled: autoFetchEnabled,
        frequency: autoFetchFrequency
      }));
    } catch (e) {}

    await new Promise(resolve => setTimeout(resolve, 800));
    setIsSaving(false);
    logMessage(`Central site operations parameter registers fully updated.`);
    triggerToast("General Settings updated successfully!", "success");
  };

  const handleToggleAuthMethod = (key: keyof typeof authMethods) => {
    const updated = { ...authMethods, [key]: !authMethods[key] };
    setAuthMethods(updated);
    logMessage(`Authentication pathway modified: '${String(key)}' set to ${updated[key] ? 'ENABLED' : 'DISABLED'}.`);
  };

  return (
    <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left font-sans">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
        <div>
          <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
            <Settings size={16} className="text-[#E50914]" /> Central Platform Operations & Settings
          </h3>
          <p className="text-[10px] text-gray-500 font-mono mt-0.5">Control core platform constants, choose authorized authentication lanes, regulate downloads, and customize global legal directives.</p>
        </div>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        
        {/* Row 1: Site Metadata & Core Status Toggles */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Site identity (7 cols) */}
          <div className="lg:col-span-7 bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-4">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
              Brand Coordinates & Assets
            </h4>

            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-bold">Platform Site Name</label>
              <input 
                type="text"
                value={siteName}
                onChange={e => setSiteName(e.target.value)}
                className="w-full bg-[#111111]/80 border border-white/5 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914]"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-bold">Logo Asset URL</label>
                <input 
                  type="text"
                  value={logoUrl}
                  onChange={e => setLogoUrl(e.target.value)}
                  className="w-full bg-[#111111]/80 text-xxs font-mono border border-white/5 rounded-xl px-3.5 py-2.5 text-gray-300 placeholder-neutral-700 focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-bold">Favicon Asset URL</label>
                <input 
                  type="text"
                  value={faviconUrl}
                  onChange={e => setFaviconUrl(e.target.value)}
                  className="w-full bg-[#111111]/80 text-xxs font-mono border border-white/5 rounded-xl px-3.5 py-2.5 text-gray-300 placeholder-neutral-700 focus:outline-none focus:border-[#E50914]"
                />
              </div>
            </div>
          </div>

          {/* Core Toggles (5 cols) */}
          <div className="lg:col-span-5 bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-4 flex flex-col justify-between">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
              Operations Control Gates
            </h4>

            <div className="space-y-4 text-xs pr-1">
              {/* Show landing page hook */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="font-bold text-white uppercase text-xxs">Show Spotlight Landing Page</p>
                  <p className="text-[9px] text-gray-500 font-mono">Bypass or show introduction gates first.</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleLandingPage(!showLandingPage)}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${showLandingPage ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${showLandingPage ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              {/* Maintenance Mode */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="font-bold text-white uppercase text-xxs">System Maintenance Gate</p>
                  <p className="text-[9px] text-gray-500 font-mono">Locks all consumer interfaces immediately.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setMaintenanceMode(!maintenanceMode)}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${maintenanceMode ? 'bg-[#E50914]' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${maintenanceMode ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              {/* Global Downloads enable */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="font-bold text-white uppercase text-xxs">Global Download Controls</p>
                  <p className="text-[9px] text-gray-500 font-mono">Locks or allows printing offline media links.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setGlobalDownload(!globalDownload)}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${globalDownload ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${globalDownload ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              {/* Download Countdown Timer Duration */}
              <div className="space-y-1 pt-2 border-t border-white/5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-bold block">Download Timer Duration (seconds)</label>
                <div className="flex items-center gap-2">
                  <input 
                    type="number"
                    min="1"
                    max="60"
                    value={downloadTimerDuration}
                    onChange={e => setDownloadTimerDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-24 bg-[#111111]/80 text-xs font-mono border border-white/5 rounded-xl px-3 py-2 text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914]"
                  />
                  <span className="text-[10px] text-gray-500 font-mono">Seconds to prep each print</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Row 2: Authorized Login Pathways & Automated Scrapers */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Auth Toggles (6 cols) */}
          <div className="lg:col-span-6 bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-4">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5 flex items-center gap-1">
              <ShieldCheck size={12} className="text-[#E50914]" /> Verified Sign-in Methods
            </h4>
            
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5 text-left">
                  <p className="font-bold text-white uppercase text-xxs">Standard Email / Password</p>
                  <p className="text-[9px] text-gray-500 font-mono font-bold">Standard master encryption login.</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleAuthMethod('email_password')}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${authMethods.email_password ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${authMethods.email_password ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5 text-left">
                  <p className="font-bold text-white uppercase text-xxs">Google OAuth Federated Login</p>
                  <p className="text-[9px] text-gray-500 font-mono">Access using instant popup Google profiles.</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleAuthMethod('google_oauth')}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${authMethods.google_oauth ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${authMethods.google_oauth ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5 text-left">
                  <p className="font-bold text-white uppercase text-xxs">Telephone SMS OTP Verification</p>
                  <p className="text-[9px] text-gray-500 font-mono">Bypasses registration using custom cell codes.</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleAuthMethod('phone_otp')}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${authMethods.phone_otp ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${authMethods.phone_otp ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                <div className="space-y-0.5 text-left">
                  <p className="font-bold text-white uppercase text-xxs tracking-wide">Master Registration Gate</p>
                  <p className="text-[9px] text-gray-500 font-mono">Allows new cinematic profiles to be created.</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleAuthMethod('registration_enabled')}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${authMethods.registration_enabled ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${authMethods.registration_enabled ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>
            </div>
          </div>

          {/* Auto scrapers & TMDB (6 cols) */}
          <div className="lg:col-span-6 bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-4">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5 flex items-center gap-1">
              <RefreshCw size={12} className="text-[#E50914] rotate-12" /> TMDB Integration Settings
            </h4>

            <div className="space-y-4 pr-1 text-xs">
              {/* Mode C: Live TMDB Feed */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="font-bold text-white uppercase text-xxs">Live TMDB Feed</p>
                  <p className="text-[9px] text-gray-500 font-mono">ON: Show live TMDB trending directly on Explore. OFF: Show only approved database content.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setLiveTmdbFeed(!liveTmdbFeed)}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${liveTmdbFeed ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${liveTmdbFeed ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              {/* Mode B: Auto-Fetch New Content */}
              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                <div className="space-y-0.5">
                  <p className="font-bold text-white uppercase text-xxs">Auto-Fetch New Content</p>
                  <p className="text-[9px] text-gray-500 font-mono">ON: Automatically ingest new movies and shows from TMDB daily or weekly into pending queue.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setAutoFetchEnabled(!autoFetchEnabled)}
                  className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${autoFetchEnabled ? 'bg-green-600' : 'bg-neutral-800'}`}
                >
                  <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${autoFetchEnabled ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                </button>
              </div>

              {/* Mode B Dropdown: Auto-Fetch Frequency */}
              <div className="space-y-1">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Auto-Fetch Frequency</label>
                <select
                  disabled={!autoFetchEnabled}
                  value={autoFetchFrequency}
                  onChange={e => setAutoFetchFrequency(e.target.value)}
                  className="w-full bg-[#111111] border border-white/5 rounded-xl px-3 py-2.5 text-xxs text-white focus:outline-none focus:border-[#E50914] disabled:opacity-40 font-bold"
                >
                  <option value="DAILY">Daily (RECOMMENDED BALANCE)</option>
                  <option value="WEEKLY">Weekly (MAINTENANCE THREAD)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* LATEST CATALOG SETTINGS SECTION */}
        <div className="bg-[#0f0f0f] p-6 rounded-2xl border border-white/5 space-y-4 text-xs font-sans text-left">
          <div className="flex items-center gap-2 pb-2 border-b border-white/5">
            <Layers size={14} className="text-[#E50914]" />
            <div>
              <h4 className="text-[11px] font-black uppercase text-white tracking-wider">
                LATEST CATALOG SETTINGS
              </h4>
              <p className="text-[9px] text-gray-500 font-mono mt-0.5">Adjust how many items populate the Latest Catalog index grid.</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end gap-3 pt-1">
            <div className="space-y-1.5 flex-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">
                Number of posts to show
              </label>
              <input 
                type="number"
                min="4"
                max="50"
                value={latestCatalogCount}
                onChange={e => {
                  const val = parseInt(e.target.value, 10);
                  setLatestCatalogCount(isNaN(val) ? 10 : val);
                }}
                className="w-full bg-[#111111]/90 border border-white/5 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914]"
                required
              />
              <p className="text-[9px] text-gray-500 font-mono">
                Min: 4, Max: 50. This controls how many posts appear in Latest Catalog on explore page.
              </p>
            </div>
            
            <button
              type="button"
              onClick={handleSaveLatestCount}
              disabled={isSavingLatestCount}
              className="py-2.5 px-6 bg-[#E50914] hover:bg-[#FF1A1A] disabled:bg-[#E50914]/40 text-white font-black text-xs uppercase rounded-xl transition-all font-sans cursor-pointer flex items-center justify-center gap-1.5 shrink-0 h-[40px]"
            >
              {isSavingLatestCount ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save size={13} /> Save
                </>
              )}
            </button>
          </div>
        </div>

        {/* Row 3: Social configurations */}
        <div className="bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-4 text-xs font-sans">
          <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
            Community Social Links
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-bold text-neutral-400">Discord Gate Link</label>
              <input 
                type="url"
                value={discordLink}
                onChange={e => setDiscordLink(e.target.value)}
                placeholder="https://discord.gg/..."
                className="w-full bg-[#111111] border border-white/5 rounded-xl p-2.5 text-xxs text-gray-300 font-mono focus:outline-none focus:border-[#E50914]"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-bold text-neutral-400">WhatsApp Broadcast Link</label>
              <input 
                type="url"
                value={whatsappLink}
                onChange={e => setWhatsappLink(e.target.value)}
                className="w-full bg-[#111111] border border-white/5 rounded-xl p-2.5 text-xxs text-gray-300 font-mono focus:outline-none focus:border-[#E50914]"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-bold text-neutral-400">Instagram Handle</label>
              <input 
                type="url"
                value={instagramLink}
                onChange={e => setInstagramLink(e.target.value)}
                className="w-full bg-[#111111] border border-white/5 rounded-xl p-2.5 text-xxs text-gray-300 font-mono focus:outline-none focus:border-[#E50914]"
              />
            </div>
          </div>
        </div>

        {/* Row 4: LEGAL COMPLIANCE DOCUMENTS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs font-sans">
          <div className="bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-2 text-left">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5 flex items-center gap-1">
              <FileText size={11} className="text-[#E50914]" /> Privacy Policy Directives ({privacyPolicy.length} Chars)
            </h4>
            <textarea
              value={privacyPolicy}
              onChange={e => setPrivacyPolicy(e.target.value)}
              rows={4}
              className="w-full bg-[#111111] border border-white/5 rounded-xl p-3 text-xxs text-gray-300 focus:outline-none focus:border-[#E50914]"
            />
          </div>

          <div className="bg-neutral-950/60 p-5 rounded-2xl border border-white/5 space-y-2 text-left">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5 flex items-center gap-1">
              <FileText size={11} className="text-[#E50914]" /> Terms of Use & Code of Conduct
            </h4>
            <textarea
              value={termsOfUse}
              onChange={e => setTermsOfUse(e.target.value)}
              rows={4}
              className="w-full bg-[#111111] border border-white/5 rounded-xl p-3 text-xxs text-gray-300 focus:outline-none focus:border-[#E50914]"
            />
          </div>
        </div>

        {/* Global Save */}
        <button
          type="submit"
          disabled={isSaving}
          className="w-full py-3 bg-[#E50914] hover:bg-[#FF1A1A] disabled:bg-[#E50914]/40 text-white font-black text-xs uppercase rounded-xl transition-all font-sans cursor-pointer flex items-center justify-center gap-1.5 shadow-[0_5px_15px_rgba(229,9,20,0.2)]"
        >
          {isSaving ? (
            <>
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              <span>Realigning Central Operation Parameters...</span>
            </>
          ) : (
            <>
              <Save size={13} /> WRITE CENTRAL OPERATIONS REGISTERS
            </>
          )}
        </button>

      </form>
    </div>
  );
}
