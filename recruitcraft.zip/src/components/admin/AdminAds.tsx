import React, { useState, useEffect } from 'react';
import { Globe, Save, HelpCircle, Eye, AlertCircle, ShieldEllipsis } from 'lucide-react';
import { triggerToast, db, isFirebaseConfigured } from '../../lib/firebase';
import { doc, setDoc, onSnapshot, deleteDoc } from 'firebase/firestore';

interface PlacementConfig {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  code: string;
  isMandatory?: boolean;
}

const PLACEMENTS_RAW: Omit<PlacementConfig, 'enabled' | 'code'>[] = [
  { id: 'explore_top_banner', name: 'Explore Top Banner', description: 'Displays right at the very top of the Explore Page.' },
  { id: 'explore_middle', name: 'Explore Middle', description: 'Slices between the grid columns on the Explore Page.' },
  { id: 'explore_bottom', name: 'Explore Bottom Banner', description: 'Stands at the very base of the Explore Page.' },
  { id: 'schedule_top_banner', name: 'Schedule Page Top', description: 'Displays at the top of theatrical calendar release dates.' },
  { id: 'schedule_between_dates', name: 'Schedule Between Dates', description: 'Displays between weekly dates in the calendar.' },
  { id: 'content_below_trailer', name: 'Content Below Trailer', description: 'Inserted directly below the trailer player on detail pages.' },
  { id: 'content_below_overview', name: 'Content Below Overview', description: 'Sits right beneath the synopsis summary block.' },
  { id: 'content_below_cast', name: 'Content Below Cast', description: 'Positioned right after the cast listing row.' },
  { id: 'content_below_reviews', name: 'Content Below Reviews', description: 'Renders beneath the critic reviews listing section.' },
  { id: 'content_sticky_bottom', name: 'Content Sticky Footer', description: 'Sticky banner overlaying the bottom edge of content detail page viewports.' },
  { id: 'spaces_top_banner', name: 'Spaces Top Banner', description: 'Prominent header banner on the Spaces Page.' },
  { id: 'spaces_between_posts', name: 'Spaces Between Posts', description: 'Displays between articles and news blogs on Spaces Page.' },
  { id: 'collections_top_banner', name: 'Collections Top Banner', description: 'Displays at the top of the collections portal.' },
  { id: 'profile_below_info', name: 'Profile Below Stats', description: 'Sits directly below member evaluation matrices on user profiles.' },
  { id: 'search_top_banner', name: 'Search Overlay Top', description: 'Banners loaded above search keyword feedback bars.' },
  { id: 'news_top_banner', name: 'News Grid Top', description: 'Displays on the top area of News sections.' },
  { id: 'news_middle', name: 'News Middle Content', description: 'Slices between news reports.' },
  { id: 'discussion_top_banner', name: 'Discussion Thread Top', description: 'Displays at the top area of active discussions.' },
  { id: 'download_before_link', name: 'Download Intercept Panel', description: 'Forced ad node locking access before movie downloads are completed.', isMandatory: true }
];

export default function AdminAds({ logMessage }: { logMessage: (msg: string) => void }) {
  const [globalDisable, setGlobalDisable] = useState(false);
  const [placements, setPlacements] = useState<PlacementConfig[]>([]);

  useEffect(() => {
    if (!isFirebaseConfigured || !db) {
      // Offline fallback
      const compiled: PlacementConfig[] = PLACEMENTS_RAW.map(raw => ({
        ...raw,
        enabled: true,
        code: ''
      }));
      setPlacements(compiled);
      setGlobalDisable(false);
      return;
    }

    try {
      const docRef = doc(db, 'settings', 'ads_config');
      const unsubscribe = onSnapshot(docRef, (docSnap) => {
        let loadedConfig: Record<string, any> = {};
        if (docSnap.exists()) {
          loadedConfig = docSnap.data();
          setGlobalDisable(!!loadedConfig.disable_all);
        } else {
          setGlobalDisable(false);
        }

        const compiled: PlacementConfig[] = PLACEMENTS_RAW.map(raw => {
          const savedPlacement = loadedConfig[raw.id];
          return {
            ...raw,
            enabled: raw.isMandatory ? true : (savedPlacement?.enabled ?? true),
            code: savedPlacement?.code || ''
          };
        });
        setPlacements(compiled);
      }, (error) => {
        console.error('Failed to read ad placements from Firestore:', error);
      });

      return () => unsubscribe();
    } catch (e) {
      console.error('Error establishing onSnapshot for ads_config in AdminAds:', e);
    }
  }, []);

  const saveToConfigStore = async (updatedPlacements: PlacementConfig[], globalState: boolean) => {
    if (!isFirebaseConfigured || !db) {
      logMessage(`Firebase integration is not configured. Falling back to local offline states.`);
      return;
    }

    const configMap: Record<string, any> = {
      disable_all: globalState
    };
    updatedPlacements.forEach(p => {
      configMap[p.id] = {
        enabled: p.isMandatory ? true : p.enabled,
        code: p.code
      };
    });

    try {
      const docRef = doc(db, 'settings', 'ads_config');
      await setDoc(docRef, configMap);
    } catch (err: any) {
      console.error('Failed to update ad placements in Firestore:', err);
      logMessage(`Error persisting ad configurations in database: ${err.message}`);
      triggerToast('Could not save configuration changes', 'error');
    }
  };

  const handleToggleGlobal = () => {
    const nextState = !globalDisable;
    setGlobalDisable(nextState);
    saveToConfigStore(placements, nextState);
    logMessage(`System Ad Placement Engine modified. Global ad rendering: ${nextState ? 'SUSPENDED (except mandatory locks)' : 'ACTIVE'}.`);
    triggerToast(nextState ? "All non-mandatory ad layers disabled" : "Ad network fully online!", "success");
  };

  const handleTogglePlacement = (id: string, isMandatory?: boolean) => {
    if (isMandatory) {
      triggerToast("Download Intercept ad is mandatory and can never be disabled", "error");
      return;
    }

    const updated = placements.map(p => {
      if (p.id === id) {
        return { ...p, enabled: !p.enabled };
      }
      return p;
    });

    setPlacements(updated);
    saveToConfigStore(updated, globalDisable);
    const item = updated.find(x => x.id === id);
    logMessage(`Ad Placement '${id}' state altered: ${item?.enabled ? 'LIVE' : 'OFFLINE'}.`);
    triggerToast(`Placement ${item?.enabled ? 'enabled' : 'disabled'} successfully`, "success");
  };

  const handleCodeChange = (id: string, code: string) => {
    setPlacements(prev => prev.map(p => {
      if (p.id === id) return { ...p, code };
      return p;
    }));
  };

  const handleSaveCode = (id: string) => {
    const target = placements.find(p => p.id === id);
    if (!target) return;

    saveToConfigStore(placements, globalDisable);
    logMessage(`Updated ad tag credentials code injection for slot '${id}'.`);
    triggerToast("Custom credentials code saved", "success");
  };

  const handleResetDefaults = async () => {
    if (!window.confirm("Are you sure you want to discard all customized HTML injection codes and restore responsive layout placeholders?")) return;
    
    if (isFirebaseConfigured && db) {
      try {
        const docRef = doc(db, 'settings', 'ads_config');
        await deleteDoc(docRef);
        logMessage(`Discharged advertisement registers. Live slots reset to defaults globally.`);
        triggerToast("Ad placements restored to standard presets", "success");
      } catch (err: any) {
        console.error('Error resetting ad configs in Firestore:', err);
        logMessage(`Failed to reset ad settings in Firestore: ${err.message}`);
        triggerToast("Error resetting settings in database", "error");
      }
    } else {
      const reset = placements.map(p => ({
        ...p,
        enabled: true,
        code: ''
      }));
      setPlacements(reset);
      setGlobalDisable(false);
      logMessage(`Discharged advertisement registers. Live slots reset to defaults locally.`);
      triggerToast("Ad placements restored to standard presets", "success");
    }
  };

  return (
    <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
        <div>
          <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5 font-sans">
            <Globe size={16} className="text-[#E50914]" /> Commercial Ad Networks & Placements
          </h3>
          <p className="text-[10px] text-gray-500 font-mono mt-0.5">Control system monetization modules, coordinate responsive display banner positions or inject customized HTML/JS network tags.</p>
        </div>
        <button
          onClick={handleResetDefaults}
          className="px-3.5 py-1.5 bg-neutral-900 border border-white/10 text-neutral-400 hover:text-white hover:bg-neutral-800 text-xxs font-bold uppercase rounded-lg transition-all"
        >
          Reset To Presets
        </button>
      </div>

      {/* Global Toggle Block */}
      <div className="p-5 bg-neutral-950/40 border border-white/5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 font-sans text-xs">
        <div className="space-y-1 text-left">
          <h4 className="font-bold text-white uppercase text-xxs tracking-wider flex items-center gap-1">
            <ShieldEllipsis size={13} className="text-red-500" /> Disable All Ad Channels (Global Overrule)
          </h4>
          <p className="text-[10px] text-gray-500 font-mono">Toggling this off suspends all commercial banners across the system immediately, except mandatory download intercept links.</p>
        </div>
        <button
          onClick={handleToggleGlobal}
          className={`px-4 py-2 text-xxs font-black uppercase rounded-xl border transition-all ${
            globalDisable 
              ? 'bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20' 
              : 'bg-green-500/10 border-green-500/20 text-green-500 hover:bg-green-500/20'
          }`}
        >
          {globalDisable ? '🛑 ADS CURRENTLY DISABLED' : '🟢 ADS CURRENTLY ONLINE'}
        </button>
      </div>

      {/* Placement List */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-2 border-b border-white/5">
          Active Placement Registers Index ({placements.length} Channels)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {placements.map((p) => {
            const isIndividualDisabled = globalDisable && !p.isMandatory;
            return (
              <div 
                key={p.id} 
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                  isIndividualDisabled 
                    ? 'bg-neutral-950/20 border-white/2 opacity-60' 
                    : p.enabled ? 'bg-neutral-950/60 border-white/5' : 'bg-[#15070a]/30 border-red-950/10'
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 text-left">
                  <div className="space-y-0.5">
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">SLOT_ID: {p.id}</span>
                    <h5 className="font-bold font-sans text-xs text-white">{p.name}</h5>
                  </div>
                  
                  {p.isMandatory ? (
                    <span className="bg-red-500/10 border border-red-500/20 text-red-400 text-[7px] font-mono font-bold uppercase rounded px-1.5 py-0.5">MANDATORY</span>
                  ) : (
                    <button
                      disabled={globalDisable}
                      onClick={() => handleTogglePlacement(p.id)}
                      className={`relative w-8 h-4 rounded-full transition-colors flex items-center ${
                        isIndividualDisabled ? 'bg-neutral-900 cursor-not-allowed' : p.enabled ? 'bg-green-600' : 'bg-neutral-800'
                      }`}
                    >
                      <span className={`w-3 h-3 bg-white rounded-full transition-transform absolute ${p.enabled && !isIndividualDisabled ? 'translate-x-[17px]' : 'translate-x-0.5'}`}></span>
                    </button>
                  )}
                </div>

                <p className="text-[10px] text-neutral-500 leading-relaxed font-sans">{p.description}</p>

                {/* Inline HTML Tag Editor */}
                <div className="space-y-1.5 mt-2">
                  <label className="text-[8px] font-mono text-gray-500 uppercase font-black">HTML Custom code injection</label>
                  <div className="relative">
                    <textarea
                      disabled={isIndividualDisabled || !p.enabled}
                      value={p.code}
                      onChange={e => handleCodeChange(p.id, e.target.value)}
                      placeholder="e.g. <iframe src='https://ad-server...'"
                      rows={2}
                      className="w-full text-[9px] font-mono bg-[#111111]/80 border border-white/5 rounded-xl px-2.5 py-2 text-gray-300 placeholder-neutral-700 focus:outline-none focus:border-[#E50914] disabled:bg-neutral-950 disabled:text-neutral-700 transition-all font-bold scrollbar-thin"
                    />
                    {p.code.trim() && (
                      <button
                        onClick={() => handleSaveCode(p.id)}
                        disabled={isIndividualDisabled || !p.enabled}
                        className="absolute bottom-2 right-2 p-1.5 bg-neutral-900/90 border border-white/10 hover:border-[#E50914] text-white hover:text-[#E50914] rounded-lg transition-all"
                        title="Save credentials code"
                      >
                        <Save size={10} />
                      </button>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
