import React, { useState, useEffect } from 'react';
import { ListOrdered, Search, Plus, Trash2, ArrowUp, ArrowDown, Save, Film, Star, AlertCircle } from 'lucide-react';
import { triggerToast } from '../../lib/firebase';
import { MuvioCatalogItem } from '../../lib/adminCatalog';

interface RankingContentItem {
  id: string;
  title: string;
  posterUrl: string;
  year: number;
  type: string;
}

export default function AdminRankings({ catalog, logMessage }: { catalog: MuvioCatalogItem[]; logMessage: (msg: string) => void }) {
  const [activeSubTab, setActiveSubTab] = useState<'MONTHLY' | 'TOP100' | 'SLIDER'>('MONTHLY');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MuvioCatalogItem[]>([]);

  // Rankings state lists
  const [monthlyList, setMonthlyList] = useState<RankingContentItem[]>([]);
  const [top100List, setTop100List] = useState<RankingContentItem[]>([]);
  const [sliderSlots, setSliderSlots] = useState<RankingContentItem[]>([]);

  useEffect(() => {
    // 1. Monthly Rankings load
    const savedMonthly = localStorage.getItem('muvio_rankings_monthly');
    if (savedMonthly) {
      try { setMonthlyList(JSON.parse(savedMonthly)); } catch (e) {}
    } else {
      // Seed default monthly ranking items if catalog has items
      const seeds = catalog.slice(0, 3).map(c => ({
        id: c.id,
        title: c.media.title,
        posterUrl: c.media.posterUrl,
        year: c.media.year,
        type: c.media.type
      }));
      setMonthlyList(seeds);
      localStorage.setItem('muvio_rankings_monthly', JSON.stringify(seeds));
    }

    // 2. Top 100 Rankings load
    const savedTop100 = localStorage.getItem('muvio_rankings_top100');
    if (savedTop100) {
      try { setTop100List(JSON.parse(savedTop100)); } catch (e) {}
    } else {
      const seeds = catalog.slice(0, 5).map(c => ({
        id: c.id,
        title: c.media.title,
        posterUrl: c.media.posterUrl,
        year: c.media.year,
        type: c.media.type
      }));
      setTop100List(seeds);
      localStorage.setItem('muvio_rankings_top100', JSON.stringify(seeds));
    }

    // 3. Slider Slots load
    const savedSlider = localStorage.getItem('muvio_rankings_slider');
    if (savedSlider) {
      try { setSliderSlots(JSON.parse(savedSlider)); } catch (e) {}
    } else {
      const seeds = catalog.slice(0, 2).map(c => ({
        id: c.id,
        title: c.media.title,
        posterUrl: c.media.posterUrl,
        year: c.media.year,
        type: c.media.type
      }));
      setSliderSlots(seeds);
      localStorage.setItem('muvio_rankings_slider', JSON.stringify(seeds));
    }
  }, [catalog]);

  // Search filter
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const clean = searchQuery.toLowerCase();
    const filtered = catalog.filter(item => 
      item.media.title.toLowerCase().includes(clean) || 
      item.genres.some(g => g.toLowerCase().includes(clean))
    );
    setSearchResults(filtered.slice(0, 5));
  }, [searchQuery, catalog]);

  // Sorting handlers (up/down reorder list indexes)
  const handleMoveUp = (index: number, type: 'MONTHLY' | 'TOP100' | 'SLIDER') => {
    if (index === 0) return;
    
    let list = type === 'MONTHLY' ? [...monthlyList] : type === 'TOP100' ? [...top100List] : [...sliderSlots];
    const item = list[index];
    list[index] = list[index - 1];
    list[index - 1] = item;

    if (type === 'MONTHLY') setMonthlyList(list);
    else if (type === 'TOP100') setTop100List(list);
    else setSliderSlots(list);
    
    triggerToast("Sequence reordered", "success");
  };

  const handleMoveDown = (index: number, type: 'MONTHLY' | 'TOP100' | 'SLIDER') => {
    let list = type === 'MONTHLY' ? [...monthlyList] : type === 'TOP100' ? [...top100List] : [...sliderSlots];
    if (index === list.length - 1) return;

    const item = list[index];
    list[index] = list[index + 1];
    list[index + 1] = item;

    if (type === 'MONTHLY') setMonthlyList(list);
    else if (type === 'TOP100') setTop100List(list);
    else setSliderSlots(list);
    
    triggerToast("Sequence reordered", "success");
  };

  const handleRemoveItem = (id: string, type: 'MONTHLY' | 'TOP100' | 'SLIDER') => {
    if (type === 'MONTHLY') setMonthlyList(prev => prev.filter(x => x.id !== id));
    else if (type === 'TOP100') setTop100List(prev => prev.filter(x => x.id !== id));
    else setSliderSlots(prev => prev.filter(x => x.id !== id));

    triggerToast("Removed item", "success");
  };

  const handleAddItem = (item: MuvioCatalogItem) => {
    const fresh: RankingContentItem = {
      id: item.id,
      title: item.media.title,
      posterUrl: item.media.posterUrl,
      year: item.media.year,
      type: item.media.type
    };

    if (activeSubTab === 'MONTHLY') {
      if (monthlyList.some(x => x.id === item.id)) {
        triggerToast("Item already present in Monthly Rankings", "error");
        return;
      }
      setMonthlyList([...monthlyList, fresh]);
    } else if (activeSubTab === 'TOP100') {
      if (top100List.some(x => x.id === item.id)) {
        triggerToast("Item already present in Top 100", "error");
        return;
      }
      setTop100List([...top100List, fresh]);
    } else {
      if (sliderSlots.length >= 5) {
        triggerToast("Slider slots strictly limited to 5 items", "error");
        return;
      }
      if (sliderSlots.some(x => x.id === item.id)) {
        triggerToast("Item already present in Slider slots", "error");
        return;
      }
      setSliderSlots([...sliderSlots, fresh]);
    }

    setSearchQuery('');
    setSearchResults([]);
    triggerToast(`Added "${fresh.title}" successfully`, "success");
  };

  const handleSaveRankings = () => {
    logMessage(`Packaging structured ranking coordinates...`);
    
    localStorage.setItem('muvio_rankings_monthly', JSON.stringify(monthlyList));
    localStorage.setItem('muvio_rankings_top100', JSON.stringify(top100List));
    localStorage.setItem('muvio_rankings_slider', JSON.stringify(sliderSlots));

    logMessage(`Rankings Indexes compiled and synchronized with database registers.`);
    triggerToast("Monthly, Top 100, and Featured Slider lists saved!", "success");
  };

  const getActiveList = () => {
    if (activeSubTab === 'MONTHLY') return monthlyList;
    if (activeSubTab === 'TOP100') return top100List;
    return sliderSlots;
  };

  return (
    <div className="bg-[#0a0a0a]/90 border border-white/5 rounded-3xl p-6 md:p-8 space-y-6 text-left font-sans">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pb-4 border-b border-white/5">
        <div>
          <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
            <ListOrdered size={16} className="text-[#E50914]" /> Curator Rankings & Featured Sliders
          </h3>
          <p className="text-[10px] text-gray-500 font-mono mt-0.5">Administer Featured Top Sliders, customize dynamic Monthly Leaderboards, or curate static Top 100 consumer indexes.</p>
        </div>
        
        <button
          onClick={handleSaveRankings}
          className="px-4 py-2 bg-[#E10c11]/10 hover:bg-[#E50914] border border-[#E10c11]/25 text-[#FF4444] hover:text-white text-xxs font-black uppercase rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-all shadow-red-500/10"
        >
          <Save size={12} /> Save All Rankings Tables
        </button>
      </div>

      {/* Internal Navigation Subtabs */}
      <div className="flex flex-wrap gap-2 border-b border-white/5 pb-1">
        {(['MONTHLY', 'TOP100', 'SLIDER'] as const).map((sub) => {
          const check = activeSubTab === sub;
          return (
            <button
              key={sub}
              onClick={() => {
                setActiveSubTab(sub);
                setSearchQuery('');
                setSearchResults([]);
              }}
              className={`px-4 py-2 rounded-xl text-xxs font-bold uppercase transition-all border ${
                check 
                  ? 'bg-neutral-900 border-white/10 text-white shadow-md' 
                  : 'bg-transparent border-transparent text-gray-500 hover:text-white'
              }`}
            >
              {sub === 'MONTHLY' ? 'Monthly Leaderboards' : sub === 'TOP100' ? 'Top 100 Index' : 'Featured Slider (Max 5)'}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left column (6 cols): Drag list */}
        <div className="lg:col-span-7 space-y-4">
          <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
            {activeSubTab === 'MONTHLY' ? 'Monthly Rankings list' : activeSubTab === 'TOP100' ? 'Top 100 list coordinates' : 'Slider slots list (Max 5)'}
          </h4>

          {getActiveList().length === 0 ? (
            <div className="p-8 border border-dashed border-white/5 bg-neutral-950/20 rounded-2xl text-center space-y-2 font-mono">
              <AlertCircle size={28} className="text-neutral-700 mx-auto" />
              <span className="text-[9px] uppercase tracking-wider text-gray-500">List is empty. Use Search bar to add items.</span>
            </div>
          ) : (
            <div className="space-y-3 font-mono">
              {getActiveList().map((item, index) => (
                <div key={item.id} className="p-3 bg-[#111111]/60 border border-white/5 rounded-2xl flex items-center justify-between gap-4 transition-all hover:bg-[#151515]">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-black text-[#E50914] w-4 text-center">
                      #{index + 1}
                    </span>
                    <div className="w-9 h-11 bg-neutral-900 rounded border border-white/5 overflow-hidden flex-shrink-0">
                      <img src={item.posterUrl} className="w-full h-full object-cover" alt="" />
                    </div>
                    <div className="space-y-0.5 text-left">
                      <h4 className="font-bold text-xs uppercase text-white font-sans line-clamp-1">{item.title}</h4>
                      <p className="text-[8px] text-neutral-500">{item.type} • {item.year}</p>
                    </div>
                  </div>

                  {/* Ordering arrows and delete */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleMoveUp(index, activeSubTab)}
                      disabled={index === 0}
                      className="p-1 px-2 bg-neutral-950 border border-white/5 hover:border-[#E50914] text-neutral-400 hover:text-white rounded-lg disabled:opacity-30 disabled:pointer-events-none transition-all"
                    >
                      <ArrowUp size={11} />
                    </button>
                    <button
                      onClick={() => handleMoveDown(index, activeSubTab)}
                      disabled={index === getActiveList().length - 1}
                      className="p-1 px-2 bg-neutral-950 border border-white/5 hover:border-[#E50914] text-neutral-400 hover:text-white rounded-lg disabled:opacity-30 disabled:pointer-events-none transition-all"
                    >
                      <ArrowDown size={11} />
                    </button>
                    <button
                      onClick={() => handleRemoveItem(item.id, activeSubTab)}
                      className="p-1.5 bg-red-650/10 hover:bg-red-700 border border-red-500/10 hover:border-red-500 text-red-400 hover:text-white rounded-lg transition-all ml-1"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right column (5 cols): Dynamic search to add */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-neutral-950/40 p-5 rounded-2xl border border-white/5 space-y-4">
            <h4 className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-white/5">
              Append Cinematic Entries
            </h4>

            {/* Keyword */}
            <div className="space-y-1">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Find in Site Catalog</label>
              <div className="relative">
                <input 
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Type film or show keyword..."
                  className="w-full bg-[#111111] border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#E50914] transition-all font-sans"
                />
                <Search size={13} className="absolute left-3.5 top-3.5 text-neutral-600" />
              </div>
            </div>

            {/* Search items listing */}
            {searchQuery.trim() && (
              <div className="space-y-2.5 pt-2 max-h-64 overflow-y-auto pr-1">
                {searchResults.length === 0 ? (
                  <p className="text-[9px] text-gray-600 font-mono italic">No coordinate matches in catalog database.</p>
                ) : (
                  searchResults.map((item) => (
                    <div key={item.id} className="p-2 bg-[#111111]/80 rounded-xl border border-white/5 flex items-center justify-between gap-3 text-left">
                      <div className="flex items-center gap-2 max-w-[70%]">
                        <div className="w-7 h-9 rounded bg-neutral-900 border border-white/5 overflow-hidden flex-shrink-0">
                          <img src={item.media.posterUrl} className="w-full h-full object-cover" alt="" />
                        </div>
                        <div className="space-y-0.5 min-w-0">
                          <p className="font-bold text-xxs text-white uppercase truncate">{item.media.title}</p>
                          <p className="text-[8px] text-gray-500 font-mono">{item.media.year} • {item.media.type}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleAddItem(item)}
                        className="py-1 px-2.5 bg-[#E50914] hover:bg-[#FF1A1A] text-white text-[8px] font-bold uppercase rounded-lg transition-all cursor-pointer flex items-center gap-1 font-mono"
                      >
                        <Plus size={9} /> Append
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
