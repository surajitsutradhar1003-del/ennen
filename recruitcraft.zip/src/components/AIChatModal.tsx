import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  X, 
  Send, 
  Trash2, 
  RefreshCw, 
  Film, 
  CornerDownLeft, 
  Info,
  Layers,
  ArrowRight
} from 'lucide-react';
import { getFallbackRichDetails, RichMediaDetails } from '../lib/tmdb';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  createdAt: string;
}

interface AIChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (to: string) => void;
  slugContext?: string | null;  // For content page context
}

export default function AIChatModal({ isOpen, onClose, onNavigate, slugContext }: AIChatModalProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load detailed context if a slug is active
  const [activeMediaDetails, setActiveMediaDetails] = useState<RichMediaDetails | null>(null);

  useEffect(() => {
    if (slugContext) {
      try {
        const details = getFallbackRichDetails(slugContext);
        if (details && details.media) {
          setActiveMediaDetails(details);
        }
      } catch (err) {
        console.warn('Could not parse active media details for chat context:', err);
      }
    } else {
      setActiveMediaDetails(null);
    }
  }, [slugContext, isOpen]);

  // Load chat history from sessionStorage on startup and when modal opens
  useEffect(() => {
    if (isOpen) {
      const cached = sessionStorage.getItem('muvio_ai_chat_history');
      if (cached) {
        setMessages(JSON.parse(cached));
      } else {
        setMessages([]);
      }
    }
  }, [isOpen]);

  // Scroll to bottom whenever messages list or loading state changes
  useEffect(() => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, [messages, loading]);

  // Default suggestions vs Content Specific suggestions
  const defaultChips = [
    "Recommend a horror movie",
    "Best movies of 2024",
    "Tell me about Dune Part Two",
    "Top rated anime"
  ];

  const contentChips = activeMediaDetails ? [
    `Tell me more about ${activeMediaDetails.media.title}'s plot`,
    `Who is in the cast of ${activeMediaDetails.media.title}?`,
    `Suggest movies similar to ${activeMediaDetails.media.title}`
  ] : [];

  const handleSend = async (textToSend: string) => {
    const cleanText = textToSend.trim();
    if (!cleanText || loading) return;

    const userMsg: Message = {
      id: 'usr_' + Math.random().toString(36).substring(2, 11),
      role: 'user',
      text: cleanText,
      createdAt: new Date().toISOString()
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    sessionStorage.setItem('muvio_ai_chat_history', JSON.stringify(nextMessages));
    setInput('');
    setLoading(true);

    try {
      // Format context data if active
      const contextData = activeMediaDetails ? {
        title: activeMediaDetails.media.title,
        description: activeMediaDetails.media.description,
        genre: activeMediaDetails.genres.join(', '),
        year: activeMediaDetails.media.year
      } : undefined;

      // Build system instruction
      let systemInstruction = "You are Muvio AI, a cinematic expert for the Muvio movie platform. Answer questions about movies, TV shows, anime, cast, directors, plot, recommendations and box office concisely.";
      if (contextData) {
        systemInstruction += `\n\n[CONTEXT] The user is currently viewing: "${contextData.title}". Synopsis: "${contextData.description || ''}". Genre: "${contextData.genre || ''}". Year: "${contextData.year || ''}". Tailor responses to this content where appropriate.`;
      }

      // Format messages for Gemini API
      const formattedContents = nextMessages.map(m => ({
        role: m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.text }]
      }));

      // Direct Gemini API call — no server needed
      const savedConfig = localStorage.getItem('muvio_api_keys_v1');
      const config = savedConfig ? JSON.parse(savedConfig) : {};
      const GEMINI_API_KEY = config.geminiApiKey || import.meta.env.VITE_GEMINI_API_KEY || '';
      const GEMINI_MODEL = config.geminiModel || 'gemini-3.5-flash';

      // Build contents with system instruction prepended for compatibility
      const contentsWithSystem = [
        { role: 'user', parts: [{ text: '[SYSTEM] ' + systemInstruction + '\n\nNow respond to the user.' }] },
        { role: 'model', parts: [{ text: 'Understood. I am Muvio AI, ready to help.' }] },
        ...formattedContents
      ];

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: contentsWithSystem,
            generationConfig: { temperature: 0.7 }
          })
        }
      );

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        console.error('Gemini API error:', res.status, errData);
        throw new Error('Gemini API returned ' + res.status);
      }

      const data = await res.json();
      const responseText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Sorry, I couldn't process that right now.";
      
      const aiMsg: Message = {
        id: 'ai_' + Math.random().toString(36).substring(2, 11),
        role: 'model',
        text: responseText,
        createdAt: new Date().toISOString()
      };

      const updatedHistory = [...nextMessages, aiMsg];
      setMessages(updatedHistory);
      sessionStorage.setItem('muvio_ai_chat_history', JSON.stringify(updatedHistory));
    } catch (err) {
      console.error('Gemini chat request failed:', err);
      const errMsg: Message = {
        id: 'err_' + Math.random().toString(36).substring(2, 11),
        role: 'model',
        text: "Sorry, I couldn't process that right now.",
        createdAt: new Date().toISOString()
      };
      setMessages([...nextMessages, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setMessages([]);
    sessionStorage.removeItem('muvio_ai_chat_history');
  };

  const handleNewConversation = () => {
    setMessages([]);
    sessionStorage.removeItem('muvio_ai_chat_history');
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-md flex items-end md:items-center justify-center p-0 md:p-6"
        id="muvio-ai-chat-overlay"
      >
        {/* Semi-transparent dismissal tap-target for tablet/desktop */}
        <div className="absolute inset-0 -z-10" onClick={onClose} />

        <motion.div
          initial={{ y: '100%', opacity: 0.9 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '100%', opacity: 0.9 }}
          transition={{ type: 'spring', damping: 24, stiffness: 220 }}
          className="w-full bg-[#050505] border-t md:border border-white/5 md:rounded-t-[40px] md:rounded-b-[40px] h-full max-h-full md:h-[82vh] md:max-w-4xl flex flex-col overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.8)]"
          id="muvio-cinematic-oracle-panel"
        >
          {/* HEADER SECTION */}
          <div className="px-6 py-4.5 border-b border-white/5 flex items-center justify-between shrink-0 bg-[#080808]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] relative">
                <Sparkles size={16} className="animate-glow-pulse" />
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-red-600"></span>
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-display font-black tracking-tight text-sm uppercase text-white">
                    Cinematic Oracle
                  </h3>
                  <span className="text-[7px] uppercase font-mono px-1 bg-red-600/10 text-[#E50914] border border-red-500/20 rounded font-semibold tracking-widest">
                    Gemini 3.5
                  </span>
                </div>
                <p className="text-[10px] text-gray-500 font-mono">
                  MUVIO DIRECTOR ASSISTANT
                </p>
              </div>
            </div>

            {/* HEADER ACTIONS */}
            <div className="flex items-center gap-2">
              {messages.length > 0 && (
                <div className="flex items-center gap-1 bg-white/2 p-0.5 rounded-xl border border-white/5">
                  <button
                    onClick={handleNewConversation}
                    className="p-1 px-2.5 hover:bg-white/5 text-gray-400 hover:text-white rounded-lg text-3xs font-mono font-black uppercase tracking-wider transition-all flex items-center gap-1 select-none cursor-pointer"
                    title="Start fresh chat"
                  >
                    <RefreshCw size={10} />
                    <span>New Chat</span>
                  </button>
                  <button
                    onClick={handleClear}
                    className="p-1 px-1.5 hover:bg-red-500/10 text-gray-400 hover:text-[#E50914] rounded-lg transition-all cursor-pointer"
                    title="Clear history"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              )}

              <button
                onClick={onClose}
                className="p-2 bg-white/2 hover:bg-white/5 border border-white/5 text-gray-400 hover:text-white rounded-xl transition-all outline-none cursor-pointer"
                id="btn-close-oracle"
              >
                <X size={15} />
              </button>
            </div>
          </div>

          {/* ACTIVE CONTENT VIEWING CONTEXT FLAG */}
          {activeMediaDetails && (
            <div className="px-6 py-2.5 bg-[#E50914]/2 border-b border-white/5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 text-left min-w-0">
                <Film size={12} className="text-[#E50914]" />
                <span className="text-[10px] font-mono text-gray-400 truncate">
                  Contextually Synced on: <strong className="text-white hover:underline cursor-pointer font-bold" onClick={() => { onClose(); onNavigate(`/content/${activeMediaDetails.media.id}`); }}>{activeMediaDetails.media.title}</strong>
                </span>
              </div>
              <span className="text-[8px] uppercase font-mono text-emerald-400 bg-emerald-500/10 px-1 rounded border border-emerald-500/20 py-0.2 select-none">
                Bound
              </span>
            </div>
          )}

          {/* MESSAGES CORE VIEW STAGING */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-5 bg-[#030303] custom-scrollbar">
            {messages.length === 0 ? (
              /* WELCOME / IDLE INTRO VIEW */
              <div className="h-full flex flex-col justify-between py-4">
                <div className="space-y-6 max-w-md mx-auto text-center pt-10 select-none">
                  <div className="w-16 h-16 rounded-3xl bg-neutral-900 border border-white/5 flex items-center justify-center mx-auto text-[#E50914] shadow-xl relative animate-bounce">
                    <Sparkles size={28} />
                    <span className="absolute inset-0 bg-[#E50914]/10 rounded-3xl blur-md scale-102"></span>
                  </div>
                  
                  <div className="space-y-1.5">
                    <h4 className="text-sm font-display font-black text-white uppercase tracking-wider">
                      Consult the Oracle
                    </h4>
                    <p className="text-2xs text-gray-400 font-sans leading-relaxed max-w-sm mx-auto">
                      Hi! I'm Muvio AI. Ask me anything about movies, shows, anime, cast, plot, recommendations and more!
                    </p>
                  </div>
                </div>

                {/* SUGGESTED INTERACTION CHIPS */}
                <div className="space-y-2 max-w-lg mx-auto w-full pt-10">
                  <span className="text-[9px] font-mono font-black text-gray-600 block text-center uppercase tracking-widest">
                    Quick Prompt Pathways
                  </span>
                  <div className="flex flex-wrap justify-center gap-2">
                    {(activeMediaDetails ? contentChips : defaultChips).map((chipText) => (
                      <button
                        key={chipText}
                        onClick={() => handleSend(chipText)}
                        className="px-3.5 py-2.5 bg-[#090909] hover:bg-[#E50914]/5 border border-white/5 hover:border-[#E50914]/20 rounded-2xl text-left text-xxs text-gray-300 hover:text-white transition-all duration-200 active:scale-98 cursor-pointer flex items-center gap-1.5 group select-none shadow-sm"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-red-600/30 group-hover:bg-[#E50914] transition-colors shrink-0"></span>
                        <span className="font-medium">{chipText}</span>
                        <ArrowRight size={10} className="opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all text-[#E50914]" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* CHAT SESSION ROW LIST */
              <div className="space-y-4">
                {messages.map((message) => {
                  const isUser = message.role === 'user';
                  return (
                    <div
                      key={message.id}
                      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-[24px] p-4 text-xs font-sans leading-relaxed shadow-sm relative group overflow-hidden ${
                          isUser
                            ? 'bg-[#E50914] text-white rounded-tr-sm ml-8'
                            : 'bg-neutral-900 border border-white/5 text-gray-200 rounded-tl-sm mr-8 text-left'
                        }`}
                      >
                        {/* Soft visual subtle layout glow on response */}
                        {!isUser && (
                          <div className="absolute top-0 left-0 w-24 h-24 bg-[radial-gradient(circle_at_left_top,rgba(229,9,20,0.04)_0%,transparent_70%)] pointer-events-none"></div>
                        )}
                        <p className="whitespace-pre-line tracking-wide font-medium">
                          {message.text}
                        </p>
                      </div>
                    </div>
                  );
                })}

                {/* TYPING LOADER SPINNER INDICATOR */}
                {loading && (
                  <div className="flex w-full justify-start transition-opacity pointer-events-none">
                    <div className="bg-neutral-900 border border-white/5 text-gray-400 rounded-[24px] rounded-tl-sm p-4 text-xs flex items-center gap-2 shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-[#E50914] animate-bounce shrink-0" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 rounded-full bg-[#E50914] animate-bounce shrink-0" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 rounded-full bg-[#E50914] animate-bounce shrink-0" style={{ animationDelay: '300ms' }} />
                      <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest pl-1">
                        Oracle Interrogating...
                      </span>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* SUGGESTED INLINE CHIP PANELS DURING CONVERSATION */}
          {messages.length > 0 && !loading && (
            <div className="px-6 py-2 bg-[#050505] flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-none border-t border-white/2 select-none">
              <span className="text-[8px] font-mono font-black text-gray-600 uppercase tracking-wider mr-1">Suggestions:</span>
              <div className="flex gap-1.5 py-1">
                {(activeMediaDetails ? contentChips : defaultChips).slice(0, 3).map((chipText) => (
                  <button
                    key={'inline_' + chipText}
                    onClick={() => handleSend(chipText)}
                    className="px-2.5 py-1.5 bg-[#090909] hover:bg-[#E50914]/5 border border-white/5 rounded-xl text-3xs text-gray-400 hover:text-white font-medium select-none cursor-pointer transition-all"
                  >
                    {chipText}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* LOWER MESSAGE INPUT BOX CORES */}
          <div className="p-4 md:p-6 border-t border-white/5 bg-[#080808] shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend(input);
              }}
              className="relative flex items-center"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={activeMediaDetails 
                  ? `Ask Oracle about ${activeMediaDetails.media.title}...`
                  : "State your cinematic query to the Director Oracle..."
                }
                className="w-full bg-[#030303] border border-white/10 hover:border-white/15 focus:border-[#E50914]/50 rounded-2xl h-13 pl-5 pr-22 text-xs text-white placeholder-gray-600 outline-none transition-all shadow-inner font-medium tracking-wide"
                disabled={loading}
                id="input-oracle-chat"
              />

              <div className="absolute right-1.5 flex items-center gap-1">
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="w-10 h-10 bg-[#E50914] hover:bg-[#FF1A1A] disabled:opacity-30 text-white rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md select-none"
                  id="btn-oracle-submit"
                >
                  <Send size={14} />
                </button>
              </div>
            </form>

            <div className="mt-3 flex items-center justify-between text-[9px] font-mono text-gray-600 select-none px-1">
              <span className="flex items-center gap-1">
                <Info size={10} />
                <span>Conversations are handled via sandbox session cache.</span>
              </span>
              <span className="flex items-center gap-0.5">
                <span>Enterprise Shield Encrypted</span>
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
