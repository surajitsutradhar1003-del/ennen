import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Flame, 
  ChevronLeft, 
  ChevronRight, 
  SlidersHorizontal,
  LayoutGrid,
  Info,
  Clock,
  CheckCircle,
  Sparkles
} from 'lucide-react';
import { triggerToast, UserProfile } from '../lib/firebase';
import { createNotification } from '../lib/userInteractions';
import { isLiveTmdbFeedOn } from '../lib/tmdb';
import { getCustomPublishedMedia } from '../lib/adminCatalog';
import AdSlot from './AdSlot';

interface SchedulePageProps {
  onNavigate: (to: string) => void;
  currentUser: UserProfile | null;
  onTriggerAuthPrompt?: () => void;
}

export interface ScheduleItem {
  id: string;
  title: string;
  type: 'MOVIE' | 'SHOW' | 'ANIME';
  status: 'released' | 'upcoming' | 'announced';
  releaseDate: string; // ISO yyyy-mm-dd
  posterUrl: string;
  backdropUrl: string;
  description: string;
  interestedCount: number;
}

// 2026-06-13 general relative mock entries
const INITIAL_SCHEDULE_ITEMS: ScheduleItem[] = [
  {
    id: "movie-dune3",
    title: "Dunes: Part Three",
    type: "MOVIE",
    status: "upcoming",
    releaseDate: "2026-06-25",
    posterUrl: "https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=1200",
    description: "The cinematic conclusion to Villeneuve's desert prophecy saga. Arrakis burns with interstellar holy war.",
    interestedCount: 1420
  },
  {
    id: "movie-br2049",
    title: "Blade Runner: Replicant Division",
    type: "MOVIE",
    status: "released",
    releaseDate: "2026-04-12",
    posterUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=1200",
    description: "A synth-detective uncovers highly classified neural-net projects which threaten the synthetic labor line.",
    interestedCount: 890
  },
  {
    id: "anime-evasynth",
    title: "Neon Genesis: Synthetic Core",
    type: "ANIME",
    status: "released",
    releaseDate: "2026-05-18",
    posterUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=1200",
    description: "Pilots launch tactical defense programs against biomechanical sky deities. Depths of soul interrogation.",
    interestedCount: 2011
  },
  {
    id: "show-cyber2099",
    title: "Cyberpunk: 2099 Legends",
    type: "SHOW",
    status: "upcoming",
    releaseDate: "2026-07-15",
    posterUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=1200",
    description: "The neon-slicked body-mod streets of Night City are back with a fresh high-tier netrunner legend.",
    interestedCount: 3410
  },
  {
    id: "movie-spaceinf",
    title: "Interstellar: Stargate Chronicles",
    type: "MOVIE",
    status: "announced",
    releaseDate: "2027-05-14",
    posterUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&q=80&w=1200",
    description: "Venturing into uncharted folds of the super-singularity. Quantum math reveals multiple temporal bridges.",
    interestedCount: 4530
  },
  {
    id: "movie-avengersdoom",
    title: "Avengers: Secret Incursions",
    type: "MOVIE",
    status: "announced",
    releaseDate: "2027-11-20",
    posterUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=1200",
    description: "The multiverse begins collapse as regional dimensions clash over core resources. Elite tactical alliances.",
    interestedCount: 9480
  },
  {
    id: "show-stranger5",
    title: "Stranger Encounters: Chapter 5",
    type: "SHOW",
    status: "upcoming",
    releaseDate: "2026-06-20",
    posterUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=1200",
    description: "The dimensional rift reaches its peak. Retro-town heroes face the ultimate entity in a fight for earth.",
    interestedCount: 5210
  },
  {
    id: "anime-ghostcore",
    title: "Ghost Shell: Synthetic Hub",
    type: "ANIME",
    status: "upcoming",
    releaseDate: "2026-06-25",
    posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=400",
    backdropUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1200",
    description: "Neural pathways are exposed in a sprawling synth city. Major Motoko traces ghost hacks on military servers.",
    interestedCount: 1980
  }
];

export default function SchedulePage({ onNavigate, currentUser, onTriggerAuthPrompt }: SchedulePageProps) {
  const [activeTab, setActiveTab] = useState<'released' | 'upcoming' | 'announced'>('upcoming');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'MOVIE' | 'SHOW' | 'ANIME'>('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'calendar'>('grid');
  const [loading, setLoading] = useState(true);

  // Calendar states
  const [currentMonth, setCurrentMonth] = useState(new Date(2026, 5, 1)); // Default June 2026

  // Local storage keys for interests & schedules
  const [interestedIds, setInterestedIds] = useState<string[]>(() => {
    const cached = localStorage.getItem('muvio_user_interests');
    return cached ? JSON.parse(cached) : [];
  });

  const [scheduleItems, setScheduleItems] = useState<ScheduleItem[]>([]);

  useEffect(() => {
    if (!isLiveTmdbFeedOn()) {
      const customMedia = getCustomPublishedMedia();
      const mapped: ScheduleItem[] = customMedia.map(m => {
        const isUpcoming = new Date(m.releaseDate).getTime() > Date.now();
        return {
          id: m.id,
          title: m.title,
          type: m.type,
          status: isUpcoming ? 'upcoming' as const : 'released' as const,
          releaseDate: m.releaseDate,
          posterUrl: m.posterUrl,
          backdropUrl: m.backdropUrl,
          description: m.description,
          interestedCount: m.voteCount || 42
        };
      });
      setScheduleItems(mapped);
    } else {
      const cached = localStorage.getItem('muvio_schedule_list');
      setScheduleItems(cached ? JSON.parse(cached) : INITIAL_SCHEDULE_ITEMS);
    }
  }, []);

  useEffect(() => {
    // Simulate loading state
    const timer = setTimeout(() => {
      setLoading(false);
    }, 600);
    return () => clearTimeout(timer);
  }, [activeTab, activeFilter, viewMode]);

  const handleToggleInterest = async (itemId: string, itemTitle: string) => {
    if (!currentUser) {
      if (onTriggerAuthPrompt) {
        onTriggerAuthPrompt();
      } else {
        triggerToast('Please log in with your credentials to mark interest.', 'error');
        onNavigate('/login');
      }
      return;
    }

    let isInterested = false;
    const nextIds = [...interestedIds];
    const idx = nextIds.indexOf(itemId);
    if (idx !== -1) {
      nextIds.splice(idx, 1);
      triggerToast(`Removed interest in "${itemTitle}".`, 'success');
    } else {
      nextIds.push(itemId);
      isInterested = true;
      triggerToast(`Marked interest in "${itemTitle}"! You will receive notification logs. ❤️`, 'success');

      // Part C: Trigger in-app notification & FCM remind logs
      try {
        await createNotification(
          currentUser.uid, // sender is also recipient for self content release
          'muvio_system', 
          'Muvio System',
          'CONTENT_RELEASE' as any,
          itemId,
          itemId,
          `You marked interest in upcoming drop: ${itemTitle}. Reminder logged.`
        );
      } catch (err) {
        console.warn('System notifications trigger errored: ', err);
      }
    }

    setInterestedIds(nextIds);
    localStorage.setItem('muvio_user_interests', JSON.stringify(nextIds));

    // Update interested count on list
    const updatedSchedules = scheduleItems.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          interestedCount: isInterested ? item.interestedCount + 1 : Math.max(0, item.interestedCount - 1)
        };
      }
      return item;
    });
    setScheduleItems(updatedSchedules);
    localStorage.setItem('muvio_schedule_list', JSON.stringify(updatedSchedules));
  };

  // Group by date logic
  const filteredItems = scheduleItems.filter(item => {
    const matchTab = item.status === activeTab;
    const matchFilter = activeFilter === 'ALL' || item.type === activeFilter;
    return matchTab && matchFilter;
  });

  // Sort by date soonest to latest
  const sortedItems = [...filteredItems].sort((a, b) => {
    return new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime();
  });

  // Grouped items by date map
  const groupedByDate: Record<string, ScheduleItem[]> = {};
  sortedItems.forEach(item => {
    const d = item.releaseDate;
    if (!groupedByDate[d]) {
      groupedByDate[d] = [];
    }
    groupedByDate[d].push(item);
  });

  // Format Helper for dates
  const formatDateHeader = (dateStr: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateStr).toLocaleDateString('en-US', options).toUpperCase();
  };

  // Monthly calendar build helpers
  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const startDay = getFirstDayOfMonth(currentMonth);
    const blanks = Array(startDay).fill(null);
    const monthWeeks: (any)[][] = [];

    const monthDays: any[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      monthDays.push(d);
    }

    const allDays = [...blanks, ...monthDays];
    for (let i = 0; i < allDays.length; i += 7) {
      monthWeeks.push(allDays.slice(i, i + 7));
    }

    const monthName = currentMonth.toLocaleString('en-US', { month: 'long', year: 'numeric' }).toUpperCase();

    return (
      <div className="bg-[#0b0b0b] border border-white/5 rounded-3xl p-6 space-y-4">
        {/* CALENDAR NAVIGATION */}
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
            <h4 className="text-sm font-black font-mono tracking-widest text-white">{monthName}</h4>
          </div>
          <div className="flex gap-1">
            <button 
              onClick={handlePrevMonth}
              className="p-1 px-2.5 rounded-lg bg-white/2 hover:bg-white/5 border border-white/5 text-xs font-mono font-bold text-gray-400 hover:text-white cursor-pointer"
            >
              <ChevronLeft size={14} />
            </button>
            <button 
              onClick={handleNextMonth}
              className="p-1 px-2.5 rounded-lg bg-white/2 hover:bg-white/5 border border-white/5 text-xs font-mono font-bold text-gray-400 hover:text-white cursor-pointer"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* CALENDAR HEADER DAYS */}
        <div className="grid grid-cols-7 gap-1.5 text-center text-[10px] font-mono text-gray-400 font-bold uppercase tracking-wider">
          <div>Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>

        {/* CALENDAR INDEX GRID */}
        <div className="space-y-1.5">
          {monthWeeks.map((week, wIdx) => (
            <div key={wIdx} className="grid grid-cols-7 gap-1.5">
              {week.map((day, dIdx) => {
                if (day === null) {
                  return <div key={`${wIdx}-${dIdx}`} className="aspect-square bg-transparent rounded-xl"></div>;
                }

                // Check calendar drop dates
                const formattedDayStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                
                // Upcoming releases on this day
                const daysItems = scheduleItems.filter(item => item.releaseDate === formattedDayStr && item.status === 'upcoming');

                return (
                  <div 
                    key={`${wIdx}-${dIdx}`} 
                    className={`aspect-square rounded-2xl relative p-1 text-left flex flex-col justify-between transition-colors border group ${
                      daysItems.length > 0 
                        ? 'bg-red-950/20 border-red-500/20 hover:border-red-500/40' 
                        : 'bg-black/30 border-white/2 hover:bg-white/2'
                    }`}
                  >
                    <span className={`text-[10px] font-mono font-black ${daysItems.length > 0 ? 'text-red-400' : 'text-gray-500'}`}>{day}</span>
                    
                    {daysItems.length > 0 && (
                      <div className="space-y-0.5">
                        {daysItems.slice(0, 2).map(item => (
                          <div 
                            key={item.id}
                            onClick={() => onNavigate(`/content/${item.id}`)}
                            className="bg-red-600/90 text-[8px] font-mono font-black text-white px-1 leading-tight rounded truncate block cursor-pointer select-none"
                            title={item.title}
                          >
                            {item.title}
                          </div>
                        ))}
                        {daysItems.length > 2 && (
                          <span className="text-[7px] text-gray-400 block px-0.5 leading-none font-mono font-black">+{daysItems.length - 2} MORE</span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* CALENDAR LEGEND */}
        <div className="pt-3 border-t border-white/5 flex gap-4 text-[10px] font-mono text-gray-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-red-950/20 border border-red-500/20 rounded-md"></span>
            <span>Release Scheduled</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-black/30 border border-white/2 rounded-md"></span>
            <span>No Airings</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 text-left">
      <AdSlot placementId="schedule_top_banner" />

      {/* HEADER STRIP */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[#E50914] text-[10px] tracking-widest font-mono font-black block uppercase">
            MUVIO LOGISTIC PIPELINES
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight">
            Schedules & Airings
          </h2>
          <p className="text-2xs text-gray-400 font-mono mt-0.5 max-w-sm">
            Inspect dropped master copies, monitor pipeline upcoming campaigns, or check prospective releases in the galactic calendar grid.
          </p>
        </div>

        {/* COMPACT ROUTE STATE SELECTOR */}
        <div className="flex bg-[#111111]/90 p-1 border border-white/5 rounded-2xl self-start md:self-auto">
          {(['released', 'upcoming', 'announced'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                if (tab !== 'upcoming') setViewMode('grid');
              }}
              className={`px-4 py-2.5 rounded-xl text-2xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                activeTab === tab
                  ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER BUTTON PILLS */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {(['ALL', 'MOVIE', 'SHOW', 'ANIME'] as const).map((pill) => (
            <button
              key={pill}
              onClick={() => setActiveFilter(pill)}
              className={`px-3 py-1.5 rounded-full text-3xs font-mono font-black uppercase tracking-wider border transition-all cursor-pointer ${
                activeFilter === pill
                  ? 'bg-neutral-800 border-white/10 text-white'
                  : 'bg-[#111111]/30 border-white/5 text-gray-500 hover:text-white'
              }`}
            >
              {pill}
            </button>
          ))}
        </div>

        {/* CALENDAR / GRID TOGGLE (ONLY RELEVANT FOR UPCOMING) */}
        {activeTab === 'upcoming' && (
          <div className="flex bg-[#111111]/90 p-0.5 border border-white/5 rounded-xl">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 px-3 rounded-lg text-3xs font-mono font-black uppercase transition-all cursor-pointer flex items-center gap-1 ${
                viewMode === 'grid'
                  ? 'bg-neutral-800 text-white'
                  : 'text-gray-500 hover:text-white'
              }`}
            >
              <LayoutGrid size={11} /> Grid
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`p-1.5 px-3 rounded-lg text-3xs font-mono font-black uppercase transition-all cursor-pointer flex items-center gap-1 ${
                viewMode === 'calendar'
                  ? 'bg-neutral-800 text-white'
                  : 'text-gray-500 hover:text-white'
              }`}
            >
              <Calendar size={11} /> Calendar View
            </button>
          </div>
        )}
      </div>

      {/* DISPLAY SWITCHER */}
      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div
            key="skeleton"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {[1, 2].map(grp => (
              <div key={grp} className="space-y-4">
                <div className="h-4 w-44 bg-zinc-900 rounded-md animate-pulse"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1, 2].map(i => (
                    <div key={i} className="bg-zinc-950 border border-white/5 rounded-3xl h-36 flex animate-pulse">
                      <div className="w-24 bg-zinc-900 rounded-l-3xl"></div>
                      <div className="p-4 space-y-2 flex-1">
                        <div className="h-4 bg-zinc-900 rounded w-3/4"></div>
                        <div className="h-3 bg-zinc-900 rounded w-1/2"></div>
                        <div className="h-3 bg-zinc-900 rounded w-5/6 pt-2"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        ) : viewMode === 'calendar' ? (
          <motion.div
            key="calendar_view"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
          >
            {renderCalendar()}
          </motion.div>
        ) : Object.keys(groupedByDate).length === 0 ? (
          <motion.div
            key="empty_state"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="p-16 border-2 border-dashed border-white/5 rounded-[2.5rem] text-center space-y-4 bg-[#0a0a0a]/30"
          >
            <Clock size={44} className="mx-auto text-gray-600 stroke-1" />
            <div className="space-y-1.5 max-w-sm mx-auto">
              <h4 className="text-xs uppercase font-mono font-black text-neutral-400 tracking-wider">
                {!isLiveTmdbFeedOn() && getCustomPublishedMedia().length === 0 ? "No content available yet" : "No Scheduled Items Found"}
              </h4>
              <p className="text-2xs text-gray-500 font-sans leading-normal">
                {!isLiveTmdbFeedOn() && getCustomPublishedMedia().length === 0 
                  ? "The database is empty and live TMDB feed is deactivated. Check back later." 
                  : "Our projection schedules are fully loaded, but no catalogued profiles matched these exact database filters."}
              </p>
            </div>
            {(isLiveTmdbFeedOn() || getCustomPublishedMedia().length > 0) && (
              <button
                onClick={() => { setActiveFilter('ALL'); setActiveTab('upcoming'); }}
                className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-3xs font-black uppercase tracking-widest cursor-pointer transition-colors"
              >
                Reset Schedule Filters
              </button>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="grid_view"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-8"
          >
            {Object.entries(groupedByDate).map(([date, items], idx) => (
              <div key={date} className="space-y-4">
                {idx === 1 && (
                  <div className="py-2">
                    <AdSlot placementId="schedule_between_dates" />
                  </div>
                )}
                {/* DATE FLOATER HEADER */}
                <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-600"></div>
                  <h3 className="text-2xs font-mono font-black text-gray-400 tracking-widest uppercase">
                    {formatDateHeader(date)}
                  </h3>
                </div>

                {/* 2-COLUMN POSTER GRID */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {items.map((item) => {
                    const isFav = interestedIds.includes(item.id);
                    return (
                      <div
                        key={item.id}
                        className="bg-[#0b0b0b] border border-white/5 hover:border-white/10 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 flex text-left group"
                      >
                        {/* Poster */}
                        <div 
                          onClick={() => onNavigate(`/content/${item.id}`)}
                          className="w-24 sm:w-28 relative bg-zinc-950 overflow-hidden shrink-0 cursor-pointer"
                        >
                          <img 
                            src={item.posterUrl} 
                            alt={item.title} 
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-104"
                          />
                        </div>

                        {/* Details */}
                        <div className="p-4 flex flex-col justify-between flex-1 space-y-2">
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[8px] font-mono font-black text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/20 px-2 py-0.5 rounded uppercase">
                                {item.type}
                              </span>
                              <span className="text-[9px] font-mono text-gray-500 font-bold">
                                {new Date(item.releaseDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                              </span>
                            </div>

                            <h4 
                              onClick={() => onNavigate(`/content/${item.id}`)}
                              className="text-white text-xs md:text-sm font-black uppercase group-hover:text-[#E50914] transition-colors leading-tight cursor-pointer line-clamp-1"
                            >
                              {item.title}
                            </h4>

                            <p className="text-[10px] text-gray-400 leading-normal line-clamp-2 pr-2">
                              {item.description}
                            </p>
                          </div>

                          {/* ACTION BANNER */}
                          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[9px] font-mono">
                            <span className="text-gray-500 uppercase font-black tracking-tighter">
                              {item.interestedCount} tracking
                            </span>

                            {(item.status === 'upcoming' || item.status === 'announced') && (
                              <button
                                onClick={() => handleToggleInterest(item.id, item.title)}
                                className={`px-2.5 py-1 rounded-lg border text-[8px] font-mono font-black uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer ${
                                  isFav
                                    ? 'bg-red-600/10 border-red-500/30 text-red-500'
                                    : 'bg-white/2 border-white/5 text-gray-400 hover:text-white'
                                }`}
                              >
                                <Flame size={10} className={isFav ? 'fill-red-500' : ''} />
                                {isFav ? 'Interested' : 'Remind'}
                              </button>
                            )}

                            {item.status === 'released' && (
                              <span className="text-emerald-400 flex items-center gap-0.5 font-bold uppercase text-[8px] tracking-wide">
                                <CheckCircle size={10} /> Dispatched
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
