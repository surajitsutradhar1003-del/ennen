import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Search, 
  Sparkles, 
  History, 
  Clock, 
  Film, 
  Tv, 
  Gamepad, 
  Clapperboard,
  Compass,
  ArrowRight
} from 'lucide-react';
import { searchCatalog, MuvioMedia, isLiveTmdbFeedOn, generateSlug } from '../lib/tmdb';
import { getCustomPublishedMedia } from '../lib/adminCatalog';
import { UserProfile } from '../lib/firebase';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (to: string) => void;
  currentUser: UserProfile | null;
}

export default function SearchOverlay({ isOpen, onClose, onNavigate, currentUser }: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'ALL' | 'MOVIE' | 'SHOW' | 'ANIME'>('ALL');
  const [results, setResults] = useState<MuvioMedia[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Gemini AI parsing state
  const [aiLoading, setAiLoading] = useState(false);
  const [isAiActive, setIsAiActive] = useState(false);
  const [aiResults, setAiResults] = useState<MuvioMedia[]>([]);

  // Recent searches stored per-user
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  const inputRef = useRef<HTMLInputElement>(null);

  // Load recent searches on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 150);
      const userKey = currentUser ? `muvio_recents_${currentUser.uid}` : `muvio_recents_anonymous`;
      const cached = localStorage.getItem(userKey);
      if (cached) {
        setRecentSearches(JSON.parse(cached));
      } else {
        // Prep seed
        const defaults = ['Blade Runner', 'Dunes', 'Anime'];
        setRecentSearches(defaults);
      }
    } else {
      setQuery('');
      setResults([]);
      setIsAiActive(false);
      setAiResults([]);
    }
  }, [isOpen, currentUser]);

  // Debounced real-time keyword search
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    if (isAiActive) {
      return;
    }

    setLoading(true);
    const delayDebounce = setTimeout(async () => {
      try {
        const searchRes = await searchCatalog(query, activeTab);
        setResults(searchRes);
      } catch (err) {
        console.error('Search failed: ', err);
      } finally {
        setLoading(false);
      }
    }, 400);

    return () => clearTimeout(delayDebounce);
  }, [query, activeTab, isAiActive]);

  const saveToRecents = (searchVal: string) => {
    const trimmed = searchVal.trim();
    if (!trimmed) return;

    let nextRecents = [trimmed, ...recentSearches.filter(s => s.toLowerCase() !== trimmed.toLowerCase())];
    nextRecents = nextRecents.slice(0, 5); // limit to 5
    setRecentSearches(nextRecents);

    const userKey = currentUser ? `muvio_recents_${currentUser.uid}` : `muvio_recents_anonymous`;
    localStorage.setItem(userKey, JSON.stringify(nextRecents));
  };

  const handleClearRecent = (valToDelete: string) => {
    const nextRecents = recentSearches.filter(s => s !== valToDelete);
    setRecentSearches(nextRecents);
    const userKey = currentUser ? `muvio_recents_${currentUser.uid}` : `muvio_recents_anonymous`;
    localStorage.setItem(userKey, JSON.stringify(nextRecents));
  };

  const handleQuerySubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    saveToRecents(query);
  };

  const handleRecentClick = (recentItem: string) => {
    setQuery(recentItem);
  };

  // Gemini natural-language interpreter action
  const handleAskGemini = async () => {
    if (!query.trim()) return;

    setAiLoading(true);
    saveToRecents(query);

    try {
      const response = await fetch('/api/search/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();

      if (data && !data.error && !data.explanation?.includes("translation failed") && !data.explanation?.includes("failed")) {
        // Apply filters extracted by AI
        const classification = (data.typeFilter || 'ALL').toUpperCase();
        if (['ALL', 'MOVIE', 'SHOW', 'ANIME'].includes(classification)) {
          setActiveTab(classification as any);
        }

        const searchQuery = data.searchQuery || query;
        // Apply extracted topic
        setQuery(searchQuery);

        // Get matching results from local database ONLY
        const customMedia = getCustomPublishedMedia();
        const cleanSQ = searchQuery.toLowerCase().trim();

        const filtered = customMedia.filter(item => {
          // filter by type
          let matchType = true;
          if (classification === 'ANIME') {
            matchType = item.type === 'ANIME';
          } else if (classification !== 'ALL') {
            matchType = item.type === classification;
          }
          if (!matchType) return false;

          // filter by query (title or description match)
          const titleL = item.title.toLowerCase();
          const descL = item.description.toLowerCase();
          if (titleL.includes(cleanSQ) || descL.includes(cleanSQ)) return true;

          // words check
          const words = cleanSQ.split(/\s+/).filter(w => w.length > 2);
          if (words.length > 0 && words.some(w => titleL.includes(w) || descL.includes(w))) return true;

          return false;
        });

        setAiResults(filtered);
        setIsAiActive(true);
      } else {
        // Silently fall back to normal keyword search
        setIsAiActive(false);
        const searchRes = await searchCatalog(query, activeTab);
        setResults(searchRes);
      }
    } catch (err) {
      console.warn('Gemini search proxy call failed, silently falling back:', err);
      // Silently fall back to normal keyword search
      setIsAiActive(false);
      try {
        const searchRes = await searchCatalog(query, activeTab);
        setResults(searchRes);
      } catch (fallbackErr) {
        console.error('Fallback search failed:', fallbackErr);
      }
    } finally {
      setAiLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-[#000000]/98 backdrop-blur-2xl z-[100] overflow-y-auto px-4 md:px-10 py-8 text-left flex flex-col"
        id="muvio-search-overlay"
      >
        {/* TOP SEARCH NAVIGATION CONTROL PANEL */}
        <div className="w-full max-w-4xl mx-auto flex items-center justify-between border-b border-white/5 pb-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#E50914] animate-pulse"></span>
            <span className="font-mono font-black text-3xs tracking-widest text-[#E50914] uppercase">
              Search
            </span>
          </div>

          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/5 border border-white/5 rounded-2xl text-gray-400 hover:text-white transition-all cursor-pointer"
            id="btn-search-overlay-close"
          >
            <X size={18} />
          </button>
        </div>

        {/* DIALOG MAIN CORE */}
        <div className="w-full max-w-4xl mx-auto flex-1 flex flex-col py-6 space-y-6">
          {!isLiveTmdbFeedOn() && getCustomPublishedMedia().length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-20 text-center space-y-3" id="search-empty-feed-off">
              <Search size={40} className="mx-auto text-gray-600 animate-pulse" />
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">No content available yet</h4>
              <p className="text-2xs text-neutral-500 max-w-sm leading-normal">
                The database is currently empty and live TMDB feed is deactivated. Check back later once curators approve content.
              </p>
            </div>
          ) : (
            <>
              {/* SEARCH BOX INPUT */}
              <form onSubmit={handleQuerySubmit} className="relative flex items-center">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setIsAiActive(false);
              }}
              placeholder="Search by keywords, titles, or prompt Gemini (e.g. 'retro cyberpunk cartoon series')..."
              className="w-full bg-[#0a0a0a] border border-white/10 hover:border-white/20 focus:border-[#E50914]/50 rounded-2xl h-14 pl-12 pr-32 text-sm text-white font-medium tracking-wide placeholder-gray-600 outline-none transition-all shadow-inner"
              id="input-search-query"
            />
            
            <Search size={18} className="absolute left-4.5 text-gray-500" />

            {/* INTEGRATED GEMINI PROMPT TRIGGER */}
            <div className="absolute right-2 flex items-center gap-1">
              {query.trim().length > 0 && (
                <button
                  type="button"
                  disabled={aiLoading}
                  onClick={handleAskGemini}
                  className="h-10 px-4 bg-[#E50914]/10 hover:bg-[#E50914] hover:text-white border border-[#E50914]/30 rounded-xl text-3xs font-mono font-black tracking-widest text-[#E50914] uppercase transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  title="Ask Gemini Director to interpret intent"
                  id="btn-ask-gemini-trigger"
                >
                  <Sparkles size={11} className={aiLoading ? 'animate-spin' : ''} />
                  {aiLoading ? 'Interpreting...' : 'Gemini AI'}
                </button>
              )}
            </div>
          </form>

          {/* CLASSIFIED TYPE TABS */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex bg-[#111111]/80 p-0.5 border border-white/5 rounded-2xl">
              {(['ALL', 'MOVIE', 'SHOW', 'ANIME'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => {
                    setActiveTab(tab);
                    setIsAiActive(false);
                  }}
                  className={`px-4 py-2 rounded-xl text-3xs font-mono font-black uppercase tracking-wider transition-all cursor-pointer ${
                    activeTab === tab
                      ? 'bg-neutral-800 text-white'
                      : 'text-gray-500 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {loading && (
              <span className="text-3xs font-mono text-gray-500 tracking-wider animate-pulse uppercase">
                Crawling Cinematic Indices...
              </span>
            )}
          </div>

          {/* CONDITIONAL LAYOUTS: RECENTS VS RESULTS */}
          {!query.trim() ? (
            /* RECENT SEARCHES PANEL */
            <div className="space-y-4 pt-4">
              <div className="flex items-center gap-2 text-gray-500">
                <History size={14} />
                <h4 className="text-2xs font-mono font-black uppercase tracking-wider">
                  Recent Cinematic Searches
                </h4>
              </div>

              {recentSearches.length === 0 ? (
                <p className="text-2xs text-gray-600 font-mono italic">No recent search records found in history.</p>
              ) : (
                <div className="flex flex-col gap-1">
                  {recentSearches.map((item) => (
                    <div 
                      key={item}
                      className="flex items-center justify-between p-3 py-2 bg-[#0a0a0a]/40 border border-white/2 hover:border-white/5 rounded-xl text-xs text-gray-400 hover:text-white cursor-pointer transition-all group"
                    >
                      <div 
                        onClick={() => handleRecentClick(item)}
                        className="flex-1 flex items-center gap-3"
                      >
                        <Clock size={12} className="text-gray-600 group-hover:text-red-500 transition-colors" />
                        <span className="font-medium">{item}</span>
                      </div>
                      <button 
                        onClick={() => handleClearRecent(item)}
                        className="p-1 hover:bg-white/5 rounded-lg text-gray-600 hover:text-red-500 transition-colors"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* RECOMMENDED POPULAR PATHWAYS */}
              <div className="space-y-4 pt-6">
                <div className="flex items-center gap-2 text-gray-500">
                  <Compass size={14} />
                  <h4 className="text-2xs font-mono font-black uppercase tracking-wider">
                    Recommended Categories
                  </h4>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { title: 'Blockbusters', icon: Film, q: 'Dunes' },
                    { title: 'Anime Legends', icon: Gamepad, q: 'Neon Genesis' },
                    { title: 'Sci-Fi Masterpieces', icon: Clapperboard, q: 'Interstellar' },
                    { title: 'Trending Series', icon: Tv, q: 'Stranger Things' },
                  ].map((cat) => (
                    <div
                      key={cat.title}
                      onClick={() => handleRecentClick(cat.q)}
                      className="p-4 bg-[#0a0a0a]/60 border border-white/5 hover:border-[#E50914]/20 hover:bg-[#E50914]/2 rounded-2xl text-center cursor-pointer transition-all group flex flex-col items-center justify-center space-y-2 select-none"
                    >
                      <cat.icon size={20} className="text-gray-500 group-hover:text-[#E50914] transition-all group-hover:scale-105" />
                      <span className="text-3xs uppercase font-mono font-black tracking-wider text-gray-400 group-hover:text-white transition-colors">{cat.title}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (isAiActive ? aiResults : results).length === 0 && !loading ? (
             /* EMPTY RESULTS */
            <div className="py-16 text-center space-y-2.5">
              <Search size={40} className="mx-auto text-gray-600" />
              <div className="space-y-1 max-w-sm mx-auto">
                <h4 className="text-xs uppercase font-mono font-black text-gray-400">
                  No Cinematic Matches
                </h4>
                <p className="text-2xs text-gray-500 leading-normal font-sans">
                  We completed an inspection of the search indexes but returned zero matches matching your query: <span className="text-gray-400">"{query}"</span>. Ensure details are spelled correctly.
                </p>
              </div>
            </div>
          ) : (
            /* GRID RESULTS DISPLAY */
            <div className="space-y-3">
              <span className="text-[10px] font-mono font-black text-gray-500 uppercase block tracking-widest">
                Search matches ({(isAiActive ? aiResults : results).length})
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {(isAiActive ? aiResults : results).map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      saveToRecents(query);
                      onClose();
                      onNavigate(`/content/${generateSlug(item.title)}`);
                    }}
                    className="p-3 bg-[#0a0a0a] border border-white/5 hover:border-white/10 rounded-3xl cursor-pointer transition-all flex gap-3 group text-left relative overflow-hidden"
                  >
                    <div className="w-16 h-22 bg-neutral-900 rounded-2xl overflow-hidden shrink-0 relative">
                      <img 
                        src={item.posterUrl} 
                        alt={item.title} 
                        className="w-full h-full object-cover group-hover:scale-104 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex flex-col justify-between py-1 flex-1 min-w-0">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-mono font-bold text-[#E50914] uppercase tracking-wide px-1.5 py-0.2 bg-[#E50914]/10 rounded border border-[#E50914]/20">
                            {item.type}
                          </span>
                          <span className="text-[8px] font-mono text-gray-500">
                            {item.year || '2025'}
                          </span>
                        </div>
                        <h4 className="text-xs text-white font-black uppercase tracking-tight group-hover:text-[#E50914] transition-colors truncate">
                          {item.title}
                        </h4>
                        <p className="text-[10px] text-gray-500 line-clamp-1 truncate">
                          {item.description}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 text-red-500 text-[9px] font-mono font-black uppercase">
                        <span>Details</span>
                        <ArrowRight size={10} className="group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
