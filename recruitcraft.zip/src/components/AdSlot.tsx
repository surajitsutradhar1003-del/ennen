import React, { useEffect, useState } from 'react';
import { AlertCircle, ShieldAlert } from 'lucide-react';
import { db, isFirebaseConfigured } from '../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';

interface AdSlotProps {
  placementId: string;
}

export default function AdSlot({ placementId }: AdSlotProps) {
  const [enabled, setEnabled] = useState(true);
  const [adCode, setAdCode] = useState('');
  const [isAllDisabled, setIsAllDisabled] = useState(false);

  useEffect(() => {
    if (!isFirebaseConfigured || !db) {
      // Fallback if Firebase environment is not active
      if (placementId === 'download_before_link') {
        setEnabled(true);
      } else {
        setEnabled(true);
      }
      setAdCode('');
      setIsAllDisabled(false);
      return;
    }

    try {
      const docRef = doc(db, 'settings', 'ads_config');
      const unsubscribe = onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
          const config = docSnap.data();
          const placement = config[placementId];
          const globalDisable = !!config.disable_all;

          setIsAllDisabled(globalDisable);

          // download_before_link is mandatory, cannot be disabled
          if (placementId === 'download_before_link') {
            setEnabled(true);
            setAdCode(placement?.code || '');
          } else {
            setEnabled(globalDisable ? false : (placement?.enabled ?? true));
            setAdCode(placement?.code || '');
          }
        } else {
          // Default seed setup if document is absent
          if (placementId === 'download_before_link') {
            setEnabled(true);
          } else {
            setEnabled(true);
          }
          setAdCode('');
          setIsAllDisabled(false);
        }
      }, (error) => {
        console.error('Failed to listen to ad configurations from Firestore:', error);
      });

      return () => unsubscribe();
    } catch (e) {
      console.error('Error establishing onSnapshot for ads_config:', e);
    }
  }, [placementId]);

  if (!enabled) return null;

  // Render raw HTML ad code if present
  if (adCode.trim()) {
    return (
      <div 
        className="w-full my-6 p-4 bg-neutral-950/40 border border-white/5 rounded-2xl flex flex-col items-center justify-center relative overscroll-contain overflow-hidden"
        id={`ad-slot-${placementId}`}
      >
        <div className="absolute top-1.5 right-3 text-[7px] font-mono uppercase tracking-widest text-[#E50914] opacity-50 bg-[#E50914]/10 px-1.5 py-0.5 rounded border border-[#E50914]/20">SPONSORED</div>
        <div 
          className="w-full text-center text-xs text-neutral-300 font-sans mt-3"
          dangerouslySetInnerHTML={{ __html: adCode }}
        />
      </div>
    );
  }

  // Beautiful pre-cooked stylish display ads tailored to placement
  const getPreCookedAd = () => {
    switch (placementId) {
      case 'download_before_link':
        return {
          title: "🔑 PREMIUM HIGH-VELOCITY CORES ACCESS",
          desc: "Upgrade to premium Muvio Vault Pass to bypass all download gates instantly and unlock ultra-fidelity master-quality 10-bit HDR prints at 10 Gbps speeds.",
          buttonText: "UNLOCK PREMIUM FASTPASS NOW",
          tags: ["4K INFIDELITY", "NO GATES"]
        };
      case 'explore_top_banner':
      case 'schedule_top_banner':
      case 'spaces_top_banner':
      case 'collections_top_banner':
      case 'search_top_banner':
      case 'news_top_banner':
      case 'discussion_top_banner':
        return {
          title: "🎬 IMPOSED THEATRICAL MARATHON: CRITERION CODES",
          desc: "Unlock immediate digital access. Exclusively streaming 50 rare restored Criterion classics with live creator commentary and dual-audio. Special Beta promo offering $3.99/mo.",
          buttonText: "CLAIM FESTIVAL DIRECT PASS",
          tags: ["CRITERION VAULTS", "LIMITED TIME"]
        };
      case 'explore_middle':
      case 'news_middle':
      case 'schedule_between_dates':
      case 'spaces_between_posts':
        return {
          title: "🎙️ ORACLE SESSIONS: DIRECTORS TALK BACK",
          desc: "Gain entry to live interactive audio stream rooms with legendary visionary directors discussing independent cinema, cinematography tricks, and production blueprints.",
          buttonText: "RESERVE SEAT FOR NEXT LIVE",
          tags: ["LIVE SESSIONS", "EXCLUSIVE"]
        };
      case 'content_below_trailer':
      case 'content_below_overview':
      case 'content_below_cast':
      case 'content_below_reviews':
        return {
          title: "🍿 EXPAND YOUR CINEMATIC CORRIDORS",
          desc: "Order standard-delivery physical prints, screenplays, concept artbooks, and official licensing replicas directly from the official filmmaker merchandise inventory.",
          buttonText: "EXPLORE MOVIE STORES",
          tags: ["FILM MERCH", "STORES"]
        };
      case 'profile_below_info':
        return {
          title: "💎 THE CRITIC BADGE REVELATION",
          desc: "Complete your member bio and post 5 high-fidelity analyses to earn the Golden Critic Badge. Verified badge accounts bypass general queue lines and vote in the Elite Rankings list.",
          buttonText: "VERIFY CRITIC PROFILE",
          tags: ["AUDIENCE LEVEL 2", "EARN STATUS"]
        };
      case 'content_sticky_bottom':
        return {
          title: "🔔 DON'T MISS A SCREENING: RELEASE RADAR",
          desc: "Set instant push reminders for upcoming regional midnight screenings, major local previews, and global theatrical events.",
          buttonText: "ACTIVATE CALENDAR SIGNALS",
          tags: ["REMINDERS", "AUTOPILOT"]
        };
      default:
        return {
          title: "🍿 CHAT WITH VISIONARY DIRECTOR ORACLE",
          desc: "Got queries regarding themes, character motifs, complex plots, or cinematography splits? Spark conversational loops with our custom real-time Cinematic Mentor.",
          buttonText: "SUMMON CINEMA ORACLE",
          tags: ["AI ORACLE", "FREE COGNITIVE"]
        };
    }
  };

  const ad = getPreCookedAd();

  return (
    <div 
      className="w-full my-6 p-5 rounded-[24px] bg-gradient-to-r from-neutral-950 via-[#100305] to-neutral-950 border border-white/5 relative overflow-hidden transition-all duration-300 hover:border-[#E50914]/20 group flex flex-col md:flex-row items-center md:justify-between gap-4 text-left"
      id={`ad-slot-${placementId}`}
    >
      <div className="absolute top-0 right-0 h-[100px] w-[150px] bg-[#E50914]/5 blur-[70px] rounded-full group-hover:bg-[#E50914]/10 transition-colors pointer-events-none"></div>
      
      {/* Background decoration */}
      <span className="absolute top-2 right-3 text-[7px] font-mono uppercase tracking-[0.2em] text-[#E50914] font-black opacity-60 bg-[#E50914]/10 px-1.5 py-0.5 rounded border border-[#E50914]/15">
        SPONSORED AD
      </span>

      <div className="space-y-2 flex-1 max-w-xl">
        <div className="flex gap-1.5 items-center flex-wrap">
          <span className="text-xxs font-mono text-neutral-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
            {placementId.toUpperCase()}
          </span>
          {ad.tags.map((tag) => (
            <span key={tag} className="text-[7px] font-mono font-bold text-[#E50914] bg-[#E50914]/10 border border-[#E50914]/15 px-1 rounded">
              {tag}
            </span>
          ))}
        </div>
        <h4 className="font-display font-medium text-xs text-white uppercase tracking-tight group-hover:text-[#FF1A1A] transition-colors mt-1">
          {ad.title}
        </h4>
        <p className="text-[10px] text-neutral-400 font-sans leading-relaxed">
          {ad.desc}
        </p>
      </div>

      <button className="flex-shrink-0 px-4 py-2 bg-[#E10c11]/10 hover:bg-[#E10c11]/20 border border-[#E10c11]/25 hover:border-[#E10c11]/50 text-[#FF4444] text-[10px] font-black uppercase rounded-xl transition-all duration-300 shadow-[0_5px_15px_rgba(225,12,17,0.1)] group-hover:shadow-[0_5px_20px_rgba(225,12,17,0.2)]">
        {ad.buttonText}
      </button>
    </div>
  );
}
