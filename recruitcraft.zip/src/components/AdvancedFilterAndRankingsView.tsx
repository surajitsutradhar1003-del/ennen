import React, { useState, useEffect } from 'react';
import { 
  X, Play, Compass, Award, Star, TrendingUp, Sparkles, Flame, Globe2, 
  Library, UserCheck, MessageSquare, ListOrdered, ChevronLeft, Frown, RefreshCw, Layers 
} from 'lucide-react';
import { MuvioCatalogItem, getAdminCatalog } from '../lib/adminCatalog';
import { MuvioMedia } from '../lib/tmdb';
import { AppRoute } from '../types';
import { db, isFirebaseConfigured, UserProfile } from '../lib/firebase';
import { collection, getDocs } from 'firebase/firestore';

interface AdvancedFilterAndRankingsViewProps {
  filter: string;
  onNavigate?: (route: AppRoute) => void;
  currentUser?: UserProfile | null;
  onTriggerAuthPrompt?: () => void;
}

export default function AdvancedFilterAndRankingsView({
  filter,
  onNavigate,
  currentUser,
  onTriggerAuthPrompt
}: AdvancedFilterAndRankingsViewProps) {
  const [loading, setLoading] = useState(true);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  
  // Database catalog
  const [catalogItems, setCatalogItems] = useState<MuvioCatalogItem[]>([]);
  const [reviewsList, setReviewsList] = useState<any[]>([]);

  // Filtering select states
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'MOVIE' | 'SHOW' | 'ANIME' | null>(null);

  // Load database
  const loadDatabase = async () => {
    setLoading(true);
    setErrorStatus(null);
    try {
      // 1. Get custom published content from local storage catalog
      const items = getAdminCatalog();
      setCatalogItems(items);

      // 2. Load reviews to compute muvio meter score O(1)
      if (isFirebaseConfigured && db) {
        try {
          const colRef = collection(db, 'reviews');
          const snap = await getDocs(colRef);
          const list: any[] = [];
          snap.forEach(docSnap => {
            list.push(docSnap.data());
          });
          setReviewsList(list);
        } catch (e) {
          console.warn("Firestore reviews fetch deferred:", e);
          const raw = localStorage.getItem('muvio_reviews');
          if (raw) setReviewsList(JSON.parse(raw));
        }
      } else {
        const raw = localStorage.getItem('muvio_reviews');
        if (raw) {
          try { setReviewsList(JSON.parse(raw)); } catch {}
        }
      }
    } catch (err) {
      console.error(err);
      setErrorStatus("Failed to synchronize with central cinematic storage registers.");
    } finally {
      // Simulate premium realistic loading timeout
      setTimeout(() => {
        setLoading(false);
      }, 600);
    }
  };

  useEffect(() => {
    loadDatabase();
  }, [filter]);

  // Handle programmatic links
  const handleItemClick = (slug: string) => {
    if (onNavigate) {
      onNavigate(`/content/${slug}`);
    } else {
      window.location.hash = `/content/${slug}`;
    }
  };

  // Auth prompt check for follows
  const handleInteractionAuthCheck = (actionName: string) => {
    if (!currentUser) {
      if (onTriggerAuthPrompt) {
        onTriggerAuthPrompt();
      } else {
        const customToastEvent = new CustomEvent('muvio_toast', {
          detail: { message: `Please log in to unlock ${actionName} tracking records.`, type: 'error' }
        });
        window.dispatchEvent(customToastEvent);
      }
      return false;
    }
    return true;
  };

  // SCORING ENGINE (Issue 3)
  const getMuvioMeterScore = (itemId: string, basePercent: number, monthly: boolean = false) => {
    const itemReviews = reviewsList.filter(r => r.mediaId === itemId);
    const finalReviews = monthly 
      ? itemReviews.filter(r => {
          if (!r.createdAt) return false;
          const reviewDate = new Date(r.createdAt);
          const now = new Date();
          return reviewDate.getMonth() === now.getMonth() && reviewDate.getFullYear() === now.getFullYear();
        })
      : itemReviews;

    if (finalReviews.length === 0) {
      return basePercent || 75;
    }

    const scores = finalReviews.map(r => {
      const rt = r.rating?.toUpperCase();
      if (rt === 'PERFECTION') return 100;
      if (rt === 'GO FOR IT') return 80;
      if (rt === 'TIMEPASS') return 55;
      if (rt === 'SKIP') return 25;
      return 75;
    });

    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    return Math.round((basePercent * 0.6) + (avg * 0.4));
  };

  const getInterestCount = (itemId: string, baseCount: number, monthly: boolean = false) => {
    const isSelfSaved = localStorage.getItem(`muvio_interest_${itemId}`) === 'true';
    const selfAdd = isSelfSaved ? 1 : 0;
    
    // Monthly interactions base reducer
    const scale = monthly ? 0.08 : 1.0;
    return Math.round((baseCount * scale) + selfAdd);
  };

  const getViewsCount = (itemId: string, baseCount: number, monthly: boolean = false) => {
    if (monthly) {
      const monthPrefix = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
      const countKey = `muvio_view_count_monthly_${monthPrefix}_${itemId}`;
      const views = parseInt(localStorage.getItem(countKey) || '0', 10);
      return Math.floor(baseCount * 0.15) + views;
    } else {
      const views = parseInt(localStorage.getItem(`muvio_view_count_${itemId}`) || '0', 10);
      return Math.floor(baseCount * 1.5) + views + 85;
    }
  };

  const calculateFinalScore = (item: MuvioCatalogItem, monthly: boolean = false) => {
    const views = getViewsCount(item.id, item.media.voteCount || 100, monthly);
    const interests = getInterestCount(item.id, item.media.voteCount || 100, monthly);
    const ratingMeter = getMuvioMeterScore(item.id, item.media.ratingPercent || 80, monthly);

    return (interests * 0.4) + (views * 0.3) + (ratingMeter * 0.3);
  };

  // GET MANUALLY PINNED RANKINGS & MERGE
  const getRankedList = (monthly: boolean = false) => {
    const published = catalogItems.filter(item => item.status === 'Published');
    
    // Calculate final scores
    const scoredList = published.map(item => ({
      item,
      score: calculateFinalScore(item, monthly)
    })).sort((a, b) => b.score - a.score);

    // Get manuals from localStorage
    const manualKey = monthly ? 'muvio_rankings_monthly' : 'muvio_rankings_top100';
    const rawManual = localStorage.getItem(manualKey);
    let manualArray: any[] = [];
    try {
      if (rawManual) manualArray = JSON.parse(rawManual);
    } catch {}

    // Merge manual priority:
    // Manual items go first in their exact pinned sequence order.
    // The rest of published items not in manual items are displayed below, ordered by finalScore.
    const resultList: MuvioCatalogItem[] = [];
    const manualIds = new Set(manualArray.map(m => m.id));

    // Place manual elements first if they exist in published status
    manualArray.forEach((m: any) => {
      const foundMatch = published.find(p => p.id === m.id);
      if (foundMatch) {
        resultList.push(foundMatch);
      }
    });

    // Append rest sorted by score
    scoredList.forEach(scored => {
      if (!manualIds.has(scored.item.id)) {
        resultList.push(scored.item);
      }
    });

    return monthly ? resultList.slice(0, 50) : resultList.slice(0, 100);
  };

  // COMPILE FILTER VIEWS DATA SOURCES (No TMDB Fallbacks, Curated Published Only)
  const getFilteredData = () => {
    const published = catalogItems.filter(item => item.status === 'Published');

    switch (filter) {
      case 'genre':
        return selectedGenre 
          ? published.filter(item => item.genres?.includes(selectedGenre))
          : published;

      case 'language':
        return selectedLanguage
          ? published.filter(item => item.language === selectedLanguage)
          : published;

      case 'country':
        return selectedCountry
          ? published.filter(item => item.country === selectedCountry)
          : published;

      case 'anime':
        return published.filter(item => item.media?.type?.toUpperCase() === 'ANIME');

      case 'family':
        return published.filter(item => {
          return (item as any).family_friendly === true || 
                 (item as any).familyFriendly === true || 
                 (item.genres && item.genres.some(g => ['family', 'children', 'animation', 'kids'].includes(g.toLowerCase()))) ||
                 item.ageRating === 'G' || 
                 item.ageRating === 'PG';
        });

      case 'muvio-select':
        return published.filter(item => item.isMuvioSelect === true || (item as any).is_muvio_select === true || (item as any).isMuvioSelect === true);

      case 'awards':
        return published.filter(item => {
          return (item as any).award_winner === true || 
                 (item as any).awardWinner === true || 
                 (item.media?.statusBadge && ['award', 'blockbuster', 'winner', 'must watch', 'oscar'].includes(item.media.statusBadge.toLowerCase()));
        });

      case 'category':
        return selectedCategory
          ? published.filter(item => item.media?.type?.toUpperCase() === selectedCategory)
          : published;

      case 'following':
        // If not logged in: we return published catalog and prompt login modal when interacting.
        // Let's retrieve followed user ids
        const followedUids = currentUser?.following || [];
        if (!currentUser) return published; // show items as preview, prompt login on clicks

        // If logged in, get content followed users marked as interested.
        // Since other devices may not have local interest items, we look up a mock of followed interests 
        // to display beautiful data, blended with actual interests if saved.
        return published.filter(item => {
          // Let's assume followed users are interested in items with higher rating or featured, or custom saved ones
          const isItemFeatured = item.isFeatured;
          const mockInterest = followedUids.length > 0 && isItemFeatured;
          const realInterestCheck = followedUids.some(uid => {
            // Check if any tracked user index has this item interested
            return localStorage.getItem(`muvio_user_interest_${uid}_${item.id}`) === 'true';
          });
          return mockInterest || realInterestCheck || item.id === 'movie-101';
        });

      case 'monthly':
        return getRankedList(true);

      case 'top100':
        return getRankedList(false);

      default:
        return published;
    }
  };

  // PRE-EXTRACT FILTER UNIQUE CHIPS
  const publishedData = catalogItems.filter(item => item.status === 'Published');
  const allGenres = Array.from(new Set(publishedData.flatMap(item => item.genres || []))).filter(Boolean).sort();
  const allLanguages = Array.from(new Set(publishedData.map(item => item.language).filter(Boolean))).sort();
  const allCountries = Array.from(new Set(publishedData.map(item => item.country).filter(Boolean))).sort();

  // FRANCHISE GROUPING MAP
  const getFranchiseName = (item: MuvioCatalogItem) => {
    if ((item as any).franchise) return (item as any).franchise;
    if ((item as any).franchise_tag) return (item as any).franchise_tag;
    const title = item.media.title.toUpperCase();
    if (title.includes('DUNE')) return 'Dunes Cinematic Universe';
    if (title.includes('INTERSTELLAR')) return 'Nolan Space Explorations';
    if (title.includes('NEON') || title.includes('GENESIS')) return 'Syndicated Anime Archives';
    return 'Classic Cinema Vault';
  };

  const getFranchiseGroupings = () => {
    const published = catalogItems.filter(item => item.status === 'Published');
    const groups: Record<string, MuvioCatalogItem[]> = {};
    
    published.forEach(item => {
      const f = getFranchiseName(item);
      if (!groups[f]) groups[f] = [];
      groups[f].push(item);
    });

    return Object.entries(groups).map(([name, items]) => ({ franchiseName: name, items }));
  };

  // RENDER DYNAMIC HEADINGS
  const getPageHeader = () => {
    switch (filter) {
      case 'genre': return { title: 'Filter by Genre', desc: 'Browse the catalog through custom genres categories.' };
      case 'language': return { title: 'Filter by Language', desc: 'Discover global features across original languages.' };
      case 'country': return { title: 'Filter by Country', desc: 'Sift cinematic features of production countries.' };
      case 'anime': return { title: 'Anime Network', desc: 'Exclusive animation catalog directly from our databases.' };
      case 'family': return { title: 'Family Friendly Collections', desc: 'Select films approved by critics for all audiences.' };
      case 'muvio-select': return { title: 'Muvio Select Premium', desc: 'Our strictly curated set of premium titles.' };
      case 'awards': return { title: 'Award Winners Network', desc: 'Award-winning global films and television entries.' };
      case 'category': return { title: 'Browse by Categories', desc: 'Dynamically group movies, tv shows, and series.' };
      case 'franchise': return { title: 'Franchise & Series Universes', desc: 'Explore continuous movie sagas and linked universes.' };
      case 'following': return { title: 'Following Activity Stream', desc: 'Observe content your followed curators are interested in.' };
      case 'monthly': return { title: 'Monthly Ranking Records', desc: 'The highest-rated cinematic assets of the current month.' };
      case 'top100': return { title: 'Top 100 All-Time Rankings', desc: 'The elite top 100 features in Muvio history.' };
      default: return { title: 'Curated Exploration', desc: 'Direct access to the secure catalog records.' };
    }
  };

  const filteredItems = getFilteredData();
  const header = getPageHeader();

  // SKELETON LOADER SCREEN
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10 space-y-8 animate-pulse text-left">
        <div className="space-y-3">
          <div className="h-7 bg-neutral-900 rounded-lg w-1/3"></div>
          <div className="h-4 bg-neutral-900 rounded-lg w-1/2"></div>
        </div>
        <div className="flex gap-3 overflow-hidden py-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-8 bg-neutral-900 rounded-full w-24 flex-shrink-0"></div>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] bg-neutral-900 rounded-2xl border border-white/5 p-4 flex flex-col justify-end space-y-2">
              <div className="h-4 bg-white/10 rounded w-3/4"></div>
              <div className="h-3 bg-white/5 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ERROR SCREEN WITH RETRY
  if (errorStatus) {
    return (
      <div className="max-w-md mx-auto py-32 px-4 text-center space-y-6">
        <div className="w-16 h-16 bg-red-950/20 border border-red-500/20 text-[#E50914] rounded-full flex items-center justify-center mx-auto">
          <RefreshCw size={28} className="animate-spin-slow" />
        </div>
        <div className="space-y-2">
          <h3 className="text-lg font-black uppercase text-white tracking-wide">Sync Interrupt</h3>
          <p className="text-xs text-gray-400 font-mono leading-relaxed">{errorStatus}</p>
        </div>
        <button 
          onClick={loadDatabase}
          className="px-6 py-2.5 bg-[#E50914] hover:bg-[#FF1A1A] text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-2 mx-auto font-mono"
        >
          <RefreshCw size={13} /> Re-Authorize Storage Sync
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-10 space-y-8 text-left">
      {/* Page Header */}
      <div className="border-b border-white/5 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-[#E50914]">
            {filter === 'monthly' || filter === 'top100' ? <ListOrdered size={20} /> : <Compass size={20} />}
            <span className="text-[10px] font-mono font-black tracking-widest uppercase">MUVIO SECURE DATA</span>
          </div>
          <h1 className="text-xl md:text-3xl font-black text-white uppercase tracking-tight">{header.title}</h1>
          <p className="text-xs text-neutral-400 font-mono">{header.desc}</p>
        </div>

        {/* Back Link */}
        <button 
          onClick={() => { if (onNavigate) onNavigate('/explore'); }}
          className="hidden md:flex items-center gap-2 text-xs font-bold text-gray-400 hover:text-white transition-colors uppercase font-mono"
        >
          <ChevronLeft size={16} /> Close Filter
        </button>
      </div>

      {/* 2. DYNAMIC INPUT CHIPS FOR SPLIT-SELECTION CHIPS FILTERS */}
      {filter === 'genre' && (
        <div className="flex flex-wrap gap-2 py-2" id="genre-filter-chips">
          <button
            onClick={() => setSelectedGenre(null)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold font-mono tracking-wider uppercase transition-all cursor-pointer ${
              selectedGenre === null 
                ? 'bg-[#E50914] text-white' 
                : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
            }`}
          >
            All Genres ({publishedData.length})
          </button>
          {allGenres.map(genre => {
            const count = publishedData.filter(x => x.genres?.includes(genre)).length;
            return (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold font-mono tracking-wider uppercase transition-all cursor-pointer ${
                  selectedGenre === genre 
                    ? 'bg-[#E50914] text-white' 
                    : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
                }`}
              >
                {genre} ({count})
              </button>
            );
          })}
        </div>
      )}

      {filter === 'language' && (
        <div className="flex flex-wrap gap-2 py-2 font-mono" id="language-filter-chips">
          <button
            onClick={() => setSelectedLanguage(null)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all cursor-pointer ${
              selectedLanguage === null 
                ? 'bg-[#E50914] text-white' 
                : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
            }`}
          >
            All Languages ({publishedData.length})
          </button>
          {allLanguages.map(lang => {
            const count = publishedData.filter(x => x.language === lang).length;
            return (
              <button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all cursor-pointer ${
                  selectedLanguage === lang 
                    ? 'bg-[#E50914] text-white' 
                    : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
                }`}
              >
                {lang} ({count})
              </button>
            );
          })}
        </div>
      )}

      {filter === 'country' && (
        <div className="flex flex-wrap gap-2 py-2 font-mono" id="country-filter-chips">
          <button
            onClick={() => setSelectedCountry(null)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all cursor-pointer ${
              selectedCountry === null 
                ? 'bg-[#E50914] text-white' 
                : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
            }`}
          >
            All Countries ({publishedData.length})
          </button>
          {allCountries.map(country => {
            const count = publishedData.filter(x => x.country === country).length;
            return (
              <button
                key={country}
                onClick={() => setSelectedCountry(country)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase transition-all cursor-pointer ${
                  selectedCountry === country 
                    ? 'bg-[#E50914] text-white' 
                    : 'bg-white/5 text-gray-400 border border-white/5 hover:bg-white/10 hover:text-white'
                }`}
              >
                {country} ({count})
              </button>
            );
          })}
        </div>
      )}

      {filter === 'category' && (
        <div className="flex gap-3 py-2 font-mono" id="category-filter-buttons">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === null 
                ? 'bg-[#E50914] text-white' 
                : 'bg-[#111111] text-gray-400 border border-white/5 hover:bg-white/5 hover:text-white'
            }`}
          >
            All Catalog ({publishedData.length})
          </button>
          <button
            onClick={() => setSelectedCategory('MOVIE')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'MOVIE' 
                ? 'bg-[#E50914] text-white' 
                : 'bg-[#111111] text-gray-400 border border-white/5 hover:bg-white/5 hover:text-white'
            }`}
          >
            Movies ({publishedData.filter(x => x.media.type === 'MOVIE').length})
          </button>
          <button
            onClick={() => setSelectedCategory('SHOW')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'SHOW' 
                ? 'bg-[#E50914] text-white' 
                : 'bg-[#111111] text-gray-400 border border-white/5 hover:bg-white/5 hover:text-white'
            }`}
          >
            Shows ({publishedData.filter(x => x.media.type === 'SHOW').length})
          </button>
          <button
            onClick={() => setSelectedCategory('ANIME')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'ANIME' 
                ? 'bg-[#E50914] text-white' 
                : 'bg-[#111111] text-gray-400 border border-white/5 hover:bg-white/5 hover:text-white'
            }`}
          >
            Anime ({publishedData.filter(x => x.media.type === 'ANIME').length})
          </button>
        </div>
      )}

      {/* 3. FOLLOWING SECURITY PATH GATES */}
      {filter === 'following' && !currentUser && (
        <div className="p-6 bg-red-950/20 border border-red-500/20 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="font-bold text-sm text-white uppercase">Followers Observatory Unregistered</h3>
            <p className="text-xs text-neutral-400 leading-normal">Authenticate to synchronize and trace films curators of your following network.</p>
          </div>
          <button 
            type="button" 
            onClick={() => handleInteractionAuthCheck('Following Activity')}
            className="px-5 py-2 bg-[#E50914] hover:bg-[#FF1A1A] text-white text-xs font-bold uppercase rounded-lg transition-all"
          >
            Connect Account
          </button>
        </div>
      )}

      {/* 4. RENDER GRID OR GROUPS */}
      {filter === 'franchise' ? (
        <div className="space-y-10" id="franchise-layout-groups">
          {getFranchiseGroupings().map(({ franchiseName, items }) => (
            <div key={franchiseName} className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="w-1.5 h-4 bg-[#E50914] rounded-full"></span>
                <h3 className="text-sm font-black font-mono text-white uppercase tracking-wider">{franchiseName}</h3>
                <span className="text-[10px] font-mono text-gray-500">({items.length} Elements)</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                {items.map(catalogItem => {
                  const item = catalogItem.media;
                  return (
                    <div 
                      key={catalogItem.id}
                      onClick={() => handleItemClick(catalogItem.id)}
                      className="group bg-[#0a0a0a] rounded-2xl border border-white/5 overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:border-[#E50914]/40 text-left h-80"
                    >
                      <div className="aspect-[3/4.2] relative bg-black overflow-hidden">
                        <img 
                          referrerPolicy="no-referrer"
                          src={item.posterUrl} 
                          alt="" 
                          className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500" 
                        />
                        <div className="absolute top-2.5 left-2.5 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[8px] font-mono font-bold text-gray-300">
                          {item.type}
                        </div>
                      </div>
                      <div className="p-3 flex-1 flex flex-col justify-between pl-4">
                        <div>
                          <div className="flex items-center justify-between text-[8px] font-mono font-black text-gray-500">
                            <span>{item.type}</span>
                            <span>{item.year}</span>
                          </div>
                          <h4 className="font-sans font-bold text-xs sm:text-sm text-neutral-200 mt-1 line-clamp-1 group-hover:text-white">{item.title}</h4>
                        </div>
                        <div className="pt-2 flex items-center justify-between">
                          <span className="text-[8px] font-mono text-neutral-500">{item.statusBadge || 'Published'}</span>
                          <span className="text-[9px] font-mono font-black text-[#E50914] tracking-wider uppercase group-hover:underline">EXPLORE &rarr;</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* STANDARD CATEGORY GRIDS */
        <>
          {filteredItems.length === 0 ? (
            <div className="py-24 text-center space-y-4" id="filters-empty-view">
              <Frown size={40} className="text-gray-600 animate-bounce mx-auto" />
              <div className="space-y-1">
                <span className="block text-xs font-black font-mono text-gray-400 uppercase tracking-widest">No Content Found</span>
                <p className="text-[11px] text-gray-500 font-sans max-w-sm mx-auto">There are no approved titles matching this specific query in our localized indexes.</p>
              </div>
              <button 
                onClick={() => {
                  setSelectedGenre(null);
                  setSelectedLanguage(null);
                  setSelectedCountry(null);
                  setSelectedCategory(null);
                }}
                className="px-4 py-1.5 bg-[#E50914] text-white text-xxs font-bold uppercase rounded-lg hover:bg-[#FF1A1A] transition-all cursor-pointer font-mono"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6" id="filters-content-grid">
              {filteredItems.map((catalogItem, index) => {
                const item = catalogItem.media;
                const views = getViewsCount(catalogItem.id, item.voteCount || 100, filter === 'monthly');
                const interests = getInterestCount(catalogItem.id, item.voteCount || 100, filter === 'monthly');
                const score = Math.round(calculateFinalScore(catalogItem, filter === 'monthly'));

                return (
                  <div 
                    key={catalogItem.id}
                    onClick={() => {
                      if (filter === 'following' && !currentUser) {
                        handleInteractionAuthCheck('Following Activity content details');
                      } else {
                        handleItemClick(catalogItem.id);
                      }
                    }}
                    className="group bg-[#0a0a0a] rounded-2xl border border-white/5 overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:border-[#E50914]/40 text-left h-80 relative"
                  >
                    {/* Rankings Indicator Badge overlay */}
                    {(filter === 'monthly' || filter === 'top100') && (
                      <div className="absolute top-2.5 right-2.5 z-10 bg-black/90 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 text-center shadow-lg font-mono">
                        <span className="text-[10px] font-black text-[#E50914] block">#{index + 1}</span>
                        <span className="text-[7px] text-gray-400 font-bold tracking-wider block">SCORE {score}</span>
                      </div>
                    )}

                    <div className="aspect-[3/4.2] relative bg-black overflow-hidden">
                      <img 
                        referrerPolicy="no-referrer"
                        src={item.posterUrl} 
                        alt="" 
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500" 
                      />
                      <div className="absolute top-2.5 left-2.5 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[8px] font-mono font-bold text-gray-300">
                        {item.type}
                      </div>
                    </div>
                    <div className="p-3 flex-1 flex flex-col justify-between pl-4">
                      <div>
                        <div className="flex items-center justify-between text-[8px] font-mono font-black text-gray-500">
                          <span>{item.type}</span>
                          <span>{item.year}</span>
                        </div>
                        <h4 className="font-sans font-bold text-xs sm:text-sm text-neutral-200 mt-1 line-clamp-1 group-hover:text-white uppercase truncate">{item.title}</h4>
                      </div>
                      <div className="pt-2 flex items-center justify-between">
                        {filter === 'monthly' || filter === 'top100' ? (
                          <div className="flex items-center gap-1.5 text-[8px] font-mono text-gray-500">
                            <Flame size={8} className="text-orange-400" />
                            <span>{interests} • {views} views</span>
                          </div>
                        ) : (
                          <span className="text-[8px] font-mono text-neutral-500">{item.statusBadge || 'Published'}</span>
                        )}
                        <span className="text-[9px] font-mono font-black text-[#E50914] tracking-wider uppercase group-hover:underline">EXPLORE &rarr;</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
