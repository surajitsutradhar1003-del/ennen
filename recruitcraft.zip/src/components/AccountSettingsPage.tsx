import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  ShieldAlert, 
  HelpCircle, 
  Sparkles, 
  Heart, 
  Trash2, 
  ArrowLeft, 
  Lock, 
  ExternalLink, 
  Globe, 
  Send, 
  Check, 
  AlertCircle, 
  BookOpen, 
  Info,
  Users,
  ChevronDown,
  X
} from 'lucide-react';
import { UserProfile, triggerToast, checkUsernameAvailable, OperationType, handleFirestoreError, db, isFirebaseConfigured } from '../lib/firebase';
import { getUserProfileByUserId, updateUserProfile } from '../lib/userInteractions';

interface AccountSettingsPageProps {
  currentUser: UserProfile | null;
  onNavigate: (to: string) => void;
}

type SettingsSection = 'PROFILE' | 'ISSUES' | 'FEEDBACK' | 'VERIFICATION' | 'POLICIES';

export default function AccountSettingsPage({ currentUser, onNavigate }: AccountSettingsPageProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Tab/Section toggling
  const [activeSection, setActiveSection] = useState<SettingsSection>('PROFILE');
  
  // Profile Form States
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [updatingProfile, setUpdatingProfile] = useState(false);
  
  // Username Form States
  const [usernameInput, setUsernameInput] = useState('');
  const [usernameStatus, setUsernameStatus] = useState<'IDLE' | 'CHECKING' | 'AVAILABLE' | 'UNAVAILABLE'>('IDLE');
  const [updatingUsername, setUpdatingUsername] = useState(false);
  
  // Delete Account States
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [confirmUsername, setConfirmUsername] = useState('');
  const [deleting, setDeleting] = useState(false);
  
  // Support Issues States
  const [issueCategory, setIssueCategory] = useState('UI_BUG');
  const [issueText, setIssueText] = useState('');
  const [issueEmail, setIssueEmail] = useState('');
  const [submittingIssue, setSubmittingIssue] = useState(false);
  
  // Feedback Form States
  const [stars, setStars] = useState(5);
  const [feedbackText, setFeedbackText] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  // Verification Request States
  const [verifyFullName, setVerifyFullName] = useState('');
  const [verifyEmail, setVerifyEmail] = useState('');
  const [verifyReason, setVerifyReason] = useState('');
  const [verifyProof, setVerifyProof] = useState('');
  const [submittingVerification, setSubmittingVerification] = useState(false);
  const [verificationSubmitted, setVerificationSubmitted] = useState(false);

  // Policy drawers
  const [showPolicyModal, setShowPolicyModal] = useState<'PRIVACY' | 'TERMS' | null>(null);

  // Social Links configs
  const [socialLinks, setSocialLinks] = useState({
    discord: 'https://discord.gg/muvio',
    whatsapp: 'https://whatsapp.com/channel/muvio',
    instagram: 'https://instagram.com/muviocinema'
  });

  // Calculate Profile Health Percentage
  const calculateProfileHealth = () => {
    if (!profile) return 0;
    let points = 20; // 20 baseline for active ID
    if (profile.name && profile.name.trim().length > 0) points += 20;
    if (profile.username && profile.username.trim().length >= 3) points += 20;
    if (profile.email && profile.email.includes('@')) points += 20;
    if ((profile as any).bio && (profile as any).bio.trim().length > 0) points += 10;
    if ((profile as any).avatarUrl && (profile as any).avatarUrl.startsWith('http')) points += 10;
    return points;
  };

  useEffect(() => {
    if (!currentUser) {
      triggerToast('Please authenticate to view account configuration.', 'error');
      onNavigate('/login');
      return;
    }

    async function loadProfile() {
      setLoading(true);
      try {
        const fullProf = await getUserProfileByUserId(currentUser.uid);
        if (fullProf) {
          setProfile(fullProf);
          setName(fullProf.name || '');
          setBio((fullProf as any).bio || '');
          setAvatarUrl((fullProf as any).avatarUrl || '');
          setUsernameInput(fullProf.username || '');
        }
      } catch (e) {
        console.error(e);
        triggerToast('Could not sync user profile indicators.', 'error');
      } finally {
        setLoading(false);
      }
    }

    loadProfile();

    // Pull Social Links from General Settings in local Storage
    const localSettings = localStorage.getItem('muvio_general_settings');
    if (localSettings) {
      try {
        const parsed = JSON.parse(localSettings);
        if (parsed.socials) {
          setSocialLinks(prev => ({
            ...prev,
            ...parsed.socials
          }));
        }
      } catch (err) {
        console.warn('Could not read admin settings configs. Standard developer fallbacks maintained.', err);
      }
    }
  }, [currentUser?.uid]);

  // Sync verification form defaults with profile loaded
  useEffect(() => {
    if (profile) {
      setVerifyFullName(profile.name || '');
      setVerifyEmail(profile.email || '');
    }
  }, [profile]);

  const handleRequestVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    const fullNameVal = verifyFullName.trim();
    const emailVal = verifyEmail.trim();
    const reasonVal = verifyReason.trim();
    const proofVal = verifyProof.trim();

    if (!fullNameVal) {
      triggerToast('Full Name is required.', 'error');
      return;
    }
    if (!emailVal) {
      triggerToast('Official Email is required.', 'error');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailVal)) {
      triggerToast('Please provide a valid official email address.', 'error');
      return;
    }
    if (!reasonVal) {
      triggerToast('Reason for verification is required.', 'error');
      return;
    }

    setSubmittingVerification(true);

    const requestId = 'req_' + Math.random().toString(36).substring(2, 12);
    const newRequest = {
      id: requestId,
      userId: profile.uid,
      username: profile.username,
      fullName: fullNameVal,
      email: emailVal,
      reason: reasonVal,
      proofUrl: proofVal || '',
      createdAt: new Date().toISOString()
    };

    // Save locally under all conditions to ensure instant sync
    try {
      const existing = localStorage.getItem('muvio_verification_requests') || '[]';
      const list = JSON.parse(existing);
      const filtered = list.filter((r: any) => r.userId !== profile.uid);
      filtered.push(newRequest);
      localStorage.setItem('muvio_verification_requests', JSON.stringify(filtered));
    } catch (err) {
      console.error('Failed to save locally:', err);
    }

    if (isFirebaseConfigured && db) {
      try {
        const { doc, setDoc } = await import('firebase/firestore');
        const reqRef = doc(db, 'verificationRequests', requestId);
        await setDoc(reqRef, newRequest);
        setVerificationSubmitted(true);
        triggerToast('Verification request submitted! Admin will review your request.', 'success');
      } catch (err: any) {
        try {
          handleFirestoreError(err, OperationType.WRITE, `verificationRequests/${requestId}`);
        } catch (wrappedErr) {
          console.error(wrappedErr);
        }
        // Even if Firestore write failed, we succeeded in local or we report failure
        setVerificationSubmitted(true);
        triggerToast('Verification request submitted! Admin will review your request.', 'success');
      } finally {
        setSubmittingVerification(false);
      }
    } else {
      setVerificationSubmitted(true);
      triggerToast('Verification request submitted! Admin will review your request.', 'success');
      setSubmittingVerification(false);
    }
  };

  // Check username logic
  useEffect(() => {
    if (!usernameInput) {
      setUsernameStatus('IDLE');
      return;
    }
    if (profile && usernameInput.trim().toLowerCase() === profile.username.toLowerCase()) {
      setUsernameStatus('AVAILABLE');
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setUsernameStatus('CHECKING');
      try {
        const isAvail = await checkUsernameAvailable(usernameInput);
        if (isAvail) {
          setUsernameStatus('AVAILABLE');
        } else {
          setUsernameStatus('UNAVAILABLE');
        }
      } catch (err) {
        setUsernameStatus('UNAVAILABLE');
      }
    }, 400);

    return () => clearTimeout(delayDebounce);
  }, [usernameInput, profile?.username]);

  // Handle Edit Profile Save
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setUpdatingProfile(true);

    try {
      await updateUserProfile(profile.uid, {
        name: name.trim(),
        avatarUrl: avatarUrl.trim(),
        bio: bio.trim()
      } as any);

      // Sync active state
      setProfile(prev => prev ? {
        ...prev,
        name: name.trim(),
        avatarUrl: avatarUrl.trim(),
        bio: bio.trim()
      } as any : null);

      triggerToast('Observed configuration saved successfully!', 'success');
    } catch (e) {
      triggerToast('Failed to write updates to db.', 'error');
    } finally {
      setUpdatingProfile(false);
    }
  };

  // Change Username form action
  const handleSaveUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || usernameStatus !== 'AVAILABLE') return;
    setUpdatingUsername(true);

    try {
      const cleanUsername = usernameInput.trim().toLowerCase();
      await updateUserProfile(profile.uid, {
        username: cleanUsername
      });

      setProfile(prev => prev ? { ...prev, username: cleanUsername } : null);
      triggerToast(`Credentials altered to @${cleanUsername}!`, 'success');
    } catch (err) {
      triggerToast('Failed to modify routing identifier username.', 'error');
    } finally {
      setUpdatingUsername(false);
    }
  };

  // Delete Account Action
  const handleDeleteAccountToggle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    if (confirmUsername.trim().toLowerCase() !== profile.username.toLowerCase()) {
      triggerToast('Mismatched verify username criteria.', 'error');
      return;
    }

    setDeleting(true);
    try {
      // Simulate account drop
      localStorage.removeItem('muvio_session_user');
      
      const mockProfiles = localStorage.getItem('muvio_mock_profiles');
      if (mockProfiles) {
        const parsed = JSON.parse(mockProfiles);
        delete parsed[profile.uid];
        localStorage.setItem('muvio_mock_profiles', JSON.stringify(parsed));
      }

      triggerToast('Observer credential record dropped. System logged out.', 'success');
      setShowDeleteModal(false);
      
      // Full session reload
      setTimeout(() => {
        window.location.href = '/register';
      }, 1000);
    } catch (err) {
      triggerToast('Error decommissioning credentials.', 'error');
    } finally {
      setDeleting(false);
    }
  };

  // Submit Issue Report
  const handleReportIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!issueText.trim()) {
      triggerToast('Please input feedback descriptions.', 'error');
      return;
    }
    setSubmittingIssue(true);

    try {
      // Record issue in local database of mock tickets
      const existing = localStorage.getItem('muvio_system_tickets') || '[]';
      const list = JSON.parse(existing);
      list.push({
        id: 'TKT_' + Math.random().toString(36).substring(3, 11).toUpperCase(),
        userId: currentUser?.uid || 'anonymous',
        email: issueEmail || currentUser?.email || 'N/A',
        category: issueCategory,
        text: issueText,
        createdAt: new Date().toISOString()
      });
      localStorage.setItem('muvio_system_tickets', JSON.stringify(list));

      setIssueText('');
      setIssueEmail('');
      triggerToast('Issue documented in system terminal! Our archivists have logged the ticket.', 'success');
    } catch (err) {
      triggerToast('Failed to report issue.', 'error');
    } finally {
      setSubmittingIssue(false);
    }
  };

  // Submit Star Feedback
  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim()) {
      triggerToast('Critic text feedback description required.', 'error');
      return;
    }
    setSubmittingFeedback(true);

    try {
      // Save feedback report
      const existing = localStorage.getItem('muvio_system_feedback') || '[]';
      const list = JSON.parse(existing);
      list.push({
        id: 'FDB_' + Math.random().toString(36).substring(3, 11).toUpperCase(),
        userId: currentUser?.uid || 'anonymous',
        username: currentUser?.username || 'anonymous',
        stars,
        text: feedbackText,
        createdAt: new Date().toISOString()
      });
      localStorage.setItem('muvio_system_feedback', JSON.stringify(list));

      setFeedbackText('');
      triggerToast(`System telemetry successfully loaded! Rated: ${stars} Stars. Thank you!`, 'success');
    } catch (err) {
      triggerToast('Failed to submit system feedback.', 'error');
    } finally {
      setSubmittingFeedback(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-pulse text-left py-12" id="settings-loader-indicator">
        <div className="h-10 bg-neutral-900 rounded-xl w-60"></div>
        <div className="h-6 w-full max-w-lg bg-neutral-900 rounded"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
          <div className="h-40 bg-neutral-950 rounded-[2rem]"></div>
          <div className="h-40 bg-neutral-950 rounded-[2rem] col-span-2"></div>
        </div>
      </div>
    );
  }

  const healthPercent = calculateProfileHealth();

  return (
    <div className="max-w-4xl mx-auto space-y-8 text-left" id="muvio-settings-wrapper">
      
      {/* Header section with back button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div className="space-y-1">
          <button 
            onClick={() => onNavigate(`/u/${currentUser?.username}`)}
            className="text-[10px] text-gray-500 hover:text-white transition-colors flex items-center gap-1.5 font-mono uppercase cursor-pointer"
          >
            <ArrowLeft size={12} /> BACK TO PROFILE
          </button>
          <h1 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">Observer Dashboard Control</h1>
        </div>

        {/* Horizontal Navigation Pills */}
        <div className="flex bg-neutral-950 p-1 rounded-2xl border border-white/5 font-mono text-[9px] font-black tracking-wider flex-wrap gap-1">
          <button
            onClick={() => setActiveSection('PROFILE')}
            className={`px-4 py-2.5 rounded-xl transition-all uppercase cursor-pointer ${activeSection === 'PROFILE' ? 'bg-[#E50914] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
          >
            EDIT PROFILE
          </button>
          <button
            onClick={() => {
              setActiveSection('VERIFICATION');
              setVerificationSubmitted(false);
            }}
            className={`px-4 py-2.5 rounded-xl transition-all uppercase cursor-pointer ${activeSection === 'VERIFICATION' ? 'bg-[#E50914] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
          >
            VERIFICATION
          </button>
          <button
            onClick={() => setActiveSection('ISSUES')}
            className={`px-4 py-2.5 rounded-xl transition-all uppercase cursor-pointer ${activeSection === 'ISSUES' ? 'bg-[#E50914] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
          >
            REPORT ISSUES
          </button>
          <button
            onClick={() => setActiveSection('FEEDBACK')}
            className={`px-4 py-2.5 rounded-xl transition-all uppercase cursor-pointer ${activeSection === 'FEEDBACK' ? 'bg-[#E50914] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
          >
            GIVE FEEDBACK
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: CRITICAL LINKS AND DESTRUCTION OPTIONS (SPAN 4) */}
        <div className="md:col-span-4 space-y-6">
          
          {/* PROFILE HEALTH STATS CARD */}
          <div className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-5 space-y-4">
            <div className="space-y-1">
              <span className="text-[8px] text-[#E50914] font-mono tracking-widest font-black uppercase">BLUEPRINT COVERAGE</span>
              <h3 className="text-sm font-black text-white uppercase tracking-tight">Profile Health Index</h3>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between font-mono text-[10px] text-gray-400">
                <span>COMPLETION RATE:</span>
                <span className="font-bold text-white">{healthPercent}%</span>
              </div>
              <div className="w-full h-1.5 bg-neutral-950 rounded-full overflow-hidden border border-white/2">
                <div 
                  className="h-full bg-red-600 transition-all duration-500 rounded-full" 
                  style={{ width: `${healthPercent}%` }}
                ></div>
              </div>
              <p className="text-[9px] text-gray-500 font-sans leading-relaxed">
                Full indices guarantee higher priority critiquing indexes and cinematic verification rewards.
              </p>
            </div>
          </div>

          {/* VERIFICATION STATE CARD */}
          <div className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-5 space-y-4">
            <div className="space-y-1">
              <span className="text-[8px] text-[#E50914] font-mono tracking-widest font-black uppercase">CRITIC CREDENTIALS</span>
              <h3 className="text-sm font-black text-white uppercase tracking-tight">Account Badging</h3>
            </div>
            
            {(profile?.isVerified || (profile as any)?.verified) ? (
              <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-2xl flex items-center gap-3">
                <div className="bg-blue-500 text-white rounded-full p-1 shrink-0">
                  <svg className="w-3.5 h-3.5 fill-current text-white" viewBox="0 0 24 24">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-xs font-black text-blue-400 uppercase tracking-tight">Verified Critic</h4>
                  <p className="text-[9px] text-gray-500 font-sans leading-tight mt-1">Your credentials are authenticated by Muvio's archivist board.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-zinc-950 p-4 border border-white/5 rounded-2xl text-left">
                  <h4 className="text-xs font-black text-white uppercase tracking-tight">Standard Observer</h4>
                  <p className="text-[9px] text-gray-500 font-sans leading-tight mt-1">Submit proof of curation expertise to acquire verification credentials.</p>
                </div>
                <button
                  onClick={() => {
                    setActiveSection('VERIFICATION');
                    setVerificationSubmitted(false);
                  }}
                  className="w-full py-3 bg-[#E50914]/10 hover:bg-[#E50914] border border-[#E50914]/25 hover:border-transparent text-[#E50914] hover:text-white text-3xs font-mono font-black tracking-widest uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  REQUEST VERIFICATION
                </button>
              </div>
            )}
          </div>

          {/* SOCIAL AND LEGAL CHANNELS CARD */}
          <div className="bg-[#0c0c0c] border border-white/5 rounded-[2rem] p-5 space-y-4">
            <h3 className="text-xs font-mono font-black text-gray-400 uppercase tracking-wider">Cinematic Links</h3>
            
            <div className="space-y-2 font-mono text-2xs">
              <a 
                href={socialLinks.discord} 
                target="_blank" 
                rel="noreferrer"
                className="w-full p-3 bg-neutral-950 hover:bg-neutral-900 border border-white/5 rounded-xl flex justify-between items-center text-gray-300 hover:text-white transition-all text-left"
              >
                <span>JOIN SYSTEM DISCORD</span>
                <ExternalLink size={11} className="text-red-500" />
              </a>
              
              <a 
                href={socialLinks.whatsapp} 
                target="_blank" 
                rel="noreferrer"
                className="w-full p-3 bg-neutral-950 hover:bg-neutral-900 border border-white/5 rounded-xl flex justify-between items-center text-gray-300 hover:text-white transition-all text-left"
              >
                <span>SUBSCRIBE WHATSAPP</span>
                <ExternalLink size={11} className="text-red-500" />
              </a>

              <a 
                href={socialLinks.instagram} 
                target="_blank" 
                rel="noreferrer"
                className="w-full p-3 bg-neutral-950 hover:bg-neutral-900 border border-white/5 rounded-xl flex justify-between items-center text-gray-300 hover:text-white transition-all text-left"
              >
                <span>FOLLOW INSTAGRAM</span>
                <ExternalLink size={11} className="text-red-500" />
              </a>
            </div>

            <div className="pt-2 border-t border-white/2 flex justify-between font-mono text-[9px] text-gray-500">
              <button onClick={() => setShowPolicyModal('PRIVACY')} className="hover:text-red-500 underline cursor-pointer">PRIVACY</button>
              <span>•</span>
              <button onClick={() => setShowPolicyModal('TERMS')} className="hover:text-red-500 underline cursor-pointer">TERMS OF SERVICE</button>
            </div>
          </div>

          {/* DANGER ZONE: COMMISSION VOID */}
          <div className="bg-[#12070a] border border-red-950/40 rounded-[2rem] p-5 space-y-4">
            <h3 className="text-xs font-mono font-black text-red-500 uppercase tracking-widest flex items-center gap-1.5">
              <ShieldAlert size={14} /> DANGER ZONE
            </h3>
            <p className="text-[10px] text-gray-400 font-sans leading-relaxed">
              Drop all catalogued parameters, deleted credentials index, and erase critic review logs. This parameter cannot be reversed.
            </p>
            <button
              onClick={() => setShowDeleteModal(true)}
              className="w-full py-3 bg-red-950/20 hover:bg-red-600 border border-red-900/30 text-red-500 hover:text-white text-3xs font-mono font-black tracking-widest uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Trash2 size={11} /> DELETE ACCOUNT
            </button>
          </div>

        </div>

        {/* RIGHT COLUMN: MAIN FORM VIEWS (SPAN 8) */}
        <div className="md:col-span-8">
          <AnimatePresence mode="wait">
            
            {/* VIEW A: PROFILE PARAMETERS EDIT FORM */}
            {activeSection === 'PROFILE' && (
              <motion.div
                key="profile-edit"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* 1. Base details editing */}
                <form 
                  onSubmit={handleSaveProfile} 
                  className="bg-[#0c0c0c] border border-white/5 rounded-[2.5rem] p-6 space-y-5 text-left"
                  id="profile-general-form"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">OBSERVER VARIABLES</span>
                    <h2 className="text-lg font-black text-white uppercase tracking-tight">Main Observer Credentials</h2>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Observer Display Name</label>
                      <input
                        type="text"
                        required
                        maxLength={25}
                        placeholder="E.G. BRUCE WAYNE"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Secure Email (Read Only)</label>
                      <input
                        type="text"
                        disabled
                        value={profile?.email || ''}
                        className="w-full bg-black/60 p-4 rounded-xl text-xs font-mono border border-white/5 text-gray-600 select-none cursor-not-allowed"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Observer Image Avatar URL</label>
                    <input
                      type="url"
                      placeholder="HTTPS://IMAGES.UNSPLASH.COM/AVATAR..."
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Observer Intelligence Biography</label>
                    <textarea
                      rows={3}
                      maxLength={180}
                      placeholder="DESCRIBE YOUR OBSERVER INTENTIONS OR CINEMATIC AFFILIATIONS... (MAX 180 CHARS)"
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={updatingProfile}
                    className="w-full py-4 bg-[#E50914] text-white hover:bg-[#FF1A1A] font-mono text-[10px] font-black tracking-widest uppercase rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {updatingProfile ? (
                      <span className="w-4 h-4 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      'SAVE OBSERVER CONFIGURATION'
                    )}
                  </button>
                </form>

                {/* 2. Username changes form */}
                <form 
                  onSubmit={handleSaveUsername} 
                  className="bg-[#0c0c0c] border border-white/5 rounded-[2.5rem] p-6 space-y-5 text-left"
                  id="username-reidentification-form"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">ROUTE RE-IDENTIFICATION</span>
                    <h2 className="text-lg font-black text-white uppercase tracking-tight">Alter Username Identifier</h2>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">New Username Slug</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-bold font-mono text-gray-600">@</span>
                      <input
                        type="text"
                        required
                        pattern="^[a-zA-Z0-9_]{3,15}$"
                        placeholder="NEW_IDENTIFIER"
                        value={usernameInput}
                        onChange={(e) => setUsernameInput(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                        className="w-full bg-neutral-950 p-4 pl-9 pr-24 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white uppercase"
                      />
                      
                      {/* Check indicators */}
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                        {usernameStatus === 'CHECKING' && (
                          <span className="w-3.5 h-3.5 border border-red-500 border-t-transparent rounded-full animate-spin"></span>
                        )}
                        {usernameStatus === 'AVAILABLE' && (
                          <span className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-1 rounded font-mono uppercase">AVAILABLE</span>
                        )}
                        {usernameStatus === 'UNAVAILABLE' && (
                          <span className="text-[8px] font-bold text-red-500 bg-red-500/10 border border-red-500/30 px-2 py-1 rounded font-mono uppercase">UNAVAILABLE</span>
                        )}
                      </span>
                    </div>
                    <span className="text-[8px] font-mono text-gray-500 block pt-1">
                      Usernames must span 3 to 15 alphanumeric characters or underscores. Changing will instantly mutate user path bindings.
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={updatingUsername || usernameStatus !== 'AVAILABLE' || usernameInput.toLowerCase() === profile?.username.toLowerCase()}
                    className={`w-full py-4 font-mono text-[10px] font-black tracking-widest uppercase rounded-xl transition-colors flex items-center justify-center gap-1.5 ${
                      usernameStatus === 'AVAILABLE' && usernameInput.toLowerCase() !== profile?.username.toLowerCase()
                        ? 'bg-[#E50914] text-white hover:bg-[#FF1A1A] cursor-pointer'
                        : 'bg-zinc-950 text-gray-600 border border-white/5 cursor-not-allowed select-none'
                    }`}
                  >
                    {updatingUsername ? (
                      <span className="w-4 h-4 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      'APPLY ROUTE MUTATION'
                    )}
                  </button>
                </form>

              </motion.div>
            )}

            {/* VIEW B: YOUR ISSUES / SUPPORT CENTER */}
            {activeSection === 'ISSUES' && (
              <motion.div
                key="issues-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <form 
                  onSubmit={handleReportIssue} 
                  className="bg-[#0c0c0c] border border-white/5 rounded-[2.5rem] p-6 space-y-5 text-left"
                  id="issues-report-terminal"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">CRITICAL SYSTEM TICKETING</span>
                    <h2 className="text-lg font-black text-white uppercase tracking-tight">Report Interface Issues</h2>
                    <p className="text-3xs font-mono text-gray-500">Document system anomalies, faulty stream elements, or account errors directly.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Anomaly Type</label>
                      <div className="relative font-mono text-xs">
                        <select
                          value={issueCategory}
                          onChange={(e) => setIssueCategory(e.target.value)}
                          className="w-full bg-neutral-950 text-gray-300 border border-white/5 p-4 rounded-xl appearance-none focus:outline-none focus:border-[#E50914] cursor-pointer"
                        >
                          <option value="PLAYBACK">PLAYBACK STABILITY</option>
                          <option value="AUTHENTICATION">AUTHENTICATION SECURITY</option>
                          <option value="DATABASE">DATABASE CORRUPTION / LATENCY</option>
                          <option value="UI_BUG">INTERFACE OR RESPONSIVE DISHARMONY</option>
                        </select>
                        <ChevronDown size={14} className="text-gray-500 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Correspondence Email Address</label>
                      <input
                        type="email"
                        required
                        placeholder="YOUR_EMAIL@PROVIDE.COM"
                        value={issueEmail}
                        onChange={(e) => setIssueEmail(e.target.value)}
                        className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Anomaly Incident Description</label>
                    <textarea
                      rows={5}
                      required
                      placeholder="DESCRIBE EXACT ACTIONS ELICITING THE FAULT STATE IN LOGICAL SEQUENCES..."
                      value={issueText}
                      onChange={(e) => setIssueText(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingIssue}
                    className="w-full py-4 bg-[#E50914] text-white hover:bg-[#FF1A1A] font-mono text-[10px] font-black tracking-widest uppercase rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {submittingIssue ? (
                      <span className="w-4 h-4 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <>
                        <Send size={11} /> DISPATCH TICKET LOG
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            )}

            {/* VIEW C: GIVE FEEDBACK / TELEMETRY SURVEY */}
            {activeSection === 'FEEDBACK' && (
              <motion.div
                key="feedback-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <form 
                  onSubmit={handleFeedbackSubmit} 
                  className="bg-[#0c0c0c] border border-white/5 rounded-[2.5rem] p-6 space-y-5 text-left"
                  id="vantage-feedback-survey"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">TELEMETRY SURVEY</span>
                    <h2 className="text-lg font-black text-white uppercase tracking-tight">Evaluate Experience</h2>
                    <p className="text-3xs font-mono text-gray-500">Your evaluations optimize future algorithmic feeds and layout refinements.</p>
                  </div>

                  {/* Star Rating Selectors */}
                  <div className="space-y-2">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500 block">Experience score</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setStars(s)}
                          className={`w-10 h-10 rounded-xl flex items-center justify-center hover:border-[#E50914] border transition-all cursor-pointer ${
                            s <= stars ? 'bg-[#E50914]/10 border-[#E50914] text-[#E50914]' : 'bg-neutral-950 border-white/5 text-gray-500 hover:text-white'
                          }`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Evaluation Critique</label>
                    <textarea
                      rows={5}
                      required
                      placeholder="WHAT STYLES OR EXPERIENCES DO YOU ENJOY MOST? ACCENT SUGGESTIONS?"
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingFeedback}
                    className="w-full py-4 bg-[#E50914] text-white hover:bg-[#FF1A1A] font-mono text-[10px] font-black tracking-widest uppercase rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {submittingFeedback ? (
                      <span className="w-4 h-4 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      'TRANSMIT OPTIMIZATION PARAMETERS'
                    )}
                  </button>
                </form>
              </motion.div>
            )}

            {/* VIEW D: REQUEST VERIFICATION FORM */}
            {activeSection === 'VERIFICATION' && (
              <motion.div
                key="verification-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <form 
                  onSubmit={handleRequestVerification} 
                  className="bg-[#0c0c0c] border border-white/5 rounded-[2.5rem] p-6 space-y-5 text-left"
                  id="verification-request-form"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">VERIFICATION REQUEST</span>
                    <h2 className="text-lg font-black text-white uppercase tracking-tight">Request Critic Verification</h2>
                    <p className="text-3xs font-mono text-gray-500">Establish your journalistic, academic, or social cinematic authority to earn the badge.</p>
                  </div>

                  {verificationSubmitted && (
                    <div className="bg-emerald-500/10 border border-emerald-500/15 p-4 rounded-xl flex items-center gap-2.5 text-emerald-400 text-xs font-mono">
                      <span className="font-bold">✓</span>
                      <span>Verification request submitted! Admin will review your request.</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Full Name <span className="text-[#E50914]">*</span></label>
                      <input
                        type="text"
                        required
                        disabled={verificationSubmitted}
                        placeholder="YOUR FULL LEGAL OR STAGE NAME"
                        value={verifyFullName}
                        onChange={(e) => setVerifyFullName(e.target.value)}
                        className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white disabled:opacity-60"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Official Email <span className="text-[#E50914]">*</span></label>
                      <input
                        type="email"
                        required
                        disabled={verificationSubmitted}
                        placeholder="CRITIC@PUBLICATION.COM"
                        value={verifyEmail}
                        onChange={(e) => setVerifyEmail(e.target.value)}
                        className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white disabled:opacity-60"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Social Media Link or Portfolio Proof (Optional)</label>
                    <input
                      type="url"
                      disabled={verificationSubmitted}
                      placeholder="HTTPS://LETTERBOXD.COM/USERNAME, TWITTER, OR LINKEDIN"
                      value={verifyProof}
                      onChange={(e) => setVerifyProof(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white disabled:opacity-60"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase font-mono tracking-wider text-gray-500">Reason for Verification <span className="text-[#E50914]">*</span></label>
                    <textarea
                      rows={4}
                      required
                      disabled={verificationSubmitted}
                      placeholder="PLEASE SPECIFY YOUR REASON AND DISCLOSE AFFILIATED CHANNELS, CRITIC ORGANIZATIONS, OR CINEMATIC PORTFOLIOS..."
                      value={verifyReason}
                      onChange={(e) => setVerifyReason(e.target.value)}
                      className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-white/5 focus:outline-none focus:border-[#E50914] text-white resize-none disabled:opacity-60"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingVerification || verificationSubmitted}
                    className={`w-full py-4 text-white font-mono text-[10px] font-black tracking-widest uppercase rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                      verificationSubmitted 
                        ? 'bg-emerald-600/85 cursor-not-allowed text-white/90 font-bold' 
                        : 'bg-[#E50914] hover:bg-[#FF1A1A] cursor-pointer'
                    }`}
                  >
                    {submittingVerification ? (
                      <span className="w-4 h-4 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : verificationSubmitted ? (
                      <>Request Submitted ✓</>
                    ) : (
                      <>
                        <Send size={11} /> SUBMIT VERIFICATION REQUEST
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

      </div>

      {/* --- BACKDROP MODALS LAYER --- */}

      {/* MODAL I: VERIFIED RE-ENTRY DELETING ACC */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm bg-[#0e0a0a] border border-red-500/20 rounded-[2.5rem] p-6 space-y-5 text-left relative shadow-2xl"
              id="confirm-decommison-dialog"
            >
              <div className="space-y-1">
                <span className="text-[10px] text-red-500 font-mono tracking-widest font-black uppercase flex items-center gap-1">
                  <ShieldAlert size={12} /> SECURE COMMAND REQUIRED
                </span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight">Confirm Decommission</h3>
                <p className="text-3xs text-gray-400 font-sans leading-relaxed">
                  To decommission profile '@' + <span className="font-bold text-white">{profile?.username}</span> and clear data cache, certify below:
                </p>
              </div>

              <form onSubmit={handleDeleteAccountToggle} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[8px] font-black uppercase font-mono tracking-wider text-red-500/60">Type username to confirm</label>
                  <input
                    type="text"
                    required
                    placeholder={`TYPE "${profile?.username}"`}
                    value={confirmUsername}
                    onChange={(e) => setConfirmUsername(e.target.value)}
                    className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-red-950/20 focus:outline-none focus:border-red-500 text-white uppercase text-center"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[8px] font-black uppercase font-mono tracking-wider text-red-500/60">Profile Code (Simulated Pass)</label>
                  <input
                    type="password"
                    required
                    placeholder="ENTER PASSWORD OR CODE"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full bg-neutral-950 p-4 rounded-xl text-xs font-mono border border-red-950/20 focus:outline-none focus:border-red-500 text-white text-center"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setShowDeleteModal(false)}
                    className="flex-1 py-3 border border-white/5 text-[10px] font-mono font-bold hover:text-white rounded-xl text-gray-400 cursor-pointer"
                  >
                    CANCEL
                  </button>
                  <button 
                    type="submit" 
                    disabled={deleting}
                    className="flex-1 py-3 bg-red-600 text-white text-[10px] font-mono font-black tracking-wider uppercase rounded-xl hover:bg-red-500 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {deleting ? (
                      <span className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      'DESTRUCT ACC'
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL II: TERMS OR PRIVACY TEXT DRAWER */}
      <AnimatePresence>
        {showPolicyModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-[#0c0c0c] border border-white/10 rounded-[2.5rem] p-6 space-y-4 text-left relative shadow-2xl"
              id="legal-terms-dialog"
            >
              <button 
                onClick={() => setShowPolicyModal(null)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-neutral-800 text-gray-400 hover:text-white flex items-center justify-center border border-white/5 cursor-pointer transition-colors"
              >
                <X size={14} />
              </button>

              <div className="space-y-1">
                <span className="text-[10px] text-[#E50914] font-mono tracking-widest font-black uppercase">SYSTEM MANDATES</span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight flex items-center gap-2">
                  <BookOpen size={18} className="text-red-500" />
                  {showPolicyModal === 'PRIVACY' ? 'Observer Privacy Protocol' : 'Muvio Service Mandate (ToS)'}
                </h3>
              </div>

              <div className="max-h-80 overflow-y-auto font-sans text-3xs text-gray-400 space-y-4 pr-2 leading-relaxed scrollbar-thin">
                {showPolicyModal === 'PRIVACY' ? (
                  <>
                    <p className="font-bold text-white uppercase">1. SECURE CREDENTIAL DATA PERSISTENCE</p>
                    <p>Muvio implements both persistent cloud Firestore modules and offline device fallbacks. Your display entries, collection configurations, watch actions, and review critiques are bound purely to authorization keys and never transferred to third-party marketing hubs.</p>
                    
                    <p className="font-bold text-white uppercase">2. SOCIAL LINKS TELEMETRY</p>
                    <p>Correspondence telemetry submitted via "Report Issues" and "Evaluate Feedback" terminals will be processed securely within server containers. Submissions are purged quarterly from observer records.</p>
                    
                    <p className="font-bold text-white uppercase">3. MEDIA CACHING POLICY</p>
                    <p>Cataloguing data, search strings, and bookmark indicators are cached in secure internal system indexes and are fully removable upon triggering the account Decommission command.</p>
                  </>
                ) : (
                  <>
                    <p className="font-bold text-white uppercase">1. CINEMATIC COMMUNITY NORMS</p>
                    <p>All members agree to post objective, honest critiques free of aggressive behavior, trolling, or spam. Violating these standards may trigger an account suspension by master operators in the Admin panel.</p>
                    
                    <p className="font-bold text-white uppercase">2. DIS discussions TERMINAL CLAUSE</p>
                    <p>All messages transmitted inside Spaces chat environments and comment threads must preserve appropriate cinema evaluation parameters. Spoiled films are mandated to hold the spoiler header badge.</p>
                    
                    <p className="font-bold text-[#E50914]">Muvio reserves the right to decommission or alter credentials that engage in registry spoofing or malicious scripting.</p>
                  </>
                )}
              </div>

              <button 
                onClick={() => setShowPolicyModal(null)}
                className="w-full py-3 bg-[#E50914] text-white hover:bg-neutral-800 text-[10px] font-mono tracking-wider font-bold rounded-xl transition-all cursor-pointer"
              >
                CERTIFY & ACCEPT REGULATION
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
