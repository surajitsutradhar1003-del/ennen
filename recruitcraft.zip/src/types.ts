export type AppRoute = '/' | '/explore' | '/schedule' | '/spaces' | '/collections' | '/profile' | '/login' | '/register' | '/admin' | string;

export interface NavItem {
  id: string;
  name: string;
  label: string;
  href: AppRoute;
  iconName: string;
}

export interface DrawerLink {
  label: string;
  href: string; // Internal state or external
  isAction?: boolean;
  isDanger?: boolean;
}

export interface DrawerSection {
  title: string;
  links: DrawerLink[];
}

export interface SystemSettings {
  show_landing_page: boolean;
}

export interface UserWatched {
  id: string; // mediaId: e.g., "movie-123"
  title: string;
  type: string;
  posterUrl: string;
  watched: boolean;
  watchedAt: string;
}

export interface UserCollection {
  id: string; // collection slug/id
  name: string;
  createdAt: string;
  mediaIds: string[]; // list of media ids, e.g. ["movie-12345"]
}

export interface MuvioReview {
  id: string;
  mediaId: string;
  userId: string;
  username: string;
  userAvatar: string;
  rating: 'SKIP' | 'TIMEPASS' | 'GO FOR IT' | 'PERFECTION';
  text: string;
  spoiler: boolean;
  createdAt: string;
  updatedAt: string;
  likedBy: string[];
  sentiment?: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  sentimentScore?: number;
}

export interface MuvioComment {
  id: string;
  reviewId: string;
  userId: string;
  username: string;
  userAvatar: string;
  text: string;
  createdAt: string;
  parentId: string | null;
  replyToUsername: string | null;
  likedBy: string[];
}

export interface MuvioNotification {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  type: 'LIKE_REVIEW' | 'COMMENT_REVIEW' | 'REPLY_COMMENT' | 'NEW_FOLLOWER' | 'CONTENT_RELEASE' | 'RELEASE_REMINDER' | 'DISCUSSION_REPLY' | 'SPACES_REPLY' | 'TRENDING_CONTENT';
  targetId: string;
  mediaId: string;
  text: string;
  read: boolean;
  createdAt: string;
}
