import { db, isFirebaseConfigured } from './firebase';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  getDocs,
  deleteDoc,
  query,
  where
} from 'firebase/firestore';
import { UserWatched, UserCollection, MuvioReview, MuvioComment, MuvioNotification } from '../types';

/**
 * --- HELPER LOCAL KEY GENERATORS ---
 */
const getLocalWatchedKey = (userId: string) => `muvio_watched_${userId}`;
const getLocalCollectionsKey = (userId: string) => `muvio_collections_${userId}`;
const getLocalReviewsKey = () => `muvio_reviews`;
const getLocalCommentsKey = () => `muvio_comments`;

/**
 * --- WATCHED STATUS SERVICES ---
 */

export async function getWatchedStatus(userId: string, mediaId: string): Promise<UserWatched | null> {
  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'users', userId, 'watched', mediaId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as UserWatched;
      }
      return null;
    } catch (error) {
      console.warn('Firestore getWatchedStatus failed, checking local storage fallback:', error);
    }
  }

  // Fallback
  const key = getLocalWatchedKey(userId);
  const data = localStorage.getItem(key);
  if (data) {
    const list: Record<string, UserWatched> = JSON.parse(data);
    return list[mediaId] || null;
  }
  return null;
}

export async function toggleWatchedStatus(
  userId: string,
  mediaId: string,
  title: string,
  type: string,
  posterUrl: string
): Promise<boolean> {
  const current = await getWatchedStatus(userId, mediaId);
  const nextState = !current?.watched;

  const updatedItem: UserWatched = {
    id: mediaId,
    title,
    type,
    posterUrl,
    watched: nextState,
    watchedAt: nextState ? new Date().toISOString() : ''
  };

  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'users', userId, 'watched', mediaId);
      await setDoc(docRef, updatedItem, { merge: true });
      return nextState;
    } catch (error) {
      console.warn('Firestore toggleWatchedStatus failed, updating local storage fallback:', error);
    }
  }

  // Fallback
  const key = getLocalWatchedKey(userId);
  const raw = localStorage.getItem(key);
  const list: Record<string, UserWatched> = raw ? JSON.parse(raw) : {};
  
  if (nextState) {
    list[mediaId] = updatedItem;
  } else {
    delete list[mediaId];
  }
  
  localStorage.setItem(key, JSON.stringify(list));
  return nextState;
}

export async function getUserWatchedItems(userId: string): Promise<UserWatched[]> {
  const result: UserWatched[] = [];

  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'users', userId, 'watched');
      const snap = await getDocs(colRef);
      snap.forEach(docSnap => {
        const item = docSnap.data() as UserWatched;
        if (item.watched) {
          result.push(item);
        }
      });
      return result;
    } catch (error) {
      console.warn('Firestore getUserWatchedItems failed, checking local storage fallback:', error);
    }
  }

  // Fallback
  const key = getLocalWatchedKey(userId);
  const data = localStorage.getItem(key);
  if (data) {
    try {
      const record: Record<string, UserWatched> = JSON.parse(data);
      Object.values(record).forEach(item => {
        if (item.watched) {
          result.push(item);
        }
      });
    } catch (e) {
      console.warn('Failed parsing local watched data:', e);
    }
  }
  return result;
}

/**
 * --- CUSTOM COLLECTIONS SERVICES ---
 */

export async function getUserCollections(userId: string): Promise<UserCollection[]> {
  const mergedList: any[] = [];

  // 1. Get from database/standard user space
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'users', userId, 'collections');
      const snap = await getDocs(colRef);
      snap.forEach(docSnap => {
        mergedList.push(docSnap.data() as UserCollection);
      });
    } catch (error) {
      console.warn('Firestore getUserCollections failed, checking local storage:', error);
    }
  }

  // 2. If nothing from Firestore or not configured, load fallback local profile collections
  if (mergedList.length === 0) {
    const key = getLocalCollectionsKey(userId);
    const data = localStorage.getItem(key);
    if (data) {
      try {
        mergedList.push(...JSON.parse(data));
      } catch (e) {}
    }
    // No default seed collections — start empty
  }

  // 3. Load user-owned collections from primary 'muvio_collections_list'
  try {
    const globalColData = localStorage.getItem('muvio_collections_list');
    if (globalColData) {
      const globalCols = JSON.parse(globalColData) as any[];
      const userGlobalCols = globalCols.filter(col => col.ownerId === userId);
      userGlobalCols.forEach(col => {
        const existingIdx = mergedList.findIndex(item => item.id === col.id);
        if (existingIdx !== -1) {
          mergedList[existingIdx] = {
            ...mergedList[existingIdx],
            ...col
          };
        } else {
          mergedList.push(col);
        }
      });
    }
  } catch (err) {
    console.warn('Unable to load global collections from fallback list:', err);
  }

  return mergedList.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

export async function createCollection(userId: string, name: string): Promise<UserCollection> {
  const collectionId = 'col_' + Math.random().toString(36).substring(2, 10);
  const newCol: UserCollection = {
    id: collectionId,
    name: name.trim(),
    createdAt: new Date().toISOString(),
    mediaIds: []
  };

  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'users', userId, 'collections', collectionId);
      await setDoc(docRef, newCol);
    } catch (error) {
      console.warn('Firestore createCollection failed, writing to local storage fallback:', error);
    }
  }

  // Fallback
  const key = getLocalCollectionsKey(userId);
  const data = localStorage.getItem(key);
  let localList: UserCollection[] = data ? JSON.parse(data) : [];
  localList.push(newCol);
  localStorage.setItem(key, JSON.stringify(localList));

  // ALSO register it in global 'muvio_collections_list'
  try {
    let globalCols: any[] = [];
    const globalData = localStorage.getItem('muvio_collections_list');
    if (globalData) {
      globalCols = JSON.parse(globalData);
    }

    let ownerUsername = 'me';
    try {
      const profStr = localStorage.getItem('muvio_user_profile');
      if (profStr) {
        const prof = JSON.parse(profStr);
        if (prof && prof.username) {
          ownerUsername = prof.username;
        }
      }
    } catch (e) {}

    const randomImages = [
      "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
      "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=600",
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=600",
    ];
    const chosenCover = randomImages[Math.floor(Math.random() * randomImages.length)];

    const extraColItem = {
      id: collectionId,
      name: name.trim(),
      description: 'A curated user playlist.',
      createdAt: new Date().toISOString(),
      mediaIds: [],
      ownerId: userId,
      ownerUsername: ownerUsername,
      isPublic: false, // Default created from modal is Private
      likesCount: 0,
      likedBy: [],
      coverUrl: chosenCover
    };

    globalCols.push(extraColItem);
    localStorage.setItem('muvio_collections_list', JSON.stringify(globalCols));
  } catch (err) {
    console.error('Failed to register in muvio_collections_list:', err);
  }

  return newCol;
}

export async function updateCollectionItems(
  userId: string,
  collectionId: string,
  mediaIds: string[]
): Promise<boolean> {
  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'users', userId, 'collections', collectionId);
      await setDoc(docRef, { mediaIds }, { merge: true });
    } catch (error) {
      console.warn('Firestore updateCollectionItems failed:', error);
    }
  }

  // Fallback
  try {
    const key = getLocalCollectionsKey(userId);
    const data = localStorage.getItem(key);
    if (data) {
      const collections = JSON.parse(data) as any[];
      const col = collections.find(c => c.id === collectionId);
      if (col) {
        col.mediaIds = mediaIds;
        localStorage.setItem(key, JSON.stringify(collections));
      }
    }
  } catch (e) {}

  // Sync to 'muvio_collections_list'
  try {
    const globalColData = localStorage.getItem('muvio_collections_list');
    if (globalColData) {
      let globalCols = JSON.parse(globalColData) as any[];
      const idx = globalCols.findIndex(c => c.id === collectionId);
      if (idx !== -1) {
        globalCols[idx] = {
          ...globalCols[idx],
          mediaIds
        };
        localStorage.setItem('muvio_collections_list', JSON.stringify(globalCols));
      } else {
        // If not in global list yet, create it there!
        const key = getLocalCollectionsKey(userId);
        const data = localStorage.getItem(key);
        let collections: any[] = [];
        if (data) {
          collections = JSON.parse(data);
        }
        const col = collections.find(c => c.id === collectionId);
        if (col) {
          const randomImages = [
            "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
            "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=600",
            "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=600",
          ];
          const chosenCover = randomImages[Math.floor(Math.random() * randomImages.length)];
          const extraColItem = {
            id: collectionId,
            name: col.name,
            description: (col as any).description || 'A curated user playlist.',
            createdAt: col.createdAt || new Date().toISOString(),
            mediaIds: mediaIds,
            ownerId: userId,
            ownerUsername: 'me',
            isPublic: (col as any).isPublic !== undefined ? (col as any).isPublic : false,
            likesCount: (col as any).likesCount || 0,
            likedBy: (col as any).likedBy || [],
            coverUrl: (col as any).coverUrl || chosenCover
          };
          globalCols.push(extraColItem);
          localStorage.setItem('muvio_collections_list', JSON.stringify(globalCols));
        }
      }
    }
  } catch (err) {
    console.error('Failed to sync in updateCollectionItems:', err);
  }

  return true;
}

/**
 * --- REVIEWS & DISCUSSIONS SERVICES (Phase 5) ---
 */

export async function getReviewsForMedia(mediaId: string): Promise<MuvioReview[]> {
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'reviews');
      const q = query(colRef, where('mediaId', '==', mediaId));
      const snap = await getDocs(q);
      const results: MuvioReview[] = [];
      snap.forEach(docSnap => {
        results.push(docSnap.data() as MuvioReview);
      });
      return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (error) {
      console.warn('Firestore getReviewsForMedia failed, checking local storage:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalReviewsKey());
  const list: MuvioReview[] = raw ? JSON.parse(raw) : [];
  return list
    .filter(r => r.mediaId === mediaId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function saveReview(review: MuvioReview): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'reviews', review.id);
      await setDoc(docRef, review, { merge: true });
      return;
    } catch (error) {
      console.warn('Firestore saveReview failed, writing to local storage fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalReviewsKey());
  const list: MuvioReview[] = raw ? JSON.parse(raw) : [];
  const existingIdx = list.findIndex(r => r.id === review.id);
  if (existingIdx !== -1) {
    list[existingIdx] = review;
  } else {
    list.push(review);
  }
  localStorage.setItem(getLocalReviewsKey(), JSON.stringify(list));
}

export async function deleteReview(reviewId: string): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'reviews', reviewId));
      // Optionally find and delete associated comments
      const commQ = query(collection(db, 'comments'), where('reviewId', '==', reviewId));
      const snap = await getDocs(commQ);
      snap.forEach(async (docSnap) => {
        await deleteDoc(doc(db, 'comments', docSnap.id));
      });
      return;
    } catch (error) {
      console.warn('Firestore deleteReview failed, attempting local fallback:', error);
    }
  }

  // Fallback
  const rawReviews = localStorage.getItem(getLocalReviewsKey());
  const reviews: MuvioReview[] = rawReviews ? JSON.parse(rawReviews) : [];
  const updatedReviews = reviews.filter(r => r.id !== reviewId);
  localStorage.setItem(getLocalReviewsKey(), JSON.stringify(updatedReviews));

  const rawComments = localStorage.getItem(getLocalCommentsKey());
  const comments: MuvioComment[] = rawComments ? JSON.parse(rawComments) : [];
  const updatedComments = comments.filter(c => c.reviewId !== reviewId);
  localStorage.setItem(getLocalCommentsKey(), JSON.stringify(updatedComments));
}

export async function toggleLikeReview(
  userId: string,
  reviewId: string,
  authorId: string,
  mediaId: string,
  senderName: string
): Promise<string[]> {
  let likedBy: string[] = [];

  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'reviews', reviewId);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data() as MuvioReview;
        likedBy = data.likedBy ? [...data.likedBy] : [];
        const likedIdx = likedBy.indexOf(userId);

        if (likedIdx !== -1) {
          likedBy.splice(likedIdx, 1);
        } else {
          likedBy.push(userId);
          // Trigger notification write
          if (userId !== authorId) {
            await createNotification(
              authorId,
              userId,
              senderName,
              'LIKE_REVIEW',
              reviewId,
              mediaId,
              'liked your movie review.'
            );
          }
        }

        await setDoc(docRef, { likedBy }, { merge: true });
        return likedBy;
      }
    } catch (error) {
      console.warn('Firestore toggleLikeReview failed, checking local fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalReviewsKey());
  const list: MuvioReview[] = raw ? JSON.parse(raw) : [];
  const existing = list.find(r => r.id === reviewId);
  if (existing) {
    likedBy = existing.likedBy ? [...existing.likedBy] : [];
    const idx = likedBy.indexOf(userId);

    if (idx !== -1) {
      likedBy.splice(idx, 1);
    } else {
      likedBy.push(userId);
      if (userId !== authorId) {
        await createNotification(
          authorId,
          userId,
          senderName,
          'LIKE_REVIEW',
          reviewId,
          mediaId,
          'liked your movie review.'
        );
      }
    }

    existing.likedBy = likedBy;
    localStorage.setItem(getLocalReviewsKey(), JSON.stringify(list));
  }
  return likedBy;
}

/**
 * --- NESTED COMMENTS SERVICES ---
 */

export async function getCommentsForReview(reviewId: string): Promise<MuvioComment[]> {
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'comments');
      const q = query(colRef, where('reviewId', '==', reviewId));
      const snap = await getDocs(q);
      const results: MuvioComment[] = [];
      snap.forEach(docSnap => {
        results.push(docSnap.data() as MuvioComment);
      });
      return results.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    } catch (error) {
      console.warn('Firestore getCommentsForReview failed, local fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalCommentsKey());
  const list: MuvioComment[] = raw ? JSON.parse(raw) : [];
  return list
    .filter(c => c.reviewId === reviewId)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

export async function saveComment(
  comment: MuvioComment,
  mediaId: string,
  parentAuthorId?: string // review author ID or top comment author ID
): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'comments', comment.id);
      await setDoc(docRef, comment);

      // Trigger user notifications on save
      if (parentAuthorId && comment.userId !== parentAuthorId) {
        const notifType = comment.parentId ? 'REPLY_COMMENT' : 'COMMENT_REVIEW';
        const notifText = comment.parentId 
          ? `replied to your comment: "${comment.text.slice(0, 30)}..."` 
          : `commented on your review: "${comment.text.slice(0, 30)}..."`;

        await createNotification(
          parentAuthorId,
          comment.userId,
          comment.username,
          notifType,
          comment.reviewId,
          mediaId,
          notifText
        );
      }
      return;
    } catch (error) {
      console.warn('Firestore saveComment failed, writing local fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalCommentsKey());
  const list: MuvioComment[] = raw ? JSON.parse(raw) : [];
  list.push(comment);
  localStorage.setItem(getLocalCommentsKey(), JSON.stringify(list));

  // local Notification
  if (parentAuthorId && comment.userId !== parentAuthorId) {
    const notifType = comment.parentId ? 'REPLY_COMMENT' : 'COMMENT_REVIEW';
    const notifText = comment.parentId 
      ? `replied to your comment: "${comment.text.slice(0, 30)}..."` 
      : `commented on your review: "${comment.text.slice(0, 30)}..."`;

    await createNotification(
      parentAuthorId,
      comment.userId,
      comment.username,
      notifType,
      comment.reviewId,
      mediaId,
      notifText
    );
  }
}

export async function deleteComment(commentId: string): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'comments', commentId));
      // Delete child comments replies too
      const q = query(collection(db, 'comments'), where('parentId', '==', commentId));
      const snap = await getDocs(q);
      snap.forEach(async (docSnap) => {
        await deleteDoc(doc(db, 'comments', docSnap.id));
      });
      return;
    } catch (error) {
      console.warn('Firestore deleteComment failed, local fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalCommentsKey());
  const list: MuvioComment[] = raw ? JSON.parse(raw) : [];
  
  // Exclude current comment and any replies that had it as parentId
  const updated = list.filter(c => c.id !== commentId && c.parentId !== commentId);
  localStorage.setItem(getLocalCommentsKey(), JSON.stringify(updated));
}

export async function toggleLikeComment(userId: string, commentId: string): Promise<string[]> {
  let likedBy: string[] = [];

  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'comments', commentId);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const comment = snap.data() as MuvioComment;
        likedBy = comment.likedBy ? [...comment.likedBy] : [];
        const likedIdx = likedBy.indexOf(userId);

        if (likedIdx !== -1) {
          likedBy.splice(likedIdx, 1);
        } else {
          likedBy.push(userId);
        }

        await setDoc(docRef, { likedBy }, { merge: true });
        return likedBy;
      }
    } catch (error) {
      console.warn('Firestore toggleLikeComment failed, local fallback:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem(getLocalCommentsKey());
  const list: MuvioComment[] = raw ? JSON.parse(raw) : [];
  const existing = list.find(c => c.id === commentId);
  if (existing) {
    likedBy = existing.likedBy ? [...existing.likedBy] : [];
    const idx = likedBy.indexOf(userId);

    if (idx !== -1) {
      likedBy.splice(idx, 1);
    } else {
      likedBy.push(userId);
    }

    existing.likedBy = likedBy;
    localStorage.setItem(getLocalCommentsKey(), JSON.stringify(list));
  }
  return likedBy;
}

/**
 * --- GENERAL NOTIFICATION HARDENING SERVICE ---
 */

export async function createNotification(
  recipientId: string,
  senderId: string,
  senderName: string,
  type: 'LIKE_REVIEW' | 'COMMENT_REVIEW' | 'REPLY_COMMENT' | 'NEW_FOLLOWER' | 'CONTENT_RELEASE' | 'RELEASE_REMINDER' | 'DISCUSSION_REPLY' | 'SPACES_REPLY' | 'TRENDING_CONTENT',
  targetId: string,
  mediaId: string,
  text: string
): Promise<void> {
  if (recipientId === senderId && type !== 'CONTENT_RELEASE' && type !== 'RELEASE_REMINDER' && type !== 'TRENDING_CONTENT') return;

  const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
  const newNotif: MuvioNotification = {
    id: notifId,
    recipientId,
    senderId,
    senderName,
    type,
    targetId,
    mediaId,
    text,
    read: false,
    createdAt: new Date().toISOString()
  };

  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'notifications', notifId);
      await setDoc(docRef, newNotif);
      return;
    } catch (error) {
      console.warn('Firestore createNotification failed:', error);
    }
  }

  // Fallback
  const key = `muvio_notifications_${recipientId}`;
  const raw = localStorage.getItem(key);
  const list: MuvioNotification[] = raw ? JSON.parse(raw) : [];
  list.unshift(newNotif);
  localStorage.setItem(key, JSON.stringify(list));
}

export async function getNotifications(recipientId: string): Promise<MuvioNotification[]> {
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'notifications');
      const q = query(colRef, where('recipientId', '==', recipientId));
      const snap = await getDocs(q);
      const results: MuvioNotification[] = [];
      snap.forEach(docSnap => {
        results.push(docSnap.data() as MuvioNotification);
      });
      return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (e) {
      console.warn('Firestore getNotifications failed, resorting to localStorage:', e);
    }
  }

  const key = `muvio_notifications_${recipientId}`;
  const raw = localStorage.getItem(key);
  return raw ? JSON.parse(raw) : [];
}

export async function markAllNotificationsAsRead(recipientId: string): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'notifications');
      const q = query(colRef, where('recipientId', '==', recipientId), where('read', '==', false));
      const snap = await getDocs(q);
      snap.forEach(async (docSnap) => {
        const docRef = doc(db, 'notifications', docSnap.id);
        await setDoc(docRef, { read: true }, { merge: true });
      });
    } catch (e) {
      console.warn('Firestore markAllNotificationsAsRead failed, resorting to localStorage:', e);
    }
  }

  const key = `muvio_notifications_${recipientId}`;
  const raw = localStorage.getItem(key);
  if (raw) {
    const list: MuvioNotification[] = JSON.parse(raw);
    list.forEach(n => { n.read = true; });
    localStorage.setItem(key, JSON.stringify(list));
  }
}

export async function markNotificationAsRead(recipientId: string, notifId: string): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      const docRef = doc(db, 'notifications', notifId);
      await setDoc(docRef, { read: true }, { merge: true });
    } catch (e) {
      console.warn('Firestore markNotificationAsRead failed:', e);
    }
  }

  const key = `muvio_notifications_${recipientId}`;
  const raw = localStorage.getItem(key);
  if (raw) {
    const list: MuvioNotification[] = JSON.parse(raw);
    const item = list.find(n => n.id === notifId);
    if (item) {
      item.read = true;
    }
    localStorage.setItem(key, JSON.stringify(list));
  }
}

/**
 * --- PROFILE, FOLLOWER, AND SETTINGS MANAGEMENT (Phase 10) ---
 */

import { UserProfile } from './firebase';

export async function getReviewsForUser(userId: string): Promise<MuvioReview[]> {
  if (isFirebaseConfigured && db) {
    try {
      const colRef = collection(db, 'reviews');
      const q = query(colRef, where('userId', '==', userId));
      const snap = await getDocs(q);
      const results: MuvioReview[] = [];
      snap.forEach(docSnap => {
        results.push(docSnap.data() as MuvioReview);
      });
      return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (error) {
      console.warn('Firestore getReviewsForUser failed, using local storage fallback:', error);
    }
  }

  const raw = localStorage.getItem(getLocalReviewsKey());
  const list: MuvioReview[] = raw ? JSON.parse(raw) : [];
  return list
    .filter(r => r.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function getUserProfileByUsername(username: string): Promise<UserProfile | null> {
  const cleanUsername = username.trim().toLowerCase();
  
  if (isFirebaseConfigured && db) {
    try {
      const q = query(collection(db, 'users'), where('username', '==', cleanUsername));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs[0].data() as UserProfile;
      }
    } catch (error) {
      console.warn('Firestore getUserProfileByUsername failed:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem('muvio_mock_profiles');
  if (raw) {
    const list = JSON.parse(raw);
    const found = Object.values(list).find(
      (u: any) => u.username && u.username.toLowerCase() === cleanUsername
    );
    if (found) return found as UserProfile;
  }
  return null;
}

export async function getUserProfileByUserId(userId: string): Promise<UserProfile | null> {
  if (isFirebaseConfigured && db) {
    try {
      const docSnap = await getDoc(doc(db, 'users', userId));
      if (docSnap.exists()) {
        return docSnap.data() as UserProfile;
      }
    } catch (error) {
      console.warn('Firestore getUserProfileByUserId failed:', error);
    }
  }

  // Fallback
  const raw = localStorage.getItem('muvio_mock_profiles');
  if (raw) {
    const list = JSON.parse(raw);
    if (list[userId]) return list[userId] as UserProfile;
  }
  return null;
}

export async function updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<void> {
  if (isFirebaseConfigured && db) {
    try {
      const userRef = doc(db, 'users', userId);
      await setDoc(userRef, updates, { merge: true });
    } catch (error) {
      console.warn('Firestore updateUserProfile failed:', error);
    }
  }

  // Fallback list update
  const raw = localStorage.getItem('muvio_mock_profiles');
  const list = raw ? JSON.parse(raw) : {};
  const current = list[userId] || { uid: userId, name: 'Critic Space', username: `user_${userId}`, email: '', createdAt: new Date().toISOString(), role: 'user' };
  
  const updatedProfile = { ...current, ...updates };
  list[userId] = updatedProfile;
  localStorage.setItem('muvio_mock_profiles', JSON.stringify(list));

  // If this is the current active user, update their session too!
  const rawSession = localStorage.getItem('muvio_session_user');
  if (rawSession) {
    const sessionUser = JSON.parse(rawSession);
    if (sessionUser.uid === userId) {
      localStorage.setItem('muvio_session_user', JSON.stringify({ ...sessionUser, ...updates }));
      
      // Also update usernames index fallback if username changed
      if (updates.username && updates.username.toLowerCase() !== current.username.toLowerCase()) {
        const usernameIdxRaw = localStorage.getItem('muvio_mock_usernames') || '{}';
        const usernamesIdx = JSON.parse(usernameIdxRaw);
        delete usernamesIdx[current.username.toLowerCase()];
        usernamesIdx[updates.username.toLowerCase()] = userId;
        localStorage.setItem('muvio_mock_usernames', JSON.stringify(usernamesIdx));
      }
    }
  }
}

export async function toggleFollowUser(currentUserId: string, targetUserId: string): Promise<boolean> {
  if (currentUserId === targetUserId) return false;

  const currentUserProf = await getUserProfileByUserId(currentUserId);
  const targetUserProf = await getUserProfileByUserId(targetUserId);

  if (!currentUserProf || !targetUserProf) return false;

  const currentFollowing = (currentUserProf as any).following || [];
  const targetFollowers = (targetUserProf as any).followers || [];

  const isFollowing = currentFollowing.includes(targetUserId);
  let nextFollowing: string[];
  let nextFollowers: string[];

  if (isFollowing) {
    nextFollowing = currentFollowing.filter((id: string) => id !== targetUserId);
    nextFollowers = targetFollowers.filter((id: string) => id !== currentUserId);
  } else {
    nextFollowing = [...currentFollowing, targetUserId];
    nextFollowers = [...targetFollowers, currentUserId];

    // Notification of new follower
    await createNotification(
      targetUserId,
      currentUserId,
      currentUserProf.name || currentUserProf.username,
      'NEW_FOLLOWER',
      currentUserId,
      '',
      `started following your profile observatory blueprint.`
    );
  }

  await updateUserProfile(currentUserId, { following: nextFollowing } as any);
  await updateUserProfile(targetUserId, { followers: nextFollowers } as any);

  return !isFollowing;
}

// ─────────────────────────────────────────────
// INTERESTS (Firebase) — replaces localStorage
// ─────────────────────────────────────────────

export interface InterestRecord {
  mediaId: string;
  title: string;
  type: string;
  year: number;
  posterUrl: string;
  backdropUrl?: string;
  createdAt: number; // timestamp ms
}

/** Toggle interest for a media item — saves to Firestore */
export async function toggleInterest(
  userId: string,
  item: { id: string; title: string; type: string; year: number; posterUrl: string; backdropUrl?: string }
): Promise<boolean> {
  if (!isFirebaseConfigured || !db) return false;

  // 1. interests/{mediaId}/users/{userId} — for ranking
  const rankRef = doc(db, 'interests', item.id, 'users', userId);
  // 2. userInterests/{userId}/media/{mediaId} — for fast user lookup on refresh
  const userRef = doc(db, 'userInterests', userId, 'media', item.id);

  const snap = await getDoc(rankRef);
  if (snap.exists()) {
    // Remove from both
    await deleteDoc(rankRef);
    await deleteDoc(userRef);
    return false;
  } else {
    const record = {
      mediaId: item.id,
      title: item.title,
      type: item.type,
      year: item.year,
      posterUrl: item.posterUrl,
      backdropUrl: item.backdropUrl || '',
      createdAt: Date.now(),
    } as InterestRecord;
    await setDoc(rankRef, record);
    await setDoc(userRef, record);
    return true;
  }
}

/** Get all media IDs the user has marked as interested — fast lookup from userInterests */
export async function getUserInterests(userId: string): Promise<Record<string, boolean>> {
  if (!isFirebaseConfigured || !db) return {};
  try {
    const colRef = collection(db, 'userInterests', userId, 'media');
    const snap = await getDocs(colRef);
    const map: Record<string, boolean> = {};
    snap.docs.forEach(d => { map[d.id] = true; });
    return map;
  } catch (e) {
    console.warn('getUserInterests failed:', e);
    return {};
  }
}

/** Get most interested media sorted by count, filtered by time */
export async function getMostInterestedFromFirebase(
  filter: 'week' | 'month' | 'all'
): Promise<{ id: string; count: number; data: InterestRecord }[]> {
  if (!isFirebaseConfigured || !db) return [];
  try {
    const now = Date.now();
    const cutoff =
      filter === 'week'
        ? now - 7 * 24 * 60 * 60 * 1000
        : filter === 'month'
        ? now - 30 * 24 * 60 * 60 * 1000
        : 0;

    const interestsRef = collection(db, 'interests');
    const allMedia = await getDocs(interestsRef);

    const results: { id: string; count: number; data: InterestRecord }[] = [];

    await Promise.all(
      allMedia.docs.map(async (mediaDoc) => {
        const usersRef = collection(db, 'interests', mediaDoc.id, 'users');
        const usersSnap = await getDocs(
          cutoff > 0
            ? query(usersRef, where('createdAt', '>=', cutoff))
            : usersRef
        );
        if (usersSnap.size > 0) {
          // Use first user doc as representative data
          const firstDoc = usersSnap.docs[0].data() as InterestRecord;
          results.push({ id: mediaDoc.id, count: usersSnap.size, data: firstDoc });
        }
      })
    );

    return results.sort((a, b) => b.count - a.count).slice(0, 15);
  } catch (e) {
    console.warn('getMostInterestedFromFirebase failed:', e);
    return [];
  }
}
