// Muvio cinematic database TMDB API Client
import { isFirebaseConfigured } from './firebase';
import { getCustomDetailsBySlug, getCustomPublishedMedia } from './adminCatalog';

export const TMDB_BASE_URL = '/api/tmdb';
export const TMDB_IMAGE_URL = 'https://image.tmdb.org/t/p';

export function generateSlug(title: string): string {
  if (!title) return '';
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function isLiveTmdbFeedOn(): boolean {
  try {
    const raw = localStorage.getItem('muvio_general_settings');
    if (raw) {
      const parsed = JSON.parse(raw);
      return !!parsed.liveTmdbFeed;
    }
  } catch (e) {
    console.warn('Failed to parse muvio_general_settings', e);
  }
  return false;
}

export interface TMDBMediaItem {
  id: number;
  title: string;
  original_title?: string;
  name?: string;
  original_name?: string;
  media_type?: 'movie' | 'tv';
  backdrop_path: string | null;
  poster_path: string | null;
  overview: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  vote_count: number;
  genre_ids: number[];
  popularity: number;
}

export interface MuvioMedia {
  id: string; // "movie-123" or "tv-456"
  tmdbId: number;
  title: string;
  type: 'MOVIE' | 'SHOW' | 'ANIME';
  year: number;
  description: string;
  backdropUrl: string;
  posterUrl: string;
  ratingPercent: number; // e.g. 84 for 8.4 rating
  voteCount: number;
  releaseDate: string;
  statusBadge: string;
}

// Map TMDB item to Muvio standard structure
export function mapTMDBToMuvio(item: TMDBMediaItem, forcedType?: 'MOVIE' | 'SHOW' | 'ANIME'): MuvioMedia {
  const isMovie = forcedType 
    ? forcedType === 'MOVIE' 
    : item.media_type === 'movie' || !!item.release_date;

  const isAnime = forcedType === 'ANIME' || 
    (item.genre_ids && item.genre_ids.includes(16) && ['ja', 'ja-JP'].includes((item as any).original_language || ''));

  let type: 'MOVIE' | 'SHOW' | 'ANIME' = 'MOVIE';
  if (isAnime) {
    type = 'ANIME';
  } else if (isMovie) {
    type = 'MOVIE';
  } else {
    type = 'SHOW';
  }

  const title = item.title || item.name || item.original_title || item.original_name || 'Untitled masterwork';
  
  // Year extract
  const dateStr = item.release_date || item.first_air_date || '';
  const year = dateStr ? new Date(dateStr).getFullYear() : 2025;

  const backdropUrl = item.backdrop_path 
    ? `${TMDB_IMAGE_URL}/w1280${item.backdrop_path}` 
    : 'https://images.unsplash.com/photo-1547483238-f400e65ccd56?auto=format&fit=crop&q=80&w=1200';

  const posterUrl = item.poster_path 
    ? `${TMDB_IMAGE_URL}/w500${item.poster_path}` 
    : 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&q=80&w=400';

  const ratingPercent = Math.round((item.vote_average || 7.0) * 10);

  // Status badge logic
  let statusBadge = 'Trending';
  if (item.popularity > 150) {
    statusBadge = 'Blockbuster';
  } else if (item.vote_average > 8.0) {
    statusBadge = 'Must Watch';
  } else if (type === 'ANIME') {
    statusBadge = 'Sub/Dub';
  } else if (type === 'SHOW') {
    statusBadge = 'New Seasons';
  } else {
    statusBadge = 'Standard Catalog';
  }

  return {
    id: `${type.toLowerCase()}-${item.id}`,
    tmdbId: item.id,
    title,
    type,
    year,
    description: item.overview || 'No overview available',
    backdropUrl,
    posterUrl,
    ratingPercent,
    voteCount: item.vote_count || 42,
    releaseDate: dateStr || '2025-01-01',
    statusBadge
  };
}

// Fetch helper through our secure server proxy
async function fetchFromTMDB(endpoint: string, queryParams: Record<string, string> = {}, bypassLiveCheck = false): Promise<any> {
  if (!bypassLiveCheck && !isLiveTmdbFeedOn()) {
    throw new Error('TMDB Live Feed is deactivated in settings.');
  }
  const searchParams = new URLSearchParams();
  Object.entries(queryParams).forEach(([key, val]) => {
    searchParams.append(key, val);
  });
  
  const queryString = searchParams.toString();
  const url = `${TMDB_BASE_URL}${endpoint}${queryString ? '?' + queryString : ''}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`TMDB Catalog fetch error (${response.status}): Failed to retrieve movie profiles.`);
  }
  return response.json();
}

/**
 * FETCH FEATURED CINEMATIC SLIDER CONTENT (All Trending + Highly rated hits)
 */
export async function getFeaturedSliderContent(): Promise<MuvioMedia[]> {
  const customFeatured = getCustomPublishedMedia().filter(m => {
    const catalog = JSON.parse(localStorage.getItem('muvio_admin_catalog') || '[]');
    const matched = catalog.find((c: any) => c.id === m.id);
    return matched && matched.isFeatured;
  });

  if (!isLiveTmdbFeedOn()) {
    return customFeatured;
  }

  try {
    const data = await fetchFromTMDB('/trending/all/week');
    const results = (data.results || []) as TMDBMediaItem[];
    // Filter backdrops to look grand
    const tmdbMapped = results
      .filter(item => item.backdrop_path && item.overview)
      .slice(0, 10)
      .map(item => mapTMDBToMuvio(item));

    return [...customFeatured, ...tmdbMapped];
  } catch (error) {
    console.warn('TMDB Featured error, no live results available:', error);
    return customFeatured;
  }
}

/**
 * FETCH CATEGORIES: ALL CATALOG, MOVIES, SHOWS, ANIME
 */
export async function getContentByCategory(category: 'ALL' | 'MOVIE' | 'SHOW' | 'ANIME', page = 1): Promise<MuvioMedia[]> {
  // Aggregate only admin/custom-published media; live TMDB results are appended below
  const customPublished = getCustomPublishedMedia();

  let combinedMedia = [...customPublished];

  if (isLiveTmdbFeedOn()) {
    try {
      let endpoint = '/trending/all/week';
      const params: Record<string, string> = { page: String(page) };

      if (category === 'MOVIE') {
        endpoint = '/discover/movie';
        params.sort_by = 'popularity.desc';
      } else if (category === 'SHOW') {
        endpoint = '/discover/tv';
        params.sort_by = 'popularity.desc';
      } else if (category === 'ANIME') {
        endpoint = '/discover/tv';
        params.with_genres = '16'; // Animation
        params.original_language = 'ja'; // Japanese audio matches Anime
        params.sort_by = 'popularity.desc';
      }

      const data = await fetchFromTMDB(endpoint, params);
      const results = (data.results || []) as TMDBMediaItem[];
      const tmdbItems = results.map(item => mapTMDBToMuvio(item, category === 'ALL' ? undefined : category));
      
      combinedMedia = [...combinedMedia, ...tmdbItems];
    } catch (error) {
      console.warn(`TMDB ${category} fetch failed inside getContentByCategory.`, error);
    }
  }

  // Deduplicate items on key ID
  const seenIds = new Set<string>();
  const uniqueItems = combinedMedia.filter(item => {
    if (!item || !item.id) return false;
    if (seenIds.has(item.id)) return false;
    seenIds.add(item.id);
    return true;
  });

  // Filter based on selected category tab
  const filteredItems = uniqueItems.filter(item => 
    category === 'ALL' || item.type === category
  );

  // Sort by newest first (newest releaseDate first, falling back to year)
  filteredItems.sort((a, b) => {
    const dateA = a.releaseDate || `${a.year}-01-01`;
    const dateB = b.releaseDate || `${b.year}-01-01`;
    return dateB.localeCompare(dateA);
  });

  return filteredItems;
}

/**
 * MOST INTERESTED CONTENT (Ranked)
 * Filter pills: 'week' | 'month' | 'all'
 */
export async function getMostInterested(filter: 'week' | 'month' | 'all'): Promise<MuvioMedia[]> {
  if (!isLiveTmdbFeedOn()) {
    const custom = getCustomPublishedMedia();
    return [...custom].sort((a, b) => (b.ratingPercent || 0) - (a.ratingPercent || 0)).slice(0, 10);
  }

  try {
    let endpoint = '/movie/top_rated';
    const params: Record<string, string> = {};

    if (filter === 'week') {
      endpoint = '/trending/all/day';
    } else if (filter === 'month') {
      endpoint = '/trending/all/week';
    } else {
      endpoint = '/movie/top_rated';
    }

    const data = await fetchFromTMDB(endpoint, params);
    const results = (data.results || []) as TMDBMediaItem[];
    // Take top 10 items
    return results.slice(0, 10).map(item => mapTMDBToMuvio(item));
  } catch (error) {
    console.warn('TMDB top rated/trending fetch failed in getMostInterested:', error);
    const custom = getCustomPublishedMedia();
    return [...custom].sort((a, b) => (b.ratingPercent || 0) - (a.ratingPercent || 0)).slice(0, 10);
  }
}

/**
 * TALK OF THE TOWN (Megaphone icon list)
 */
export async function getTalkOfTheTown(): Promise<MuvioMedia[]> {
  if (!isLiveTmdbFeedOn()) {
    const custom = getCustomPublishedMedia();
    return [...custom].slice(0, 5);
  }

  try {
    const data = await fetchFromTMDB('/trending/all/day');
    const results = (data.results || []) as TMDBMediaItem[];
    return results.slice(0, 5).map(item => mapTMDBToMuvio(item));
  } catch (error) {
    console.warn('TMDB trending fetch failed in getTalkOfTheTown:', error);
    const custom = getCustomPublishedMedia();
    return [...custom].slice(0, 5);
  }
}

export interface MuvioCastMember {
  id: number;
  name: string;
  character: string;
  profileUrl: string;
}

export interface MuvioCrewMember {
  id: number;
  name: string;
  role: string;
  profileUrl: string;
}

export interface MuvioCompany {
  id: number;
  name: string;
  logoUrl: string | null;
}

export interface RichMediaDetails {
  media: MuvioMedia;
  genres: string[];
  duration: string;
  directedBy: string;
  country: string;
  language: string;
  ageRating: string;
  trailerUrl: string | null;
  productionCompanies: MuvioCompany[];
  cast: MuvioCastMember[];
  crew: MuvioCrewMember[];
  downloads?: { quality: string; url: string; enabled: boolean; size?: string }[];
  downloadsEnabled?: boolean;
  ticketLinks?: { platform: string; url: string; type?: string; domain?: string }[];
  dataSource?: 'DATABASE' | 'LIVE_TMDB';
  streamingEnabled?: boolean;
  streamingLinks?: { platform: string; embedCode: string; enabled: boolean }[];
  streamingSeasons?: {
    seasonNumber: number;
    episodes: {
      episodeNumber: number;
      title: string;
      platforms: { platform: string; embedCode: string; enabled: boolean }[];
    }[];
  }[];
}

/**
 * FETCH DETAILED MEDIA RECORD WITH CREDIT LINKS AND TRAILERS
 */
export async function getRichMediaDetails(type: 'movie' | 'tv', id: number, bypassLiveCheck = false, forceLiveTMDB = false): Promise<RichMediaDetails> {
  const idStr = `${type === 'movie' ? 'movie' : 'tv'}-${id}`;
  if (!forceLiveTMDB) {
    const customOverride = getCustomDetailsBySlug(idStr);
    if (customOverride) {
      return customOverride;
    }
  }

  try {
    const [detailData, creditsData, videosData] = await Promise.all([
      fetchFromTMDB(`/${type}/${id}`, {}, bypassLiveCheck),
      fetchFromTMDB(`/${type}/${id}/credits`, {}, bypassLiveCheck).catch(() => ({ cast: [], crew: [] })),
      fetchFromTMDB(`/${type}/${id}/videos`, {}, bypassLiveCheck).catch(() => ({ results: [] }))
    ]);

    const media = mapTMDBToMuvio(detailData, type === 'movie' ? 'MOVIE' : 'SHOW');
    
    // Genres list
    const genres = (detailData.genres || []).map((g: any) => g.name);

    // Duration extraction
    let duration = 'N/A';
    if (type === 'movie' && detailData.runtime) {
      const hrs = Math.floor(detailData.runtime / 60);
      const mins = detailData.runtime % 60;
      duration = hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m`;
    } else if (detailData.episode_run_time && detailData.episode_run_time.length > 0) {
      duration = `${detailData.episode_run_time[0]}m per Ep`;
    } else if (detailData.number_of_seasons) {
      duration = `${detailData.number_of_seasons} Seasons`;
    } else {
      duration = '2h 15m';
    }

    // Directed By
    const directors = (creditsData.crew || [])
      .filter((member: any) => member.job === 'Director' || member.job === 'Series Director')
      .map((member: any) => member.name);
    const directedBy = directors.length > 0 ? directors.join(', ') : 'Unknown';

    // Country
    const country = detailData.production_countries && detailData.production_countries.length > 0
      ? detailData.production_countries[0].name
      : 'United States';

    // Language
    const language = detailData.spoken_languages && detailData.spoken_languages.length > 0
      ? detailData.spoken_languages[0].english_name
      : detailData.original_language?.toUpperCase() || 'English';

    // Age Rating
    let ageRating = '';
    if (type === 'movie') {
      const usRelease = (detailData.release_dates?.results || [])
        .find((r: any) => r.iso_3166_1 === 'US');
      if (usRelease && usRelease.release_dates && usRelease.release_dates.length > 0) {
        ageRating = usRelease.release_dates[0].certification;
      }
    } else if (detailData.content_ratings?.results) {
      const usRating = (detailData.content_ratings.results)
        .find((r: any) => r.iso_3166_1 === 'US');
      if (usRating) {
        ageRating = usRating.rating;
      }
    }
    if (!ageRating) ageRating = 'PG-13';

    // Youtube Video Url Lookup
    let trailerUrl: string | null = null;
    const trailerVideo = (videosData.results || []).find(
      (v: any) => v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser')
    );
    if (trailerVideo) {
      trailerUrl = `https://www.youtube.com/embed/${trailerVideo.key}`;
    }

    // Production Companies list
    const productionCompanies = (detailData.production_companies || []).slice(0, 6).map((c: any) => ({
      id: c.id,
      name: c.name,
      logoUrl: c.logo_path ? `${TMDB_IMAGE_URL}/w185${c.logo_path}` : null
    }));

    // Cast members
    const cast = (creditsData.cast || []).slice(0, 12).map((m: any) => ({
      id: m.id,
      name: m.name,
      character: m.character || 'Supporting Role',
      profileUrl: m.profile_path 
        ? `${TMDB_IMAGE_URL}/w185${m.profile_path}` 
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120'
    }));

    // Crew members
    const crew = (creditsData.crew || [])
      .filter((m: any) => ['Director', 'Producer', 'Screenplay', 'Writer', 'Composer', 'Editor'].includes(m.job))
      .slice(0, 12)
      .map((m: any) => ({
        id: m.id,
        name: m.name,
        role: m.job,
        profileUrl: m.profile_path 
          ? `${TMDB_IMAGE_URL}/w185${m.profile_path}` 
          : 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&q=80&w=120'
      }));

    return {
      media,
      genres: genres.length > 0 ? genres : [media.type, 'Science Fiction', 'Adventure'],
      duration,
      directedBy,
      country,
      language,
      ageRating,
      trailerUrl,
      productionCompanies,
      cast,
      crew
    };
  } catch (error) {
    console.warn(`TMDB details endpoint failed for ${type}-${id}, resolving custom fallback:`, error);
    return getFallbackRichDetails(`${type.toLowerCase()}-${id}`);
  }
}

/**
 * QUICK UTILITY TO FETCH MEDIA BASICS BY SLUG
 */
export async function getMediaDetails(type: 'movie' | 'tv', id: number): Promise<MuvioMedia | null> {
  try {
    const data = await fetchFromTMDB(`/${type}/${id}`);
    return mapTMDBToMuvio(data, type === 'movie' ? 'MOVIE' : 'SHOW');
  } catch (err) {
    console.warn(`getMediaDetails failed for ${type}-${id}, fetching fallbacks:`, err);
    const fallbackRich = getFallbackRichDetails(`${type.toLowerCase()}-${id}`);
    return fallbackRich.media;
  }
}

/**
 * DETAILED MOCK GENERATOR FOR COMPREHENSIVE OFFLINE VIEWER SUPPORT
 */
export function getFallbackRichDetails(slug: string): RichMediaDetails {
  const customOverride = getCustomDetailsBySlug(slug);
  if (customOverride) {
    return customOverride;
  }

  const foundMedia = {
    id: slug,
    tmdbId: 99999,
    title: slug.split('-').join(' ').toUpperCase() || 'CINEMATIC SELECTION',
    type: slug.startsWith('tv') ? 'SHOW' : slug.startsWith('anime') ? 'ANIME' : 'MOVIE',
    year: 2025,
    description: 'No overview available',
    backdropUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1200',
    posterUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=400',
    ratingPercent: 86,
    voteCount: 4280,
    releaseDate: '2025-05-15',
    statusBadge: 'Trending'
  } as MuvioMedia;

  const mockCast: MuvioCastMember[] = [
    { id: 1, name: 'Oscar Issac', character: 'Paul Atreides', profileUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120' },
    { id: 2, name: 'Zendaya Coleman', character: 'Chani Kynes', profileUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120' },
    { id: 3, name: 'Cillian Murphy', character: 'Robert Oppenheimer', profileUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=120' },
    { id: 4, name: 'Florence Pugh', character: 'Princess Irulan', profileUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=120' },
    { id: 5, name: 'Timothée Chalamet', character: 'Feyd-Rautha', profileUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=120' }
  ];

  const mockCrew: MuvioCrewMember[] = [
    { id: 11, name: 'Denis Villeneuve', role: 'Director', profileUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=120' },
    { id: 12, name: 'Hans Zimmer', role: 'Composer', profileUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=120' },
    { id: 13, name: 'Greig Fraser', role: 'Director of Photography', profileUrl: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=crop&q=80&w=120' }
  ];

  const mockCompanies: MuvioCompany[] = [
    { id: 31, name: 'Legendary Pictures', logoUrl: null },
    { id: 32, name: 'Warner Bros. Pictures', logoUrl: null },
    { id: 33, name: 'Syncopy Films', logoUrl: null }
  ];

  let genres = ['Action', 'Sci-Fi', 'Adventure'];
  let duration = '2h 35m';
  let directedBy = 'Denis Villeneuve';
  let ageRating = 'PG-13';
  let trailerUrl = 'https://www.youtube.com/embed/dQw4w9WgXcQ'; // Rick astley as general fun trailer!

  if (slug.includes('101') || slug === 'dunes-part-three') {
    genres = ['Drama', 'Sci-Fi', 'Adventure'];
    duration = '2h 55m';
    directedBy = 'Denis Villeneuve';
    ageRating = 'PG-13';
    trailerUrl = 'https://www.youtube.com/embed/Way9Dexny3w';
  } else if (slug.includes('102') || slug === 'interstellar-infinity') {
    genres = ['Science Fiction', 'Adventure', 'Mystery'];
    duration = '2h 49m';
    directedBy = 'Christopher Nolan';
    ageRating = 'PG-13';
    trailerUrl = 'https://www.youtube.com/embed/zSWdZVtXT7E';
  } else if (slug.includes('201') || slug === 'neon-genesis-archives') {
    genres = ['Animation', 'Psychological', 'Sci-Fi'];
    duration = '26 Episodes';
    directedBy = 'Hideaki Anno';
    ageRating = 'TV-MA';
  } else if (slug.includes('103') || slug === 'blade-runner-2049') {
    genres = ['Drama', 'Sci-Fi', 'Mystery'];
    duration = '2h 44m';
    directedBy = 'Denis Villeneuve';
    ageRating = 'R';
  } else if (slug.includes('104') || slug === 'stranger-things') {
    genres = ['Drama', 'Sci-Fi', 'Mystery'];
    duration = '4 Seasons';
    directedBy = 'The Duffer Brothers';
    ageRating = 'TV-14';
  } else if (slug.includes('202') || slug === 'cyberpunk-edgerunners') {
    genres = ['Animation', 'Sci-Fi', 'Action'];
    duration = '10 Episodes';
    directedBy = 'Hiroyuki Imaishi';
    ageRating = 'TV-MA';
  } else if (slug.includes('105') || slug === 'inception') {
    genres = ['Action', 'Sci-Fi', 'Adventure'];
    duration = '2h 28m';
    directedBy = 'Christopher Nolan';
    ageRating = 'PG-13';
  }

  return {
    media: foundMedia,
    genres,
    duration,
    directedBy,
    country: 'United States',
    language: 'English',
    ageRating,
    trailerUrl,
    productionCompanies: mockCompanies,
    cast: mockCast,
    crew: mockCrew
  };
}

/**
 * DYNAMIC SEARCH CATALOG (Combining TMDB searching API and local rich backups)
 */
export async function searchCatalog(
  queryText: string, 
  typeFilter: 'ALL' | 'MOVIE' | 'SHOW' | 'ANIME' = 'ALL',
  forceLiveTmdb = false
): Promise<MuvioMedia[]> {
  const cleanQ = queryText.trim().toLowerCase();
  if (!cleanQ) return [];

  if (!forceLiveTmdb && !isLiveTmdbFeedOn()) {
    const custom = getCustomPublishedMedia();
    return custom.filter(item => {
      const matchQuery = item.title.toLowerCase().includes(cleanQ) || item.description.toLowerCase().includes(cleanQ);
      
      let matchType = true;
      if (typeFilter === 'ANIME') {
        matchType = item.type === 'ANIME';
      } else if (typeFilter !== 'ALL') {
        matchType = item.type === typeFilter;
      }
      return matchQuery && matchType;
    });
  }

  try {
    let endpoint = '/search/multi';
    const params: Record<string, string> = { query: queryText };
    
    if (typeFilter === 'MOVIE') {
      endpoint = '/search/movie';
    } else if (typeFilter === 'SHOW' || typeFilter === 'ANIME') {
      endpoint = '/search/tv';
    }

    const data = await fetchFromTMDB(endpoint, params, forceLiveTmdb);
    const results = (data.results || []) as TMDBMediaItem[];
    let mapped = results.map(item => mapTMDBToMuvio(item));

    if (typeFilter === 'ANIME') {
      mapped = mapped.filter(item => item.type === 'ANIME' || item.statusBadge === 'Sub/Dub');
    } else if (typeFilter !== 'ALL') {
      mapped = mapped.filter(item => item.type === typeFilter);
    }

    if (mapped.length > 0) return mapped;
  } catch (error) {
    console.warn(`TMDB search failed for query "${queryText}", falling back to local indexing.`, error);
  }

  if (forceLiveTmdb) return [];

  // No live TMDB results and nothing in the admin-published catalog matched
  return [];
}
