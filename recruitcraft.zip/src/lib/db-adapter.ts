import { 
  getSettingValue as getSettingValueFB,
  updateSettingValue as updateSettingValueFB,
  checkUsernameAvailable as checkUsernameAvailableFB,
  UserProfile,
  isFirebaseConfigured
} from './firebase';

import {
  getWatchedStatus as getWatchedStatusFB,
  toggleWatchedStatus as toggleWatchedStatusFB,
  getUserCollections as getUserCollectionsFB,
  createCollection as createCollectionFB,
  updateCollectionItems as updateCollectionItemsFB,
  getReviewsForMedia as getReviewsForMediaFB,
  saveReview as saveReviewFB,
  deleteReview as deleteReviewFB,
  toggleLikeReview as toggleLikeReviewFB,
  getCommentsForReview as getCommentsForReviewFB,
  saveComment as saveCommentFB,
  deleteComment as deleteCommentFB,
  toggleLikeComment as toggleLikeCommentFB,
  createNotification as createNotificationFB,
  getNotifications as getNotificationsFB,
  markAllNotificationsAsRead as markAllNotificationsAsReadFB,
  markNotificationAsRead as markNotificationAsReadFB,
  getReviewsForUser as getReviewsForUserFB,
  getUserProfileByUserId as getUserProfileByUserIdFB,
  getUserProfileByUsername as getUserProfileByUsernameFB,
  updateUserProfile as updateUserProfileFB,
  toggleFollowUser as toggleFollowUserFB,
  getUserWatchedItems as getUserWatchedItemsFB
} from './userInteractions';

import {
  getAdminCatalog as getAdminCatalogFB,
  saveCatalogItem as saveCatalogItemFB,
  deleteCatalogItem as deleteCatalogItemFB,
  bulkApproveItems as bulkApproveItemsFB,
  bulkRejectItems as bulkRejectItemsFB,
  getAutoFetchSettings as getAutoFetchSettingsFB,
  saveAutoFetchSettings as saveAutoFetchSettingsFB,
  getFetchLogs as getFetchLogsFB,
  addFetchLog as addFetchLogFB,
  MuvioCatalogItem,
  TMDBFetchLog
} from './adminCatalog';

import { MuvioReview, MuvioComment, UserWatched } from '../types';

// Helper to determine the database mode
export type DatabaseMode = 'firestore' | 'mysql';

const DB_MODE_KEY = 'muvio_database_mode_cached';

export function getDatabaseMode(): DatabaseMode {
  if (typeof window === 'undefined') return 'firestore';
  return (localStorage.getItem(DB_MODE_KEY) as DatabaseMode) || 'firestore';
}

export async function setDatabaseMode(mode: DatabaseMode): Promise<boolean> {
  if (typeof window !== 'undefined') {
    localStorage.setItem(DB_MODE_KEY, mode);
  }
  try {
    const res = await fetch('/api/db/set-mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode })
    });
    const data = await res.json();
    return !!data.success;
  } catch (err) {
    console.error('Failed to sync database mode on server:', err);
    return false;
  }
}

// Fetch configuration mode from backend on start
export async function syncDatabaseModeWithServer(): Promise<DatabaseMode> {
  try {
    const res = await fetch('/api/db/get-mode');
    const data = await res.json();
    if (data && data.mode) {
      if (typeof window !== 'undefined') {
        localStorage.setItem(DB_MODE_KEY, data.mode);
      }
      return data.mode;
    }
  } catch (err) {
    console.warn('Network offline or proxy failed during database mode synchronization:', err);
  }
  return getDatabaseMode();
}

/**
 * REST API Helper for MySQL Database routing
 */
async function callMySQLAPI(method: string, payload: any = {}): Promise<any> {
  const response = await fetch(`/api/db/mysql/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(errText || `MySQL Database API error [${response.status}]`);
  }
  return response.json();
}

/**
 * DUAL DATABASE LAYER ACTIONS ROUTER
 */

export async function getSettingValue(key: string, defaultValue: any): Promise<any> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getSettingValue', { key, defaultValue });
      return data.value;
    } catch (e) {
      console.warn('MySQL getSettingValue failed, falling back to local fallback:', e);
      return getSettingValueFB(key, defaultValue);
    }
  }
  return getSettingValueFB(key, defaultValue);
}

export async function updateSettingValue(key: string, value: any): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('updateSettingValue', { key, value });
      return;
    } catch (e) {
      console.warn('MySQL updateSettingValue failed, writing to Firestore/fallback:', e);
    }
  }
  return updateSettingValueFB(key, value);
}

export async function checkUsernameAvailable(username: string): Promise<boolean> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('checkUsernameAvailable', { username });
      return data.available;
    } catch (e) {
      console.warn('MySQL checkUsernameAvailable failed, fallback to firebase:', e);
      return checkUsernameAvailableFB(username);
    }
  }
  return checkUsernameAvailableFB(username);
}

export async function getUserProfileByUserId(userId: string): Promise<UserProfile | null> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getUserProfileByUserId', { userId });
      return data.profile;
    } catch (e) {
      console.warn('MySQL getUserProfileByUserId failed, fallback to firebase:', e);
      return getUserProfileByUserIdFB(userId);
    }
  }
  return getUserProfileByUserIdFB(userId);
}

export async function getUserProfileByUsername(username: string): Promise<UserProfile | null> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getUserProfileByUsername', { username });
      return data.profile;
    } catch (e) {
      console.warn('MySQL getUserProfileByUsername failed, fallback to firebase:', e);
      return getUserProfileByUsernameFB(username);
    }
  }
  return getUserProfileByUsernameFB(username);
}

export async function updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('updateUserProfile', { userId, updates });
      return;
    } catch (e) {
      console.warn('MySQL updateUserProfile failed, fallback to firebase:', e);
    }
  }
  return updateUserProfileFB(userId, updates);
}

export async function toggleFollowUser(currentUserId: string, targetUserId: string): Promise<boolean> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('toggleFollowUser', { currentUserId, targetUserId });
      return data.following;
    } catch (e) {
      console.warn('MySQL toggleFollowUser failed, fallback to firebase:', e);
      return toggleFollowUserFB(currentUserId, targetUserId);
    }
  }
  return toggleFollowUserFB(currentUserId, targetUserId);
}

export async function getWatchedStatus(userId: string, mediaId: string): Promise<any | null> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getWatchedStatus', { userId, mediaId });
      return data.status;
    } catch (e) {
      console.warn('MySQL getWatchedStatus failed, fallback to firebase:', e);
      return getWatchedStatusFB(userId, mediaId);
    }
  }
  return getWatchedStatusFB(userId, mediaId);
}

export async function toggleWatchedStatus(
  userId: string,
  mediaId: string,
  title: string,
  type: string,
  posterUrl: string
): Promise<boolean> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('toggleWatchedStatus', { userId, mediaId, title, type, posterUrl });
      return data.watched;
    } catch (e) {
      console.warn('MySQL toggleWatchedStatus failed, fallback to firebase:', e);
      return toggleWatchedStatusFB(userId, mediaId, title, type, posterUrl);
    }
  }
  return toggleWatchedStatusFB(userId, mediaId, title, type, posterUrl);
}

export async function getUserWatchedItems(userId: string): Promise<UserWatched[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getUserWatchedItems', { userId });
      return (data.watchedList || []).map((r: any) => ({
        id: r.mediaId,
        title: r.title,
        type: r.type,
        posterUrl: r.posterUrl,
        watched: r.watched,
        watchedAt: r.watchedAt
      }));
    } catch (e) {
      console.warn('MySQL getUserWatchedItems failed, fallback to firebase:', e);
      return getUserWatchedItemsFB(userId);
    }
  }
  return getUserWatchedItemsFB(userId);
}

export async function getUserCollections(userId: string): Promise<any[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getUserCollections', { userId });
      return data.collections;
    } catch (e) {
      console.warn('MySQL getUserCollections failed, fallback to firebase:', e);
      return getUserCollectionsFB(userId);
    }
  }
  return getUserCollectionsFB(userId);
}

export async function createCollection(userId: string, name: string): Promise<any> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('createCollection', { userId, name });
      return data.collection;
    } catch (e) {
      console.warn('MySQL createCollection failed, fallback to firebase:', e);
      return createCollectionFB(userId, name);
    }
  }
  return createCollectionFB(userId, name);
}

export async function updateCollectionItems(
  userId: string,
  collectionId: string,
  mediaIds: string[]
): Promise<boolean> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('updateCollectionItems', { userId, collectionId, mediaIds });
      return data.success;
    } catch (e) {
      console.warn('MySQL updateCollectionItems failed, fallback to firebase:', e);
      return updateCollectionItemsFB(userId, collectionId, mediaIds);
    }
  }
  return updateCollectionItemsFB(userId, collectionId, mediaIds);
}

export async function getReviewsForMedia(mediaId: string): Promise<MuvioReview[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getReviewsForMedia', { mediaId });
      return data.reviews;
    } catch (e) {
      console.warn('MySQL getReviewsForMedia failed, fallback to firebase:', e);
      return getReviewsForMediaFB(mediaId);
    }
  }
  return getReviewsForMediaFB(mediaId);
}

export async function saveReview(review: MuvioReview): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('saveReview', { review });
      return;
    } catch (e) {
      console.warn('MySQL saveReview failed, fallback to firebase:', e);
    }
  }
  return saveReviewFB(review);
}

export async function deleteReview(reviewId: string): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('deleteReview', { reviewId });
      return;
    } catch (e) {
      console.warn('MySQL deleteReview failed, fallback to firebase:', e);
    }
  }
  return deleteReviewFB(reviewId);
}

export async function toggleLikeReview(
  userId: string,
  reviewId: string,
  authorId: string,
  mediaId: string,
  senderName: string
): Promise<string[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('toggleLikeReview', { userId, reviewId, authorId, mediaId, senderName });
      return data.likedBy;
    } catch (e) {
      console.warn('MySQL toggleLikeReview failed, fallback to firebase:', e);
      return toggleLikeReviewFB(userId, reviewId, authorId, mediaId, senderName);
    }
  }
  return toggleLikeReviewFB(userId, reviewId, authorId, mediaId, senderName);
}

export async function getCommentsForReview(reviewId: string): Promise<MuvioComment[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getCommentsForReview', { reviewId });
      return data.comments;
    } catch (e) {
      console.warn('MySQL getCommentsForReview failed, fallback to firebase:', e);
      return getCommentsForReviewFB(reviewId);
    }
  }
  return getCommentsForReviewFB(reviewId);
}

export async function saveComment(
  comment: MuvioComment,
  mediaId: string,
  parentAuthorId?: string
): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('saveComment', { comment, mediaId, parentAuthorId });
      return;
    } catch (e) {
      console.warn('MySQL saveComment failed, fallback to firebase:', e);
    }
  }
  return saveCommentFB(comment, mediaId, parentAuthorId);
}

export async function deleteComment(commentId: string): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('deleteComment', { commentId });
      return;
    } catch (e) {
      console.warn('MySQL deleteComment failed, fallback to firebase:', e);
    }
  }
  return deleteCommentFB(commentId);
}

export async function toggleLikeComment(userId: string, commentId: string): Promise<string[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('toggleLikeComment', { userId, commentId });
      return data.likedBy;
    } catch (e) {
      console.warn('MySQL toggleLikeComment failed, fallback to firebase:', e);
      return toggleLikeCommentFB(userId, commentId);
    }
  }
  return toggleLikeCommentFB(userId, commentId);
}

export async function createNotification(
  recipientId: string,
  senderId: string,
  senderName: string,
  type: string,
  targetId: string,
  mediaId: string,
  text: string
): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('createNotification', { recipientId, senderId, senderName, type, targetId, mediaId, text });
      return;
    } catch (e) {
      console.warn('MySQL createNotification failed, fallback to firebase:', e);
    }
  }
  return createNotificationFB(recipientId, senderId, senderName, type as any, targetId, mediaId, text);
}

export async function getNotifications(recipientId: string): Promise<any[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getNotifications', { recipientId });
      return data.notifications;
    } catch (e) {
      console.warn('MySQL getNotifications failed, fallback to firebase:', e);
      return getNotificationsFB(recipientId);
    }
  }
  return getNotificationsFB(recipientId);
}

export async function markAllNotificationsAsRead(recipientId: string): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('markAllNotificationsAsRead', { recipientId });
      return;
    } catch (e) {
      console.warn('MySQL markAllNotificationsAsRead failed, fallback to firebase:', e);
    }
  }
  return markAllNotificationsAsReadFB(recipientId);
}

export async function markNotificationAsRead(recipientId: string, notifId: string): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('markNotificationAsRead', { recipientId, notifId });
      return;
    } catch (e) {
      console.warn('MySQL markNotificationAsRead failed, fallback to firebase:', e);
    }
  }
  return markNotificationAsReadFB(recipientId, notifId);
}

export async function getReviewsForUser(userId: string): Promise<MuvioReview[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getReviewsForUser', { userId });
      return data.reviews;
    } catch (e) {
      console.warn('MySQL getReviewsForUser failed, fallback to firebase:', e);
      return getReviewsForUserFB(userId);
    }
  }
  return getReviewsForUserFB(userId);
}

export async function getAdminCatalog(): Promise<MuvioCatalogItem[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getAdminCatalog');
      return data.catalog;
    } catch (e) {
      console.warn('MySQL getAdminCatalog failed, fallback to firebase:', e);
      return getAdminCatalogFB();
    }
  }
  return getAdminCatalogFB();
}

export async function saveCatalogItem(item: MuvioCatalogItem): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('saveCatalogItem', { item });
      return;
    } catch (e) {
      console.warn('MySQL saveCatalogItem failed, fallback to firebase:', e);
    }
  }
  return saveCatalogItemFB(item);
}

export async function deleteCatalogItem(id: string): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('deleteCatalogItem', { id });
      return;
    } catch (e) {
      console.warn('MySQL deleteCatalogItem failed, fallback to firebase:', e);
    }
  }
  return deleteCatalogItemFB(id);
}

export async function bulkApproveItems(ids: string[]): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('bulkApproveItems', { ids });
      return;
    } catch (e) {
      console.warn('MySQL bulkApproveItems failed, fallback to firebase:', e);
    }
  }
  return bulkApproveItemsFB(ids);
}

export async function bulkRejectItems(ids: string[]): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('bulkRejectItems', { ids });
      return;
    } catch (e) {
      console.warn('MySQL bulkRejectItems failed, fallback to firebase:', e);
    }
  }
  return bulkRejectItemsFB(ids);
}

export async function getAutoFetchSettings(): Promise<any> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getAutoFetchSettings');
      return data.settings;
    } catch (e) {
      console.warn('MySQL getAutoFetchSettings failed, fallback to firebase:', e);
      return getAutoFetchSettingsFB();
    }
  }
  return getAutoFetchSettingsFB();
}

export async function saveAutoFetchSettings(settings: any): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('saveAutoFetchSettings', { settings });
      return;
    } catch (e) {
      console.warn('MySQL saveAutoFetchSettings failed, fallback to firebase:', e);
    }
  }
  return saveAutoFetchSettingsFB(settings);
}

export async function getFetchLogs(): Promise<TMDBFetchLog[]> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      const data = await callMySQLAPI('getFetchLogs');
      return data.logs;
    } catch (e) {
      console.warn('MySQL getFetchLogs failed, fallback to firebase:', e);
      return getFetchLogsFB();
    }
  }
  return getFetchLogsFB();
}

export async function addFetchLog(log: TMDBFetchLog): Promise<void> {
  const mode = getDatabaseMode();
  if (mode === 'mysql') {
    try {
      await callMySQLAPI('addFetchLog', { log });
      return;
    } catch (e) {
      console.warn('MySQL addFetchLog failed, fallback to firebase:', e);
    }
  }
  return addFetchLogFB(log);
}
