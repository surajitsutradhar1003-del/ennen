import { isFirebaseConfigured, db } from './firebase';
import { MuvioMedia, RichMediaDetails, MuvioCompany, MuvioCastMember, MuvioCrewMember, generateSlug } from './tmdb';
import { collection as fsCollection, getDocs, setDoc, deleteDoc, doc } from 'firebase/firestore';

export interface MuvioCatalogItem {
  id: string;
  media: MuvioMedia;
  genres: string[];
  duration: string;
  directedBy: string;
  country: string;
  language: string;
  ageRating: string;
  trailerUrl: string | null;
  productionCompanies: MuvioCompany[];
  cast: MuvioCastMember[];
  crew: MuvioCrewMember[];
  status: 'Published' | 'Pending' | 'Draft';
  source: 'Manual' | 'TMDB Import' | 'Daily Auto-Fetch';
  dateAdded: string;
  downloads: { quality: string; url: string; enabled: boolean; size?: string }[];
  downloadsEnabled?: boolean;
  ticketLinks: { platform: string; url: string; type?: string; domain?: string }[];
  isFeatured: boolean;
  isMuvioSelect: boolean;
  dataSource?: 'DATABASE' | 'LIVE_TMDB';
  streamingEnabled?: boolean;
  streamingLinks?: { platform: string; embedCode: string; enabled: boolean }[];
  streamingSeasons?: {
    seasonNumber: number;
    episodes: {
      episodeNumber: number;
      title: string;
      platforms: { platform: string; embedCode: string; enabled: boolean }[];
    }[];
  }[];
}

export interface TMDBFetchLog {
  id: string;
  date: string;
  itemsFetched: number;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  details: string;
}

export interface AutoFetchSettings {
  enabled: boolean;
  frequency: 'Daily' | 'Weekly';
  lastRun: string | null;
}

const STORAGE_KEY = 'muvio_admin_catalog';
const LOGS_KEY = 'muvio_admin_fetch_logs';
const SETTINGS_KEY = 'muvio_admin_fetch_settings';
const CATALOG_COLLECTION = 'catalog';
const DEMO_IDS = ['movie-101', 'movie-102', 'movie-103', 'anime-201', 'anime-202', 'show-104'];

// ─── FIREBASE SYNC (background) ───────────────────────────────────────────────

// Load from Firestore and cache in localStorage
export async function syncCatalogFromFirebase(): Promise<void> {
  if (!isFirebaseConfigured || !db) return;
  try {
    const snap = await getDocs(fsCollection(db, CATALOG_COLLECTION));
    const items: MuvioCatalogItem[] = [];
    snap.forEach(d => items.push(d.data() as MuvioCatalogItem));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.warn('Firestore syncCatalogFromFirebase failed:', e);
  }
}

// Save single item to Firestore in background
async function pushItemToFirebase(item: MuvioCatalogItem): Promise<void> {
  if (!isFirebaseConfigured || !db) return;
  try {
    await setDoc(doc(db, CATALOG_COLLECTION, item.id), item);
  } catch (e) {
    console.warn('Firestore pushItemToFirebase failed:', e);
  }
}

// Delete item from Firestore in background
async function deleteItemFromFirebase(id: string): Promise<void> {
  if (!isFirebaseConfigured || !db) return;
  try {
    await deleteDoc(doc(db, CATALOG_COLLECTION, id));
  } catch (e) {
    console.warn('Firestore deleteItemFromFirebase failed:', e);
  }
}

// ─── SYNC ACCESSORS ──────────────────────────────────────────────────────────

export function getAdminCatalog(): MuvioCatalogItem[] {
  const cached = localStorage.getItem(STORAGE_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      // Clear old demo data if present
      const hasDemoData = parsed.some((item: MuvioCatalogItem) => DEMO_IDS.includes(item.id));
      if (hasDemoData) {
        localStorage.removeItem(STORAGE_KEY);
        return [];
      }
      return parsed;
    } catch (e) {
      return [];
    }
  }
  return [];
}

export function saveAdminCatalog(items: MuvioCatalogItem[]): void {
  const filtered = items.filter(i => !DEMO_IDS.includes(i.id));
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  // Sync to Firebase in background
  filtered.forEach(item => pushItemToFirebase(item));
}

export function saveCatalogItem(item: MuvioCatalogItem): void {
  const catalog = getAdminCatalog();
  const idx = catalog.findIndex(c => c.id === item.id);
  if (idx !== -1) {
    catalog[idx] = item;
  } else {
    catalog.push(item);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(catalog));
  // Push to Firebase in background
  pushItemToFirebase(item);
}

export function deleteCatalogItem(id: string): void {
  const catalog = getAdminCatalog();
  const filtered = catalog.filter(c => c.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  // Delete from Firebase in background
  deleteItemFromFirebase(id);
}

export function getCatalogItemById(id: string): MuvioCatalogItem | null {
  const catalog = getAdminCatalog();
  return catalog.find(item => item.id === id) || null;
}

export function getCustomDetailsBySlug(slug: string): RichMediaDetails | null {
  const catalog = getAdminCatalog();
  const found = catalog.find(item => {
    const slugLower = slug.toLowerCase();
    const cleanId = item.id.toLowerCase();
    const tmdbIdStr = String(item.media.tmdbId);
    return (
      cleanId === slugLower ||
      generateSlug(item.media.title) === slugLower ||
      tmdbIdStr === slugLower ||
      cleanId.endsWith(`-${slugLower}`)
    ) && item.status === 'Published';
  });
  if (found) {
    return {
      media: found.media,
      genres: found.genres,
      duration: found.duration,
      directedBy: found.directedBy,
      country: found.country,
      language: found.language,
      ageRating: found.ageRating,
      trailerUrl: found.trailerUrl,
      productionCompanies: found.productionCompanies,
      cast: found.cast,
      crew: found.crew,
      downloads: found.downloads,
      downloadsEnabled: found.downloadsEnabled,
      ticketLinks: found.ticketLinks,
      dataSource: found.dataSource,
      streamingEnabled: found.streamingEnabled,
      streamingLinks: found.streamingLinks,
      streamingSeasons: found.streamingSeasons
    };
  }
  return null;
}

export function getCustomPublishedMedia(): MuvioMedia[] {
  const catalog = getAdminCatalog();
  return catalog
    .filter(item => item.status === 'Published')
    .map(item => item.media);
}

export function bulkApproveItems(ids: string[]): void {
  const catalog = getAdminCatalog();
  const updated = catalog.map(item => {
    if (ids.includes(item.id)) {
      return {
        ...item,
        status: 'Published' as const,
        media: {
          ...item.media,
          statusBadge: item.media.statusBadge === 'Pending' ? 'Published' : item.media.statusBadge
        }
      };
    }
    return item;
  });
  saveAdminCatalog(updated);
}

export function bulkRejectItems(ids: string[]): void {
  const catalog = getAdminCatalog();
  const updated = catalog.map(item => {
    if (ids.includes(item.id)) {
      return { ...item, status: 'Draft' as const };
    }
    return item;
  });
  saveAdminCatalog(updated);
}

// ─── AUTO FETCH SETTINGS & LOGS ──────────────────────────────────────────────

export function getAutoFetchSettings(): AutoFetchSettings {
  const cached = localStorage.getItem(SETTINGS_KEY);
  if (cached) {
    try { return JSON.parse(cached); } catch (e) {}
  }
  const defaultSettings: AutoFetchSettings = {
    enabled: false,
    frequency: 'Daily',
    lastRun: null
  };
  saveAutoFetchSettings(defaultSettings);
  return defaultSettings;
}

export function saveAutoFetchSettings(settings: AutoFetchSettings): void {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function getFetchLogs(): TMDBFetchLog[] {
  const cached = localStorage.getItem(LOGS_KEY);
  if (cached) {
    try { return JSON.parse(cached); } catch (e) {}
  }
  return [];
}

export function saveFetchLogs(logs: TMDBFetchLog[]): void {
  localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
}

export function addFetchLog(log: TMDBFetchLog): void {
  const logs = getFetchLogs();
  logs.unshift(log);
  saveFetchLogs(logs.slice(0, 50));
}
